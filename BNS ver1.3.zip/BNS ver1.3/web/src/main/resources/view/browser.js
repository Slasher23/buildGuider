const opn = require('opn');

console.log('React App Environment:', process.env.REACT_APP_ENVIRONMENT);

opn(process.env.APP_URL, { app: process.env.DEFAULT_BROWSER });
