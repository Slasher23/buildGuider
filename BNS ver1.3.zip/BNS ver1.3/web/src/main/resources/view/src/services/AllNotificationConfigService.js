import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';
import NotifStore from './../stores/NotifStore';

class AllNotificationConfigServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH + '/allNotificationConfig';
  }

  postAllConfig(data) {
    const path = this.url + '/save';

    let body = {
      bnsToken: NotifStore.getBNSCif().bnsToken,
      request: data
    }

    return RestService.post(path, body)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const AllNotificationConfigService = new AllNotificationConfigServiceClass();

export default AllNotificationConfigService;
