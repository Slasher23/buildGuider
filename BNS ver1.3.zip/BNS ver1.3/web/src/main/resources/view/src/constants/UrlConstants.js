import { ConfigConstants } from './ConfigConstants';

export const UrlConstants = {
    HOME_PAGE: ConfigConstants.CONTEXT_PATH + '/register',
    ERROR_PAGE: '#/error',
};