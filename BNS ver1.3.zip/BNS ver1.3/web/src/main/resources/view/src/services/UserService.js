import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class UserServiceClass {
  constructor(bpkenn) {
    this.url = ConfigConstants.API_PATH + '/person';
  }

  getUserInfo() {
    return RestService.post(this.url)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const UserService = new UserServiceClass(ConfigConstants.DEFAULT_BPKENN);

export default UserService;
