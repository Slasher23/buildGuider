import React, { Component } from 'react';
import NotifActions from './../actions/NotifActions';
import NotifStore from './../stores/NotifStore';
import NotifPageLayout from './../components/NotifPageLayout';
import Modal from './../components/Modal';

class NotifPage extends Component {

    constructor() {
        super();
        this._onChange = this._onChange.bind(this);

        this.state = {
            data: NotifStore.getStoreData()
        };
    }

    componentDidMount() {
        NotifStore.addChangeListener(this._onChange);
        NotifActions.validateEmail();
    }

    componentWillUnmount() {
        NotifStore.removeChangeListener(this._onChange);
    }

    _onChange() {
        this.setState({
            data: NotifStore.getStoreData()
        });
    }

    render() {

        if (this.state.data.isLoading) {
            return (
                <div>
                    <button type="button modal-trigger" id="noEmailErrorButton" className="hidden" data-toggle="modal" data-target="#noEmailErrorModal">No Email Error Layer</button>
                    <Modal id="noEmailErrorModal" type="error" headerText={this.state.data.staticTexts.modalHeading_Notification} message={this.state.data.staticTexts.modalButton_NoEmail_Text1} message2={this.state.data.staticTexts.modalButton_NoEmail_Text2} okayText={this.state.data.staticTexts.modalButton_Close} okayURL="back" />
                </div>
            );
        } else {

            return (
                <div>
                    <NotifPageLayout data={this.state.data}/>
                    <button type="button modal-trigger" id="noEmailErrorButton" className="hidden" data-toggle="modal" data-target="#noEmailErrorModal">No Email Error Layer</button>
                    <Modal id="noEmailErrorModal" type="error" headerText={this.state.data.staticTexts.modalHeading_Notification} message={this.state.data.staticTexts.modalButton_NoEmail_Text1} message2={this.state.data.staticTexts.modalButton_NoEmail_Text2} okayText={this.state.data.staticTexts.modalButton_Close} okayURL="back" />
                </div>
            );
        }

    }
}

export default NotifPage;