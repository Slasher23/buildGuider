import React from 'react';
import ReactDOM from 'react-dom';
import Overview from './pages/Overview';
import './styles.css';

// Render application
ReactDOM.render(<Overview />, document.getElementById('root'));
