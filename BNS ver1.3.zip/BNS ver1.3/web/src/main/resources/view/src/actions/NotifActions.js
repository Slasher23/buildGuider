import AppDispatcher from '../dispatcher/AppDispatcher';
import { NotifConstants } from '../constants/NotifConstants';

class NotifActionsClass {

    readBNSCif() {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.READ_BNS_CIF
        });
    }

    validateEmail() {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.VALIDATE_EMAIL
        });
    }

    toggleAllNotif() {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.TOGGLE_ALL_NOTIF,
        });
    }

    clickAllConfig() {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.CLICK_ALL_CONFIG,
        });
    }

    cancelAllConfig() {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.CANCEL_ALL_CONFIG,
        });
    }

    saveAllConfig(data) {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.SAVE_ALL_CONFIG,
            data: data,
        });
    }

    toggleAgreementNotif(notifObj) {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.TOGGLE_AGREEMENT_NOTIF,
            data: notifObj,
        });
    }

    clickAgreementStiff(notifObj) {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.CLICK_AGREEMENT_STIFF,
            data: notifObj,
        });
    }

    cancelNotifConfig(notifObj) {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.CANCEL_NOTIF_CONFIG,
            data: notifObj,
        });
    }

    saveNotifConfig(notifObj, notifConfig) {
        AppDispatcher.handleViewAction({
            actionType: NotifConstants.SAVE_NOTIF_CONFIG,
            notifObj: notifObj,
            notifConfig: notifConfig,
        });
    }
}

const NotifActions = new NotifActionsClass();

export default NotifActions;
