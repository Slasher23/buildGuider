import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class TranslationServiceClass {
  constructor(language) {
    this.url = ConfigConstants.API_PATH + '/translatedTexts';
    this._language = language;
  }

  get language() {
    return this._language;
  }

  set language(language) {
    this._language = language ? language : this._language;
  }

  getTexts() {
    const data = {
      lang: this.language,
    };
    const path = this.url;
    return RestService.post(path, data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const TranslationService = new TranslationServiceClass(ConfigConstants.DEFAULT_LANGUAGE);

export default TranslationService;
