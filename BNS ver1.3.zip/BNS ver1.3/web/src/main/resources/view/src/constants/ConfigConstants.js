let contextPath = '/cobest/bns';
let apiPath = './api';
if (process.env.REACT_APP_ENVIRONMENT === 'development') {
  apiPath = 'http://localhost:8090' + contextPath + '/api'; // Development
  contextPath = '';
}
if (process.env.REACT_APP_ENVIRONMENT === 'staging') {
  apiPath = 'http://wasapd05.zit.commerzbank.com:29581' + contextPath + '/api'; // Staging
  contextPath = '';
}
if (process.env.REACT_APP_ENVIRONMENT === 'production') {
  apiPath = 'http://wasapd05.zit.commerzbank.com:29581' + contextPath + '/api'; // Production
  contextPath = '';
}

export const ConfigConstants = {
  CONTEXT_PATH: contextPath,
  API_PATH: apiPath,
  DEFAULT_LANGUAGE: 'DE',
  DEFAULT_USER: 1,
  DEFAULT_BPKENN: 'BPKENNTEST',
};
