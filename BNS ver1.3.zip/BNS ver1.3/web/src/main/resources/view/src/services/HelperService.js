import _ from 'lodash';

class HelperClass {
  hasClass(element, className) {
    if (element.classList) {
      return element.classList.contains(className);
    } else {
      return !!element.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
    }
  }

  addClass(element, className) {
    if (element.classList) {
      element.classList.add(className);
    } else if (!this.hasClass(element, className)) {
      element.className += ' ' + className;
    }
  }

  removeClass(element, className) {
    if (element.classList) {
      element.classList.remove(className);
    } else if (this.hasClass(element, className)) {
      const reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
      element.className = element.className.replace(reg, ' ');
    }
  }

  getParameterByName(name) {
    const url = window.location.href;
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

  parseStr(str, variablesObj) {
    const match = str.match(/\{[\w]+\}/g);
    match &&
      match.forEach(state => {
        const regex = new RegExp(state, 'g');
        const stateItem = state.split(/{|}/g)[1];
        const replacementStr = _.isObject(variablesObj) ? variablesObj[stateItem] : variablesObj;
        str = str.replace(regex, replacementStr);
      });
    return str;
  }

  scrollToTop() {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

  detectScroll() {
    const fixedEl = document.querySelector('.App-content.fixed');
    const fixedElStyle = window.getComputedStyle(fixedEl);
    const scrollableEl = document.querySelector('.App-content.scrollable');
    scrollableEl.style.top = _.parseInt(this.getAbsoluteHeight(fixedEl)) - _.parseInt(fixedElStyle.paddingTop) + 'px';
    this.scrollToTop();
    const headerEl = document.querySelector('.header.row');
    const scrollEl = window;
    let scrollTop = 0;
    let hasScrolled = false;
    scrollEl.addEventListener('scroll', () => {
      scrollTop = scrollEl.pageYOffset !== undefined
        ? scrollEl.pageYOffset
        : (document.documentElement || document.body.parentNode || document.body).scrollTop;
      if (scrollTop > 0) {
        if (!hasScrolled) {
          this.addClass(headerEl, 'fixed');
          hasScrolled = true;
        }
      } else {
        if (hasScrolled) {
          this.removeClass(headerEl, 'fixed');
          hasScrolled = false;
        }
      }
    });
  }

  getAbsoluteHeight(element) {
    element = typeof element === 'string' ? document.querySelector(element) : element;
    const styles = window.getComputedStyle(element);
    const margin = parseFloat(styles.marginTop) + parseFloat(styles.marginBottom);
    return element.offsetHeight + margin;
  }

  clickElement(element) {
    const activeElement = typeof element === 'string' ? document.querySelector(element) : element;
    if (activeElement) {
      activeElement.click();
    } else {
      setTimeout(() => {
        this.clickElement(element);
      }, 100);
    }
  }

  removeElement(element) {
    element = typeof element === 'string' ? document.querySelector(element) : element;
    if (element) {
      element.parentNode.removeChild(element);
    }
  }

  setCookie(cname, cvalue, exdays) {
    const d = new Date();
    exdays = exdays ? exdays : 1;
    d.setTime(d.getTime() + exdays * 24 * 60 * 60);
    const expires = 'expires=' + d.toUTCString();
    document.cookie = cname + '=' + cvalue + ';' + expires + ';path=/';
  }

  getCookie(cname) {
    const name = cname + '=';
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) === 0) {
        return c.substring(name.length, c.length);
      }
    }
    return null;
  }

  storeValue(key, value) {
    if (window.localStorage) {
      window.localStorage.setItem(key, value);
    } else {
      this.setCookie(key, value);
    }
  }

  getStoredValue(key) {
    let value = window.localStorage ? window.localStorage.getItem(key) : this.getCookie(key);
    return value;
  }

  removeStoredValue(key) {
    if (window.localStorage) {
      window.localStorage.removeItem(key);
    } else {
      this.setCookie(key, '', -1);
    }
  }

  postDataRedirect(dataName, dataValue, location) {
    let form = document.createElement('form');

    form.method = 'POST';
    form.action = location;

    if (dataValue.constructor === Array && dataName.constructor === Array) {
      for (let i = 0; i < dataValue.length; i++) {
        let element = document.createElement('input');
        element.type = 'hidden';
        element.name = dataName[i];
        element.value = dataValue[i];
        form.appendChild(element);
      }
    } else {
      let element = document.createElement('input');
      element.type = 'hidden';
      element.name = dataName;
      element.value = dataValue;
      form.appendChild(element);
    }

    document.body.appendChild(form);

    form.submit();
    this.removeElement(form);
  }

  initSmoothScrolling() {
    var duration = 400;

    var pageUrl = window.location.hash ? stripHash(window.location.href) : window.location.href;

    directLinkHijacking();

    function directLinkHijacking() {
      [].slice.call(document.querySelectorAll('a')).filter(isInPageLink).forEach(function(a) {
        a.addEventListener('click', onClick, false);
      });

      function onClick(e) {
        e.stopPropagation();
        e.preventDefault();

        var element = document.getElementById(e.target.hash.substring(1));
        removeClass(element, 'hidden');

        jump(e.target.hash, {
          duration: duration,
        });
      }
    }

    function isInPageLink(n) {
      return n.tagName.toLowerCase() === 'a' && n.hash.length > 0 && stripHash(n.href) === pageUrl;
    }

    function stripHash(url) {
      return url.slice(0, url.lastIndexOf('#'));
    }

    function removeClass(element, className) {
      if (element.classList) {
        element.classList.remove(className);
      } else if (this.hasClass(element, className)) {
        var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
        element.className = element.className.replace(reg, ' ');
      }
    }

    function jump(target, options) {
      var start = window.pageYOffset,
        opt = {
          duration: options.duration,
          offset: options.offset || 0,
          callback: options.callback,
          easing: options.easing || easeInOutQuad,
        },
        distance = typeof target === 'string'
          ? opt.offset + document.querySelector(target).getBoundingClientRect().top
          : target,
        duration = typeof opt.duration === 'function' ? opt.duration(distance) : opt.duration,
        timeStart,
        timeElapsed;

      requestAnimationFrame(function(time) {
        timeStart = time;
        loop(time);
      });

      function loop(time) {
        timeElapsed = time - timeStart;

        window.scrollTo(0, opt.easing(timeElapsed, start, distance, duration));

        if (timeElapsed < duration) requestAnimationFrame(loop);
        else end();
      }

      function end() {
        window.scrollTo(0, start + distance);

        if (typeof opt.callback === 'function') opt.callback();
      }

      function easeInOutQuad(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
      }
    }
  }
}

const HelperService = new HelperClass();

export default HelperService;
