package com.commerzbank.gdk.bns.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.PersonCustomDAO;
import com.commerzbank.gdk.bns.model.Person;

/**
 * DAO Implementation Class to get the Person
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.01		ZE2SARO 	InitialVersion
 * 09/02/2018       1.02        ZE2MACL    Removed throws Exception
 *          </pre>
 */
@Repository
public class PersonDAOImpl implements PersonCustomDAO {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Retrieves the Person records using a given BPKENN
     * 
     * @param bpkenn String of Person Record to set
     * @return Person Get Person using BPKENN
     */
    @Override
    public Person getPerson(String bpkenn) {

        Person person = null;
        TypedQuery<Person> query = this.entityManager.createQuery("FROM Person WHERE bpkenn = :bpkenn ", Person.class)
                        .setParameter("bpkenn", bpkenn);
        if (query.getResultList().size() != 0)
            person = query.setMaxResults(1).getSingleResult();

        return person;
    }

}
