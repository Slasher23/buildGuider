package com.commerzbank.gdk.bns.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;

import com.commerzbank.gdk.bns.conf.security.AuthenticatedUser;

/**
 * <description>
 * 
 * @author ze2rubi
 * @since 12.10.2017
 * @version 1.04
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/10/2017	     1.01       ZE2RUBI    Initial Version
 * 27/10/2017		 1.02		ZE2BAUL	   Added the processRunID for ZSL use only
 * 05/02/2018        1.03       ZE2FUEN    Removed processRunID in ZSL parse request
 * 20/02/2018        1.04       ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
public class Tokenizer {

    private static final Pattern userIdPattern = Pattern.compile("<userid>(.*?)<");
    private static final Pattern requesterPattern = Pattern.compile("<requester>(.*?)<");
    private static final Pattern userTypePattern = Pattern.compile("<useridType>(.*?)<");

    private String cobaUserTicket;
    private String cobaActivityID;
    private String cobaApplicationTicket;
    private String bpkenn;
    private String userId;
    private String userType;
    private String role;
    private String databackpack;
    private boolean error;
    private String errorMessage;

    public Tokenizer() {
    }

    public static Tokenizer getUserToken(Authentication authentication) {
        AuthenticatedUser user = (AuthenticatedUser) authentication.getPrincipal();
        return user.getToken();
    }

    public static Tokenizer parseZSLRequest(HttpServletRequest request) {
        Tokenizer token = new Tokenizer();
        token.setUserId("");

        return token;
    }

    public static Tokenizer parseAuthHeader(String authHeader) {
        Tokenizer token = new Tokenizer();
        boolean hasMissingData = false;
        token.setUserId("");

        if (Objects.nonNull(authHeader)) {

            Matcher userTypeMatcher = userTypePattern.matcher(authHeader);

            if (userTypeMatcher.find()) {
                token.setUserType(userTypeMatcher.group(1));
            } else {
                hasMissingData = true;
            }

            Matcher userIdMatcher = userIdPattern.matcher(authHeader);

            if (userIdMatcher.find()) {
                String userId = userIdMatcher.group(1);

                String[] userIdArray = userId.split(";");

                if (userIdArray.length > 1) {
                    token.setBpkenn(userIdArray[1]);

                    if (token.getUserType().toUpperCase().equals("COMSIID")) {
                        token.setUserId(userIdArray[0]);
                    }

                } else {
                    hasMissingData = true;
                }

            } else {
                hasMissingData = true;
            }

            Matcher requesterMatcher = requesterPattern.matcher(authHeader);

            if (requesterMatcher.find()) {
                token.setRole(requesterMatcher.group(1));
            } else {
                hasMissingData = true;
            }

        } else {
            hasMissingData = true;
        }

        token.setError(hasMissingData);

        return token;
    }

    public static boolean validator(Tokenizer token) {
        boolean validToken = false;

        if (Objects.nonNull(token) && !token.getError()) {
            validToken = true;
        }

        return validToken;
    }

    /**
     * Returns the value of cobaUserTicket
     *
     * @return the cobaUserTicket
     */
    public String getCobaUserTicket() {
        return cobaUserTicket;
    }

    /**
     * Sets the value of cobaUserTicket
     *
     * @param cobaUserTicket the cobaUserTicket to set
     */
    public void setCobaUserTicket(String cobaUserTicket) {
        this.cobaUserTicket = cobaUserTicket;
    }

    /**
     * Returns the value of cobaActivityID
     *
     * @return the cobaActivityID
     */
    public String getCobaActivityID() {
        return cobaActivityID;
    }

    /**
     * Sets the value of cobaActivityID
     *
     * @param cobaActivityID the cobaActivityID to set
     */
    public void setCobaActivityID(String cobaActivityID) {
        this.cobaActivityID = cobaActivityID;
    }

    /**
     * Returns the value of cobaApplicationTicket
     *
     * @return the cobaApplicationTicket
     */
    public String getCobaApplicationTicket() {
        return cobaApplicationTicket;
    }

    /**
     * Sets the value of cobaApplicationTicket
     *
     * @param cobaApplicationTicket the cobaApplicationTicket to set
     */
    public void setCobaApplicationTicket(String cobaApplicationTicket) {
        this.cobaApplicationTicket = cobaApplicationTicket;
    }

    /**
     * Gets the value of userId
     * 
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of userId
     * 
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the value of userType
     * 
     * @return the userType
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Sets the value of userType
     * 
     * @param userType the userType to set
     */
    public void setUserType(String userType) {
        this.userType = userType;
    }

    /**
     * Gets the value of role
     * 
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of role
     * 
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Gets the value of databackpack
     * 
     * @return the databackpack
     */
    public String getDatabackpack() {
        return databackpack;
    }

    /**
     * Sets the value of databackpack
     * 
     * @param databackpack the databackpack to set
     */
    public void setDatabackpack(String databackpack) {
        this.databackpack = databackpack;
    }

    /**
     * Gets the value of error
     *
     * @return the error
     */
    public Boolean getError() {
        return error;
    }

    /**
     * Sets the value of error
     *
     * @param error the error to set
     */
    public void setError(Boolean error) {
        this.error = error;
    }

    /**
     * Gets the value of errorMessage
     *
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of errorMessage
     *
     * @param errorMessage the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getBpkenn() {
        return bpkenn;
    }

    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Returns the String representation of Tokenizer Model
     * 
     * @return String String representation of Tokenizer Model
     */
    @Override
    public String toString() {
        return "Tokenizer [cobaUserTicket=" + cobaUserTicket + ", cobaActivityID=" + cobaActivityID
                + ", cobaApplicationTicket=" + cobaApplicationTicket + ", bpkenn=" + bpkenn + ", userId=" + userId
                + ", userType=" + userType + ", role=" + role + ", databackpack=" + databackpack + ", error=" + error
                + ", errorMessage=" + errorMessage + "]";
    }

}
