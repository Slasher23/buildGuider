package com.commerzbank.gdk.bns.model;

/**
 * Model Class for Event Type
 * This class is used for logging events
 * 
 * @since 04/08/2017
 * @author ZE2RUBI
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.01       ZE2RUBI    Initial Version
 * </pre>
 */

public class EventType {
	
	private String type;
	
	private String description;
	
	private String objectType;
	
	/**
	 * Returns the value of Event Type
	 * 
	 * @return String Event Type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Sets the value of Event Type
	 * 
	 * @param type String Event Type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Returns the value of Event Description
	 * 
	 * @return String Event Description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the value of Event Description
	 * 
	 * @param description String Event Description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Returns the String representation of Event Type Model
	 * 
	 * @return String String representation of Event Type Model
	 */
	@Override
	public String toString() {
		return "EventType [type= " + type + " , description=" + description + "]";
	}

	/**
	 * @return the objectType
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * @param objectType the objectType to set
	 */
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

}

