package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Databackpack
 * 
 * @since 21/12/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2BUEN    Initial Version
 * 08/02/2018        1.01       ZE2BUEN    Added isValid field
 * </pre>
 */

@XmlRootElement
public class Databackpack {

	private List<Customer> customerList;

	private List<Agreement> agreementList;

	private Person person;

	private NotificationConfigPerson notificationConfigPerson;

	private List<Email> emailList;
	
	private boolean isValid; 

	/**
	 * Returns the List of Customers
	 * 
	 * @return List List of Customers
	 */
	public List<Customer> getCustomerList() {
		return customerList;
	}

	/**
	 * Sets the List of Customers
	 * 
	 * @param customerList
	 *            List List of Customers to set
	 */
	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}

	/**
	 * Returns the List of Agreements
	 * 
	 * @return List List of Agreements
	 */
	public List<Agreement> getAgreementList() {
		return agreementList;
	}

	/**
	 * Sets the List of Agreements
	 * 
	 * @param agreementList
	 *            List List of Agreements to set
	 */
	public void setAgreementList(List<Agreement> agreementList) {
		this.agreementList = agreementList;
	}

	/**
	 * Returns the Person
	 * 
	 * @return Person Person
	 */
	public Person getPerson() {
		return person;
	}

	/**
	 * Sets the Person
	 * 
	 * @param person
	 *            Person Person to set
	 */
	public void setPerson(Person person) {
		this.person = person;
	}

	/**
	 * Returns the Notification Configuration Person
	 * 
	 * @return NotificationConfigPerson Notification Configuration Person
	 */
	public NotificationConfigPerson getNotificationConfigPerson() {
		return notificationConfigPerson;
	}

	/**
	 * Sets the Notification Configuration Person
	 * 
	 * @param notificationConfigPerson
	 *            NotificationConfigPerson Notification Configuration Person to
	 *            set
	 */
	public void setNotificationConfigPerson(NotificationConfigPerson notificationConfigPerson) {
		this.notificationConfigPerson = notificationConfigPerson;
	}

	/**
	 * Returns the List of Emails
	 * 
	 * @return List List of Emails
	 */
	public List<Email> getEmailList() {
		return emailList;
	}

	/**
	 * Sets the List of Emails
	 * 
	 * @param emailList
	 *            List List of Emails to set
	 */
	public void setEmailList(List<Email> emailList) {
		this.emailList = emailList;
	}
	
	/**
	 * Returns isValid flag
	 * 
	 * @return boolean isValid flag
	 */
	public boolean getIsValid() {
		return isValid;
	}
	
	/**
	 * Sets the isValid flag
	 * 
	 * @param boolean isValid flag
	 */
	public void setIsValid(boolean isValid) {
		this.isValid = isValid;
	}

	/**
	 * Returns the String representation of Databackpack Model
	 * 
	 * @return String String representation of Databackpack Model
	 */
	@Override
	public String toString() {
		return "Databackpack [customerList=" + customerList + ", agreementList=" + agreementList + ", person=" + person
				+ ", notificationConfigPerson=" + notificationConfigPerson + ", emailList=" + emailList 
				+ ", isValid=" + isValid +"]";
	}

}
