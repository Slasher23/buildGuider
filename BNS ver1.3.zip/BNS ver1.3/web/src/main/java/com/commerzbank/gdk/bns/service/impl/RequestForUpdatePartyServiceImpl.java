package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.ComplexElectronicAddress;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement the business logic to update
 * party.
 * 
 * @since 07/12/2017
 * @author ZE2GOME
 * @version 1.07
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/12/2017        1.00       ZE2GOME    Initial Version
 * 13/12/2017        1.01       ZE2SARO    Add validation
 * 14/12/2017        1.02       ZE2MENY    Change complexelectronicalAddress into electronicalAddress
 * 15/12/2017        1.03       ZE2GOME    Bug fix
 * 14/12/2017        1.04       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 06/02/2018        1.05       ZE2MACL    Remove throws Exception and replace it with try catch block
 * 21/02/2018        1.06       ZE2MACL    Added required field/s validation
 *
 *          </pre>
 */
@Service
@Transactional
public class RequestForUpdatePartyServiceImpl implements RequestForUpdatePartyService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private EmailDAO emailDao;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForUpdatePartyServiceImpl.class);

    private static final String STATUS_OK                     = "ZSL_STATUS_OK";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS   = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_INVALID_REQUEST     = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_NO_CHANGES_REQ         = "ZSL_STATUS_NO_CHANGES_REQ";
    private static final String STATUS_FA_FAILED_UPDATE_PARTY = "ZSL_STATUS_FA_FAILED_UPDATE_PARTY";
    private static final String EMPTY_STRING                  = "";

    /**
     * Return the updated party
     * 
     * @param updatePartyRequest UpdatePartyRequest
     * @return response ZslUpdateResponse
     */
    @Override
    public ZslUpdateResponse requestForUpdateParty(UpdatePartyRequest updatePartyRequest) {

        ZslUpdateResponse response = new ZslUpdateResponse();
        String status = EMPTY_STRING;

        try {
            status = validateRequestFields(updatePartyRequest);
            if (isNullOrEmpty(status)) {
                response = validateBpkennInDB(updatePartyRequest);
            } else {
                response.setBpkenn(updatePartyRequest.getBpkenn());
                response.setStatus(status);
            }

        } catch (Exception e) {
            response.setStatus(this.environment.getProperty(STATUS_FA_FAILED_UPDATE_PARTY));
            LOGGER.error(e.getMessage(), e);
        }

        return response;
    }

    /**
     * Method to validate request
     * 
     * @param updatePartyRequest
     * @return String
     */
    private String validateRequestFields(UpdatePartyRequest updatePartyRequest) {
        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        if (isNullOrEmpty(updatePartyRequest.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        if (isNullOrEmpty(updatePartyRequest.getFirstName())) {
            invalidFields.add("firstName");
        }

        if (isNullOrEmpty(updatePartyRequest.getLastName())) {
            invalidFields.add("lastName");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;
    }

    /**
     * validate if BPKENN exist in DB
     * 
     * @param updatePartyRequest UpdatePartyRequest
     * @return response ZslUpdateResponse
     */
    private ZslUpdateResponse validateBpkennInDB(UpdatePartyRequest updatePartyRequest) {

        ZslUpdateResponse response = new ZslUpdateResponse();

        Person person = this.personDAO.findByBpkennIgnoreCase(updatePartyRequest.getBpkenn());

        if (Objects.nonNull(person)) {
            response = validateRequest(person, updatePartyRequest);
        } else {
            response.setBpkenn(updatePartyRequest.getBpkenn());
            response.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
        }

        return response;
    }

    /**
     * Validate request if null or empty
     * 
     * @param person Person
     * @param updatePartyRequest UpdatePartyRequest
     * @return response ZslUpdateResponse
     */
    private ZslUpdateResponse validateRequest(Person person, UpdatePartyRequest updatePartyRequest) {

        ZslUpdateResponse response = new ZslUpdateResponse();

        if (this.isValidRequest(updatePartyRequest)) {
            boolean isEmailUpdatable = checkRequestToDb(person, updatePartyRequest);
            boolean isPersonUpdatable = updatePersonTable(person, updatePartyRequest);

            if (isPersonUpdatable || isEmailUpdatable) {
                response.setBpkenn(updatePartyRequest.getBpkenn());
                response.setStatus(this.environment.getProperty(STATUS_OK));
            } else {
                response.setBpkenn(updatePartyRequest.getBpkenn());
                response.setStatus(this.environment.getProperty(STATUS_NO_CHANGES_REQ));
            }

        } else {
            response.setBpkenn(updatePartyRequest.getBpkenn());
            response.setStatus(this.environment.getProperty(STATUS_FA_INVALID_REQUEST));
        }

        return response;
    }

    /**
     * Check request if existing in DB
     * 
     * @param person Person
     * @param updatePartyRequest UpdatePartyRequest
     * @return response ZslUpdateResponse
     */
    private boolean checkRequestToDb(Person person, UpdatePartyRequest updatePartyRequest) {

        boolean isUpdated = false;
        ZslUpdateResponse response = new ZslUpdateResponse();

        List<Email> emails = this.emailDao.findByPersonUID(person.getPersonUID());
        List<Long> tempList = new ArrayList<>();

        if (Objects.nonNull(emails)) {

            for (Email mail : emails) {
                tempList.add(mail.getAddressId());
            }
        }

        for (ComplexElectronicAddress request : updatePartyRequest.getElectronicalAddress()) {

            if (Objects.nonNull(request)) {

                if (tempList.contains(request.getAddressId())) {
                    Email email = this.emailDao.findByPersonUIDAndAddressId(person.getPersonUID(),
                                    request.getAddressId());

                    if (Objects.nonNull(email)) {

                        if (!email.getEmailAddress().equals(request.getEmailAddress())) {
                            email.setEmailAddress(request.getEmailAddress());
                            this.emailDao.save(email);
                            isUpdated = true;
                        }
                    }

                    tempList.remove(request.getAddressId());
                } else {
                    Email newEmail = new Email();
                    newEmail.setPersonUID(person.getPersonUID());
                    newEmail.setAddressId(request.getAddressId());
                    newEmail.setEmailAddress(request.getEmailAddress());
                    this.emailDao.save(newEmail);
                    isUpdated = true;
                }
            }
        }

        if (tempList.size() > 0) {
            for (Long id : tempList) {
                Email toDeleteEmail = this.emailDao.findByPersonUIDAndAddressId(person.getPersonUID(), id);
                this.emailDao.delete(toDeleteEmail);
                isUpdated = true;
            }
        }

        response.setBpkenn(updatePartyRequest.getBpkenn());
        response.setStatus(this.environment.getProperty(STATUS_OK));

        return isUpdated;
    }

    /**
     * Update Person and email table
     * 
     * @param person Person
     * @param updatePartyRequest UpdatePartyRequest
     * @param email Email
     * @param cel ComplexElectronicAddress
     * @return
     */
    private boolean updatePersonTable(Person person, UpdatePartyRequest updatePartyRequest) {

        boolean isUpdated = false;

        if (this.isUpdatable(person, updatePartyRequest)) {
            person.setGivenName(updatePartyRequest.getFirstName());
            person.setLastName(updatePartyRequest.getLastName());
            person.setSalutation(updatePartyRequest.getSalutation());
            person.setTitle(updatePartyRequest.getTitle());
            this.personDAO.save(person);
            isUpdated = true;
        }

        return isUpdated;
    }

    /**
     * check if request can be update
     * 
     * @param person Person
     * @param updatePartyRequest UpdatePartyRequest
     * @return boolean
     */
    private boolean isUpdatable(Person person, UpdatePartyRequest updatePartyRequest) {

        boolean updatable = true;

        if (Objects.equals(person.getGivenName(), updatePartyRequest.getFirstName())
                        && Objects.equals(person.getLastName(), updatePartyRequest.getLastName())
                        && Objects.equals(person.getSalutation(), updatePartyRequest.getSalutation())
                        && Objects.equals(person.getTitle(), updatePartyRequest.getTitle())) {
            updatable = false;
        }

        return updatable;
    }

    /**
     * check string if null or empty
     * 
     * @param request String
     * @return boolean
     */
    private boolean isNullOrEmpty(String request) {
        return Objects.isNull(request) || request.isEmpty();
    }

    /**
     * Validate request
     * 
     * @param updatePartyRequest UpdatePartyRequest
     * @return boolean
     */
    private boolean isValidRequest(UpdatePartyRequest updatePartyRequest) {

        boolean firstNameIsNull = isNullOrEmpty(updatePartyRequest.getFirstName());
        boolean lastNameIsNull = isNullOrEmpty(updatePartyRequest.getLastName());

        return !(firstNameIsNull || lastNameIsNull);
    }

}
