package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.BatchUpdatePersonResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePerson;
import com.commerzbank.gdk.bns.model.RequestForUpdatePersonRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePersonService;

/**
 * RequestForUpdatePersonController - Update the firstname and lastname of a
 * person. This is triggered by the CORE event UPDATE_PERSON.
 * 
 * @since 27/11/2017
 * @author ZE2MENY
 * @version 1.07
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2MENY    Initial Version
 * 29/11/2017        1.01       ZE2MENY    Implementation of BatchProcessing
 * 04/12/2017        1.02       ZE2MENY    Refactor to use BatchUpdatePersonResponse
 * 07/12/2017        1.03       ZE2SARO    Add Validation
 * 13/12/2017        1.04       ZE2BUEN    Clean up for ZSL logging
 * 12/12/2017        1.05       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 05/02/2018        1.06       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.07       ZE2MACL    Removed throws Exception
 *          </pre>
 */

@RestController
public class RequestForUpdatePersonController {

    @Autowired
    private RequestForUpdatePersonService requestForUpdatePersonService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForUpdatePersonController.class);

    /**
     * Accept client post request and call service to request for update person
     * also consumes and produces json or xml format.
     * 
     * @param requestForUpdatePersonRequest
     *            RequestForUpdatePersonRequest
     * @param httpRequest
     *            HttpServletRequest
     * @return ZslUpdateResponse
     */
    @PostMapping(value = "/api/zsl/requestForUpdatePerson")
    public ResponseEntity<ZslUpdateResponse> requestForUpdatePerson(
                    @Valid @RequestBody RequestForUpdatePersonRequest requestForUpdatePersonRequest,
                    HttpServletRequest httpRequest, BindingResult result) {        
                    
        LOGGER.info("=>> System [{}] - requestForUpdatePerson({})", "ZSL", requestForUpdatePersonRequest.toString());

        ZslUpdateResponse updateResponse = new ZslUpdateResponse();
        
        if (!result.hasErrors()) {
            
            updateResponse = this.requestForUpdatePersonService.requestForUpdateResponse(requestForUpdatePersonRequest);

            if (Objects.isNull(updateResponse)) {
                updateResponse = new ZslUpdateResponse();
            }
        }

        ResponseEntity<ZslUpdateResponse> response = new ResponseEntity<ZslUpdateResponse>(updateResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", updateResponse.toString());

        return response;
    }

    /**
     * Accept client post request and call service to request for update person
     * in list also consumes and produces json or xml format.
     * 
     * @param requestForBatchUpdatePersonList
     *            List <RequestForUpdatePersonRequest>
     * @param request
     *            HttpServletRequest
     * @return BatchUpdatePersonResponse
     */
    @PostMapping(value = "/api/zsl/requestForBatchUpdatePerson")
    public ResponseEntity<BatchUpdatePersonResponse> requestForBatchUpdatePerson(
                    @Valid @RequestBody RequestForBatchUpdatePerson requestForBatchUpdatePersonList,
                    HttpServletRequest request, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForBatchUpdatePerson({})", "ZSL", requestForBatchUpdatePersonList);

        BatchUpdatePersonResponse batchResponse = new BatchUpdatePersonResponse();

        if (!result.hasErrors()) {
            batchResponse = this.requestForUpdatePersonService
                    .requestForBatchUpdatePerson(requestForBatchUpdatePersonList);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new BatchUpdatePersonResponse();
            }
        }

        ResponseEntity<BatchUpdatePersonResponse> response = new ResponseEntity<BatchUpdatePersonResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;

    }
}
