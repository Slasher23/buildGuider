package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.CustomerDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.CustomerNotificationService;
import com.commerzbank.gdk.bns.service.NotificationService;
import static com.commerzbank.gdk.bns.utils.GlobalProperties.*;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement business logic service in
 * notification
 * 
 * @author ZE2SARO
 * @since 09/11/2017
 * @version 1.06
 * 
 * <pre>
 * Modified Date    Version     Author      Description
 * 09/11/2017       1.00        ZE2SARO     InitialVersion
 * 07/12/2017       1.01        ZE2SARO     Add Validation
 * 12/12/2017       1.02        ZE2BUEN     Refactor/Clean up for ZSL Status Messages
 * 11/01/2017       1.03        ZE2FUEN     Added daily logging
 * 06/02/2018       1.04        ZE2MACL     Remove throws Exception and replace it with try catch block
 * 21/02/2018       1.05        ZE2MACL     Added required field/s validation
 * 09/03/2018       1.06        ZE2BUEN     Refactor Notification Matrix
 * </pre>
 */
@Transactional
@Service
public class CustomerNotificationServiceImpl implements CustomerNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerNotificationServiceImpl.class);

	@Value("${NOTIF_EVENT03}")
	private String eventType;

	@Autowired
	private CustomerDAO customerDAO;

	@Autowired
	private PersonDAO personDao;

	@Autowired
	private NotificationService notifService;

	@Autowired
	private DailyReportLogDAO dailyReportLogDAO;

	@Autowired
	private RequiredFieldValidation requiredFieldValidation;

	/**
	 * get notification based on customer request
	 * 
	 * @param request CustomerNotificationRequest use to get notification
	 * @return List<NotificationResponse> list of notification
	 */
	@Override
	public CustomerNotificationsResponse getResponse(CustomerNotificationRequest request) {
		String status = BNSConstants.EMPTY_STRING;

		DailyReportLog dailyReportLog = new DailyReportLog();
		dailyReportLog.setEventType(eventType);
		dailyReportLog.setTimestamp(new Date());
		this.dailyReportLogDAO.save(dailyReportLog);

		CustomerNotificationsResponse response = new CustomerNotificationsResponse();
		List<NotificationResponse> listNotifResponse = new ArrayList<NotificationResponse>();
		NotificationResponse notificationResponse = new NotificationResponse();

		try {
			List<Customer> listCustomer = this.customerDAO.findByCustomerNumber(request.getKundennummer());
			int successCtr = 0;
			boolean isCustomerExist = listCustomer.size() > 0 ? true : false;

			status = validateRequest(request);
			if (isNullOrEmpty(status)) {

				if (isCustomerExist) {
					List<String> listBpkenn = getBpkenn(listCustomer);

					for (String bpkenn : listBpkenn) {
						notificationResponse = getNotifResponse(request, bpkenn);
						listNotifResponse.add(notificationResponse);

						if (notificationResponse.getStatus()
								.equalsIgnoreCase(ZSL_STATUS_OK)) {
							successCtr++;
						}

					}

					response.setStatus(getStatus(successCtr));
				} else {
					response.setStatus(ZSL_STATUS_FA_KUNDE_NOT_EXISTS);
				}

			} else {
				response.setStatus(status);
			}

		} catch (Exception e) {
			response.setStatus(ZSL_STATUS_FA_INTERNAL_ERROR);
			LOGGER.error(e.getMessage(), e);
		}

		response.setKundennummer(request.getKundennummer());
		response.setCustomerNotifications(listNotifResponse);

		return response;
	}

	/**
	 * Method to validate data in NotificationRequest
	 * 
	 * @param request CustomerNotificationRequest
	 * @return String
	 */
	private String validateRequest(CustomerNotificationRequest request) {
		HashSet<String> invalidFields = new HashSet<String>();
		String inValidMsg;

		if (isNullOrEmpty(request.getKundennummer())) {

			invalidFields.add("kundennummer");
		}

		if ((isNullOrEmpty(request.getVereinbarungskennung()) && Objects.nonNull(request.getSparte())
				|| (!isNullOrEmpty(request.getVereinbarungskennung()) && Objects.isNull(request.getSparte())))) {

			if (Objects.isNull(request.getSparte())) {
				invalidFields.add("sparte");
			}

			if (isNullOrEmpty(request.getVereinbarungskennung())) {
				invalidFields.add("vereinbarungskennung");
			}
		}

		inValidMsg = requiredFieldValidation.requiredField(invalidFields);

		return inValidMsg;
	}

	/**
	 * Method to check if string is null or empty.
	 * 
	 * @param stringToCheck String string to validate
	 * @return boolean isNullOrEmpty
	 */
	private boolean isNullOrEmpty(String stringToCheck) {

		return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
	}

	/**
	 * Get status message
	 * 
	 * @param successCtr int
	 * @return String
	 */
	private String getStatus(int successCtr) {

		String status = ZSL_STATUS_OK;
		if (successCtr <= 0) {
			status = ZSL_STATUS_FA_NO_VALID_CUSTOMER_NOTIF;
		}

		return status;
	}

	/**
	 * Get notification response
	 * 
	 * @param request
	 * @param bpkenn
	 * @return notification response
	 */
	private NotificationResponse getNotifResponse(CustomerNotificationRequest request, String bpkenn) {

		NotificationRequest notifRequest = new NotificationRequest();
		notifRequest.setBpkenn(bpkenn);
		notifRequest.setSparte(request.getSparte());
		notifRequest.setVereinbarungskennung(request.getVereinbarungskennung());
		NotificationResponse notifResponse = this.notifService.sendNotification(notifRequest);

		return notifResponse;
	}

	/**
	 * Get list of bpkenn
	 * 
	 * @param listCustomer List<Customer> Customer List
	 * @return List<String> List of bpkenn
	 */
	private List<String> getBpkenn(List<Customer> listCustomer) {

		List<String> listBpkenn = new ArrayList<String>();

		for (Customer data : listCustomer) {
			Person person = new Person();

			if (Objects.nonNull(data)) {
				person = this.personDao.findOne(data.getPersonUID());

				if (Objects.nonNull(person) && !person.getBPKENN().isEmpty()) {
					listBpkenn.add(person.getBPKENN());
				}

			}

		}

		return listBpkenn;
	}

}
