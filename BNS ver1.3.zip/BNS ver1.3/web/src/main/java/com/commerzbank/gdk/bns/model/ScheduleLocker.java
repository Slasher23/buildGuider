package com.commerzbank.gdk.bns.model;

import java.util.Date;


import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
/**
 * ScheduleLocker class for single ode locking of the scheduler
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.01
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 15/02/2018       1.00        ZE2RUBI     Initial Version
 * 13/03/2018       1.01        ZE2RUBI     Change update_at to updatable = true
 *          </pre>
 */
@Entity
@Table(name = "SCHEDULE_LOCKER")
public class ScheduleLocker {
    @Id
    @Column(name = "SCHEDULE_LOCKER_UID")
    @GeneratedValue(generator = "SCHEDULE_LOCKER_ID_SEQ")
    @SequenceGenerator(name = "SCHEDULE_LOCKER_ID_SEQ", sequenceName = "SCHEDULE_LOCKER_SEQ")
    private Long uid;
    
    @Column(name = "NODE_NAME")
    private String nodeName;

    @Column(name = "RANDOM")
    private int random;

    @Basic(optional = false)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATE_AT", insertable = true, updatable = true)
    private Date updated_at = new Date();
       
    public ScheduleLocker(){}

    public ScheduleLocker(Long uid, String nodeName, int random,Date updated_at) {
        super();
        this.uid = uid;
        this.nodeName = nodeName;
        this.random = random;
        this.updated_at = updated_at;
    }

    /**
     * @return the scheduleLocker
     */
    public Long getUid() {
        return uid;
    }

    /**
     * @param scheduleLocker the scheduleLocker to set
     */
    public void setUid(Long uid) {
       this. uid = uid;
    }

    /**
     * @return the nodeName
     */
    public String getNodeName() {
        return nodeName;
    }

    /**
     * @param nodeName the nodeName to set
     */
    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    /**
     * @return the random
     */
    public int getRandom() {
        return random;
    }

    /**
     * @param random the random to set
     */
    public void setRandom(int random) {
        this.random = random;
    }

    /**
     * @return the update_at
     */
    public Date getUpdated_at() {
        return updated_at;
    }

    /**
     * @param update_at the update_at to set
     */
    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ScheduleLocker [uid=" + uid + ", nodeName=" + nodeName + ", random=" + random
                + ", updated_at=" + updated_at + "]";
    }
   
    
}
