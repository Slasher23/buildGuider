package com.commerzbank.gdk.bns.enums;

/**
 * Enum for Information Channel Type
 * 
 * @since 26/10/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2BUEN    Initial Version
 * </pre>
 */
public enum InformationChannelTypeE {
	
	/**
	 * Email
	 */
	EMAIL(1001),
	
	/**
	 * Push
	 */
	PUSH(1002);
	
	private int id;
	
	private InformationChannelTypeE(int id) {
		this.id = id;
	}
	
	/**
	 * Returns the ID of channel Type
	 * 
	 * @return int ID of channel Type
	 */
	public int getId() {
		return id;
	}

}
