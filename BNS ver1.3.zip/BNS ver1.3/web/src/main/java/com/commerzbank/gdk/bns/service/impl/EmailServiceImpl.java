/**
 * 
 */
package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.EmailService;

/**
 * Service Implementation Class used to implement the business logic in getting
 * the Email List
 *
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 10/11/2017       1.01        ZE2MACL     Updated method to used Response builder with error code
 * 24/11/2017       1.02        ZE2MORA     Implemented Status Codes
 *          </pre>
 * 
 */
@Service
@Transactional
public class EmailServiceImpl implements EmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	private EmailDAO emailDAO;

	@Autowired
	private PersonDAO personDAO;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	/**
	 * Retrieves the value of Email using a given Unique Identifier of Person
	 * record
	 * 
	 * @param token to identify the user
	 * @param bpkenn
	 *            String Unique Identifier of Person Record to set
	 * @return list of Email based on bpkenn
	 */
	@Override
	public ResponseBuilder<List<Email>> getEmailList(Tokenizer token, String bpkenn) {

		ResponseBuilder<List<Email>> builder = new ResponseBuilder<List<Email>>(LOGGER, token, globalResponseWrapper);

		try {

			Long personUID = 0L;
			Person person = this.personDAO.getPerson(bpkenn);

			if (Objects.nonNull(person)) {
				personUID = person.getPersonUID();

				List<Email> result = Lists.newArrayList(this.emailDAO.getEmailList(personUID));

				if (Objects.nonNull(result)) {
					builder.OK(result);
				} else {
					builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
				}
			} else {
				builder.OK(Response.SUCCESS_NO_PERSON_FOUND);
			}

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] getEmailList({}) request was successfully processed.", token.getUserId(), bpkenn);

		return builder;
	}

}