package com.commerzbank.gdk.bns.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Ausloser(Trigger)
 * 
 * @since 30/06/2017
 * @author ZE2BAUL
 * @version 1.06
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 30/06/2017        1.01       ZE2BAUL    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 20/09/2017        1.03       ZE2BUEN    Added personUID and branch columns. Remove Umlauts from table and column names
 * 27/10/2017        1.04       ZE2BUEN    Removed branch column.
 * 23/11/2017        1.05       ZE2BUEN    Modified PERSON_UID to BPKENN
 * 07/12/2017        1.06       ZE2BUEN    Modified Trigger model to remove table reference
 * </pre>
 */

@XmlRootElement
public class Trigger {

	private String triggerType;

	private Date timestampTrigger;

	private String eventType;

	private Long eventID;
	
	private String bpkenn;
	
	/**
	 * Returns the value of Trigger Type
	 * 
	 * @return String Trigger Type
	 */
	public String getTriggerType() {
		return triggerType;
	}

	/**
	 * Sets the value of Trigger Type
	 * 
	 * @param triggerType String Trigger Type to set
	 */
	public void setTriggerType(String triggerType) {
		this.triggerType = triggerType;
	}

	/**
	 * Returns the value of Timestamp Trigger
	 * 
	 * @return Date Timestamp Trigger
	 */
	public Date getTimestampTrigger() {
		return timestampTrigger;
	}

	/**
	 * Sets the value of Timestamp Trigger
	 * 
	 * @param timestampTrigger Date Timestamp Trigger to set
	 */
	public void setTimestampTrigger(Date timestampTrigger) {
		this.timestampTrigger = timestampTrigger;
	}

	/**
	 * Returns the value of Event Type
	 * 
	 * @return String Event Type
	 */
	public String getEventType() {
		return eventType;
	}

	/**
	 * Sets the value of Event Type
	 * 
	 * @param eventType String Event Type to set
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	/**
	 * Returns the value of Event ID
	 * 
	 * @return Long Event ID
	 */
	public Long getEventID() {
		return eventID;
	}

	/**
	 * Sets the value of Event ID
	 * 
	 * @param eventID Long Event ID to set
	 */
	public void setEventID(Long eventID) {
		this.eventID = eventID;
	}
	
	/**
	 * Returns the value of BPKENN
	 * 
	 * @return String BPKENN
	 */
	public String getBpkenn() {
		return bpkenn;
	}
	
	/**
	 * Sets the value of BPKENN
	 * 
	 * @param bpkenn String BPKENN record to set
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the String representation of Trigger Model
	 * 
	 * @return String String representation of Trigger Model
	 */
	@Override
	public String toString() {
		return "Trigger [triggerType=" + triggerType + ", timestampTrigger=" + timestampTrigger + ", eventType="
				+ eventType + ", eventID=" + eventID + ", bpkenn=" + bpkenn + "]";
	}
	
}
