package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.PersonConfigService;

/**
 * Service Implementation Class used to implement the business logic in saving
 * after toggle action for PersonConfig
 * 
 * @since 03/10/2017
 * @author ZE2BAUL
 * @version 1.04
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 03/10/2017		1.01		ZE2BAUL 	InitialVersion
 * 27/11/2017       1.02        ZE2CRUH     Removed Participant Number
 * 28/11/2017       1.03        ZE2BAUL     Implemented Status Codes
 * 09/02/2018       1.04        ZE2MACL     Removed throws Exception
 *          </pre>
 */

@Transactional
@Service
public class PersonConfigServiceImpl implements PersonConfigService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PersonConfigServiceImpl.class);

	@Autowired
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Autowired
	private Environment environment;

	@Autowired
	private NotificationTextDAO notificationTextDAO;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	/**
	 * Retrieves the Notification Configuration Person using a given Unique
	 * Identifier.
	 * 
	 * @param token
	 *            Tokenizer used for identifying user
	 * @param token
	 *            used for identifying the user
	 * @param UID
	 *            Long Unique Identifier to set
	 * @return notificationConfigPerson Get NotifConfigPerson by UID
	 */
	@Override
	public ResponseBuilder<NotificationConfigPerson> getNotifConfigPersonById(Tokenizer token, Long UID) {

		ResponseBuilder<NotificationConfigPerson> builder = new ResponseBuilder<NotificationConfigPerson>(LOGGER, token,
				globalResponseWrapper);

		try {

			NotificationConfigPerson result = this.notificationConfigPersonDAO.findOne(UID);

			if (Objects.nonNull(result)) {
				builder.OK(result);
			} else {
				builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
			}

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("=>> User [{}] getNotifConfigPersonById({})", token.getUserId(), UID);

		return builder;
	}

	/**
	 * Retrieves the Notification Configuration Person using the
	 * notificationConfigPerson
	 * 
	 * @param token
	 *            Tokenizer used for identifying user
	 * @param token
	 *            used for identifying the user
	 * @param notificationConfigPerson
	 *            Notification Configuration Person to set
	 * @return NotificationConfigPerson Save Notification Configuration Person
	 */
	@Override
	public ResponseBuilder<NotificationConfigPerson> postCustomer(Tokenizer token,
			NotificationConfigPerson notificationConfigPerson) {

		ResponseBuilder<NotificationConfigPerson> builder = new ResponseBuilder<NotificationConfigPerson>(LOGGER, token,
				globalResponseWrapper);

		try {
			NotificationConfigPerson result = this.notificationConfigPersonDAO.save(notificationConfigPerson);

			builder.OK(result);

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] postCustomer({}) request was successfully processed.", token.getUserId(),
				notificationConfigPerson.toString());

		return builder;

	}

	/**
	 * Returns the value of Notification Configuration Person
	 * 
	 * @param token
	 *            used for identifying the user
	 * @return NotificationConfigPerson List of Notification Configuration
	 *         Person
	 */
	@Override
	public ResponseBuilder<List<NotificationConfigPerson>> getNotifConfigPersonList(Tokenizer token) {

		ResponseBuilder<List<NotificationConfigPerson>> builder = new ResponseBuilder<List<NotificationConfigPerson>>(
				LOGGER, token, globalResponseWrapper);

		try {

			List<NotificationConfigPerson> result = Lists.newArrayList(this.notificationConfigPersonDAO.findAll());

			if (Objects.nonNull(result)) {
				builder.OK(result);
			} else {
				builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
			}

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}]  getNotifConfigPersonList() request was successfully processed.", token.getUserId());

		return builder;

	}

	/**
	 * Retrieves the value of Saving Notification Configuration Agreement
	 * 
	 * @param token
	 *            used for identifying the user
	 * @param savingNotifConfigAgreement
	 *            SavingNotifConfigAgreement to set
	 * @return the saved NotificationConfigPerson
	 */
	@Override
	public ResponseBuilder<PersonConfig> postNotifConfigPerson(Tokenizer token, PersonConfig savingNotifConfigPerson) {

		ResponseBuilder<PersonConfig> builder = new ResponseBuilder<PersonConfig>(LOGGER, token, globalResponseWrapper);

		try {

			builder = new ResponseBuilder<PersonConfig>(LOGGER, token, globalResponseWrapper);

			NotificationConfigPerson nf = savingNotifConfigPerson.getNotificationConfigPerson();
			// insert notif text if not exist
			if (Objects.isNull(nf.getNotificationTextUID()) || nf.getNotificationTextUID() == 0) {
				Long notiftextUID = saveNotifText(token, nf.getPersonUID());
				nf.setNotificationTextUID(notiftextUID);
			}
			this.notificationConfigPersonDAO.save(nf);

			builder.OK(savingNotifConfigPerson);

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}]  postNotifConfigPerson({}) request was successfully processed.", token.getUserId(),
				savingNotifConfigPerson.toString());

		return builder;
	}

	/**
	 * Save notification text.
	 * 
	 * @param token
	 *            used for identifying the user
	 * @param Long
	 *            participantNumberUID to set
	 * @return the NotificationTextUID saved
	 */
	private Long saveNotifText(Tokenizer token, Long personUID) {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(personUID);
		notifText.setEventType(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY));
		notifText.setNotificationTextType(BNSConstants.TEXT_TYPE_STD);
		NotificationText savedNotificationText = this.notificationTextDAO.save(notifText);

		LOGGER.info("<<= User [{}] saveNotifText({}) request was successfully processed.", token.getUserId(),
				personUID.toString());

		return savedNotificationText.getNotificationTextUID();
	}

}
