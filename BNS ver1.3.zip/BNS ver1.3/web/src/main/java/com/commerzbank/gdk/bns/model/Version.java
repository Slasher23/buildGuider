package com.commerzbank.gdk.bns.model;

/**
 * Version object will the container of the Application version details
 * 
 * @since 24/10/2017
 * @author ZE2RUBI
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 24/10/2017      1.00      ZE2RUBI    Initial Version
 *          </pre>
 */
public class Version {

    private String applicationName;
    private String buildVersion;
    private String buildTimestamp;
    private String datasourceName;
    
    public Version() {}
    
    public Version(String applicationName, String buildVersion, String buildTimestamp,
            String datasourceName) {
        super();
        this.applicationName = applicationName;
        this.buildVersion = buildVersion;
        this.buildTimestamp = buildTimestamp;
        this.datasourceName = datasourceName;
    }

    public String getApplicationName() {
        return applicationName;
    }
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }
    public String getBuildVersion() {
        return buildVersion;
    }
    public void setBuildVersion(String buildVersion) {
        this.buildVersion = buildVersion;
    }
    public String getBuildTimestamp() {
        return buildTimestamp;
    }
    public void setBuildTimestamp(String buildTimestamp) {
        this.buildTimestamp = buildTimestamp;
    }
    public String getDatasourceName() {
        return datasourceName;
    }
    public void setDatasourceName(String datasourceName) {
        this.datasourceName = datasourceName;
    }

    @Override
    public String toString() {
        return "Version [ applicationName=" + applicationName + ", buildVersion=" + buildVersion
                + ", buildTimestamp=" + buildTimestamp + ", datasourceName=" + datasourceName + "]";
    }
    
    
}
