package com.commerzbank.gdk.bns.conf.security;

import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Filter that orchestrates authentication by using supplied JWT token
 * 
 * @author ZE2RUBI
 * @since 03/10/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017	     1.01       ZE2RUBI    Initial Version
 * 20/02/2018        1.02       ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
public class CifAuthorizationTokenFilter extends OncePerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(CifAuthorizationTokenFilter.class);

    private static final String authHeaderKey = "Authorization";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        
        LOGGER.info("Request URL: " + request.getRequestURL().toString());

        List<String> requestHeaderNames = Collections.list((Enumeration<String>) request.getHeaderNames());
        LOGGER.info("headerName number: " + requestHeaderNames.size());

        for (String headerName : requestHeaderNames) {
            LOGGER.info("headerName name: " + headerName + " - headerName value: " + request.getHeader(headerName));
        }
        
        String authHeader = request.getHeader(authHeaderKey);
        Authentication auth = new CifAuthorizationToken(authHeader);

        SecurityContextHolder.getContext().setAuthentication(auth);
        filterChain.doFilter(request, response);
    }

}