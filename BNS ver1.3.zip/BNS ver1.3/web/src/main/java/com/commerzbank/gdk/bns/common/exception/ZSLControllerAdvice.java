package com.commerzbank.gdk.bns.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;

/**
 * Controller Advice Class for ZSL Web Services
 * 
 * @author ZE2BUEN
 * @since 23/02/2018
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 23/02/2018        1.00       ZE2BUEN    Initial Version
 * </pre>
 */
@ControllerAdvice(basePackages = "com.commerzbank.gdk.bns.controller.zsl")
@Order(1)
public class ZSLControllerAdvice {
	
	@Autowired
    private GlobalResponseWrapper globalResponseWrapper;
	
	private static final Logger logger = LoggerFactory.getLogger(ZSLControllerAdvice.class);
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<Response<String>> returnNotReadableException(HttpMessageNotReadableException e) {

		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString());
        respMsg.setData(null);

        logger.info(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Response<String>> returnMethodArgumentNotValidException(MethodArgumentNotValidException  e) {

		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString());
        respMsg.setData(null);
        
        logger.info(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.BAD_REQUEST);
	}
	
}
