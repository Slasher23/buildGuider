package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsResponse;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.service.CustomerBatchNotificationService;
import com.commerzbank.gdk.bns.service.CustomerNotificationService;
import static com.commerzbank.gdk.bns.utils.GlobalProperties.*;

/**
 * Service Implementation Class used to implement business logic service in
 * batch notification
 * 
 * @author ZE2SARO
 * @since 09/11/2017
 * @version 1.04
 * 
 * <pre>
 * Modified Date    Version     Author      Description
 * 09/11/2017       1.00        ZE2SARO     InitialVersion
 * 07/12/2017       1.01        ZE2BUEN     Clean up for ZSL logging
 * 14/12/2017       1.02        ZE2BUEN     Refactor/clean up for status messages
 * 09/02/2018       1.03        ZE2MACL     Removed throws Exception
 * 09/03/2018       1.04        ZE2BUEN     Refactor Notification Matrix
 * </pre>
 */
@Transactional
@Service
public class CustomerBatchNotificationServiceImpl implements CustomerBatchNotificationService {

    @Autowired
    private CustomerNotificationService custNotificationService;

    /**
     * Get all notification with or without error
     * 
     * @param request CustomerBatchNotificationsRequest use to get notifications
     * @return CustomerNotificationsBatchResponse valid and invalid
     *         notifications
     */
    @Override
    public CustomerBatchNotificationsResponse getResponse(CustomerBatchNotificationsRequest request) {

        CustomerBatchNotificationsResponse response = new CustomerBatchNotificationsResponse();
        List<CustomerNotificationsResponse> withoutErrors = new ArrayList<CustomerNotificationsResponse>();
        List<CustomerNotificationsResponse> withErors = new ArrayList<CustomerNotificationsResponse>();

        for (CustomerNotificationRequest customerNotificationRequest : request.getCustomerNotificationsRequest()) {
            CustomerNotificationsResponse custResponse = this.custNotificationService
                    .getResponse(customerNotificationRequest);

            if (custResponse.getStatus().equalsIgnoreCase(ZSL_STATUS_OK)) {
                withoutErrors.add(custResponse);
            } else {
                withErors.add(custResponse);
            }

        }

        response.setCustomerNotificationResponse(withoutErrors);
        response.setCustomerNotificationResponseWithErrors(withErors);
        
        return response;
    }

}
