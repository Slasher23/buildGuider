package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for UpdatePartyRequest List
 * 
 * @since 12/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@XmlRootElement
public class BatchUpdatePartyRequest {

    private List<UpdatePartyRequest> updatePartyRequest;

    /**
     * @return the updatePartyRequest
     */
    public List<UpdatePartyRequest> getUpdatePartyRequest() {
        return updatePartyRequest;
    }

    /**
     * @param updatePartyRequest the updatePartyRequest to set
     */
    public void setUpdatePartyRequest(List<UpdatePartyRequest> updatePartyRequest) {
        this.updatePartyRequest = updatePartyRequest;
    }

    /* 
     * @return
     */
    @Override
    public String toString() {
        return "BatchUpdatePartyRequest [updatePartyRequest=" + updatePartyRequest + "]";
    }
    
}
