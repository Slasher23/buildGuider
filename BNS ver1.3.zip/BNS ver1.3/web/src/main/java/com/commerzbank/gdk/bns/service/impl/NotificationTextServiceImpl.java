package com.commerzbank.gdk.bns.service.impl;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.NotificationTextService;

/**
 * Service Implementation Class used to implement the business logic in getting
 * the Notification Text List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.03
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 27/09/2017		1.01		ZE2SARO 	Relationship of agreement and notif text is 1:1
 * 13/11/2017       1.02        ZE2MACL     Updated
 * 24/11/2017       1.03        ZE2MORA     Implemented Status Codes
 *          </pre>
 */
@Service
@Transactional
public class NotificationTextServiceImpl implements NotificationTextService {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationTextServiceImpl.class);

    @Autowired
    private NotificationTextDAO notificationTextDAO;
    
    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    /**
     * Retrieves the value of Notification Text using a given Identifier and
     * Type of Event record
     * 
     * @param token to identify the user
     * @param eventType String Type and eventId Long Identifier of Event Record
     *            to set
     * @return list of Notification Text
     */
    @Override
    public ResponseBuilder<NotificationText> getNotifText(Tokenizer token, String eventType, Long eventId) {

        ResponseBuilder<NotificationText> builder = new ResponseBuilder<NotificationText>(LOGGER, token, globalResponseWrapper);

        try {

            NotificationText notificationText = this.notificationTextDAO.getNotifText(eventType, eventId);

            if (Objects.nonNull(notificationText)) {
                builder.OK(notificationText);
            } else {
                builder.OK(notificationText, Response.SUCCESS_NO_RESULTS_FOUND);
            }

        } catch (DataAccessException e) {
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        }  catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
        	builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        LOGGER.info("<<== User [{}] getNotifText({},{})", token.getUserId(), eventType, eventId);

        return builder;
    }

}
