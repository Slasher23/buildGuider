package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.conf.CryptoServiceConfig;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.Version;
import com.commerzbank.gdk.bns.service.PersonService;
import com.commerzbank.gdk.bns.service.impl.ReportScheduler;
import com.commerzbank.gdk.bns.utils.SettingsConfig;

/**
 * SystemMonitoring Controller handles handshake request from monitoring server.
 * 
 * @since 16/10/2017
 * @author ZE2RUBI
 * @version 1.04
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 24/10/2017      1.00      ZE2RUBI    Initial Version
 * 27/11/2017      1.01      ZE2BAUL    Implemented the Status Code update
 * 11/12/2017      1.02      ZE2SARO    Update logger
 * 09/02/2018      1.03      ZE2MACL    Removed throws Exception
 * 03/13/2018      1.04      ZE2RUBI    Add healthcheckBnsDB for DB schema checking
 * </pre>
 */
@RestController
public class SystemMonitoringController {

    private static final Logger logger = LoggerFactory.getLogger(SystemMonitoringController.class);

    @Autowired
    ReportScheduler report;
    
    @Autowired
    private PersonService personService;
    
    @Value("${application.name}")
    private String applicationName;

    @Value("${build.version}")
    private String buildVersion;

    @Value("${build.timestamp}")
    private String buildTimestamp;

    @Value("${spring.datasource.name}")
    private String datasourceName;

    @Autowired
    private CryptoServiceConfig config;

    /**
     * Version method to handle get version request
     * 
     * @return List.
     * @throws Exception
     *             if exception occur.
     */
    @GetMapping(value = "/version")
    public ResponseEntity<Response<Version>> version(HttpServletRequest request) {

        String system = "SYSTEM";

        Version version = new Version(SettingsConfig.encode(applicationName), SettingsConfig.encode(buildVersion),
                SettingsConfig.encode(buildTimestamp), SettingsConfig.encode(datasourceName));

        logger.info("=>> System [{}] version[{}]", system, version);

        Response<Version> response = new Response<Version>();
        response.setCode(Response.SUCCESS_RESULTS_FOUND);
        response.setData(version);
        response.setMessage("Version");
        
        return new ResponseEntity<Response<Version>>(response, HttpStatus.OK);
    }

    /**
     * Healthcheck method to handle handshake request
     * 
     * @return HTTP.OK.
     */
    @GetMapping(value = "/healthcheck")
    public ResponseEntity<Response<?>> healthcheck(HttpServletRequest request) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] healthcheck()", system);

        return new ResponseEntity<Response<?>>(new Response<Object>(HttpStatus.OK.value(), null, "Health Check!"),
                HttpStatus.OK);

    }

    /**
     * Keep A live method to handle keep a live request
     * 
     * @return HTTP.OK.
     */
    @GetMapping(value = "/keepalive")
    public ResponseEntity<Response<?>> keepalive(HttpServletRequest request) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] keepalive()", system);

        return new ResponseEntity<Response<?>>(new Response<Object>(HttpStatus.OK.value(), null, "Keep Alive!"),
                HttpStatus.OK);

    }

    /**
     * Invalidate method to invalidate a request
     * 
     * @return HTTP.OK.
     */
    @GetMapping(value = "/invalidate")
    public ResponseEntity<Response<?>> invalidate(HttpServletRequest request) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] invalidate()", system);

        return new ResponseEntity<Response<?>>(new Response<Object>(HttpStatus.OK.value(), null, "Invalidate!"),
                HttpStatus.OK);

    }

    /**
     * HealthcheckBnsDB method to Check the health of Schema and DB
     * 
     * @return HTTP.OK.
     */
    @GetMapping(value = "/healthcheckBnsDB")
    public ResponseEntity<Response<?>> healthcheckBnsDB(HttpServletRequest request) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] healthcheckBnsDB()", system);
        
        return new ResponseEntity<Response<?>>(new Response<Object>(HttpStatus.OK.value(), null, "HealthcheckBnsDB: " + personService.getPersonCount()),
                HttpStatus.OK);

    }
    
    @PostMapping(value = "/encrypt")
    public ResponseEntity<String> encrypt(@Valid @RequestBody Parameter parameter, HttpServletRequest request,
            BindingResult result) throws Exception {
        System.out.println("Encrypting!");
        return new ResponseEntity<String>(config.encrypt(parameter.getSignedAndEncryptedDataBackPack()), HttpStatus.OK);
    }

    @PostMapping(value = "/decrypt")
    public ResponseEntity<String> decrypt(@Valid @RequestBody Parameter parameter, HttpServletRequest request,
            BindingResult result) throws Exception {
        System.out.println("Decrypting!");
        return new ResponseEntity<String>(config.decrypt(parameter.getSignedAndEncryptedDataBackPack()), HttpStatus.OK);
    }

    /**
     * Temporary controller for trigger of report generation
     * 
     * @return HTTP.OK.
     */
    @GetMapping(value = "/extractReport")
    public ResponseEntity<String> extractReport(HttpServletRequest request) {

        logger.info("=>> Extracting!");
        report.daily();
        logger.info("=>> Extracted!");

        return new ResponseEntity<String>("Done!", HttpStatus.OK);

    }
}
