package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for UpdatePartyRequest
 * 
 * @since 07/12/2017
 * @author ZE2GOME
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/12/2017        1.00       ZE2GOME    Initial Version
 * 14/12/2017        1.01       ZE2MENY    Change complexelectronicalAddress into electronicalAddress
 *          </pre>
 */
public class UpdatePartyRequest {

    private String bpkenn;

    private String firstName;

    private String lastName;

    private String title;

    private String salutation;

    private List<ComplexElectronicAddress> electronicalAddress;

    /**
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * @param bpkenn the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the salutation
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * @param salutation the salutation to set
     */
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    /**
     * @return the electronicalAddress
     */
    public List<ComplexElectronicAddress> getElectronicalAddress() {
        return electronicalAddress;
    }

    /**
     * @param electronicalAddress the electronicalAddress to set
     */
    public void setElectronicalAddress(List<ComplexElectronicAddress> electronicalAddress) {
        this.electronicalAddress = electronicalAddress;
    }

    /*
     * @return
     */
    @Override
    public String toString() {
        return "UpdatePartyRequest [bpkenn=" + bpkenn + ", firstName=" + firstName + ", lastName=" + lastName
                + ", title=" + title + ", salutation=" + salutation + ", electronicalAddress="
                + electronicalAddress + "]";
    }

}
