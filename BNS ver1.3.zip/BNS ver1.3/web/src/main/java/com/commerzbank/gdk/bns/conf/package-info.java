
/**
 * This package contains the applications java configurations.
 * 
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.conf;