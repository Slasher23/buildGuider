package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Benachrichtigungs Text (Notification Text) Table
 * 
 * @since 30/06/2017
 * @author ZE2MENY
 * @version 1.03
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 30/06/2017        1.01       ZE2MENY    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 15/11/2017        1.03       ZE2SARO    Add constructor
 *          </pre>
 */

@Entity
@Table(name = "BENACHRICHTIGUNGS_TEXT")
@XmlRootElement
public class NotificationText {

    @Id
    @Column(name = "BENACHRICHTIGUNGS_TEXT_UID")
    @GeneratedValue(generator = "BENACHRICHTIGUNGS_TEXT_ID_SEQ")
    @SequenceGenerator(name = "BENACHRICHTIGUNGS_TEXT_ID_SEQ", sequenceName = "BENACHRICHTIGUNGS_TEXT_SEQ")
    private Long notificationTextUID;

    @Size(max = 4)
    @Column(name = "BENACHRICHTIGUNGS_TEXT_TYP")
    private String notificationTextType;

    @NotNull
    @Size(max = 3)
    @Column(name = "VERANLASSUNGS_TYP")
    private String eventType;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "VERANLASSUNGS_ID")
    private Long eventID;

    @Size(max = 500)
    @Column(name = "TEXT")
    private String text;

    /**
     * Constructor
     */
    public NotificationText() {

    }
    
    /**
     * Set all records
     * 
     * @param notificationTextType
     * @param eventType
     * @param eventID
     * @param text
     */
    public NotificationText(String notificationTextType, String eventType, Long eventID, String text) {
        this.setNotificationTextType(notificationTextType);
        this.setEventType(eventType);
        this.setEventID(eventID);
        this.setText(text);
    }

    /**
     * Returns the value of Unique Identifier of Notification Text Record
     * 
     * @return Long Unique Identifier of Notification Text Record
     */
    public Long getNotificationTextUID() {
        return notificationTextUID;
    }

    /**
     * Sets the value of Unique Identifier of Notification Text Record
     * 
     * @param notificationTextUID Long Unique Identifier of Notification Text
     *            Record to set
     */
    public void setNotificationTextUID(Long notificationTextUID) {
        this.notificationTextUID = notificationTextUID;
    }

    /**
     * Returns the value of Notification Text Type
     * 
     * @return String Notification Text Type
     */
    public String getNotificationTextType() {
        return notificationTextType;
    }

    /**
     * Sets the value of Notification Text Type
     * 
     * @param notificationTextType String Notification Text Type to set
     */
    public void setNotificationTextType(String notificationTextType) {
        this.notificationTextType = notificationTextType;
    }

    /**
     * Returns the value of Event Type
     * 
     * @return String Event Type
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * Sets the value of Event Type
     * 
     * @param eventType String Event Type to set
     */
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * Returns the value of Event ID
     * 
     * @return Long Event ID
     */
    public Long getEventID() {
        return eventID;
    }

    /**
     * Sets the value of Event ID
     * 
     * @param eventID Long Event ID to set
     */
    public void setEventID(Long eventID) {
        this.eventID = eventID;
    }

    /**
     * Returns the value of Text
     * 
     * @return String Text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the value of Text
     * 
     * @param text String Text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Returns the String representation of Notification Text Model
     * 
     * @return String String representation of Notification Text Model
     */
    @Override
    public String toString() {
        return "NotificationText [notificationTextUID= " + notificationTextUID + " , notificationTextType= "
                + notificationTextType + " , eventType= " + eventType + " , eventID= " + eventID + " , text= " + text
                + "]";
    }

}
