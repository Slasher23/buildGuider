package com.commerzbank.gdk.bns.conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.commerzbank.gdk.bns.conf.filter.ZSLMDCFilter;

/**
 * ZSL Application Entry point
 * 
 * @author ZE2FUEN
 * @since 15/03/2018
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 15/03/2018 	     1.00       ZE2FUEN    Initial Version
 *          </pre>
 */
@Configuration
@EnableWebSecurity
@Order(1)
public class ZSLSecurityJavaConfig extends WebSecurityConfigurerAdapter{

    @Autowired
    private ZSLMDCFilter zslMdcFilter;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        http.antMatcher("/api/zsl/**").authorizeRequests().anyRequest().permitAll();
        http.addFilterBefore(zslMdcFilter, BasicAuthenticationFilter.class);
    }

}