package com.commerzbank.gdk.bns.model;

/**
 * Required Notification model class for logging required notification
 * 
 * @since 13/12/2017
 * @author ZE2CRUH
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 13/12/2017      1.00      ZE2CRUH    Initial Version
 * 28/12/2017      1.01      ZE2CRUH    Added NotificationPath
 *          </pre>
 */
public class RequiredNotification {

	private String bpkenn;
	
	private String uuid;
	
	private String processRunID;
	
	private String notificationType;
	
	private String notificationPath;
	
	private String notificationText;
	
	private String notificationSubject;
	
	private String status;

	/**
	 * @return the bpkenn
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * @param bpkenn the bpkenn to set
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the processRunID
	 */
	public String getProcessRunID() {
		return processRunID;
	}

	/**
	 * @param processRunID the processRunID to set
	 */
	public void setProcessRunID(String processRunID) {
		this.processRunID = processRunID;
	}

	/**
	 * @return the notificationType
	 */
	public String getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the notificationText
	 */
	public String getNotificationText() {
		return notificationText;
	}

	/**
	 * @param notificationText the notificationText to set
	 */
	public void setNotificationText(String notificationText) {
		this.notificationText = notificationText;
	}

	/**
	 * @return the notificationPath
	 */
	public String getNotificationPath() {
		return notificationPath;
	}

	/**
	 * @param notificationPath the notificationPath to set
	 */
	public void setNotificationPath(String notificationPath) {
		this.notificationPath = notificationPath;
	}

	/**
	 * @return the notificationSubject
	 */
	public String getNotificationSubject() {
		return notificationSubject;
	}

	/**
	 * @param notificationSubject the notificationSubject to set
	 */
	public void setNotificationSubject(String notificationSubject) {
		this.notificationSubject = notificationSubject;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Represents the model class into string value
	 * 
	 */
	@Override
	public String toString() {
		return "RequiredNotification [bpkenn=" + bpkenn + ", uuid=" + uuid + ", processRunID=" + processRunID
				+ ", notificationType=" + notificationType + ", notificationPath=" + notificationPath
				+ ", notificationText=" + notificationText + ", notificationSubject=" + notificationSubject
				+ ", status=" + status + "]";
	}
	
}
