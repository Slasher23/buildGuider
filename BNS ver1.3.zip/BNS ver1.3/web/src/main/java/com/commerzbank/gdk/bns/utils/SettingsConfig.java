package com.commerzbank.gdk.bns.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * Configuration Class for initialising Locale Map
 * 
 * @since 25/08/2017
 * @author ZE2CRUH
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 25/08/2017      1.00      ZE2CRUH    Initial Version
 * 11/12/2017      1.01      ZE2SARO    Add logger encoder
 *          </pre>
 */
public class SettingsConfig {

    /**
     * Reads the Locale within a file path and returns as Map
     * 
     * 
     * @param String path
     * @return Map<String,String>
     * 
     * @throws IOException
     */
    public static Map<String, String> initLocaleMap(String path) throws IOException {
        Map<String, String> localeMap = new HashMap<String, String>();
        File dir = new File(path);
        for (File file : dir.listFiles()) {
            StringBuilder builder = new StringBuilder();
            String content;
            List<String> stringList = Files.readAllLines(file.toPath());
            for (String line : stringList) {
                builder.append(line);
            }
            content = builder.toString();
            localeMap.put(file.getName().split("\\.")[0], content);
        }
        return localeMap;
    }

    public static String encode(String message) {
        message = message.replace('\n', '_').replace('\r', '_').replace('\t', '_');

        message = StringEscapeUtils.escapeHtml(StringEscapeUtils.escapeHtml(message));
        return message;
    }
}
