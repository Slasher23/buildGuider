package com.commerzbank.gdk.bns.dao;

import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;

/**
 * Custom Notification Configuration Agreement DAO Interface to 
 * get the Notification Configuration Agreement List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	Initial Version
 * 26/10/2017       1.01        ZE2SARO     Added findByAgreementUID
 * 23/11/2017       1.02        ZE2SARO     Change participantUID param to personUID
 * </pre>
 */

public interface NotificationConfigAgreementCustomDAO {

	NotificationConfigAgreement getNotifConfigAgreement(Long agreementUID);
	
	NotificationConfigAgreement findByAgreementUID(Long personUID, Integer branch, String agreementID);
	
}
