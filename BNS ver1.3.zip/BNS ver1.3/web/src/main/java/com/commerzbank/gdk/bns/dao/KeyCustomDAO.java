package com.commerzbank.gdk.bns.dao;

/**
 * Custom Key DAO Interface
 * 
 * @since 22/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 22/02/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */

public interface KeyCustomDAO {

	void deleteByKeyTyp(String keyType);

}
