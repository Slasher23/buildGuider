package com.commerzbank.gdk.bns.conf;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Aspect Class for Time Tracking of Processing Time for ZSL Web Services
 * 
 * @author ZE2BUEN
 * @since 08/02/2018
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 08/02/2018        1.00       ZE2BUEN    Initial Version
 * </pre>
 */
@Aspect
public class TimeTrackingAspect {

	private Logger LOGGER;

	@Around("execution(* com.commerzbank.gdk.bns.controller.zsl.*.*(..))")
	public Object trackTime(ProceedingJoinPoint joinPoint) {
		
		long startTime = System.currentTimeMillis();
		
		LOGGER = LoggerFactory.getLogger(joinPoint.getTarget().getClass());

		Object result = null;
		
		try {
			result = joinPoint.proceed();
		} catch (Throwable e) {
			LOGGER.error(e.getMessage(), e);
		}

		long processTime = System.currentTimeMillis() - startTime;

		LOGGER.info("[" + joinPoint.getTarget().getClass().getName() + "] Time to process method "
				+ joinPoint.getSignature().getName() + ": " + processTime + "ms");

		return result;

	}
	
}
