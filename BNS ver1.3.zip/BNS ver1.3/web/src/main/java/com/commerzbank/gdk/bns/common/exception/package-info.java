
/**
 * This package contains common classes available to the application.
 * 
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.common.exception;