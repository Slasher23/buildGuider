package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * UpdateSalutationRequest generate getter and setter
 * 
 * @since 28/11/2017
 * @author ZE2JAVO
 * @version 1.01
 *
 *          <pre>
* Modified Date   Version   Author     Description
* 28/11/2017      1.00      ZE2JAVO    Initial Version
* 09/02/2018      1.01      ZE2MACL    Added regex
 *          </pre>
 */

public class UpdateSalutationRequest {
    
    private String bpkenn;
    
    @Size(max = 2)
    @Pattern(regexp = "^[0-9]*$")
    private String salutation;
    
    @Size(max = 2)
    @Pattern(regexp = "^[0-9]*$")
    private String title;

    /**
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * @param bpkenn the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * @return the salutation
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * @param salutation the salutation to set
     */
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UpdateSalutationRequest [bpkenn=" + bpkenn + ", salutation=" + salutation + ", title=" + title + "]";
    }

}
