package com.commerzbank.gdk.bns.model;

/**
 * Model Class for AgreementNotificationRequest
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 11/12/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
public class AgreementNotificationRequest {

    String vereinbarungskennung;
    
    Integer sparte;

    /**
     * @return the vereinbarungskennung
     */
    public String getVereinbarungskennung() {
        return vereinbarungskennung;
    }

    /**
     * @param vereinbarungskennung the vereinbarungskennung to set
     */
    public void setVereinbarungskennung(String vereinbarungskennung) {
        this.vereinbarungskennung = vereinbarungskennung;
    }

    /**
     * @return the sparte
     */
    public Integer getSparte() {
        return sparte;
    }

    /**
     * @param sparte the sparte to set
     */
    public void setSparte(Integer sparte) {
        this.sparte = sparte;
    }

    /* 
     * @return
     */
    @Override
    public String toString() {
        return "AgreementNotificationRequest [vereinbarungskennung=" + vereinbarungskennung + ", sparte=" + sparte
                + "]";
    }

}
