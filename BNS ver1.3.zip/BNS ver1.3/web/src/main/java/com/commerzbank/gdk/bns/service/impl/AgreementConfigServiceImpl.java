package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementConfigService;

/**
 * Service Implementation Class used to implement the business logic in saving
 * after toggle action.
 * 
 * @since 03/08/2017
 * @author ZE2MENY
 * @version 1.04
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 03/08/2017		1.00		ZE2MENY 	InitialVersion
 * 03/10/2017		1.01		ZE2BAUL		Added the logic where the NotifText is null and 
 * 											has to be assigned an initial value
 * 14/11/2017       1.02        ZE2MACL     Updated method to used response builder and added token parameter
 * 23/11/2017       1.03        ZE2BAUL     Implemented Status Codes
 * 09/02/2018       1.04        ZE2MACL    Removed throws Exception
 *          </pre>
 */
@Transactional
@Service
public class AgreementConfigServiceImpl implements AgreementConfigService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AgreementConfigServiceImpl.class);

	@Autowired
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Autowired
	private Environment environment;

	@Autowired
	private NotificationTextDAO notificationTextDAO;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	/**
	 * Retrieves the Notification Configuration Agreement using the
	 * notificationConfigAgreement.
	 * 
	 * @param token
	 *            to identify the user
	 * @param notificationConfigAgreement
	 *            Notification Configuration Agreement to set
	 * @return NotifConfigAgreement Save Notification Configuration Agreement
	 */
	@Override
	public ResponseBuilder<NotificationConfigAgreement> postCustomer(Tokenizer token,
			NotificationConfigAgreement notificationConfigAgreement) {

		ResponseBuilder<NotificationConfigAgreement> builder = new ResponseBuilder<NotificationConfigAgreement>(LOGGER,
				token, globalResponseWrapper);

		try {

			NotificationConfigAgreement result = this.notificationConfigAgreementDAO.save(notificationConfigAgreement);

			builder.OK(result);

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] postCustomer({}) request was successfully processed.", token.getUserId(),
				notificationConfigAgreement.toString());

		return builder;
	}

	/**
	 * Retrieves the Notification Configuration Agreement using a given Unique
	 * Identifier.
	 * 
	 * @param token
	 *            to identify the user
	 * @param UID
	 *            Long Unique Identifier to set
	 * @return notificationConfigAgreement Get NotifConfigAgreement
	 */
	@Override
	public ResponseBuilder<NotificationConfigAgreement> getNotifConfigAgreementById(Tokenizer token, Long UID) {

		ResponseBuilder<NotificationConfigAgreement> builder = new ResponseBuilder<NotificationConfigAgreement>(LOGGER,
				token, globalResponseWrapper);

		try {

			NotificationConfigAgreement result = this.notificationConfigAgreementDAO.findOne(UID);

			if (Objects.nonNull(result)) {
				builder.OK(result);
			} else {
				builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
			}

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}]  getNotifConfigAgreementById({}) request was successfully processed.",
				token.getUserId(), UID.toString());

		return builder;
	}

	/**
	 * Returns the value of Notification Configuration Agreement
	 * 
	 * @param token
	 *            to identify the user
	 * 
	 * @return NotificationConfigAgreement List of Notification Configuration
	 *         Agreement
	 */
	@Override
	public ResponseBuilder<List<NotificationConfigAgreement>> getNotifConfigAgreementList(Tokenizer token) {

		ResponseBuilder<List<NotificationConfigAgreement>> builder = new ResponseBuilder<List<NotificationConfigAgreement>>(
				LOGGER, token, globalResponseWrapper);

		try {

			List<NotificationConfigAgreement> result = Lists
					.newArrayList(this.notificationConfigAgreementDAO.findAll());

			if (Objects.nonNull(result)) {
				builder.OK(result);
			} else {
				builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
			}
		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] getNotifConfigAgreementList() request was successfully processed.",
				token.getUserId());

		return builder;
	}

	/**
	 * Returns the value of Agreement Configuration
	 * 
	 * @param token
	 *            to identify the user
	 * 
	 * @return SavingNotifConfigAgreement List of Agreement Configuration
	 */
	@Override
	public ResponseBuilder<AgreementConfig> getNotifConfigAgreementsList(Tokenizer token) {

		ResponseBuilder<AgreementConfig> builder = new ResponseBuilder<AgreementConfig>(LOGGER, token,
				globalResponseWrapper);

		try {

			List<NotificationConfigAgreement> notificationConfigAgreement = Lists
					.newArrayList(this.notificationConfigAgreementDAO.findAll());

			AgreementConfig savingNotifConfigAgreement = new AgreementConfig();

			savingNotifConfigAgreement.setNotificationConfigAgreement(notificationConfigAgreement);

			if (Objects.nonNull(notificationConfigAgreement)) {
				builder.OK(savingNotifConfigAgreement);
			} else {
				builder.OK(savingNotifConfigAgreement, Response.SUCCESS_NO_RESULTS_FOUND);
			}
		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] getNotifConfigAgreementsList() request was successfully processed.",
				token.getUserId());

		return builder;
	}

	/**
	 * Retrieves the value of Saving Notification Configuration Agreement
	 * 
	 * @param token
	 *            to identify the user
	 * @param savingNotifConfigAgreement
	 *            SavingNotifConfigAgreement to set
	 * @return SavingNotifConfigAgreement Post Agreement Configuration
	 */
	@Override
	public ResponseBuilder<AgreementConfig> postNotifConfigAgreement(Tokenizer token,
			AgreementConfig savingNotifConfigAgreement) {

		ResponseBuilder<AgreementConfig> builder = new ResponseBuilder<AgreementConfig>(LOGGER, token,
				globalResponseWrapper);

		try {

			for (NotificationConfigAgreement nf : savingNotifConfigAgreement.getNotificationConfigAgreement()) {
				// insert notif text if not exist
				if (Objects.isNull(nf.getNotificationTextUID()) || nf.getNotificationTextUID() == 0) {
					Long notiftextUID = saveNotifText(token, nf.getAgreementUID());
					nf.setNotificationTextUID(notiftextUID);
				}
				this.notificationConfigAgreementDAO.save(nf);
			}

			builder.OK(savingNotifConfigAgreement);
		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] postNotifConfigAgreement({}) request was successfully processed.", token.getUserId(),
				savingNotifConfigAgreement.toString());

		return builder;
	}

	/**
	 * Save notification text
	 * 
	 * @param Tokenizer
	 *            for userId
	 * @param Long
	 *            agreementUID to set
	 * @return notificationUID
	 */
	private Long saveNotifText(Tokenizer token, Long agreementUID) {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(agreementUID);
		notifText.setEventType(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY));
		notifText.setNotificationTextType(BNSConstants.TEXT_TYPE_STD);
		notifText = this.notificationTextDAO.save(notifText);

		LOGGER.info("<<= User [{}] saveNotifText({}) request was successfully processed.", token.getUserId(),
				agreementUID.toString());

		return notifText.getNotificationTextUID();
	}
}
