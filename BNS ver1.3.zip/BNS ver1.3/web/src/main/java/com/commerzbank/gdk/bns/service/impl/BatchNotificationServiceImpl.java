package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.BatchNotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchNotification;
import com.commerzbank.gdk.bns.service.BatchNotificationService;
import com.commerzbank.gdk.bns.service.NotificationService;
import static com.commerzbank.gdk.bns.utils.GlobalProperties.*;

/**
 * Service Implementation Class used to implement request for batch notification.
 * 
 * @since 13/11/2017
 * @author ZE2GOME
 * @version 1.06
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017        1.00       ZE2GOME    Initial Version
 * 29/11/2017        1.01       ZE2BAUL    Cleanup code
 * 04/12/2017        1.02       ZE2GOME    Added JAVADOC comments
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.04       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 09/02/2018        1.05       ZE2MACL    Removed throws Exception
 * 09/03/2018        1.06       ZE2BUEN    Refactor Notification Matrix
 * </pre>
 */
@Service
public class BatchNotificationServiceImpl implements BatchNotificationService {

	@Autowired
	private NotificationService notificationService;

	/**
	 * Retrieves the value for request for batch notification.
	 * 
	 * @param notificationRequestList
	 *            List<NotificationRequest>
	 * @return batchNotificationResponseList BatchNotificationResponse
	 */
	@Override
	public BatchNotificationResponse requestForBatchNotification(RequestForBatchNotification notificationRequestList) {
		NotificationResponse response = new NotificationResponse();

		final BatchNotificationResponse batchNotificationResponseList = new BatchNotificationResponse();

		final List<NotificationResponse> notificationResponseNoError = new ArrayList<NotificationResponse>();

		final List<NotificationResponse> notificationResponseError = new ArrayList<NotificationResponse>();

		for (NotificationRequest notificationRequest : notificationRequestList.getNotificationRequest()) {
			response = this.notificationService.sendNotification(notificationRequest);

			if (response.getStatus().equalsIgnoreCase(ZSL_STATUS_OK)) {
				notificationResponseNoError.add(response);
			} else {
				notificationResponseError.add(response);
			}
		}

		batchNotificationResponseList.setNotificationResponseWithErrors(notificationResponseError);
		batchNotificationResponseList.setNotificationResponse(notificationResponseNoError);

		return batchNotificationResponseList;
	}

}
