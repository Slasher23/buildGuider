package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.Customer;

/**
 * Customer DAO Interface
 * 
 * @since 28/07/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 28/07/2017		1.00		ZE2BUEN 	Initial Version
 * 10/11/2017       1.01        ZE2SARO     Add method for getting customer using customer number
 * 29/01/2018       1.02        ZE2RUBI     Add method to get list of Customer based on PersonUid
 *          </pre>
 */

public interface CustomerDAO extends CrudRepository<Customer, Long> {

    List<Customer> findByCustomerNumber(String customerNumber);
    List<Customer> findByPersonUID(long personUid);

}
