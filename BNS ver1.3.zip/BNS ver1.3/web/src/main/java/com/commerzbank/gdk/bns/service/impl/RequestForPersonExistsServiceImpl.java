package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchPersonExistsRequest;
import com.commerzbank.gdk.bns.model.BatchPersonExistsResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonExistsRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForPersonExistsService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement the business logic in
 * RequestForPersonExists.
 * 
 * @since 7/12/2017
 * @author ZE2MENY
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 7/12/2017         1.00       ZE2MENY    Initial Version
 * 11/12/2017        1.01       ZE2MENY    Implementation of BatchProcessing
 * 12/12/2017        1.02       ZE2BUEN    Refactor/Clean up for ZSL Status Messages
 * 06/02/2018        1.03       ZE2MACL    Remove throws Exception and replace it with try catch block
 * 21/02/2018        1.04       ZE2MACL    Added required field/s validation
 *          </pre>
 */

@Service
@Transactional
public class RequestForPersonExistsServiceImpl implements RequestForPersonExistsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForPersonExistsServiceImpl.class);
    private static final String STATUS_TRUE               = "ZSL_STATUS_TRUE";
    private static final String STATUS_FALSE              = "ZSL_STATUS_FALSE";
    private static final String STATUS_FA_NOT_PROCESSED   = "ZSL_STATUS_FA_FAILED_PERSON_EXIST";
    private static final String EMPTY_STRING              = "";

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    /**
     * Method to validate if the requestedPerson exists in BNS.
     * 
     * @param request PersonExistsRequest
     * @return response ZslUpdateResponse
     */
    @Override
    public ZslUpdateResponse requestForPersonExistsResponse(PersonExistsRequest request) {
        ZslUpdateResponse response = new ZslUpdateResponse();
        String status = EMPTY_STRING;

        try {
            status = validateRequest(request);
            if (isNullOrEmpty(status)) {
                Person person = this.personDAO.findByBpkennIgnoreCase(request.getBpkenn());

                if (Objects.nonNull(person)) {
                    person.setBPKENN(request.getBpkenn());
                    status = this.environment.getProperty(STATUS_TRUE);
                } else {
                    status = this.environment.getProperty(STATUS_FALSE);
                }
            } else {
                response.setStatus(status);
            }

            response.setBpkenn(request.getBpkenn());
            response.setStatus(status);

        } catch (Exception e) {
            response.setStatus(this.environment.getProperty(STATUS_FA_NOT_PROCESSED));
            LOGGER.error(e.getMessage(), e);

        }

        return response;
    }

    /**
     * Method to validate request
     * 
     * @param request
     * @return String
     */
    private String validateRequest(PersonExistsRequest request) {
        HashSet<String> invalidFields = new HashSet<String>();
        String invalidMsg;

        if (isNullOrEmpty(request.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        invalidMsg = requiredFieldValidation.requiredField(invalidFields);

        return invalidMsg;
    }
    
    /**
     * Method to check if string is null or empty.
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
    }

    /**
     * Process client request if person exists in database.
     * 
     * @param request Parameter list of parameter
     * @return BatchPersonExistsResponse list of perosn exists response
     */
    @Override
    public BatchPersonExistsResponse requestForPersonExistsResponse(BatchPersonExistsRequest request) {

        BatchPersonExistsResponse response = new BatchPersonExistsResponse();
        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
        List<ZslUpdateResponse> personExistsResponse = new ArrayList<ZslUpdateResponse>();
        List<ZslUpdateResponse> personExistsResponseWithErrors = new ArrayList<ZslUpdateResponse>();

        for (PersonExistsRequest parameter : request.getPersonExistsRequest()) {
            zslUpdateResponse = this.requestForPersonExistsResponse(parameter);

            if (zslUpdateResponse.getStatus().equals(this.environment.getProperty(STATUS_TRUE))) {
                personExistsResponse.add(zslUpdateResponse);
            } else if (zslUpdateResponse.getStatus().equals(this.environment.getProperty(STATUS_FALSE))) {
                personExistsResponse.add(zslUpdateResponse);
            } else {
                personExistsResponseWithErrors.add(zslUpdateResponse);
            }

        }

        response.setPersonExistsResponse(personExistsResponse);
        response.setPersonExistsResponseWithErrors(personExistsResponseWithErrors);

        return response;
    }

}
