package com.commerzbank.gdk.bns;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.orm.jpa.vendor.HibernateJpaSessionFactoryBean;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.commerzbank.ccb.sc.crypto.service.SymmetricEncryptionServiceImpl;
import com.commerzbank.gdk.bns.conf.TimeTrackingAspect;
import com.commerzbank.gdk.bns.conf.filter.ZSLMDCFilter;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.utils.SettingsConfig;

/**
 * This class is the Entry Point of the application. All configuration will be
 * initialised in here upon starting of the application.
 * 
 * @author ZE2RUBI
 * @since 04/07/2017
 * @version 1.05
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/07/2017        1.00       ZE2RUBI    Initial Version
 * 11/12/2017        1.01       ZE2SARO    Remove unused logger
 * 05/02/2018        1.02       ZE2FUEN    Added registrationFilterBean for ZSLMDCFilter
 * 08/02/2018        1.03       ZE2BUEN    Added TimeTrackingAspect
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 * 15/03/2018        1.05       ZE2FUEN    Implemented ZSL filter in the securityConfig
 *          </pre>
 */

@SpringBootApplication
@ImportResource("classpath:configuration.xml")
@EnableAspectJAutoProxy
public class BNSWebApplication extends SpringBootServletInitializer implements CommandLineRunner {

    private static Logger  logger = Logger.getLogger(BNSWebApplication.class);

    @Autowired
    private ServletContext servletContext;

    @Autowired
    private Settings       settings;
       
    public static void main(String[] args) {
        SpringApplication.run(BNSWebApplication.class, args);
    }

    @Override
    public void run(String... arg0) throws Exception {

        String path = BNSWebApplication.class.getResource("/language").getPath();

        settings.setLocaleMap(SettingsConfig.initLocaleMap(path));
        logger.info("============================");
        logger.info("Initializing BNS...");
        logger.info("BNS Started Successfully!");
        logger.info("============================");
               
    }

    @Bean
    public HibernateJpaSessionFactoryBean sessionFactory() {
        return new HibernateJpaSessionFactoryBean();
    }

    @Bean
    public ContentNegotiationConfigurer configurer() {
        return new ContentNegotiationConfigurer(servletContext);
    }

    @Bean
    public Settings settings() {
        return new Settings();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*");
            }
        };
    }

    @Bean
    public SymmetricEncryptionServiceImpl symmetricEncryptionServiceImpl(){
    	return new SymmetricEncryptionServiceImpl();
    }
    
    @Bean
    public FilterRegistrationBean ZSLFilterRegistrationBean(@Autowired ZSLMDCFilter zslMdcFilter) {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean(zslMdcFilter);
        registrationBean.setEnabled(false);
        return registrationBean;
    }
    
    @Bean
    public TimeTrackingAspect timeTrackingAspect() {
        return new TimeTrackingAspect();
    }
    
}
