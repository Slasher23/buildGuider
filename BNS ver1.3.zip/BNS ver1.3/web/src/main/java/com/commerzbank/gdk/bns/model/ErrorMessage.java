package com.commerzbank.gdk.bns.model;

/**
 * Model Class for Error Message
 * 
 * @since 21/09/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description 
 * 21/09/2017        1.00       ZE2GOME    Initial Version
 * </pre>
 */
public class ErrorMessage {

	private String technicalError;
	
	private ContactList contactList;

	/**
	 *  Return Technical Error 
	 *  
	 * @return the technicalError
	 */
	public String getTechnicalError() {
		return technicalError;
	}

	/**
	 *  Set Technical Error 
	 *  
	 * @param technicalError the technicalError to set
	 */
	public void setTechnicalError(String technicalError) {
		this.technicalError = technicalError;
	}

	/**
	 *  Return Contact List 
	 * 
	 * @return the contactList
	 */
	public ContactList getContactList() {
		return contactList;
	}

	/**
	 *  Sets Contact List 
	 *  
	 * @param contactList the contactList to set
	 */
	public void setContactList(ContactList contactList) {
		this.contactList = contactList;
	}

	/**
	 * Returns the String representation of Error Message Wrapper
	 * 
	 * @return String String representation of Error Message Wrapper
	 */
	@Override
	public String toString() {
		return "ErrorMessage [technicalError=" + technicalError + ", contactList=" + contactList + "]";
	}

	
	
}
