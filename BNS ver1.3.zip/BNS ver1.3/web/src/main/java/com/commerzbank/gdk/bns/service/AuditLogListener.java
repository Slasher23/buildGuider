package com.commerzbank.gdk.bns.service;
/**
 * Interface used to access logging events listener implementation
 * 
 * @author ZE2RUBI
 * @version 1.00
 * @since 04/08/2017
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.00       ZE2RUBI   Initial Version
 * </pre>
 */
public interface AuditLogListener {
    
	void prePersist(Object object);

	void postPersist(Object object);
}
