package com.commerzbank.gdk.bns.conf.filter;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Filter class for ZSL MDC Filter
 * 
 * @author ZE2FUEN
 * @since 05/02/2018
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 05/02/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */

@Component
public class ZSLMDCFilter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ZSLMDCFilter.class);
    
    @Value("${MDC_ZSL_PROCESSRUNID}")
    private String processRunIdKey;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        try {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            String processRunId = httpRequest.getHeader(processRunIdKey);

            if (Objects.isNull(processRunId)) {
                processRunId = "null";
                LOGGER.error("Error message: {}", "Missing ProcessRunID in request");
            }

            MDC.put(processRunIdKey, processRunId);
            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }

    }

    @Override
    public void destroy() {
    }

}
