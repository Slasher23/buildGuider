package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Response for Batch Update Person.
 * 
 * @author ZE2BAUL
 * @since 21/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017	     1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "RequestForChangeConfigurationResponse")
public class ChangeConfigurationResponse {

    private String bpkenn;

    private String status;

    /**
     * Gets the bpkenn value.
     *
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * Sets the bpkenn value.
     *
     * @param bpkenn
     *            the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Gets the status value.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status value.
     *
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Returns the String representation of Request For Change Configuration
     * Response Model.
     * 
     * @return String String representation of Request For Change Configuration
     *         Response Model
     */
    @Override
    public String toString() {
        return "RequestForChangeConfigurationResponse [bpkenn= " + bpkenn + " status= " + status + "]";
    }
}
