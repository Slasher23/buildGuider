package com.commerzbank.gdk.bns.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Benachrichtigung(Notification)
 * 
 * @since 03/07/2017
 * @author ZE2MACL
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/07/2017        1.01       ZE2MACL    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 20/09/2017        1.03       ZE2BUEN    Modify AUSLOSER_UID name to remove Umlaut
 * 02/11/2017		 1.04		ZE2FUEN	   Changed NotificationTextUID to NotificationTextTyp
 * 07/12/2017        1.05       ZE2BUEN    Modified Notification model to remove table reference
 * </pre>
 */

@XmlRootElement
public class Notification {

	private Date timestampShipping;

	private String statusShipping;

	private Long informationChannelUID;

	private String notificationTextType;

	/**
	 * Returns the value of Date at which the Document was generated
	 * 
	 * @return Date Date at which the Document was generated
	 */
	public Date getTimestampShipping() {
		return timestampShipping;
	}

	/**
	 * Sets the value of Date at which the Document was generated
	 * 
	 * @param timestampShipping
	 *            Date Date at which the Document was generated to set
	 */
	public void setTimestampShipping(Date timestampShipping) {
		this.timestampShipping = timestampShipping;
	}

	/**
	 * Returns the value of Status of Shipping
	 * 
	 * @return String Status of Shipping
	 */
	public String getStatusShipping() {
		return statusShipping;
	}

	/**
	 * Sets the value of Status of Shipping
	 * 
	 * @param statusShipping
	 *            String Status of Shipping to set
	 */
	public void setStatusShipping(String statusShipping) {
		this.statusShipping = statusShipping;
	}

	/**
	 * Returns the value of Unique Identifier of Information Channel Record
	 * 
	 * @return Long Unique Identifier of Information Channel Record
	 */
	public Long getInformationChannelUID() {
		return informationChannelUID;
	}

	/**
	 * Sets the value of Unique Identifier of Information Channel Record
	 * 
	 * @param informationChannelUID
	 *            Long Unique Identifier of Information Channel Record
	 */
	public void setInformationChannelUID(Long informationChannelUID) {
		this.informationChannelUID = informationChannelUID;
	}

	/**
	 * Returns the value of Type of Notification Text
	 * 
	 * @return String Type of Notification Text
	 */
	public String getNotificationTextType() {
		return notificationTextType;
	}

	/**
	 * Sets the value of Type of Notification Text
	 * 
	 * @param notificationTextType
	 *            String Type of Notification Text
	 */
	public void setNotificationTextType(String notificationTextType) {
		this.notificationTextType = notificationTextType;
	}

	/**
	 * Returns the String representation of Notification Model
	 * 
	 * @return String String representation of Notification Model
	 */
	@Override
	public String toString() {
		return "Notification [timestampShipping=" + timestampShipping + ", statusShipping=" + statusShipping
				+ ", informationChannelUID=" + informationChannelUID + ", notificationTextType=" + notificationTextType
				+ "]";
	}

}
