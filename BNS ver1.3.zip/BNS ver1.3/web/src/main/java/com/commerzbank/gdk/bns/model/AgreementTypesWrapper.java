package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for Agreement Types
 * This class returns and sets List of Agreements and Agreement Type
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 08/08/2017        1.01       ZE2SARO    Initial Version
 * </pre>
 */

@XmlRootElement(name = "agreementTypes")
public class AgreementTypesWrapper {

	private String agreementType;
	
	private List<NotificationConfigAgreementWrapper> agreements;

	/**
	 * Returns the List of Agreements
	 * 
	 * @return List List of Agreements
	 */
	public List<NotificationConfigAgreementWrapper> getAgreements() {
		return agreements;
	}

	/**
	 * Sets the List of Agreement
	 * 
	 * @param agreements List List of Agreements to set
	 */
	public void setAgreements(List<NotificationConfigAgreementWrapper> agreements) {
		this.agreements = agreements;
	}

	/**
	 * Returns the value of Agreement Type
	 * 
	 * @return String Agreement Type
	 */
	public String getAgreementType() {
		return agreementType;
	}

	/**
	 * Sets the value of Agreement Type
	 * 
	 * @param agreementType String Agreement Type to set
	 */
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}
	
	/**
	 * Returns the String representation of Agreement Types Wrapper
	 * 
	 * @return String String representation of Agreement Types Wrapper
	 */
	@Override
	public String toString() {
		return "AgreementTypesWrapper [agreementType= " + agreementType + " , agreements= " + agreements + "]";
	}
	
}
