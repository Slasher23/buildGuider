package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Notification Response
 * 
 * @since 14/09/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 14/09/2017        1.01       ZE2BUEN    Initial Version
 * 23/11/2017        1.02       ZE2GOME    Remove s to notifications
 * </pre>
 */
@XmlRootElement(name = "NotificationResponse")
public class NotificationResponse {
	
	private String BPKENN;
	
	private List<Notifications> notification;
	
	private String status;

	/**
	 * Returns the value of BPKENN
	 * 
	 * @return String BPKENN  
	 */
	public String getBPKENN() {
		return BPKENN;
	}

	/**
	 * Sets the value of BPKENN
	 * 
	 * @param bPKENN String BPKENN to set
	 */
	public void setBPKENN(String BPKENN) {
		this.BPKENN = BPKENN;
	}
	
    /**
	 * Returns the value of Complex Notification
	 * 
	 * @return List<Notifications> Complex Notification  
	 */
    public List<Notifications> getNotification() {
        return notification;
    }

	/**
	 * Sets the value of Complex Notification
	 * 
	 * @param notifications List<Notifications> Complex Notification to set
	 */
    public void setNotification(List<Notifications> notification) {
        this.notification = notification;
    }

	/**
	 * Returns the value of Status
	 * 
	 * @return String Status  
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the value of Status
	 * 
	 * @param status String Status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Returns the String representation of Notification Response
	 * 
	 * @return String String representation of Notification Response
	 */
	@Override
	public String toString() {
		return "NotificationResponse [BPKENN=" + BPKENN + ", notification=" + notification + ", status=" + status
				+ "]";
	}

}
