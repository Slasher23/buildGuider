package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.InformationChannelService;

/**
 * InformationChannelServiceImpl -used to implement the business logic for
 * getting the Information Channel List
 * 
 * @since 08/08/2017
 * @author ZESARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 13/10/2017       1.01        ZE2MACL     Updated method to used response builder and added token parameter
 * 24/11/2017       1.02        ZE2MORA     Implemented Status Codes
 *          </pre>
 */
@Service
@Transactional
public class InformationChannelServiceImpl implements InformationChannelService {

    private static final Logger logger = LoggerFactory.getLogger(InformationChannelServiceImpl.class);

    @Autowired
    private InformationChannelDAO informationChannelDAO;
    
    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    /**
     * Retrieves the value of Information Channel
     * 
     * @return List List of Information channel
     */
    @Override
    public ResponseBuilder<List<InformationChannel>> getInformationChannelList(Tokenizer token) {

        ResponseBuilder<List<InformationChannel>> builder = new ResponseBuilder<List<InformationChannel>>(logger, token, globalResponseWrapper);

        try {

            List<InformationChannel> result = Lists
                    .newArrayList(this.informationChannelDAO.getInformationChannelList());

            if (Objects.nonNull(result)) {
                builder.OK(result);
            } else {
                builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
            }

        } catch (DataAccessException e) {
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        } catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

        logger.info("<<= User [{}] getInformationChannelList() request was successfully processed.", token.getUserId());

        return builder;
    }

}
