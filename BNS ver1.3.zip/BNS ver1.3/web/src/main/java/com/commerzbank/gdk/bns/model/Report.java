package com.commerzbank.gdk.bns.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Report Table
 * 
 * @since 04/01/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2RUBI    Initial Version
 * </pre>
 */

@Entity
@Table(name = "REPORT")
@XmlRootElement
public class Report {

	@Id
	@Column(name = "REPORT_UID")
	@GeneratedValue(generator = "REPORT_ID_SEQ")
	@SequenceGenerator(name = "REPORT_ID_SEQ", sequenceName = "REPORT_SEQ")
	private Long reportUID;
	
    @Column(name = "REPORT_TYPE")
    private String reportType;

    @Column(name = "COUNT")
    private Double count;
    
    @Column(name = "PERCENTAGE")
    private Double percentage;
    
    @Basic(optional = false)
    @Temporal(TemporalType.DATE)
    @Column(name = "REPORT_DATE", insertable = true, updatable = false)
    private Date date;
    
    @Basic(optional = false)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "REPORT_TIME", insertable = true, updatable = false)
    private Date time;
    
    public Report() {};
    
    public Report(String reportType, Double count, Double percentage, Date date) {
    	setReportType(reportType);
    	setCount(count);
    	setPercentage(percentage);
    	setDate(date);
    }

    /**
     * @return the reportUID
     */
    public Long getReportUID() {
        return reportUID;
    }

    /**
     * @param reportUID the reportUID to set
     */
    public void setReportUID(Long reportUID) {
        this.reportUID = reportUID;
    }

    /**
     * @return the reportType
     */
    public String getReportType() {
        return reportType;
    }

    /**
     * @param reportType the reportType to set
     */
    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    /**
     * @return the count
     */
    public Double getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(Double count) {
        this.count = count;
    }

    /**
     * @return the percentage
     */
    public Double getPercentage() {
        return percentage;
    }

    /**
     * @param percentage the percentage to set
     */
    public void setPercentage(Double percentage) {
        this.percentage = percentage;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the time
     */
    public Date getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(Date time) {
        this.time = time;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Report [reportUID=" + reportUID + ", reportType=" + reportType + ", count=" + count + ", percentage="
                + percentage + ", date=" + date + ", time=" + time + "]";
    }

   
    
}
