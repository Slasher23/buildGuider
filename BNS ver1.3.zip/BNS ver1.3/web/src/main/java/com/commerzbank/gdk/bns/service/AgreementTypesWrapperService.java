package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to access the Main Agreement Type Wrapper List
 * 
 * @since 07/08/2017
 * @author ZE2SARO
 * @version 1.05
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/08/2017        1.00       ZE2SARO    Initial Version
 * 22/09/2017        1.01       ZE2SARO    Change paramter bpkken to Parameter model
 * 02/10/2017	     1.02		ZE2BAUL	   Changed the AgreementEmailChannelWrapper to MainAgreementTypeWrapper
 * 10/11/2017        1.03       ZE2MACL    Updated method to used response builder and added token parameter
 * 20/02/2018        1.04       ZE2FUEN    Updated implementation to CIF-Integration
 * 28/02/2018        1.05       ZE2FUEN    Implemented BNStoken builder
 *          </pre>
 */
public interface AgreementTypesWrapperService {

    ResponseBuilder<MainAgreementTypeWrapper> getMainAgreementTypeWrapperList(Tokenizer token, List<Long> agreementUIDList);

}
