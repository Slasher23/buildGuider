package com.commerzbank.gdk.bns.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.TranslationService;

/**
 * TranslationController Accept request and return the expected record to
 * client.
 * 
 * @since 25/08/2017
 * @author ZE2MACL
 * @version 1.08
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 25/08/2017      1.01      ZE2MACL    Initial Version
 * 25/09/2017      1.02      ZE2BAUL    Refactoring of GetMapping to PostMapping
 * 28/09/2017	   1.03		 ZE2BAUL	Applied the logging standards
 * 13/10/2017	   1.04		 ZE2RUBI	Clean Up and Implement JWT
 * 27/11/2017      1.05      ZE2BAUL    Implemented Status Codes update
 * 09/02/2018      1.06      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.07      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.08      ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@RestController
public class TranslationController {

    @Autowired
    private TranslationService translationService;

    //private static final Logger LOGGER = LoggerFactory.getLogger(TranslationController.class);

    /**
     * Accepts client request and call the service to retrieve the Locale record
     * from the Settings Locale Map consumes and produces JSON or XML format
     *
     * @param bnsInternal
     *            BNS Internal (Parameter)
     * @return Locale JSON String
     * 
     */
    @PostMapping(value = "/api/translatedTexts")
    public ResponseEntity<Response<Map<String, String>>> getTranslation(HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        ResponseBuilder<Map<String, String>> builder = this.translationService.getTranslatedTexts(request, token);

        return builder.responseEntity();
    }

}
