
/**
 * This package contains the Data Access Object implementation.
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.dao.impl;