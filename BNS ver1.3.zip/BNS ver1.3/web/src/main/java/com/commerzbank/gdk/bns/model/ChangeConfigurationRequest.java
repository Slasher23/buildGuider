package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Change Configuration.
 * 
 * @author ZE2BAUL
 * @since 21/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017	     1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "RequestForChangeConfiguration")
public class ChangeConfigurationRequest {

    private String bpkenn;

    private Boolean active;

    private List<Agreements> agreements;

    /**
     * Gets the bpkenn value.
     *
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * Sets the bpkenn value.
     *
     * @param bpkenn
     *            the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Gets the active value.
     *
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Sets the active value.
     *
     * @param active
     *            the active to set
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * Gets the agreements list.
     *
     * @return the agreements
     */
    public List<Agreements> getAgreements() {
        return agreements;
    }

    /**
     * sets the list of agreements.
     *
     * @param agreements
     *            the agreements to set
     */
    public void setAgreements(List<Agreements> agreements) {
        this.agreements = agreements;
    }

    /**
     * Returns the String representation of Request For Change Configuration
     * Model.
     * 
     * @return String String representation of Request For Change Configuration
     *         Model
     */
    @Override
    public String toString() {
        return "RequestForChangeConfiguration [bpkenn= " + bpkenn + " active= " + active + " agreements= " + agreements
                        + "]";
    }
}
