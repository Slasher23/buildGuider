package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.service.RequestForRequiredNotificationService;

/**
 * RequestForRequiredNotificationController to Accept dispatch request and
 * return the expected response.
 * 
 * @since 20/09/2017
 * @author ZE2FUEN
 * @version 1.12
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 20/09/2017      1.00      ZE2FUEN    Initial Version
 * 13/10/2017	   1.01		 ZE2RUBI	Clean Up and Implement JWT
 * 27/10/2017	   1.02		 ZE2BAUL	Logging of required fields
 * 30/10/2017	   1.03		 ZE2BAUL	Added implementation for ProcessRunID requirement
 * 03/11/2017	   1.04		 ZE2BAUL	Hard coded ZSL in to the logging as System
 * 09/11/2017	   1.05		 ZE2BAUL	Implementation of BatchProcessing
 * 23/11/2017      1.06      ZE2GOME    Change the response to NotificationResponse
 * 07/12/2017      1.07      ZE2SARO    Add Validation
 * 12/12/2017      1.08      ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 13/12/2017      1.09      ZE2CRUH    Added ProcessRunID to service call
 * 13/12/2017      1.10      ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018      1.11      ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018      1.12      ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class RequestForRequiredNotificationController {

    @Autowired
    private RequestForRequiredNotificationService requestForRequiredNotificationService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForRequiredNotificationController.class);

    /**
     * Accept client post request and call service to request for required
     * notification also consumes and produces json or xml format.
     * 
     * @param request
     * 
     * @param RequestForDispatchRequest
     * @return RequestForDispatchResponse
     */
    @PostMapping(value = "/api/zsl/requestForRequiredNotification")
    public ResponseEntity<NotificationResponse> requestForRequiredNotification(
                    @Valid @RequestBody RequiredNotificationRequest requiredNotificationRequest,
                    HttpServletRequest request, BindingResult result)  {

        LOGGER.info("=>> System [{}] - requestForRequiredNotification({})", "ZSL",
                requiredNotificationRequest.toString());

        NotificationResponse notifResponse = new NotificationResponse();

        if (!result.hasErrors()) {
            notifResponse = this.requestForRequiredNotificationService
                    .requestForRequiredNotification(requiredNotificationRequest);

            if (Objects.isNull(notifResponse)) {
                notifResponse = new NotificationResponse();
            }
        }

        ResponseEntity<NotificationResponse> response = new ResponseEntity<NotificationResponse>(notifResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", notifResponse.toString());

        return response;
    }

    /**
     * Accept client post request and call service to request for required
     * notification in list also consumes and produces json or xml format
     * 
     * @param request
     * 
     * @param RequestForDispatchRequest
     * @return RequestForDispatchResponse
     */
    @PostMapping(value = "/api/zsl/requestForRequiredBatchNotification")
    public ResponseEntity<RequiredBatchNotificationResponseWrapper> requestForRequiredBatchNotification(
                    @Valid @RequestBody RequestForRequiredBatchNotification requiredBatchNotificationList,
                    HttpServletRequest request, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForRequiredBatchNotification({})", "ZSL", requiredBatchNotificationList);

        RequiredBatchNotificationResponseWrapper batchResponse = new RequiredBatchNotificationResponseWrapper();

        if (!result.hasErrors()) {
            batchResponse = this.requestForRequiredNotificationService
                            .requestForRequiredBatchNotification(requiredBatchNotificationList);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new RequiredBatchNotificationResponseWrapper();
            }
        }

        ResponseEntity<RequiredBatchNotificationResponseWrapper> response = new ResponseEntity<RequiredBatchNotificationResponseWrapper>(
                        batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;

    }
}
