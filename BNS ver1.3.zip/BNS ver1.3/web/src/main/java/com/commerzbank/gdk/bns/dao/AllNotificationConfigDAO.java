package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.AllNotificationConfig;

/**
 * AllNotificationConfig DAO Interface
 * 
 * @since 22/09/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 22/09/2017		1.00		ZE2SARO 	Initial Version
 * 09/11/2017		1.01		ZE2BUEN 	Added findByEmailUID method
 * 23/11/2017       1.02        ZE2MACL     Added findByPersonUID method and removed findByParticipantNumberUID
 * </pre>
 */
public interface AllNotificationConfigDAO extends PagingAndSortingRepository<AllNotificationConfig, Long> {
	
	AllNotificationConfig findByPersonUID(Long personUID);
	
	List<AllNotificationConfig> findByEmailUID(Long emailUID);
	
}
