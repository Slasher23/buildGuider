package com.commerzbank.gdk.bns.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class to retrieve translatedTexts
 * 
 * @since 22/02/2018 
 * @author ZE2FUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/02/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */
public interface TranslationService {
    
    ResponseBuilder<Map<String, String>> getTranslatedTexts(HttpServletRequest request, Tokenizer token);

}
