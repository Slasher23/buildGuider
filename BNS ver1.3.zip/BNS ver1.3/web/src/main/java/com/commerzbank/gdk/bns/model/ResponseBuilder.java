package com.commerzbank.gdk.bns.model;

import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * A Response Builder for managing response entity of controllers
 * 
 * @author ZE2RUBI
 * @version 1.03
 * @since 10/10/2017
 * 
 *        <pre>
 * Modified Date     Version    Author     Description
 * 23/10/2017        1.00       ZE2RUBI	   Initial Version
 * 10/11/2017        1.01       ZE2CRUH	   Added toString()
 * 23/11/2017        1.02       ZE2MORA    Added Status Codes Map Class that handle the Exceptions
 * 24/11/2017        1.03       ZE2BAUL    Modified methods for status codes implementation
 *        </pre>
 */

public class ResponseBuilder<T> {

    private T                    data;
    private Integer              code;
    private String               message;
    
    private Logger               logger;
    private Tokenizer            token;
    private Map<Integer, String> statusCode;
    
    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param data for Build
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> build(T data) {
        this.setData(data);
        return this;
    }

    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param logger for Exception Logging
     * @param token for Determining the User
     * @param globalResponse for Global Response Class
     */
    public ResponseBuilder(Logger logger, Tokenizer token, GlobalResponseWrapper globalResponse) {
        this.logger = logger;
        this.token = token;
        this.statusCode = globalResponse.getStatusCodesMap();
    }


    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param data for generic variable that accepts any object
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> OK(T data) {
        
        Objects.requireNonNull(data, "Object should not be Null.");

        this.setData(data);
        this.setCode(Response.SUCCESS_RESULTS_FOUND);
        this.setMessage(statusMessage(Response.SUCCESS_RESULTS_FOUND));

        return this;
    }

    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param code for Status Code
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> OK(Integer code) {

        Objects.requireNonNull(code, "Code should not be Null.");
        checkCode(code);

        this.setData(null);
        this.setCode(code);
        this.setMessage(statusMessage(code));

        return this;
    }

    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param data for generic variable that accepts any object
     * @param code for Status Code
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> OK(T data, Integer code) {

        Objects.requireNonNull(code, "Code should not be Null.");
        
        checkCode(code);

        this.setData(data);
        this.setCode(code);
        this.setMessage(statusMessage(code));

        return this;
    }
    
    /**
     * 
     * Constructor ResponseBuilder for notOK accepting specific message
     *
     * @param data for generic variable that accepts any object
     * @param code status code
     * @param specificMessage for specified message
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> notOK_AddMessage(T data, Integer code, String specificMessage) {
        
        this.setData(data);
        this.setCode(code);
        this.setMessage(modifiedMessage(code, specificMessage));

        return this;
    }

    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param code for Status Code
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> notOK(Integer code) {

        checkCode(code);

        this.setData(null);
        this.setCode(code);
        this.setMessage(statusMessage(code));

        logger.error(errorMessage(code));

        return this;
    }

    /**
     * 
     * Constructor ResponseBuilder
     *
     * @param code for Status Code
     * @param e for Exception
     * @return ResponseBuilder
     */
    public ResponseBuilder<T> notOK(Integer code, Exception e) {

        checkCode(code);
        
        this.setData(null);
        this.setCode(code);
        this.setMessage(statusMessage(code));

        logger.error(errorMessage(code), e);

        return this;
    }

    /**
     * 
     * Returns the value of Response
     *
     * @return new Response
     */
    public Response<T> response() {
        return new Response<T>(this.data, this.code, this.message);
    }

    /**
     * 
     * Returns the value of ResponseEntity
     *
     * @return new ResponseEntity
     */
    public ResponseEntity<Response<T>> responseEntity() {
        return new ResponseEntity<Response<T>>(response(), HttpStatus.OK);
    }

    /**
     * 
     * Returns the value of ResponseEntity
     *
     * @param headers for Response header
     * @return new ResponseEntity
     */
    public ResponseEntity<Response<T>> responseEntity(HttpHeaders headers) {
        return new ResponseEntity<Response<T>>(response(), headers, HttpStatus.OK);
    }
    
    /**
     * 
     * Returns the value of String statusMessage
     *
     * @param code for Status Code
     * @return String statusMessage
     */
    private String statusMessage(int code) {
        return code + " - " + this.getStatusCode().get(code);
    }
    
    /**
     * 
     * Returns the value of String modifiedMessage
     *
     * @param code for Status Code
     * @param specificMessage customised status message
     * @return String the modified message with original and the customised status messages
     */
    private String modifiedMessage(int code, String specificMessage) {
        return this.getStatusCode().get(code) + " - " + specificMessage;
    }
    
    /**
     * 
     * Returns the value of String errorMessage
     *
     * @param code for Status Code
     * @return String error message
     */
    private String errorMessage(int code) {
        return "<<= User [" + token.getUserId() + "]" + " - " + this.statusMessage(code);
    }

    /**
     * 
     * Check the value of code
     *
     * @param code int to Check
     */
    private void checkCode(int code) {
        if (code < 1000) {
            throw new IllegalArgumentException("Invalid Code");
        }
    }

    /**
     * 
     * Returns the value of data
     *
     * @return T data
     */
    public T getData() {
        return data;
    }

    /**
     * 
     * Set the value of Data
     *
     * @param data T to set
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     * 
     * Returns the value of code
     *
     * @return Integer code
     */
    public Integer getCode() {
        return code;
    }

    /**
     * 
     * Set the value of Code
     *
     * @param code int to set
     */
    public void setCode(Integer code) {
        this.code = code;
    }

    /**
     * 
     * Returns the value of String message
     *
     * @return String message
     */
    public String getMessage() {
        return message;
    }

    /**
     * 
     * Set the value of String message
     *
     * @param message String to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * 
     * Returns the value of logger
     *
     * @return Logger logger
     */
    public Logger getLogger() {
        return logger;
    }

    /**
     * 
     * Set the value of logger
     *
     * @param logger Logger to set
     */
    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    /**
     * 
     * Returns the value of token
     *
     * @return Tokenizer token
     */
    public Tokenizer getToken() {
        return token;
    }

    /**
     * 
     * Set the value of token
     *
     * @param token Tokenizer to set
     */
    public void setToken(Tokenizer token) {
        this.token = token;
    }

    /**
     * 
     * Returns the value of Status Code
     *
     * @return Map<Integer, String> statusCode
     */
    public Map<Integer, String> getStatusCode() {
        return statusCode;
    }

    /**
     * 
     * Set the value of Status Code
     *
     * @param statusCode Map to set
     */
    public void setStatusCode(Map<Integer, String> statusCode) {
        this.statusCode = statusCode;
    }
    
    /**
	 * Returns the String representation of Response Model class ResponseBuilder
	 * 
	 * @return String String representation of Response Model class ResponseBuilder
	 */
    @Override
    public String toString() {
        return "ResponseBuilder [data=" + data + ", code=" + code + ", message=" + message + "]";
    }

}