/**
 * 
 */
package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class used to access the Email List
 * 
 * @since 04/08/2017
 * @author ZE2SARO
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.00       ZE2SARO    Initial Version
 * 10/11/2017        1.01       ZE2MACL    Updated method to used Response builder and added token parameter
 * </pre>
 */
public interface EmailService {
	
	ResponseBuilder<List<Email>> getEmailList(Tokenizer token, String bpkenn);

}
