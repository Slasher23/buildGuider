package com.commerzbank.gdk.bns.conf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.commerzbank.frame.jws.rest.standards.CommerzbankStandardsHandlerInterceptor;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.BatchNotificationResponse;
import com.commerzbank.gdk.bns.model.ContactList;
import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsResponse;
import com.commerzbank.gdk.bns.model.CustomerInfoWrapper;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.ErrorMessage;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotifConfigPersonWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.Notification;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.PersonConfigWrapper;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;
import com.commerzbank.gdk.bns.model.RequestForDeactivatePersonResponse;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.model.RequiredNotificationResponseWithErrors;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.ResponseMessage;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.model.Trigger;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.Version;

/**
 * This class will handle web configuration.
 * 
 * @author ZE2RUBI
 * @since 04/07/2017
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/07/2017        1.00       ZE2RUBI    Initial Version
 * 12/02/2018        1.01       ZE2RUBI    Added Frame Interceptor's
 * 14/03/2018        1.02       ZE2RUBI    Added UTF-8 charset
 * </pre>
 */

@Configuration
@ComponentScan(basePackages = "com.commerzbank.gdk.bns")
public class WebConfig extends WebMvcConfigurerAdapter {

    @Autowired
    public ContentNegotiationConfigurer configurer;
    
    @Autowired
    private CommerzbankStandardsHandlerInterceptor commerzbankStandardsHandlerInterceptor;
    
    /**
     * <p>
     * This configuration will handle REST content media type. request must
     * contain a header attribute application/xml and application/json
     * <ul>
     * <li>The media default value is JSON;</li>
     * <li>Can accept and respond with JSON; and</li>
     * <li>Can accept and respond with XML.</li>
     * </ul>
     * </p>
     * 
     * @param configurer ContentNegotiationConfigurer
     * @see {@link ContentNegotiationConfigurer}
     */
    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {

        configurer.favorPathExtension(true)
        .parameterName("mediaType")
        .ignoreAcceptHeader(false).useJaf(false)
                .defaultContentType(MediaType.APPLICATION_JSON_UTF8)
                .mediaType("application/xml", MediaType.APPLICATION_XML)
                .mediaType("application/json", MediaType.APPLICATION_JSON_UTF8);

    }

    /**
     * <p>
     * This configureMessageConverters will register an XMl converter in the
     * context. Converters will handle Object MArshalling/Unmarshalling
     * <ul>
     * <li>Can Marshall/Unmarshall an XML String.</li>
     * </ul>
     * </p>
     * 
     * @param List<HttpMessageConverter<?>> ContentNegotiationConfigurer
     * @see {@link HttpMessageConverter}
     */
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> messageConverters) {

        messageConverters.add(createXmlHttpMessageConverter());

        super.configureMessageConverters(messageConverters);
    }

    /**
     * <p>
     * Initialise XStreamMarshaller and registers aliases for classes.
     * </p>
     * 
     * @see {@link XStreamMarshaller}
     */
    private HttpMessageConverter<Object> createXmlHttpMessageConverter() {
        MarshallingHttpMessageConverter xmlConverter = new MarshallingHttpMessageConverter();

        XStreamMarshaller xstreamMarshaller = new XStreamMarshaller();

        Map<String, Class<?>> fieldAliases = new HashMap<>();

        fieldAliases.put("Agreement", Agreement.class);
        fieldAliases.put("notificationConfigAgreement", AgreementConfig.class);
        fieldAliases.put("agreementTypes", AgreementTypesWrapper.class);
        fieldAliases.put("AllNotificationConfig", AllNotificationConfig.class);
        fieldAliases.put("auditLog", AuditLog.class);
        fieldAliases.put("ContactList", ContactList.class);
        fieldAliases.put("KUNDE", Customer.class);
        fieldAliases.put("CustomerBatchNotificationsRequest", CustomerBatchNotificationsRequest.class);
        fieldAliases.put("CustomerBatchNotificationsResponse", CustomerBatchNotificationsResponse.class);
        fieldAliases.put("customer", CustomerInfoWrapper.class);
        fieldAliases.put("CustomerNotificationRequest", CustomerNotificationRequest.class);
        fieldAliases.put("CustomerNotificationsResponse", CustomerNotificationsResponse.class);
        fieldAliases.put("CustomNotifConfig", CustomNotifConfig.class);
        fieldAliases.put("EMAIL", Email.class);
        fieldAliases.put("ErrorMessage", ErrorMessage.class);
        fieldAliases.put("EventType", EventType.class);
        fieldAliases.put("GlobalEventTypeWrapper", GlobalEventTypeWrapper.class);
        fieldAliases.put("GlobalResponseWrapper", GlobalResponseWrapper.class);
        fieldAliases.put("INFORMATIONS_KANAL", InformationChannel.class);
        fieldAliases.put("MainAgreementTypeWrapper", MainAgreementTypeWrapper.class);
        fieldAliases.put("agreements", NotifConfigPersonWrapper.class);
        fieldAliases.put("BENACHRICHTIGUNG", Notification.class);
        fieldAliases.put("NotificationConfigAgreement", NotificationConfigAgreement.class);
        fieldAliases.put("agreements", NotificationConfigAgreementWrapper.class);
        fieldAliases.put("NotificationConfigPerson", NotificationConfigPerson.class);
        fieldAliases.put("NotificationMatrixChannel", NotificationMatrixChannel.class);
        fieldAliases.put("NotificationMatrixResponse", NotificationMatrixResponse.class);
        fieldAliases.put("NotificationRequest", NotificationRequest.class);
        fieldAliases.put("NotificationResponse", NotificationResponse.class);
        fieldAliases.put("Notifications", Notifications.class);
        fieldAliases.put("BENACHRICHTIGUNGS_TEXT", NotificationText.class);
        fieldAliases.put("notifTextAndAgreementConfigWrapper", NotifTextAgreementConfigWrapper.class);
        fieldAliases.put("notifTextAndPersonConfigWrapper", NotifTextPersonConfigWrapper.class);
        fieldAliases.put("Parameter", Parameter.class);
        fieldAliases.put("PERSON", Person.class);
        fieldAliases.put("notificationConfigPerson", PersonConfig.class);
        fieldAliases.put("personConfigType", PersonConfigWrapper.class);
        fieldAliases.put("PUSH_KONFIG", PushConfiguration.class);
        fieldAliases.put("PushConfigurationRequest", PushConfigurationRequest.class);
        fieldAliases.put("PushConfigurationResponse", PushConfigurationResponse.class);
        fieldAliases.put("RequiredBatchNotificationResponseWrapper", RequiredBatchNotificationResponseWrapper.class);
        fieldAliases.put("RequiredNotificationRequest", RequiredNotificationRequest.class);
        fieldAliases.put("RequiredNotificationResponseWithErrors", RequiredNotificationResponseWithErrors.class);
        fieldAliases.put("Response", Response.class);
        fieldAliases.put("ResponseBuilder", ResponseBuilder.class);
        fieldAliases.put("ResponseMessage", ResponseMessage.class);
        fieldAliases.put("Settings", Settings.class);
        fieldAliases.put("Tokenizer", Tokenizer.class);
        fieldAliases.put("AUSLOSER", Trigger.class);
        fieldAliases.put("auditLog", AuditLog.class);
        fieldAliases.put("Version", Version.class);
        fieldAliases.put("UpdateSalutationRequests", UpdateSalutationRequests.class);
        fieldAliases.put("BatchNotificationResponse", BatchNotificationResponse.class);
        fieldAliases.put("RequestForDeactivatePersonResponse", RequestForDeactivatePersonResponse.class);

        xstreamMarshaller.setAliases(fieldAliases);

        xmlConverter.setMarshaller(xstreamMarshaller);
        xmlConverter.setUnmarshaller(xstreamMarshaller);

        return xmlConverter;
    }
    
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // LogInterceptor apply to all URLs.
        registry.addInterceptor(commerzbankStandardsHandlerInterceptor).addPathPatterns("/**");

        // Old Login url, no longer use.
        // Use OldURLInterceptor to redirect to a new URL.
        // registry.addInterceptor(new OldLoginInterceptor())//
        // .addPathPatterns("/admin/oldLogin");

        // This interceptor apply to URL like /admin/*
        // Exclude /admin/oldLogin
        // registry.addInterceptor(new AdminInterceptor())//
        // .addPathPatterns("/admin/*")//
        // .excludePathPatterns("/admin/oldLogin");
    }
    
    //Temporary
    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        super.configurePathMatch(configurer);

        configurer.setUseSuffixPatternMatch(false);
    }
    
}
