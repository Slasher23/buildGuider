package com.commerzbank.gdk.bns.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.PushConfigurationCustomDAO;
import com.commerzbank.gdk.bns.model.PushConfiguration;

/**
 * DAO Implementation Class for Push Configuration
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2BUEN    Initial Version
 * 23/10/2017        1.01       ZE2SARO    Change personUId for getting push config
 *          </pre>
 */

@Repository
public class PushConfigurationDAOImpl implements PushConfigurationCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    /**
     * Retrieves List of Push Configuration records using a given Unique
     * Identifier of personUID record
     * 
     * @param personUID Long Unique Identifier of person Record to set
     * @return List List of Push Configuration Records
     */
    @Override
    public List<PushConfiguration> getPushConfiguration(Long personUID) {

        List<PushConfiguration> pushConfigurationList = null;
        TypedQuery<PushConfiguration> query = this.entityManager
                        .createQuery("FROM PushConfiguration WHERE personUID = :personUID", PushConfiguration.class)
                        .setParameter("personUID", personUID);
        if (query.getResultList().size() != 0)
            pushConfigurationList = query.getResultList();

        return pushConfigurationList;
    }

    /**
     * Retrieves Push Configuration record using a given Unique Identifier of
     * person record and Device ID
     * 
     * @param personUID Long Unique Identifier of person Record to set
     * @param deviceID String Device ID to set
     * @return PushConfiguration Push Configuration Record
     */
    @Override
    public PushConfiguration getPushConfiguration(Long personUID, String deviceID) {

        PushConfiguration pushConfiguration = null;
        TypedQuery<PushConfiguration> query = this.entityManager
                        .createQuery("FROM PushConfiguration WHERE personUID = :personUID AND deviceID = :deviceID",
                                        PushConfiguration.class)
                        .setParameter("personUID", personUID).setParameter("deviceID", deviceID);
        if (query.getResultList().size() != 0)
            pushConfiguration = query.setMaxResults(1).getSingleResult();

        return pushConfiguration;
    }

}
