package com.commerzbank.gdk.bns.dao.db2.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.db2.KeyDB2CustomDAO;
import com.commerzbank.gdk.bns.model.db2.KeyDB2;

/**
 * DAO Implementation Class to get the result of key database stored procedure
 * 
 * @since 21/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 21/02/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
@Repository
public class KeyDB2DAOImpl implements KeyDB2CustomDAO {

	/**
	 * Logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(KeyDB2DAOImpl.class);

	/**
	 * DB2 JDBC Template
	 */
	@Autowired
	@Qualifier("db2JdbcTemplate")
	JdbcTemplate db2JdbcTemplate;
	
	/**
	 * Call Key Database DB2 Stored Procedure (ZZG91SPR)
	 * 
	 * @param keyType String Key Type
	 * @return result KeyDB2 
	 */
	@Override
	public KeyDB2 callStoredProcedure(String keyType) {

		Connection dbConnection = null;
		CallableStatement callableStatement = null;

		String storedProc = "{CALL CB.ZZG91SPR(?,?,?,?,?,?,?,?,?,?,?)}";

		KeyDB2 result = null;

		try {

			dbConnection = this.db2JdbcTemplate.getDataSource().getConnection();
			
			logger.info("Key DB2 Driver Name: " + dbConnection.getMetaData().getDriverName());
			logger.info("Key DB2 Driver Version: " + dbConnection.getMetaData().getDriverVersion());
			
			callableStatement = dbConnection.prepareCall(storedProc);
			callableStatement.setString(1, "ZZG91SPR");
			callableStatement.setString(2, "");
			callableStatement.setString(3, keyType);
			callableStatement.setString(4, "");
			callableStatement.setString(5, "");
			callableStatement.registerOutParameter(6, Types.CHAR);
			callableStatement.registerOutParameter(7, Types.CHAR);
			callableStatement.registerOutParameter(8, Types.CHAR);
			callableStatement.registerOutParameter(9, Types.CHAR);
			callableStatement.registerOutParameter(10, Types.NUMERIC);
			callableStatement.registerOutParameter(11, Types.CHAR);

			// execute ZZG91SPR stored procedure
			callableStatement.execute();
			
			result = new KeyDB2();
			result.setRCD(callableStatement.getString(6));
			result.setSqlCode(callableStatement.getString(7));
			result.setSqlCa(callableStatement.getString(8));
			result.setErrorText(callableStatement.getString(9));
			result.setCount(callableStatement.getInt(10));
			result.setData(callableStatement.getString(11));

		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
		} finally {

			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					logger.error(e.getMessage(), e);
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					logger.error(e.getMessage(), e);
				}
			}

		}

		return result;

	}

}
