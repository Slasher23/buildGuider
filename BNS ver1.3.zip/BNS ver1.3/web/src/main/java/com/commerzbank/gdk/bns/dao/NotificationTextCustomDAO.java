package com.commerzbank.gdk.bns.dao;

import com.commerzbank.gdk.bns.model.NotificationText;

/**
 * Custom Notification Text DAO Interface to get the Notification 
 * Text List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	Initial Version
 * 27/09/2017		1.01		ZE2SARO 	Relationship of agreement and notif text is 1:1
 * </pre>
 */

public interface NotificationTextCustomDAO {
	
	NotificationText getNotifText(String eventType, Long eventId);
}
