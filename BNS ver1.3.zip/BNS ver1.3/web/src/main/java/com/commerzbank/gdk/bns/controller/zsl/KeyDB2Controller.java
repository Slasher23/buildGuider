package com.commerzbank.gdk.bns.controller.zsl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.service.db2.KeyDB2Service;

/**
 * KeyDB2Controller - Controller class to get the result of key database stored
 * procedure
 * 
 * @since 05/03/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 05/03/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
@RestController
public class KeyDB2Controller {

	private static final Logger LOGGER = LoggerFactory.getLogger(KeyDB2Controller.class);

	@Autowired
	private KeyDB2Service keyDB2Service;

	@Autowired
	private KeyService keyService;

	@GetMapping(value = "/api/keyDB2")
	public ResponseEntity<String> keyDB2(HttpServletRequest request) {

		// Key DB2
		Tokenizer token = new Tokenizer();
		token.setUserId("BNS-KEY DB2");

		LOGGER.info("=>> User [{}] keyDB2()", token.getUserId());

		List<Key> keyList = new ArrayList<>();

		// Salutation Key Records
		try {
			// Extract Salutation Key Records from DB2
			keyList = keyDB2Service.extractKeyDB2Records("PAKTL", token);

			if (!keyList.isEmpty()) {

				// Delete Salutation Key Records
				keyService.deleteKeyRecords("PAKTL", token);
			}

			LOGGER.info("BNS KEY DB2: Deleting Salutation Key Records Successful ");

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		try {

			if (!keyList.isEmpty()) {

				// Save Salutation Key Records from DB2
				keyService.savingKeyRecords(keyList, token);
			}

			LOGGER.info("BNS KEY DB2: Saving Salutation Key Records Successful ");

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		// Title Key Records
		keyList = new ArrayList<>();

		try {

			// Extract Title Key Records from DB2
			keyList = keyDB2Service.extractKeyDB2Records("BBANR", token);

			if (!keyList.isEmpty()) {

				// Delete Title Key Records
				keyService.deleteKeyRecords("BBANR", token);
			}

			LOGGER.info("BNS KEY DB2: Deleting Title Key Records Successful ");

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		try {

			if (!keyList.isEmpty()) {

				// Save Title Key Records from DB2
				keyService.savingKeyRecords(keyList, token);
			}

			LOGGER.info("BNS KEY DB2: Saving Title Key Records Successful ");

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
