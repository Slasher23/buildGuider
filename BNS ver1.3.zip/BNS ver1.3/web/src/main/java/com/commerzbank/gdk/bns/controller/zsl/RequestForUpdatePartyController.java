package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.BatchUpdatePartyRequest;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePartyResponse;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForBatchUpdatePartyService;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;

/**
 * RequestForUpdatePartyController - Accept update party request and return the
 * update party response to ZSL.
 * 
 * @since 07/12/2017
 * @author ZE2GOME
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2SARO    Add validation
 * 13/12/2017        1.02       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.03       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.04      ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class RequestForUpdatePartyController {

    @Autowired
    private RequestForUpdatePartyService requestForUpdatePartyService;

    @Autowired
    private RequestForBatchUpdatePartyService requestForBatchUpdatePartyService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForUpdatePartyController.class);

    /**
     * Accept client post update party then call service to get updated party
     * response. Also produces XML or JSON format.
     * 
     * @param updatePartyRequest
     *            UpdatePartyRequest
     * @param request
     *            HttpServletRequest
     * @return response ZslUpdateResponse
     */
    @PostMapping(value = "/api/zsl/requestForUpdateParty")
    public ResponseEntity<ZslUpdateResponse> requestForUpdateParty(
            @Valid @RequestBody UpdatePartyRequest updatePartyRequest, HttpServletRequest request, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForUpdateParty({})", "ZSL", updatePartyRequest.toString());
        ZslUpdateResponse updateResponse = new ZslUpdateResponse();

        if (!result.hasErrors()) {
            updateResponse = this.requestForUpdatePartyService.requestForUpdateParty(updatePartyRequest);

            if (Objects.isNull(updateResponse)) {
                updateResponse = new ZslUpdateResponse();
            }
        }

        ResponseEntity<ZslUpdateResponse> response = new ResponseEntity<>(updateResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", updateResponse.toString());

        return response;
    }

    /**
     * Accept client post batch update party then call service to get batch
     * updated party response. Also produces XML or JSON format.
     * 
     * @param updatePartyRequest
     *            UpdatePartyRequest
     * @param request
     *            HttpServletRequest
     * @return response RequestForBatchUpdatePartyResponse
     */
    @PostMapping(value = "/api/zsl/requestForBatchUpdateParty")
    public ResponseEntity<RequestForBatchUpdatePartyResponse> requestForBatchUpdateParty(
            @Valid @RequestBody BatchUpdatePartyRequest updatePartyRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForBatchUpdateParty({})", "ZSL", updatePartyRequest.toString());
        RequestForBatchUpdatePartyResponse batchResponse = new RequestForBatchUpdatePartyResponse();

        if (!result.hasErrors()) {
            batchResponse = this.requestForBatchUpdatePartyService.requestForBatchUpdateParty(updatePartyRequest);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new RequestForBatchUpdatePartyResponse();
            }

        }

        ResponseEntity<RequestForBatchUpdatePartyResponse> response = new ResponseEntity<>(batchResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;
    }

}
