package com.commerzbank.gdk.bns.dao;

/**
 * Custom ScheduleLocker DAO Interface to get the current active node
 * 
 * @since 14/02/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 14/02/2018		1.00		ZE2RUBI 	Initial Version
 * </pre>
 */

public interface ScheduleLockerCustomDAO {
	
	
	boolean getActiveScheduleLocker(String nodeName);
    
}
