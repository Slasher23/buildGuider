package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Customer Advisor Log.
 * 
 * @since 05/01/2018
 * @author ZE2MACL
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 05/01/2018        1.00       ZE2MACL    Initial Version
 *          </pre>
 */

@XmlRootElement(name = "customerAdvisorLog")
public class CustomerAdvisorLog {

    
    private String bpkenn;

    private String agreementID;

    private String customerEmail;

    private String agreementActive;

    private String customerAdvisorsWindowsID;
    
    /**
     * Returns the value of bpkenn
     * 
     * @return String bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }
    
    /**
     * Sets the value of bpkenn
     * 
     * @param bpkenn String bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }
    
    /**
     * Returns the value of agreementID
     * 
     * @return String agreementID
     */
    public String getAgreementID() {
        return agreementID;
    }
    
    /**
     * Sets the value of agreementID
     * @param agreementID String agreementID to set
     */
    public void setAgreementID(String agreementID) {
        this.agreementID = agreementID;
    }
    
    /**
     * Returns the value of customer email
     * @return String customerEmail
     */
    public String getCustomerEmail() {
        return customerEmail;
    }

    /**
     * Sets the value of customer email
     * @param customerEmail String customerEmail to set
     */
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
    
    /**
     * Returns the value of agreementActive
     * @return String agreementActive
     */
    public String getAgreementActive() {
        return agreementActive;
    }
    
    /**
     * Sets the value of agreementActive
     * @param agreementActive String agreementActive to set
     */
    public void setAgreementActive(String agreementActive) {
        this.agreementActive = agreementActive;
    }
    
    /**
     * Returns the value of customerAdvisorWindowsID
     * @return String customerAdvisorWindowsID
     */
    public String getCustomerAdvisorsWindowsID() {
        return customerAdvisorsWindowsID;
    }
    
    /**
     * Sets the value of customerAdvisorWindowsID
     * @param customerAdvisorsWindowsID String customerAdvisorWindowsID to set
     */
    public void setCustomerAdvisorsWindowsID(String customerAdvisorsWindowsID) {
        this.customerAdvisorsWindowsID = customerAdvisorsWindowsID;
    }
    
    /**
     * Returns the String representation of Customer Advisor Log Model
     * 
     * @return String String representation of Customer Advisor Log Model
     */
    @Override
    public String toString() {
        return "CustomerAdvisorLog [bpkenn=" + bpkenn + ", agreementID=" + agreementID + ", customerEmail="
                        + customerEmail + ", agreementActive=" + agreementActive + ", customerAdvisorsWindowsID="
                        + customerAdvisorsWindowsID + "]";
    }

}
