package com.commerzbank.gdk.bns.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Audit Log.
 * 
 * @since 04/08/2017
 * @author ZE2MACL
 * @version 1.05
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.01       ZE2MACL    Initial Version
 * 04/10/2017        1.02       ZE2MACK    Remove timestamp formatting for toString method
 * 23/11/2017        1.03       ZE2BUEN    Removed USER_NUMBER, TECHNICAL_USER_NUMBER and EMAIL_ADDRESS
 * 07/12/2017        1.04       ZE2BUEN    Modified Audit Log model to remove table reference
 * 21/12/2017        1.05       ZE2MORA    Added bpkenn String getter and setter
 *          </pre>
 */

@XmlRootElement(name = "auditLog")
public class AuditLog {

    /**
     * eventType for AuditLog.
     */
    private String eventType;

    /**
     * description for AuditLog.
     */
    private String description;

    /**
     * timestamp for AuditLog.
     */
    private Date timestamp;

    /**
     * userID for AuditLog.
     */
    private String userID;

    /**
     * objectType for AuditLog.
     */
    private String objectType;

    /**
     * objectID for AuditLog.
     */
    private String objectID;

    /**
     * oldValue for AuditLog.
     */
    private String oldValue;

    /**
     * newValue for AuditLog.
     */
    private String newValue;

    /**
     * bpkenn for AuditLog.
     */
    private String bpkenn;

    /**
     * Returns the value of Event Type of Audit Log.
     * 
     * @return String Event Type of Audit Log.
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * Sets the value of Event Type of Audit Log.
     * 
     * @param eventType
     *            String Event Type of Audit Log to set.
     */
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * Returns the value of Description of Audit Log.
     * 
     * @return String Description of Audit Log.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of Description of Audit Log.
     * 
     * @param description
     *            String Description of Audit Log to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the value of Timestamp on which the Audit Log is saved.
     * 
     * @return Date Timestamp on which the Audit Log is saved.
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of Timestamp on which the Audit Log is saved.
     * 
     * @param timestamp
     *            Date Timestamp on which the Audit Log is saved to set.
     */
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Returns the value of User ID of the User who created, updated or deleted.
     * the Data
     * 
     * @return String User ID of the User who created, updated or deleted the.
     *         Data
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of User ID of the User who created, updated or deleted the.
     * Data
     * 
     * @param userID
     *            String User ID of the User who created, updated or deleted the
     *            Data to set.
     */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    /**
     * Returns the value of the Affected Table Name.
     * 
     * @return String Affected Table Name
     */
    public String getObjectType() {
        return objectType;
    }

    /**
     * Sets the value of the Affected Table Name.
     * 
     * @param objectType
     *            String Affected Table Name to set.
     */
    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    /**
     * Returns the value of the Unique Identifier of the Affected Table.
     * 
     * @return String Unique Identifier of the Affected Table.
     */
    public String getObjectID() {
        return objectID;
    }

    /**
     * Sets the value of the Unique Identifier of the Affected Table.
     * 
     * @param objectID
     *            String Unique Identifier of the Affected Table to set.
     */
    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    /**
     * Returns the Old Value.
     * 
     * @return String Old Value.
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the Old Value.
     * 
     * @param oldValue
     *            String Old Value to set.
     */
    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    /**
     * Returns the New Value.
     * 
     * @return String New Value.
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * Sets the New Value.
     * 
     * @param newValue
     *            String New Value to set.
     */
    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    /**
     * Returns the value of bpkenn.
     * 
     * @return String bpkenn.
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * Sets the value of bpkenn.
     * 
     * @param bpkenn
     *            String bpkenn to set.
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Returns the String representation of Audit Log Model.
     * 
     * @return String String representation of Audit Log Model.
     */
    @Override
    public String toString() {
        return "AuditLog [eventType=" + eventType + ", description=" + description + ", timestamp=" + timestamp
                + ", userID=" + userID + ", bpkenn=" + bpkenn + ", objectType=" + objectType + ", objectID=" + objectID
                + ", oldValue=" + oldValue + ", newValue=" + newValue + "]";
    }

}
