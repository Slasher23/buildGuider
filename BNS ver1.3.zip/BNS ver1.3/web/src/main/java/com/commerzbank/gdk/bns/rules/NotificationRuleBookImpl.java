package com.commerzbank.gdk.bns.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.service.StoredProcedureService;
import static com.commerzbank.gdk.bns.utils.GlobalProperties.*;

/**
 * Service Implementation Class used to implement business logic service in
 * DispatchRuleBook
 * 
 * @since 26/10/2017
 * @author ZE2GOME
 * @version 1.09
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2GOME    Initial Version
 * 23/11/2017        1.01       ZE2SARO    Remove Participant
 * 01/12/2017        1.02       ZE2GOME    Add condition for push configuration in decision one
 * 07/12/2017        1.03       ZE2GOME    Remove global variables
 * 12/12/2017        1.04       ZE2BUEN    Refactor/clean up for status messages
 * 04/01/2018        1.05       ZE2MACL    Added decision level two Implementation and call stored procedure
 * 01/02/2018        1.06       ZE2MACL    Remove general exception(throws exception)
 * 20/02/2018        1.07       ZE2MACL    Added error message status
 * 05/03/2018        1.08       ZE2BUEN    Updated validateDecisionTwo method
 * 09/03/2018        1.09       ZE2BUEN    Refactor Notification Matrix
 * </pre>
 */
@Service
public class NotificationRuleBookImpl implements NotificationRuleBook {

	@Autowired
	private NotificationConfigPersonDAO notificationConfigPersonDao;

	@Autowired
	private NotificationConfigAgreementDAO notificationAgreementDao;

	@Autowired
	private EmailDAO emailDao;

	@Autowired
	private PersonDAO personDao;

	@Autowired
	private AgreementDAO agreementDao;

	@Autowired
	private PushConfigurationDAO pushConfigDao;

	@Autowired
	private StoredProcedureService storedProcedureService;

	/**
	 * Check decision level.
	 * 
	 * @param personUID Long
	 * @param isAgreementRelated boolean
	 * @param branch Integer
	 * @param agreementId String
	 * @return notificationResponse NotificationMatrixResponse
	 */
	@Override
	public NotificationMatrixResponse checkDecisionLevel(String bpkenn, Integer branch, String agreementID,
			boolean isAgreementRelated) {

		NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

		String decisionOne = this.decisionLevelOne(bpkenn, isAgreementRelated, branch, agreementID);

		if (decisionOne.equals(BNSConstants.EMPTY_STRING)) {

			Person person = this.personDao.findByBpkennIgnoreCase(bpkenn);
			notificationResponse = this.validateDecisionTwo(person.getPersonUID(), bpkenn, isAgreementRelated, branch,
					agreementID);

		} else {
			List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
			notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, decisionOne);
		}

		return notificationResponse;
	}

	/**
	 * Validate decision level three.
	 * 
	 * @param bpkenn String
	 * @param branch Integer
	 * @param isAgreementRelated Boolean
	 * @param agreementId String
	 * @param NotificationMatrixResponse decisionTwo
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse validateDecisionThree(String bpkenn, Integer branch, String agreementId, NotificationMatrixResponse decisionTwo) {

		NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

		String decisionThree = this.decisionLevelThree(bpkenn, agreementId, branch);

		if (decisionThree.equalsIgnoreCase("01")) {
			notificationResponse = decisionTwo;
		} else if (decisionThree.equalsIgnoreCase("02")) {
			this.storedProcedureService.deletePersonRelated(bpkenn);
			notificationResponse.setStatus(ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		} else if (decisionThree.equalsIgnoreCase("03")) {
			this.storedProcedureService.deleteAgreementRelated(agreementId, branch);
			notificationResponse.setStatus(ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		} else if (decisionThree.equalsIgnoreCase("04")) {
			notificationResponse.setStatus(ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		} else {
			notificationResponse.setStatus(ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		}

		return notificationResponse;
	}

	/**
	 * Validate decision level two.
	 * 
	 * @param personUID Long
	 * @param bpkenn String
	 * @param isAgreementRelated boolean
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse validateDecisionTwo(Long personUID, String bpkenn, boolean isAgreementRelated,
			Integer branch, String agreementId) {

		NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

		notificationResponse = this.decisionLevelTwo(personUID, isAgreementRelated, branch, agreementId);

		if (notificationResponse.getStatus().equals("SUCCESSFUL")) {
			notificationResponse = this.validateDecisionThree(bpkenn, branch, agreementId, notificationResponse);
		}

		return notificationResponse;

	}

	/**
	 * Check decision level one.
	 * 
	 * @param bpkenn String
	 * @param isAgreementRelated boolean
	 * @param agreementID String
	 * @return decision String
	 */
	private String decisionLevelOne(String bpkenn, boolean isAgreementRelated, Integer branch, String agreementID) {

		String decision = BNSConstants.EMPTY_STRING;

		Person person = this.personDao.findByBpkennIgnoreCase(bpkenn);

		if (Objects.nonNull(person)) {

			if (isAgreementRelated) {
				Agreement agreement = this.agreementDao
						.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(person.getPersonUID(), agreementID, branch);

				if (Objects.isNull(agreement)) {
					decision = ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST;
				}
			}

		} else {
			decision = ZSL_STATUS_FA_BPKENN_NOT_EXISTS;
		}

		return decision;

	}

	/**
	 * Check decision level two.
	 * 
	 * @param personUID Long
	 * @param isAgreementRelated boolean
	 * @param branch Integer
	 * @return decision boolean
	 */
	private NotificationMatrixResponse decisionLevelTwo(Long personUID, boolean isAgreementRelated, Integer branch,
			String agreementId) {
		
		NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

		if (isAgreementRelated) {

			NotificationConfigAgreement notificationConfigAgreement = this.notificationAgreementDao
					.findByAgreementUID(personUID, branch, agreementId);

			if (Objects.isNull(notificationConfigAgreement)) {
				notificationResponse = this.validatePushAndEmailConfig(null, personUID, false);
			} else {
				notificationResponse = this.validatePushAndEmailConfig(notificationConfigAgreement.getEmailUID(),
						personUID, notificationConfigAgreement.getActive());
			}

		} else {

			NotificationConfigPerson notificationConfigPerson = this.notificationConfigPersonDao
					.findByPersonUID(personUID);

			if (Objects.isNull(notificationConfigPerson)) {
				notificationResponse = this.validatePushAndEmailConfig(null, personUID, false);
			} else {
				notificationResponse = this.validatePushAndEmailConfig(notificationConfigPerson.getEmailUID(),
						personUID, notificationConfigPerson.getActive());
			}

		}

		return notificationResponse;
	}
	
	/**
	 * Check decision level three. Call stored procedure service for validation
	 * of return String.
	 * 
	 * @param bpkeen String
	 * @param agreementID String
	 * @param branch Integer
	 * @return String
	 */
	private String decisionLevelThree(String bpkenn, String agreementId, Integer branch) {
		
		String result = storedProcedureService.validateAccount(bpkenn, agreementId, branch);

		return result;
		
	}

	/**
	 * Validate push and email configuration
	 * 
	 * @param emailUID Long
	 * @param personUID Long
	 * @param active boolean
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse validatePushAndEmailConfig(Long emailUID, Long personUID, boolean active) {

		NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();
		Email mail = this.emailDao.findByEmailUID(emailUID);
		
		List<PushConfiguration> pushConfig = this.pushConfigDao.getPushConfiguration(personUID);
		List<PushConfiguration> pushConfigActive = new ArrayList<>();
		
		if(Objects.nonNull(pushConfig)) {
			pushConfigActive = this.pushConfigStatusChecking(pushConfig);
		}
		
		if (Objects.isNull(mail) && Objects.isNull(pushConfig)) {
			notificationResponse.setStatus(ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		} else if (!pushConfigActive.isEmpty() && active) {
			notificationResponse = this.setEmailAndPushConfig(notificationResponse, mail.getEmailAddress(),
					pushConfigActive);
		} else if (active) {
			notificationResponse = this.setEmailConfig(notificationResponse, mail.getEmailAddress());
		} else if (!pushConfigActive.isEmpty()) {
			notificationResponse = this.setPushConfig(notificationResponse, pushConfigActive);
		} else if (!active) {
			notificationResponse.setStatus(ZSL_STATUS_FA_NO_ACTIVATED_CONFIG);
			notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
		} 

		return notificationResponse;
	}

	/**
	 * Set email configuration
	 * 
	 * @param notificationResponse
	 * @param emailAddress
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse setEmailConfig(NotificationMatrixResponse notificationResponse,
			String emailAddress) {

		List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();
		NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
		notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
		notificationMatrixChannel.setNotificationPath(emailAddress);
		notificationMatrixChannelList.add(notificationMatrixChannel);
		notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

		return notificationResponse;
	}

	/**
	 * Set push configuration.
	 * 
	 * @param notificationResponse
	 * @param pushConfigActive
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse setPushConfig(NotificationMatrixResponse notificationResponse,
			List<PushConfiguration> pushConfigActive) {

		List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();

		for (PushConfiguration push : pushConfigActive) {
			NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
			notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
			notificationMatrixChannel.setNotificationPath(push.getDeviceID());
			notificationMatrixChannelList.add(notificationMatrixChannel);
		}

		notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

		return notificationResponse;
	}

	/**
	 * Set email and push configuration
	 * 
	 * @param notificationResponse
	 * @param path
	 * @param pushConfigActive
	 * @return notificationResponse NotificationMatrixResponse
	 */
	private NotificationMatrixResponse setEmailAndPushConfig(NotificationMatrixResponse notificationResponse,
			String path, List<PushConfiguration> pushConfigActive) {

		List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();
		NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
		notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
		notificationMatrixChannel.setNotificationPath(path);
		notificationMatrixChannelList.add(notificationMatrixChannel);

		for (PushConfiguration push : pushConfigActive) {
			NotificationMatrixChannel notificationForPush = new NotificationMatrixChannel();
			notificationForPush.setInformationChannelType(InformationChannelTypeE.PUSH);
			notificationForPush.setNotificationPath(push.getDeviceID());
			notificationMatrixChannelList.add(notificationForPush);
		}

		notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

		return notificationResponse;
	}

	/**
	 * check if push configuration is active.
	 * 
	 * @param pushConfiguration List of push configuration
	 * @return boolean status of push configuration
	 */
	private List<PushConfiguration> pushConfigStatusChecking(List<PushConfiguration> pushConfiguration) {

		List<PushConfiguration> pushConfigurationActiveList = new ArrayList<>();
		if (Objects.nonNull(pushConfiguration)) {
			for (PushConfiguration pc : pushConfiguration) {
				if (pc.getActive()) {
					pushConfigurationActiveList.add(pc);
				}
			}
		}

		return pushConfigurationActiveList;
	}

	/**
	 * 
	 * Return Dispatch matrix response
	 * 
	 * @param List<DispatchChannelTypeE>
	 *            dispatchChannelTypeList
	 * @param status
	 *            String
	 * @return dispatchMatrixResponse DispatchMatrixResponse
	 * 
	 */
	private NotificationMatrixResponse setNotificationMatrix(List<NotificationMatrixChannel> notificationMatrixChannel,
			String status) {

		NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
		notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannel);
		notificationMatrixResponse.setStatus(status);

		return notificationMatrixResponse;
	}

}
