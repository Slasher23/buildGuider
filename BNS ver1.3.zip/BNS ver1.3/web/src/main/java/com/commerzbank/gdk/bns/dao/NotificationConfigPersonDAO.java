package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.NotificationConfigPerson;

/**
 * Notification Configuration Person DAO Interface
 * 
 * @since 28/07/2017
 * @author ZE2BUEN
 * @version 1.04
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 28/07/2017       1.00        ZE2BUEN     Initial Version
 * 02/10/2017       1.01        ZE2BAUL     Added findByParticipantNumberUID method
 * 09/11/2017       1.02        ZE2BUEN     Added findByEmailUID method
 * 23/11/2017       1.03        ZE2SARO     Change method for getting notif config person
 * 05/01/2018       1.04        ZE2BUEN     Added query method findByPersonUIDAndActive
 * </pre>
 */

public interface NotificationConfigPersonDAO extends PagingAndSortingRepository<NotificationConfigPerson, Long> {

    NotificationConfigPerson findByPersonUID(Long personUID);

    List<NotificationConfigPerson> findByEmailUID(Long emailUID);

    List<NotificationConfigPerson> findByPersonUIDAndActive(Long personUID, Boolean active);

}
