package com.commerzbank.gdk.bns.dao;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.ScheduleLocker;

/**
 * ScheduleLocker DAO Interface
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.01
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 15/02/2018		1.00		ZE2RUBI 	Initial Version
 * 07/03/2018       1.01        ZE2RUBI     Add findByNodeName
 *          </pre>
 */

public interface ScheduleLockerDAO extends CrudRepository<ScheduleLocker, Long>, ScheduleLockerCustomDAO {

    ScheduleLocker findByNodeName(String node);
}
