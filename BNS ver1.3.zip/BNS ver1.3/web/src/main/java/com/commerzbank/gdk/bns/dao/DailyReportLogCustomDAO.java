package com.commerzbank.gdk.bns.dao;

import java.util.Date;

/**
 * Custom Daily Report Log DAO Interface
 * 
 * @since 11/01/2018
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 11/01/2018		1.00		ZE2BUEN 	Initial Version
 * 16/03/2018       1.01        ZE2MACL     Added countSumOfNotificationsAccumulated
 * </pre>
 */

public interface DailyReportLogCustomDAO {
    
    Integer countDailyReportLog(Date date, String eventType, String status);
    
    Integer countSumOfNotificationsAccumulated(Date date);
    
}
