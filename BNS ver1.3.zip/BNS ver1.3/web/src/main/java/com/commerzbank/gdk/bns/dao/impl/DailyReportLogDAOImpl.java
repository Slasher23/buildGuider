package com.commerzbank.gdk.bns.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.DailyReportLogCustomDAO;

/**
 * DAO Implementation Class to get the Report List
 * 
 * @since 11/01/2018
 * @author ZE2BUEN
 * @version 1.02
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 11/01/2018		1.00	    ZE2BUEN 	Initial Version
 * 03/02/2018       1.01        ZE2MACL     Added method to convert date to string
 * 03/16/2018       1.02        ZE2MACL     Added countSumOfNotificationsAccumulated method
 *          </pre>
 */

@Repository
public class DailyReportLogDAOImpl implements DailyReportLogCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public Integer countDailyReportLog(Date date, String eventType, String status) {

        String convertedDate = dateToString(date);

        StringBuilder query = new StringBuilder();
        query.append("SELECT count(distinct d.bpkenn) FROM DailyReportLog d WHERE trunc(d.timestamp) = ");
        query.append("to_date('");
        query.append(convertedDate);
        query.append("', 'dd/MM/yyyy') and ");
        query.append("d.eventType = '");
        query.append(eventType);
        query.append("' and d.status = :status");
        query.append("");

        Integer count = (int) (long) this.entityManager.createQuery(query.toString()).setParameter("status", status)
                        .getSingleResult();

        return count;

    }

    private String dateToString(Date date) {

        final String DATE_FORMAT = "dd/MM/yyyy";

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

        String covertedToString = sdf.format(date);

        return covertedToString;

    }

    @Override
    public Integer countSumOfNotificationsAccumulated(Date date) {
        String evenType01 = "01";
        String evenType02 = "02";
        String evenType03 = "03";
        String evenType04 = "04";

        String convertedDate = dateToString(date);

        StringBuilder query = new StringBuilder();
        query.append("SELECT count(dailyReportLogUID) FROM DailyReportLog d WHERE trunc(d.timestamp) = ");
        query.append("to_date('");
        query.append(convertedDate);
        query.append("', 'dd/MM/yyyy') and ");
        query.append("d.eventType IN ('");
        query.append(evenType01).append("',").append("'");
        query.append(evenType02).append("',").append("'");
        query.append(evenType03).append("',").append("'");
        query.append(evenType04).append("')");
        query.append("");

        Integer count = (int) (long) this.entityManager.createQuery(query.toString()).getSingleResult();

        return count;
    }

}
