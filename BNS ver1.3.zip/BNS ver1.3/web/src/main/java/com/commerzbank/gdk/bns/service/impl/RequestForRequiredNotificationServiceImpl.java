package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotification;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.model.RequiredNotificationResponseWithErrors;
import com.commerzbank.gdk.bns.service.RequestForRequiredNotificationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * Service Implementation Class used to implement the business logic in
 * RequestForRequiredNotification
 * 
 * @since 20/09/2017
 * @author ZE2FUEN
 * @version 1.15
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 20/09/2017        1.00       ZE2FUEN    Initial Version
 * 02/11/2017        1.01       ZE2MACL    Changed status for success and failure for error
 * 03/11/2017        1.02       ZE2BAUL    Standardized ZSL Logging
 * 10/11/2017        1.03       ZE2BAUL    Added implementation for RequiredBatchNotificationRequest
 * 23/11/2017        1.04       ZE2GOME    Change RequiredNotificationResponse to NotificationResponse
 * 07/12/2017        1.05       ZE2BUEN    Clean up for ZSL logging
 * 13/12/2017        1.06       ZE2CRUH    Added required notification logging
 * 14/12/2017        1.07       ZE2BUEN    Decoded base 64 notification text for logging
 * 14/12/2017        1.08       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.09       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 28/12/2017        1.10       ZE2CRUH    Added NotificationPath
 * 11/01/2018        1.11       ZE2BUEN    Added saving and update of daily report log record
 * 15/01/2018        1.12       ZE2FUEN    Updated eventType implementation
 * 06/02/2018        1.13       ZE2FUEN    Removed processRunId in requests for methods
 * 06/02/2018        1.14       ZE2MACL    Remove throws Exception and replace it with try catch block
 * 21/02/2018        1.15       ZE2MACL    Added required field/s validation
 *          </pre>
 */
@Service
public class RequestForRequiredNotificationServiceImpl implements RequestForRequiredNotificationService {

    private static final Logger logger = LoggerFactory.getLogger(RequestForRequiredNotificationServiceImpl.class);

    @Autowired
    private Environment environment;

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    private static final String STATUS_OK                    = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST    = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_REQ_NOTIF_NOT_SENT = "ZSL_STATUS_FA_REQ_NOTIF_NOT_SENT";
    private static final String EMPTY_STRING                 = "";

    private static final String OK   = "OK";
    private static final String FAIL = "FAIL";

    @Value("${NOTIF_EVENT04}")
    private String eventType;

    @Value("${MDC_ZSL_PROCESSRUNID}")
    private String processRunIdKey;

    @Autowired
    private Tools tools;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    /**
     * Method for requestingForRequiredNotification
     * 
     * @param RequiredNotificationRequest notification to request
     * @return RequestForRequiredNotificationResponse notification response
     */
    @Override
    public NotificationResponse requestForRequiredNotification(RequiredNotificationRequest requiredNotifRequest) {

        NotificationResponse notificationResponse = new NotificationResponse();
        String status = EMPTY_STRING;

        DailyReportLog dailyReportLog = new DailyReportLog();

        try {

            dailyReportLog = this.logDailyReport(requiredNotifRequest.getBpkenn());

            if (!this.isNullOrEmpty(requiredNotifRequest.getBpkenn())) {
                notificationResponse.setBPKENN(requiredNotifRequest.getBpkenn());
            }

            status = validateRequest(requiredNotifRequest);
            if (isNullOrEmpty(status)) {

                List<Notifications> notificationList = Lists.newArrayList();
                Notifications notification = new Notifications();

                if (!isBase64(requiredNotifRequest.getNotificationtext())) {
                    notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_INVALID_REQUEST));
                } else {
                    notificationResponse.setStatus(this.environment.getProperty(STATUS_OK));

                    notification.setNotificationType(requiredNotifRequest.getNotificationtype());
                    notification.setNotificationPath(requiredNotifRequest.getNotificationpath());
                    notification.setNotificationText(requiredNotifRequest.getNotificationtext());
                    notification.setNotificationSubject(requiredNotifRequest.getNotificationsubject());
                    notificationList.add(notification);
                    notificationResponse.setNotification(notificationList);

                }
            } else {
                notificationResponse.setStatus(status);
            }

        } catch (Exception e) {
            notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_REQ_NOTIF_NOT_SENT));
            logger.error(e.getMessage(), e);

        }

        this.logRequiredNotification(requiredNotifRequest, notificationResponse);

        if (notificationResponse.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))) {
            this.updateDailyReportStatus(dailyReportLog, OK);
        } else {
            this.updateDailyReportStatus(dailyReportLog, FAIL);
        }

        return notificationResponse;

    }

    /**
     * Method for requestingForRequiredBatchNotification
     * 
     * @param List RequiredNotificationRequest list of notification to request
     * @return RequiredBatchNotificationResponseWrapper notification response
     *         with success and errors
     */
    @Override
    public RequiredBatchNotificationResponseWrapper requestForRequiredBatchNotification(
                    RequestForRequiredBatchNotification requiredNotificatonBatchRequestList) {

        NotificationResponse response = new NotificationResponse();
        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();
        RequiredNotificationResponseWithErrors reqNotifResponseWithErrors;

        try {
            for (RequiredNotificationRequest requiredNotificationRequest : requiredNotificatonBatchRequestList
                            .getRequiredNotificationRequest()) {

                reqNotifResponseWithErrors = new RequiredNotificationResponseWithErrors();

                response = requestForRequiredNotification(requiredNotificationRequest);

                if (!response.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))) {
                    if (!this.isNullOrEmpty(response.getBPKENN())) {
                        reqNotifResponseWithErrors.setBpkenn(response.getBPKENN());
                    }

                    reqNotifResponseWithErrors.setNotification(null);
                    reqNotifResponseWithErrors.setStatus(response.getStatus());

                    reqNotifResponseWithErrorsList.add(reqNotifResponseWithErrors);
                } else {
                    reqNotifResponseList.add(response);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);

            reqNotifResponseWithErrors = new RequiredNotificationResponseWithErrors();

            reqNotifResponseWithErrors.setStatus(this.environment.getProperty(STATUS_FA_REQ_NOTIF_NOT_SENT));
            reqNotifResponseWithErrorsList.add(reqNotifResponseWithErrors);
        }

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);

        return responseWrapper;
    }

    private boolean isBase64(String stringBase64) {
        String regex = "([A-Za-z0-9+/]{4})*" + "([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)";
        Pattern pattern = Pattern.compile(regex);
        boolean isBase64 = false;

        if (Objects.nonNull(stringBase64)) {
            isBase64 = pattern.matcher(stringBase64).matches() ? true : false;
        }

        return isBase64;
    }

    /**
     * Method to validate data in NotificationRequest
     * 
     * @param notificationRequest NotificationRequest
     * @return String
     */
    private String validateRequest(RequiredNotificationRequest reqNotifRequest) {

        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        boolean nullBpkenn = this.isNullOrEmpty(reqNotifRequest.getBpkenn());
        boolean nullNotificationpath = this.isNullOrEmpty(reqNotifRequest.getNotificationpath());
        boolean nullNotificationsubject = this.isNullOrEmpty(reqNotifRequest.getNotificationsubject());
        boolean nullNotificationtext = this.isNullOrEmpty(reqNotifRequest.getNotificationtext());
        boolean nullNotificationtype = this.isNullOrEmpty(reqNotifRequest.getNotificationtype());
        boolean nullUuid = this.isNullOrEmpty(reqNotifRequest.getUuid());

        if (nullBpkenn) {
            invalidFields.add("bpkenn");
        }

        if (nullNotificationpath) {
            invalidFields.add("notificationpath");
        }

        if (nullNotificationsubject) {
            invalidFields.add("notificationsubject");
        }

        if (nullNotificationtext) {
            invalidFields.add("notificationtext");
        }

        if (nullNotificationtype) {
            invalidFields.add("notificationtype");
        }

        if (nullUuid) {
            invalidFields.add("uuid");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;
    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return boolean
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        Boolean isValidString = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;
        return isValidString;

    }

    /**
     * Method for logging the required notification
     * 
     * @param requiredNotificationRequest
     * @param notificationResponse
     * @param processRunID
     */
    private void logRequiredNotification(RequiredNotificationRequest requiredNotificationRequest,
                    NotificationResponse notificationResponse) {
        RequiredNotification requiredNotification = new RequiredNotification();
        requiredNotification.setBpkenn(requiredNotificationRequest.getBpkenn());
        requiredNotification.setNotificationSubject(requiredNotificationRequest.getNotificationsubject());

        if (isBase64(requiredNotificationRequest.getNotificationtext())) {
            requiredNotification.setNotificationText(
                            this.tools.base64Decode(requiredNotificationRequest.getNotificationtext()));
        } else {
            requiredNotification.setNotificationText(requiredNotificationRequest.getNotificationtext());
        }
        requiredNotification.setNotificationType(requiredNotificationRequest.getNotificationtype());
        requiredNotification.setProcessRunID(MDC.get(processRunIdKey));
        requiredNotification.setStatus(notificationResponse.getStatus());
        requiredNotification.setUuid(requiredNotificationRequest.getUuid());
        requiredNotification.setNotificationPath(requiredNotificationRequest.getNotificationpath());

        logger.info("=>> REQUIRED NOTIFICATION: [{}]", requiredNotification.toString());
    }

    /**
     * Method for saving the Daily Report Log record
     * 
     * @param bpkenn String BPKENN
     * @return DailyReportLog dailyReportLog Daily Report Log record
     */
    private DailyReportLog logDailyReport(String bpkenn) {

        DailyReportLog dailyReportLog = new DailyReportLog();
        dailyReportLog.setBpkenn(bpkenn);
        dailyReportLog.setEventType(eventType);
        dailyReportLog.setTimestamp(new Date());

        dailyReportLog = this.dailyReportLogDAO.save(dailyReportLog);

        return dailyReportLog;

    }

    /**
     * Method to update on the status of Daily Report Log record
     * 
     * @param dailyReportLog DailyReportLog Daily Report Log record
     * @param status String Status
     * @return
     */
    private DailyReportLog updateDailyReportStatus(DailyReportLog dailyReportLog, String status) {

        dailyReportLog.setStatus(status);
        dailyReportLog = this.dailyReportLogDAO.save(dailyReportLog);

        return dailyReportLog;

    }

}
