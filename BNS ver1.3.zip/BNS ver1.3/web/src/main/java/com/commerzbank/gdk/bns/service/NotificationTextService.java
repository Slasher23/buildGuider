package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to access the Notification Text List
 * 
 * @since 07/08/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/08/2017        1.00       ZE2SARO    Initial Version
 * 27/09/2017		 1.01		ZE2SARO    Relationship of agreement and notif text is 1:1
 * 13/11/2017        1.02       ZE2MACL    Updated method to used response builder and added token parameter
 *          </pre>
 */
public interface NotificationTextService {

	ResponseBuilder<NotificationText> getNotifText(Tokenizer token, String eventType, Long eventId);

}
