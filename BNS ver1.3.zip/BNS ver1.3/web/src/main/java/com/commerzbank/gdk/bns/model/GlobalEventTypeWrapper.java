package com.commerzbank.gdk.bns.model;

import java.util.Map;

/**
 * Wrapper Class for Global Event Type
 * 
 * @since 04/08/2017
 * @author ZE2RUBI
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.01       ZE2RUBI    Initial Version
 * </pre>
 */
public class GlobalEventTypeWrapper {

	private Map<String, EventType> eventTypeMap;
	
	/**
	 * Returns specific item on the Event Type Map
	 * 
	 * @param type String Event Type
	 * @return EventType Item on Event Type Map
	 */
	public EventType get(String type) {
		return this.eventTypeMap.get(type);
	}

	/**
	 * Returns the Event Type Map
	 * 
	 * @return Map Event Type Map
	 */
	public Map<String, EventType> getEventTypeMap() {
		return eventTypeMap;
	}

	/**
	 * Sets the Event Type Map
	 * 
	 * @param eventTypeMap Map Event Type Map to set
	 */
	public void setEventTypeMap(Map<String, EventType> eventTypeMap) {
		this.eventTypeMap = eventTypeMap;
	}
	
	/**
	 * Returns the String representation of Global Event Type Wrapper
	 * 
	 * @return String String representation of Global Event Type Wrapper
	 */
	@Override
	public String toString() {
		return "GlobalEventTypeWrapper [eventTypeMap= " + eventTypeMap + "]";
	}
	
}
