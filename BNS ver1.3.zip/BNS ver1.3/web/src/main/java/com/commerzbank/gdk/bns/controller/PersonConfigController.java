package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.PersonConfigService;

/**
 * PersonConfigController Accept request and return the expected record to
 * client.
 * 
 * @since 03/10/2017
 * @author ZE2BAUL
 * @version 1.06
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2BAUL    Initial Version
 * 13/10/2017	   1.01	     ZE2RUBI    Clean Up and Implement JWT
 * 14/11/2017      1.02      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.03      ZE2SARO    Add Validation
 * 09/02/2018      1.04      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.05      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.06      ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@RestController
public class PersonConfigController {

    @Autowired
    private PersonConfigService personConfigService;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(PersonConfigController.class);

    /**
     * Accept client post request and call service to save the data send by
     * client and return the saved data also consumes and produces json or xml
     * format.
     * 
     * @param bnsInternal
     *            BNS Internal (Person Config)
     * @return all the saved person config.
     * 
     */
    @PostMapping(value = "/api/personConfig")
    public ResponseEntity<Response<PersonConfig>> postNotifConfigPerson(
            @Valid @RequestBody PersonConfig savingNotifConfigPerson, BindingResult result, HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] postNotifConfigPerson({})", token.getUserId(), savingNotifConfigPerson.toString());
        
        ResponseBuilder<PersonConfig> builder = new ResponseBuilder<PersonConfig>(LOGGER, token, globalResponseWrapper);

        if (!result.hasErrors() && Tokenizer.validator(token)) {
            builder = this.personConfigService.postNotifConfigPerson(token, savingNotifConfigPerson);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }
}
