/**
 * 
 */
package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper class for the Notification Text and Person Configuration
 * 
 * @author 	ze2baul
 * @since 	03/10/2017
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017	     1.01       ze2baul    Initial Version
 * </pre>
 */
@XmlRootElement(name = "notifTextAndPersonConfigWrapper")
public class NotifTextPersonConfigWrapper {
	
	private NotificationText notificationText; 
	private NotificationConfigPerson notificationConfigPerson;
	
	/**
	 * Gets the notification text of the Person Config
	 *
	 * @return the notificationText
	 */
	public NotificationText getNotificationText() {
		return notificationText;
	}
	/**
	 * Sets the the notification text of the Person Config
	 *
	 * @param notificationText the notificationText to set
	 */
	public void setNotificationText(NotificationText notificationText) {
		this.notificationText = notificationText;
	}
	/**
	 * Gets the model of Person Notification Configuration
	 *
	 * @return the notificationConfigPerson
	 */
	public NotificationConfigPerson getNotificationConfigPerson() {
		return notificationConfigPerson;
	}
	/**
	 * Sets the model of Person Notification Configuration
	 *
	 * @param notificationConfigPerson the notificationConfigPerson to set
	 */
	public void setNotificationConfigPerson(NotificationConfigPerson notificationConfigPerson) {
		this.notificationConfigPerson = notificationConfigPerson;
	}
	
	/**
     * Returns the String representation of NotifTextPersonConfigWrapper Model
     * 
     * @return String String representation of NotifTextPersonConfigWrapper Model
     */
	
    @Override
    public String toString() {
        return "NotifTextPersonConfigWrapper [notificationText=" + notificationText + ", notificationConfigPerson="
                + notificationConfigPerson + "]";
    }
	
	
}
