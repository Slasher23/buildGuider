package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsResponse;

/**
 * Interface used to get CustomerNotificationBatchService
 * 
 * @since 09/11/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 09/11/2017        1.00       ZE2SARO   Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface CustomerBatchNotificationService {

    CustomerBatchNotificationsResponse getResponse(CustomerBatchNotificationsRequest request);

}
