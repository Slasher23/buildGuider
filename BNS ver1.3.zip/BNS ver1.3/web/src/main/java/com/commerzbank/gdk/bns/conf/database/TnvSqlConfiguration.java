package com.commerzbank.gdk.bns.conf.database;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Configuration Class for TNV Data Source
 * 
 * @since 02/03/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 02/03/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
@Configuration
@EnableJpaRepositories(basePackages = {
		"com.commerzbank.gdk.bns.dao.tnv" }, entityManagerFactoryRef = "tnvsqlEntityManager", transactionManagerRef = "tnvsqlTransactionManager")
public class TnvSqlConfiguration {

	@Autowired
	private Environment env;

	@Value("${spring.datasource.name}")
	private String datasourceName;

	private JndiDataSourceLookup lookup = new JndiDataSourceLookup();

	@Bean
	public LocalContainerEntityManagerFactoryBean tnvsqlEntityManager() {

		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();

		em.setDataSource(tnvsqlDatasource());
		em.setPackagesToScan("com.commerzbank.gdk.bns.model.tnv");
		em.setPersistenceUnitName("tnvsqlEntityManager");

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.tnv.hibernate.dialect"));
		properties.put("hibernate.temp.use_jdbc_metadata_defaults",
				env.getProperty("spring.jpa.properties.tnv.hibernate.temp.use_jdbc_metadata_defaults"));

		em.setJpaPropertyMap(properties);
		return em;
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.tnv.datasource")
	public DataSource tnvsqlDatasource() {

		DataSource dataSource = null;

		if (datasourceName.equalsIgnoreCase("CB_DEV")) {
			dataSource = DataSourceBuilder.create().build();
		} else {
			String jndiName = env.getProperty("spring.tnv.datasource.jndi-name");
			dataSource = lookup.getDataSource(jndiName);
		}

		return dataSource;
	}

	@Bean
	public PlatformTransactionManager tnvsqlTransactionManager() {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(tnvsqlEntityManager().getObject());
		return transactionManager;
	}

	@Bean
	public JdbcTemplate tnvJdbcTemplate(@Qualifier("tnvsqlDatasource") DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

}
