package com.commerzbank.gdk.bns.service;

import java.util.Date;

import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * ExtractReportDataService Interface to extract report data depending on report
 * type during the day of reporting
 * 
 * @since 05/01/2018
 * @author ZE2BUEN
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 05/01/2018        1.00       ZE2BUEN    Initial Version
 * 09/01/2018        1.01       ZE2MACL    Added implementation for at least one individual configured notification
 * 10/01/2018        1.02       ZE2RUBI    Remove Extract date as it is not needed in the method
 * 11/01/2018        1.03       ZE2BUEN    Added implementation for all users who received required notification
 * 11/01/2018        1.04       ZE2FUEN    Added extractAllNotificationServiceCalls method
 * 09/02/2018        1.05       ZE2MACL    Removed throws Exception
 * 16/03/2018        1.06       ZE2MACL    Added extractSumOfNotificationAcummulated method
 *          </pre>
 */

public interface ExtractReportDataService {

    Report extractActiveNotificationReport(Tokenizer token, Date reportDate);

    Report extractAllUsersWithAllActiveProducts(Tokenizer token, Date reportDate);

    Report extractOneIndividualConfiguredNotificationReport(Tokenizer token, Date reportDate);

    Report extractAllUsersWithOneProdSelected(Tokenizer token, Date reportDate);

    Report extractAllUsersWhoReceivedRequiredNotificationReport(Tokenizer token, Date reportDate);

    Report extractAllUsersAccessingNotificationWithoutEmail(Tokenizer token, Date startTime, Date endTime);

    Report extractAllNotificationServiceCalls(Tokenizer token, Date startDateTimestamp, Date endDateTimestamp);
    
    Report extractSumOfNotificationAccumulated(Tokenizer token, Date reportDate);

}
