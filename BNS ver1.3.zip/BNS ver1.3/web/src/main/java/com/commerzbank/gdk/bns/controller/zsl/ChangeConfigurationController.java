package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeConfigurationResponse;
import com.commerzbank.gdk.bns.service.ChangeConfigurationService;

/**
 * Controller Class for changing the configuration of the Person Notification
 * Configuration (activate or deactivate) on agreement level.
 * 
 * @author ZE2BAUL
 * @since 22/12/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/12/2017        1.00       ZE2BAUL    Initial Version
 * 05/02/2018        1.01       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * 
 *          </pre>
 */
@RestController
public class ChangeConfigurationController {

    /**
     * Service to be called.
     */
    @Autowired
    private ChangeConfigurationService changeConfigService;

    /**
     * Log4j variable.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ChangeConfigurationController.class);

    /**
     * Static variable for ZSL.
     */
    private static final String ZSL_STRING = "ZSL";

    /**
     * 
     * Accept client post change configuration then call service to get the
     * change configuration response then return also produces XML or JSON
     * format.
     *
     * @param changeConfigRequest
     *            Contains the active value to be set
     * @param request
     *            HTTP Servlet Request
     * @param result
     *            BindingResult
     * @return ResponseEntity of ChangeConfigurationResponse
     */
    @PostMapping(value = "/api/zsl/requestForChangeConfiguration")
    public ResponseEntity<ChangeConfigurationResponse> requestForChangeConfiguration(
                    @Valid @RequestBody ChangeConfigurationRequest changeConfigRequest, HttpServletRequest request,
                    BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForChangeConfiguration({})", ZSL_STRING, changeConfigRequest.toString());

        ChangeConfigurationResponse changeConfigResponse = new ChangeConfigurationResponse();

        if (!result.hasErrors()) {
            changeConfigResponse = this.changeConfigService.requestForChangeConfiguration(changeConfigRequest);

            if (Objects.isNull(changeConfigResponse)) {
                changeConfigResponse = new ChangeConfigurationResponse();
            }
        }

        final ResponseEntity<ChangeConfigurationResponse> response = new ResponseEntity<ChangeConfigurationResponse>(
                changeConfigResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", ZSL_STRING, changeConfigResponse.toString());

        return response;
    }
}
