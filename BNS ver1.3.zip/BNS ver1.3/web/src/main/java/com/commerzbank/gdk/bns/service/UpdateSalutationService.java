package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.BatchUpdateSalutationResponse;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequest;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * Service Class used to process request to update salutation record
 * 
 * @since 28/11/2017
 * @author ZE2JAVO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2JAVO    Initial Version
 * 29/11/2017        1.01       ZE2SARO    Add batch process
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 *          </pre>
 */

public interface UpdateSalutationService {

    ZslUpdateResponse requestUpdateSalutation(UpdateSalutationRequest request);

    BatchUpdateSalutationResponse requestUpdateSalutation(UpdateSalutationRequests request);

}
