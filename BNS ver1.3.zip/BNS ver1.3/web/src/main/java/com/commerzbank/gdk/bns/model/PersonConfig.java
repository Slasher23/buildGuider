package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Person Configuration
 * This class returns and sets List of Notification Configuration Person
 * 
 * @since 03/10/2017
 * @author ZE2BAUL
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017        1.01       ZE2BAUL    Initial Version
 * </pre>
 */

@XmlRootElement(name = "notificationConfigPerson")
public class PersonConfig {
	
	private NotificationConfigPerson notificationConfigPerson;
	
	/**
	 * Returns the List of Notification Configuration Person
	 *
	 * @return the notificationConfigPerson
	 */
	public NotificationConfigPerson getNotificationConfigPerson() {
		return notificationConfigPerson;
	}

	/**
	 * Sets the List of Notification Configuration Person
	 *
	 * @param notificationConfigPerson the notificationConfigPerson to set
	 */
	public void setNotificationConfigPerson(NotificationConfigPerson notificationConfigPerson) {
		this.notificationConfigPerson = notificationConfigPerson;
	}
		
	/**
	 * Returns the String representation of Person Configuration Model
	 * 
	 * @return String String representation of Person Configuration Model
	 */
	@Override
	public String toString() {
		return "PersonConfig [notificationConfigPerson= " + notificationConfigPerson + "]";
	}
	
}
