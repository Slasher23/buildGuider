package com.commerzbank.gdk.bns.dao;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.PushConfiguration;

/**
 * Push Configuration DAO Interface
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.01       ZE2BUEN    Initial Version
 * </pre>
 */

public interface PushConfigurationDAO extends CrudRepository<PushConfiguration, Long>, PushConfigurationCustomDAO {

}
