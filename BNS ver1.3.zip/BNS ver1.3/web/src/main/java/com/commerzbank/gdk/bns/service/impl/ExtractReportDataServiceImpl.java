package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.ExtractReportDataService;

/**
 * Service Implementation Class used to extract report data depending on report
 * type during the day of reporting
 * 
 * @since 05/01/2018
 * @author ZE2BUEN
 * @version 1.08
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 05/01/2018        1.00       ZE2BUEN    Initial Version
 * 09/01/2018        1.01       ZE2MACL    Added implementation for at least one individual configured notification
 * 10/01/2018        1.02       ZE2RUBI    Added implementation for at All active products
 * 11/01/2018        1.03       ZE2BUEN    Added implementation for all users who received required notification
 * 11/01/2018        1.04       ZE2FUEN    Added implementation for sum of all users notification service calls
 * 11/01/2018        1.05       ZE2FUEN    Fixed bug in checking non empty list in extractActiveNotificationReport
 * 09/02/2018        1.06       ZE2MACL    Removed throws Exception
 * 07/03/2018        1.07       ZE2FUEN    Used correct method in finding notificationText
 * 16/03/2018        1.08       ZE2MACL    Added implementation for extract sum off notifications accumulated
 * 
 *          </pre>
 */

@Transactional
@Service
public class ExtractReportDataServiceImpl implements ExtractReportDataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExtractReportDataServiceImpl.class);

    private static final String RPT001 = "RPT001";
    private static final String RPT002 = "RPT002";
    private static final String RPT003 = "RPT003";
    private static final String RPT004 = "RPT004";
    private static final String RPT005 = "RPT005";
    private static final String RPT006 = "RPT006";
    private static final String RPT007 = "RPT007";
    private static final String RPT008 = "RPT008";

    @Value("${NOTIF_EVENT01}")
    private String NOTIF01;

    @Value("${NOTIF_EVENT02}")
    private String NOTIF02;

    @Value("${NOTIF_EVENT03}")
    private String NOTIF03;

    @Value("${NOTIF_EVENT04}")
    private String NOTIF04;

    @Value("${CONFIG_EVENT01}")
    private String CONFIGEVENT01;

    private static final String OK = "OK";

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private NotificationConfigAgreementDAO notifConfigAgreementDAO;

    @Autowired
    private NotificationConfigPersonDAO notifConfigPersonDAO;

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private NotificationTextDAO notificationTextDAO;

    @Autowired
    private DailyReportLogDAO dailyReportLog;

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    /**
     * Extracts Sum of all Users who have active notifications during the day of
     * reporting
     * 
     * @param token Tokenizer to identify the user
     * @param reportDate Date Report Date
     * @return Report Report Details
     */
    @Override
    public Report extractActiveNotificationReport(Tokenizer token, Date reportDate) {

        List<Person> personList = Lists.newArrayList(this.personDAO.findAll());

        Double counter = 0D;

        if (Objects.nonNull(personList)) {

            try {
                for (Person person : personList) {

                    if (this.withActiveNotifConfigAgreement(person.getPersonUID()) == true
                                    || this.withActiveNotifConfigPerson(person.getPersonUID()) == true) {
                        counter = counter + 1;
                    }

                }
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

        }

        Report report = new Report();
        report.setCount(counter);
        report.setReportType(RPT001);
        report.setDate(reportDate);

        LOGGER.info("<<= User [{}] extractActiveNotificationReport() request was successfully processed.",
                        token.getUserId());

        return report;

    }

    /**
     * Extracts Report - Sum of all users who have at least one individual
     * configured notification during the day of reporting
     * 
     * @param token Tokenizer to identify the user
     * @param reportDate Date Report Date
     * @return Report Report Details
     */
    @Override
    public Report extractOneIndividualConfiguredNotificationReport(Tokenizer token, Date reportDate) {

        List<Person> personList = Lists.newArrayList(this.personDAO.findAll());

        Double counterOfPersonWithOneIndividualConfiguredNotification = 0D;

        try {

            if (Objects.nonNull(personList)) {

                for (Person person : personList) {

                    if (this.AgreementConfig(person.getPersonUID()) || this.PersonConfig(person.getPersonUID())) {
                        counterOfPersonWithOneIndividualConfiguredNotification = counterOfPersonWithOneIndividualConfiguredNotification
                                        + 1;
                    }
                }
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        Double percentage = counterOfPersonWithOneIndividualConfiguredNotification / personList.size() * 100;

        Report report = new Report();
        report.setCount(counterOfPersonWithOneIndividualConfiguredNotification);
        report.setPercentage(percentage);
        report.setReportType(RPT005);
        report.setDate(reportDate);

        LOGGER.info("<<= User [{}] extractOneIndividualConfiguredNotificationReport() request was successfully processed.",
                        token.getUserId());

        return report;

    }

    /**
     * Extracts Report - Sum of all users who have activated all their product
     * 
     * @param token Tokenizer to identify the user
     * @param reportDate Date Report Date
     * @return Report Report Details
     */
    @Override
    public Report extractAllUsersWithAllActiveProducts(Tokenizer token, Date reportDate) {
        Double countOfPersonWithAllActiveProduct = 0D;
        List<Person> personList = new ArrayList<Person>();
        try {
            personList = Lists.newArrayList(this.personDAO.findAll());
            if (!personList.isEmpty()) {
                for (Person person : personList) {
                    if (this.allActiveNotifConfigAgreement(person.getPersonUID())) {
                        countOfPersonWithAllActiveProduct++;
                    }
                }
            }

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Double percentage = countOfPersonWithAllActiveProduct / personList.size() * 100;

        Report report = new Report();
        report.setCount(countOfPersonWithAllActiveProduct);
        report.setPercentage(percentage);
        report.setReportType(RPT003);
        report.setDate(reportDate);

        LOGGER.info("<<= User [{}] extractAllUsersWithAllActiveProducts() request was successfully processed.",
                        token.getUserId());

        return report;
    }

    /**
     * Extract Report - Sum of all users which have at least 1 Product
     * notification selected, but not all Product notification selected
     * 
     * @param token Tokenizer to identify the user
     * @param report Date Date Report Date
     * @return Report Report Details
     */
    @Override
    public Report extractAllUsersWithOneProdSelected(Tokenizer token, Date reportDate) {
        List<Person> personList = new ArrayList<Person>();
        Double countOfPersonWithSomeActiveProduct = 0D;

        try {
            personList = Lists.newArrayList(this.personDAO.findAll());
            if (!personList.isEmpty()) {
                for (Person person : personList) {
                    if (this.atLeastOneProductActive(person.getPersonUID())) {
                        countOfPersonWithSomeActiveProduct++;
                    }
                }

            }

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Double percentage = countOfPersonWithSomeActiveProduct / personList.size() * 100;

        Report report = new Report(RPT004, countOfPersonWithSomeActiveProduct, percentage, reportDate);

        LOGGER.info("<<= User [{}] extractAllUsersWithOneProdSelected() request was successfully processed.",
                        token.getUserId());

        return report;
    }

    /**
     * Extract Report - Sum of all users that tried to access the notification
     * without email address
     * 
     * @param token Tokenizer to identify the user
     * @param startTime Date Timestamp
     * @param endTime Date Timestamp
     * @return Report Report Details
     */
    @Override
    public Report extractAllUsersAccessingNotificationWithoutEmail(Tokenizer token, Date startTime, Date endTime) {

        List<String> eventTypeList = new ArrayList<>();
        eventTypeList.add(CONFIGEVENT01);
        List<DailyReportLog> dailyReport = new ArrayList<DailyReportLog>();

        try {

            dailyReport = this.dailyReportLog.findByEventTypeInAndTimestampGreaterThanEqualAndTimestampLessThan(
                            eventTypeList, startTime, endTime);
        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Report report = new Report();
        report.setCount((double) dailyReport.size());
        report.setReportType(RPT007);
        report.setDate(startTime);
        report.setTime(startTime);

        LOGGER.info("<<= User [{}] extractAllUsersWithoutEmail() request was successfully processed.",
                        token.getUserId());

        return report;
    }

    /**
     * Extract Report - Sum of all users who have received a Regulatory
     * notification
     * 
     * @param token Tokenizer to identify the user
     * @param report Date Date Report Date
     */
    public Report extractAllUsersWhoReceivedRequiredNotificationReport(Tokenizer token, Date reportDate) {
        List<Person> personList = new ArrayList<Person>();
        Double count = 0D;
        try {
            personList = Lists.newArrayList(this.personDAO.findAll());

            count = Double.valueOf((this.dailyReportLogDAO.countDailyReportLog(reportDate, NOTIF04, OK)));

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Double percentage = count / personList.size() * 100;

        Report report = new Report(RPT002, count, percentage, reportDate);

        LOGGER.info("<<= User [{}] extractAllUsersWhoReceivedRequiredNotificationReport() request was successfully processed.",
                        token.getUserId());

        return report;

    }

    /* Private Methods */

    /**
     * Check notification text type if custom text
     * 
     * @param notifText NotificationText entity
     * @return Boolean customText
     */
    public boolean NotifTextCustom(NotificationText notifText) {
        String notifTextType = "FREE";
        Boolean isCustomText = false;

        if (Objects.nonNull(notifText)) {

            if (notifText.getNotificationTextType().equalsIgnoreCase(notifTextType)) {
                isCustomText = true;
            }

        }

        return isCustomText;
    }

    /**
     * Check if person has an active notification configuration person record
     * 
     * @param personUID Long Person UID
     * @return Boolean withActive
     */
    private Boolean withActiveNotifConfigPerson(Long personUID) {

        Boolean withActive = false;

        List<NotificationConfigPerson> list = this.notifConfigPersonDAO.findByPersonUIDAndActive(personUID, true);

        if (list.size() > 0) {
            withActive = true;
        }

        return withActive;

    }

    /**
     * Check if person has active notification configuration agreement records
     * 
     * @param personUID Long Person UID
     * @return Boolean withActive
     */
    private Boolean withActiveNotifConfigAgreement(Long personUID) {

        Boolean withActive = false;

        try {
            List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);
            List<Long> agreementUIDList = new ArrayList<>();

            for (Agreement agreement : agreementList) {
                agreementUIDList.add(agreement.getAgreementUID());
            }

            if (Objects.nonNull(agreementUIDList)) {

                List<NotificationConfigAgreement> list = this.notifConfigAgreementDAO
                                .findByActiveAndAgreementUIDIn(true, agreementUIDList);

                if (list.size() > 0) {
                    withActive = true;
                }

            }

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        return withActive;

    }

    /**
     * Check if person has active notification configuration agreement records
     * and check notification text type if customer text
     * 
     * @param personUID Long Person UID
     * @return Boolean customText
     */
    private boolean AgreementConfig(Long personUID) {

        Boolean isCustomText = false;
        int noOfCustomText = 0;

        try {

            List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);
            List<Long> agreementUIDList = new ArrayList<>();

            for (Agreement agreement : agreementList) {
                agreementUIDList.add(agreement.getAgreementUID());
            }

            if (Objects.nonNull(agreementUIDList)) {

                List<NotificationConfigAgreement> notificationConfigList = this.notifConfigAgreementDAO
                                .findByAgreementUIDIn(agreementUIDList);

                if (Objects.nonNull(notificationConfigList)) {

                    for (NotificationConfigAgreement notificationConfigAgreement : notificationConfigList) {
                        NotificationText notificationText = this.notificationTextDAO.findByNotificationTextUID(
                                        notificationConfigAgreement.getNotificationTextUID());

                        if (isCustomText = NotifTextCustom(notificationText)) {
                            noOfCustomText++;
                        }

                    }

                }

                if (noOfCustomText == 1) {
                    isCustomText = true;
                }

            }

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        return isCustomText;
    }

    /**
     * Check if person has notification configuration person record and check
     * notification text type if custom text
     * 
     * @param personUID Long Person UID
     * @return Boolean customText
     */
    private boolean PersonConfig(Long personUID) {

        NotificationText notificationText = new NotificationText();

        Boolean isCustomText = false;
        String notificationTextType = "FREE";

        try {
            NotificationConfigPerson notificationConfigPerson = this.notifConfigPersonDAO.findByPersonUID(personUID);

            if (Objects.nonNull(notificationConfigPerson)) {

                notificationText = this.notificationTextDAO
                                .findByNotificationTextUID(notificationConfigPerson.getNotificationTextUID());

                if (Objects.nonNull(notificationText)) {

                    if (notificationText.getNotificationTextType().equalsIgnoreCase(notificationTextType)) {
                        isCustomText = true;
                    }
                }

            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return isCustomText;

    }

    /**
     * Check if person has all active notification configuration agreement
     * records
     * 
     * @param personUID Long Person UID
     * @return Boolean with all Active >
     */
    private boolean allActiveNotifConfigAgreement(Long personUID) {

        int noOfActiveProducts = 0;
        int noOfProducts = 0;
        int personConfig = 1;

        try {

            List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);

            noOfProducts = agreementList.size() + personConfig;

            noOfActiveProducts = getNoOfActiveProducts(agreementList, personUID);

            if (noOfProducts == noOfActiveProducts) {
                return true;
            }

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        return false;

    }

    /**
     * Check if person has one active notification configuration agreement
     * records
     * 
     * @param personUID Long Person UID
     * @return Boolean with at least one Active
     */
    private boolean atLeastOneProductActive(Long personUID) {

        int noOfActiveProducts = 0;
        int noOfProducts = 0;
        int personConfig = 1;

        List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);

        noOfProducts = agreementList.size() + personConfig;

        noOfActiveProducts = getNoOfActiveProducts(agreementList, personUID);

        if (noOfActiveProducts > 0 && noOfActiveProducts != noOfProducts) {
            return true;
        }

        return false;

    }

    /**
     * Get the number of active products
     * 
     * @param agreementList List Agreement List
     * @param personUID Long Person UID
     * @return int
     */
    private int getNoOfActiveProducts(List<Agreement> agreementList, Long personUID) {

        List<Long> agreementUIDList = new ArrayList<>();
        int noOfActiveProducts = 0;

        for (Agreement agreement : agreementList) {
            agreementUIDList.add(agreement.getAgreementUID());
        }
        // get Agreement Config
        noOfActiveProducts = this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true, agreementUIDList).size();

        // get Person Config
        NotificationConfigPerson notificationConfigPerson = this.notifConfigPersonDAO.findByPersonUID(personUID);

        if (Objects.nonNull(notificationConfigPerson)) {
            if (notificationConfigPerson.getActive()) {
                noOfActiveProducts++;
            }
        }

        return noOfActiveProducts;

    }

    /**
     * Creates Report - Sum of all users notification service calls for a given
     * timestamp
     * 
     * @param token Tokenizer to identify the user
     * @param startDateTimestamp Date start timestamp
     * @param endDateTimestamp Date end timestamp
     * @return Report Report Details
     */
    @Override
    public Report extractAllNotificationServiceCalls(Tokenizer token, Date startDateTimestamp, Date endDateTimestamp) {

        List<String> eventTypeList = new ArrayList<String>();
        eventTypeList.add(NOTIF01);
        eventTypeList.add(NOTIF02);
        eventTypeList.add(NOTIF03);
        eventTypeList.add(NOTIF04);

        List<DailyReportLog> dailyReport = new ArrayList<DailyReportLog>();

        try {
            dailyReport = this.dailyReportLogDAO.findByEventTypeInAndTimestampGreaterThanEqualAndTimestampLessThan(
                            eventTypeList, startDateTimestamp, endDateTimestamp);

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Report report = new Report();
        report.setCount((double) dailyReport.size());
        report.setReportType(RPT006);
        report.setDate(startDateTimestamp);
        report.setTime(startDateTimestamp);

        LOGGER.info("<<= User [{}] extractAllNotificationServiceCalls() request was successfully processed.",
                        token.getUserId());

        return report;
    }

    /**
     * Creates Report - Total sum of notifications accumulated in one day for a
     * given timestamp
     * 
     * @param token Tokenizer to identify the user
     * @param startDateTimestamp Date start timestamp
     * @param endDateTimestamp Date end timestamp
     * @return Report Report Details
     */
    @Override
    public Report extractSumOfNotificationAccumulated(Tokenizer token, Date reportDate) {

        Integer counter = 0;

        try {
            counter = this.dailyReportLogDAO.countSumOfNotificationsAccumulated(reportDate);

        } catch (NullPointerException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        Double count = Double.valueOf(counter);

        Report report = new Report();
        report.setCount(count);
        report.setReportType(RPT008);
        report.setDate(reportDate);

        LOGGER.info("<<= User [{}] extractAllNotificationServiceCalls() request was successfully processed.",
                        token.getUserId());

        return report;
    }

}
