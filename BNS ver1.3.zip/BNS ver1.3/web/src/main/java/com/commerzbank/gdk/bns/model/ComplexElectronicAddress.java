package com.commerzbank.gdk.bns.model;

/**
 * Model Class for ComplexElectronicAddress
 * 
 * @since 07/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/12/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
public class ComplexElectronicAddress {

    private Long addressId;

    private String emailAddress;

    /**
     * @return the addressId
     */
    public Long getAddressId() {
        return addressId;
    }

    /**
     * @param addressId the addressId to set
     */
    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    /**
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * @param emailAddress the emailAddress to set
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /* 
     * @return
     */
    @Override
    public String toString() {
        return "ComplexElectronicAddress [addressId=" + addressId + ", emailAddress=" + emailAddress + "]";
    }
    
}
