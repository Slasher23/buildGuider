package com.commerzbank.gdk.bns.model;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;

/**
 * Wrapper Class for Settings
 * 
 * @since 25/08/2017
 * @author ZE2CRUH
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 25/08/2017        1.01       ZE2CRUH    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 30/10/2017		 1.03		ZE2FUEN	   Added getLocaleField method
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */
@XmlRootElement
public class Settings {
    private Map<String, String> localeMap;

    /**
     * Returns the Locale Map
     * 
     * @return the localeMap
     */
    public Map<String, String> getLocaleMap() {
        return localeMap;
    }

    /**
     * Sets value to the Locale Map
     * 
     * @param localeMap the localeMap to set
     */
    public void setLocaleMap(Map<String, String> localeMap) {
        this.localeMap = localeMap;
    }

    /**
     * Returns specific item on the Locale Map
     * 
     * @param type String Locale
     * @return String Item on Locale Map
     */
    public String getLocale(String key) {

        if (!this.localeMap.containsKey(key)) {
            return this.localeMap.get("DE");
        }

        return this.localeMap.get(key);
    }

    /**
     * Returns specific field per item on the Locale Map
     * 
     * @param String localeKey key for locale language
     * @param String fieldKey key for the field in locale
     * @return String field on Locale
     */
    public String getLocaleField(String localeKey, String fieldKey) {

        String locale = null;
        String field = null;

        if (!this.localeMap.containsKey(localeKey)) {
            locale = this.localeMap.get("DE");
        }

        locale = this.localeMap.get(localeKey);
        JSONObject jsonObj;

        try {
            jsonObj = new JSONObject(locale);
            field = jsonObj.get(fieldKey).toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return field;
    }

}
