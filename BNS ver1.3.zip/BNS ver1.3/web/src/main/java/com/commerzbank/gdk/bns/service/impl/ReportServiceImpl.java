package com.commerzbank.gdk.bns.service.impl;

import java.util.List;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.ReportDAO;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.ReportService;

/**
 * Service Implementation Class used to implement business logic service in
 * getting the Report Persistence
 * 
 * @since 11/01/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 11/01/2018       1.00        ZE2RUBI     Initial Version
 *          </pre>
 */
@Service
public class ReportServiceImpl implements ReportService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportServiceImpl.class);

    @Autowired
    private ReportDAO reportDAO;

    /**
     * Save Report then return the report model.
     * 
     * @param report extracted report
     * @return report persisted data.
     */
    @Override
    public Report saveReport(Report report, Tokenizer token) {
        try {
            reportDAO.save(report);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.info("<<= User [{}] savingReport({}) request was successfully processed.", token.getUserId(),
                report.getReportType());

        return report;
    }

    /**
     * Save List of Report then return the report model.
     * 
     * @param reports extracted report
     * @param token user identity model
     * @return reports persisted data.
     */
    @Override
    public List<Report> saveReports(List<Report> reports, Tokenizer token) {

        try {
            reports = Lists.newArrayList(reportDAO.save(reports));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.info("<<= User [{}] savingReports() Size:{} request was successfully processed.", token.getUserId(),
                reports.size());

        return reports;
    }

}
