package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchResponse;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressBatchService;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressService;

/**
 * Service Implementation Class used to process Batch Change Email Address
 * 
 * @since 27/11/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2BUEN    Initial Version
 * 07/12/2017        1.01       ZE2BUEN    Clean up for ZSL logging
 * 12/12/2017        1.02       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 09/02/2018        1.03       ZE2MACL    Removed throws Exception
 * </pre>
 */

@Transactional
@Service
public class ChangeEmailAddressBatchServiceImpl implements ChangeEmailAddressBatchService {

	@Autowired
	private ChangeEmailAddressService changeEmailAddressService;
	
	@Autowired
	private Environment environment;
	
	private static final String STATUS_OK = "ZSL_STATUS_OK";
	
	@Override
	public ChangeEmailAddressBatchResponse requestForBatchChangeEmailAddress(ChangeEmailAddressBatchRequest request) {

		ChangeEmailAddressBatchResponse response = new ChangeEmailAddressBatchResponse();
		List<ChangeEmailAddressResponse> withoutErrors = new ArrayList<ChangeEmailAddressResponse>();
		List<ChangeEmailAddressResponse> withErrors = new ArrayList<ChangeEmailAddressResponse>();

		for (ChangeEmailAddressRequest changeEmailAddressRequest : request.getChangeEmailAddressRequest()) {
			ChangeEmailAddressResponse changeEmailAddressResponse = this.changeEmailAddressService
					.requestForChangeEmailAddress(changeEmailAddressRequest);

			if (changeEmailAddressResponse.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))) {
				withoutErrors.add(changeEmailAddressResponse);
			} else {
				withErrors.add(changeEmailAddressResponse);
			}

		}

		response.setChangeEmailAddressResponse(withoutErrors);
		response.setChangeEmailAddressResponseWithErrors(withErrors);

		return response;

	}

}
