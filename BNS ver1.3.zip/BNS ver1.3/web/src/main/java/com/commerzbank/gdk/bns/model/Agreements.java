package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Agreements. Used by
 * RequestForChangeConfiguration.
 * 
 * @author ZE2BAUL
 * @since 21/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "Agreements")
public class Agreements {

    private String vereinbarungskennung;

    private Integer sparte;

    private Boolean active;

    /**
     * Gets the value for vereinbarungskennung.
     *
     * @return the vereinbarungskennung
     */
    public String getVereinbarungskennung() {
        return vereinbarungskennung;
    }

    /**
     * Sets the value for vereinbarungskennung.
     *
     * @param vereinbarungskennung
     *            the vereinbarungskennung to set
     */
    public void setVereinbarungskennung(String vereinbarungskennung) {
        this.vereinbarungskennung = vereinbarungskennung;
    }

    /**
     * Gets the value for sparte.
     *
     * @return the sparte
     */
    public Integer getSparte() {
        return sparte;
    }

    /**
     * Sets the value for sparte.
     *
     * @param sparte
     *            the sparte to set
     */
    public void setSparte(Integer sparte) {
        this.sparte = sparte;
    }

    /**
     * Gets the value for active.
     *
     * @return the active
     */
    public Boolean getActive() {
        return active;
    }

    /**
     * Sets the value for active.
     *
     * @param active
     *            the active to set
     */
    public void setActive(Boolean active) {
        this.active = active;
    }

    /**
     * Returns the String representation of Agreements Model.
     * 
     * @return String String representation of Agreements Model.
     */
    @Override
    public String toString() {
        return "Agreements [vereinbarungskennung= " + vereinbarungskennung + " sparte= " + sparte + " active= " + active
                        + "]";
    }
}
