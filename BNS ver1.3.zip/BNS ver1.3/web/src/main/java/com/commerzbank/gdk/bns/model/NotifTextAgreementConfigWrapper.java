/**
 * 
 */
package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ze2saro
 *
 */
@XmlRootElement(name = "notifTextAndAgreementConfigWrapper")
public class NotifTextAgreementConfigWrapper {

	private NotificationText notificationText; 
	private NotificationConfigAgreement notificationConfigAgreement;
	
	/**
	 * @return the notificationText
	 */
	public NotificationText getNotificationText() {
		return notificationText;
	}
	
	/**
	 * @param notificationText the notificationText to set
	 */
	public void setNotificationText(NotificationText notificationText) {
		this.notificationText = notificationText;
	}
	
	/**
	 * @return the notificationConfigAgreement
	 */
	public NotificationConfigAgreement getNotificationConfigAgreement() {
		return notificationConfigAgreement;
	}
	
	/**
	 * @param notificationConfigAgreement the notificationConfigAgreement to set
	 */
	public void setNotificationConfigAgreement(NotificationConfigAgreement notificationConfigAgreement) {
		this.notificationConfigAgreement = notificationConfigAgreement;
	}
	
	/**
     * Returns the String representation of NotifTextAgreementConfigWrapper Model
     * 
     * @return String String representation of NotifTextAgreementConfigWrapper Model
     */
    @Override
    public String toString() {
        return "NotifTextAgreementConfigWrapper [notificationText=" + notificationText
                + ", notificationConfigAgreement=" + notificationConfigAgreement + "]";
    }
	
	
	
}
