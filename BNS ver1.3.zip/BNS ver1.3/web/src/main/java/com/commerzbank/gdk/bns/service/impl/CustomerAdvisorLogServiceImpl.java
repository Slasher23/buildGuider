package com.commerzbank.gdk.bns.service.impl;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.CustomerAdvisorLog;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.CustomerAdvisorLogService;

/**
 * Service Implementation Class used to implement business logic service in
 * logging events
 * 
 * @author ZE2MACL
 * @version 1.02
 * @since 05/01/2018
 * 
 *        <pre>
 *  
 * Modified Date	Version		Author		Description
 * 05/01/2018		1.00		ZE2MACL 	InitialVersion
 * 16/01/2018       1.01        ZE2MACL     Update method and added All notification toggle log
 * 09/02/2018       1.02        ZE2MACL     Log exception
 * 
 *        </pre>
 */
@Transactional
@Service
public class CustomerAdvisorLogServiceImpl implements CustomerAdvisorLogService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerAdvisorLogServiceImpl.class);

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Autowired
    private EmailDAO emailDAO;

    @Autowired
    private AllNotificationConfigDAO allNotificationConfigDAO;

    /**
     * Retrieves the value of Audit Log and check event type of the Audit Log.
     * Set customer audit log based on the retrieved data
     * 
     * @param token to identify the user
     * @param auditLog AuditLog to set
     * @return customerAdLog
     */
    @Override
    public CustomerAdvisorLog saveLog(Tokenizer token, AuditLog auditLog) {
        String ToggleAllNotif = "1001";
        String AllConfigChangeEmail = "1007";
        String AgreementToggle = "1002";
        String PersonToggle = "1008";
        String AgreementChangeEmail = "1003";
        String PersonChangeEmail = "1010";
        String active = "true";
        String personAgreement = "Person";
        

        CustomerAdvisorLog customerAdLog = new CustomerAdvisorLog();

        try {

            if (auditLog.getEventType().equalsIgnoreCase(AgreementToggle)) {
                Long agreementUID = Long.valueOf(auditLog.getObjectID());
                Agreement agreement = this.agreementDAO.findByAgreementUID(agreementUID);
                NotificationConfigAgreement notificationConfigAgreement = this.notificationConfigAgreementDAO
                                .findByAgreementUID(agreement.getAgreementUID());
                Email email = this.emailDAO.findByEmailUID(notificationConfigAgreement.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID(agreement.getAgreementID());
                customerAdLog.setCustomerEmail(email.getEmailAddress());
                customerAdLog.setAgreementActive(auditLog.getNewValue());
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());

                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            } else if (auditLog.getEventType().equalsIgnoreCase(PersonToggle)) {
                Long personUID = Long.valueOf(auditLog.getUserID());
                NotificationConfigPerson notificationConfigPerson = this.notificationConfigPersonDAO
                                .findByPersonUID(personUID);
                Email email = this.emailDAO.findByEmailUID(notificationConfigPerson.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID(personAgreement);
                customerAdLog.setCustomerEmail(email.getEmailAddress());
                customerAdLog.setAgreementActive(auditLog.getNewValue());
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());

                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            } else if (auditLog.getEventType().equalsIgnoreCase(AgreementChangeEmail)) {
                Long agreementUID = Long.valueOf(auditLog.getObjectID());
                Agreement agreement = this.agreementDAO.findByAgreementUID(agreementUID);
                NotificationConfigAgreement notificationConfigAgreement = this.notificationConfigAgreementDAO
                                .findByAgreementUID(agreement.getAgreementUID());
                Email email = this.emailDAO.findByEmailUID(notificationConfigAgreement.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID(agreement.getAgreementID());
                customerAdLog.setCustomerEmail(email.getEmailAddress());
                customerAdLog.setAgreementActive(active);
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());

                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            } else if (auditLog.getEventType().equalsIgnoreCase(PersonChangeEmail)) {
                Long personUID = Long.valueOf(auditLog.getUserID());
                NotificationConfigPerson notificationConfigPerson = this.notificationConfigPersonDAO
                                .findByPersonUID(personUID);
                Email email = this.emailDAO.findByEmailUID(notificationConfigPerson.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID("Person");
                customerAdLog.setCustomerEmail(email.getEmailAddress());
                customerAdLog.setAgreementActive(active);
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());

                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());
                
            } else if (auditLog.getEventType().equalsIgnoreCase(ToggleAllNotif)) {
                Long personUID = Long.valueOf(auditLog.getUserID());
                AllNotificationConfig allNotificationConfig = this.allNotificationConfigDAO.findByPersonUID(personUID);
                Email email = this.emailDAO.findByEmailUID(allNotificationConfig.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID("Toggle All Notification");
                customerAdLog.setCustomerEmail(null);
                customerAdLog.setAgreementActive(auditLog.getNewValue());
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());
                
                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            }  else if (auditLog.getEventType().equalsIgnoreCase(ToggleAllNotif)) {
                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID("Toggle All Notification");
                customerAdLog.setCustomerEmail(null);
                customerAdLog.setAgreementActive(auditLog.getNewValue());
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());
                
                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            }  else if (auditLog.getEventType().equalsIgnoreCase(AllConfigChangeEmail)) {
                Long personUID = Long.valueOf(auditLog.getUserID());
                AllNotificationConfig allNotificationConfig = this.allNotificationConfigDAO.findByPersonUID(personUID);
                Email email = this.emailDAO.findByEmailUID(allNotificationConfig.getEmailUID());

                customerAdLog.setBpkenn(auditLog.getBpkenn());
                customerAdLog.setAgreementID("All Notification Change Email");
                customerAdLog.setCustomerEmail(email.getEmailAddress());
                customerAdLog.setAgreementActive(null);
                customerAdLog.setCustomerAdvisorsWindowsID(token.getUserId());
                
                LOGGER.info("Customer Advisor Log [{}]", customerAdLog.toString());

            } else {

                LOGGER.info("Customer Advisor Log [{}]", "No existing EventType");
            }

        } catch (Exception ex) {

            LOGGER.error("Customer Advisor Log [{}]", "No existing EventType  " + ex.getMessage(), ex);
        }

        return customerAdLog;
    }

}
