package com.commerzbank.gdk.bns.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.util.HtmlUtils;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.service.EmailTemplateService;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.utils.Tools;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * Service Implementation Class used to generate email template
 * 
 * @since 02/02/2018
 * @author ZE2FARI
 * @version 1.02
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 02/02/2018       1.00        ZE2FARI     InitialVersion
 * 07/02/2018       1.01        ZE2FARI     Added HtmlUtils 
 * 07/02/2018       1.02        ZE2MACL     Remove throws Exception and replace it with try catch block
 *          </pre>
 */
@Service
@Transactional
public class EmailTemplateServiceImpl implements EmailTemplateService {

    @Autowired
    private Environment environment;

    @Autowired
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Autowired
    private NotificationTextDAO notificationTextDAO;

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Autowired
    private Settings settings;

    @Autowired
    private KeyService schlusselService;

    @Autowired
    private Configuration freemarkerConfig;

    @Autowired
    private Tools tools;

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailTemplateServiceImpl.class);

    /**
     * Method to notify in EMAIL channel
     * 
     * @param person Person person object
     * @param agreementID String ID of the agreement
     * @param branch Integer branch number
     * @param notificationPath String Notification path
     * @param isAgreementRelated boolean determines if notification is
     *            agreementRelated
     * @return notifications Notifications notifications object
     */
    @Override
    public Notifications createEmailNotification(Person person, String agreementID, Integer branch,
                    String notificationPath, boolean isAgreementRelated) {

        String subjText = "";
        String informationChannel = InformationChannelTypeE.EMAIL.toString();
        Notifications notifications = new Notifications();
        NotificationText notificationText;

        try {
            if (isAgreementRelated) {
                NotificationConfigAgreement notifConfigAgreement = this.notificationConfigAgreementDAO
                                .findByAgreementUID(person.getPersonUID(), branch, agreementID);
                notificationText = this.notificationTextDAO.findOne(notifConfigAgreement.getNotificationTextUID());
            } else {
                NotificationConfigPerson notifConfigPerson = this.notificationConfigPersonDAO
                                .findByPersonUID(person.getPersonUID());
                notificationText = this.notificationTextDAO.findOne(notifConfigPerson.getNotificationTextUID());
            }

            String notificationTextDe = null;
            String notificationTextEn = null;

            if (notificationText.getNotificationTextType().equals(BNSConstants.TEXT_TYPE_STD)) {
                notificationTextDe = HtmlUtils
                                .htmlEscape(this.settings.getLocaleField("DE", "subTextArea_DefaultText"));
                notificationTextEn = HtmlUtils
                                .htmlEscape(this.settings.getLocaleField("EN", "subTextArea_DefaultText"));
                subjText = this.environment.getProperty(BNSConstants.EMAIL_SUBJECT_KEY);
            } else {
                notificationTextDe = HtmlUtils.htmlEscape(notificationText.getText());
                notificationTextEn = HtmlUtils.htmlEscape(notificationText.getText());
                subjText = this.environment.getProperty(BNSConstants.CUST_EMAIL_SUBJECT_KEY);
            }

            String encodedEmailTemplate = generateEmailTemplate(person, notificationTextDe, notificationTextEn,
                            notificationText.getNotificationTextType());

            notifications.setNotificationPath(notificationPath);
            notifications.setNotificationSubject(subjText);
            notifications.setNotificationType(informationChannel);
            notifications.setNotificationText(encodedEmailTemplate);

        } catch (IOException ioException) {
            LOGGER.error(ioException.getMessage(), ioException);
        } catch (TemplateException templateException) {
            LOGGER.error(templateException.getMessage(), templateException);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return notifications;

    }

    /**
     * Generate email template encoded in base64 format
     * 
     * @param person
     * @param notificationTextDe
     * @param notificationTextEn
     * @return String encoded in base64 format
     * @throws TemplateException
     * @throws IOException
     */
    private String generateEmailTemplate(Person person, String notificationTextDe, String notificationTextEn,
                    String notificationTextType) throws IOException, TemplateException {
        String encodedEmailTemplate = null;
        String template = "";
        String title = "";
        final String salutation = "BBANR";
        final String titel = "PAKTL";
        final String langEN = "006";
        final String langDE = "000";

        Map<String, Object> emailDetails = new HashMap<String, Object>();

        if (notificationTextType.equals(BNSConstants.TEXT_TYPE_STD)) {

            title = schlusselService.getShortTextValue(titel, person.getTitle(), langEN);

            // If there is already a title in English don't include the
            // salutation
            if (title.isEmpty() || title == null) {
                emailDetails.put("salutationEn",
                                schlusselService.getShortTextValue(salutation, person.getSalutation(), langEN));
            }

            emailDetails.put("titleEn", title);

            emailDetails.put("salutationDe",
                            schlusselService.getShortTextValue(salutation, person.getSalutation(), langDE));
            emailDetails.put("titleDe", schlusselService.getShortTextValue(titel, person.getTitle(), langDE));
            emailDetails.put("lastName", person.getLastName());
        }

        emailDetails.put("notificationTextDe", notificationTextDe);
        emailDetails.put("notificationTextEn", notificationTextEn);

        // Prepare the template
        String text = null;

        freemarkerConfig.setClassForTemplateLoading(this.getClass(), "/templates");

        if (notificationTextType.equals(BNSConstants.TEXT_TYPE_STD)) {
            template = "NotificationEmailTemplate.ftl";
        } else {
            template = "CustomNotificationEmailTemplate.ftl";
        }

        Template t = freemarkerConfig.getTemplate(template);
        text = FreeMarkerTemplateUtils.processTemplateIntoString(t, emailDetails);

        encodedEmailTemplate = this.tools.base64Encode(text);

        return encodedEmailTemplate;
    }

}
