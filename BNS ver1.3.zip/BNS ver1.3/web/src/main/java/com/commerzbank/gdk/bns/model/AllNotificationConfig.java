package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for BENACH_KONFIG_ALLE(AllNotificationConfig) Table
 * 
 * @since 22/09/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/09/2017        1.01       ZE2SARO    Initial Version
 * 23/11/2017        1.02       ZE2BUEN    Modified TEILNEHMENUMMER_UID to PERSON_UID
 *          </pre>
 */

@Entity
@Table(name = "BENACH_KONFIG_ALLE")
@XmlRootElement
public class AllNotificationConfig {

    @Id
    @Column(name = "BENACH_KONFIG_ALLE_UID")
    @GeneratedValue(generator = "BENACH_KONFIG_ALLE_UID_SEQ")
    @SequenceGenerator(name = "BENACH_KONFIG_ALLE_UID_SEQ", sequenceName = "BENACH_KONFIG_ALLE_SEQ")
    private Long allNotificationConfigUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "INFORMATIONS_KANAL_UID")
    private Long informationChannelUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "EMAIL_UID")
    private Long emailUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "PERSON_UID")
    private Long personUID;

    /**
     * Returns the value of Unique Identifier of allNotificationConfig Record
     * 
     * @return Long Unique Identifier of allNotificationConfig Record
     */
    public Long getAllNotificationConfigUID() {
        return allNotificationConfigUID;
    }

    /**
     * Sets the value of Unique Identifier of allNotificationConfig Record
     * 
     * @param informationChannelUID Long Unique IallNotificationConfig Record to
     *            set
     */
    public void setAllNotificationConfigUID(Long allNotificationConfigUID) {
        this.allNotificationConfigUID = allNotificationConfigUID;
    }

    /**
     * Returns the value of Unique Identifier of Information Channel Record
     * 
     * @return Long Unique Identifier of Information Channel Record
     */
    public Long getInformationChannelUID() {
        return informationChannelUID;
    }

    /**
     * Sets the value of Unique Identifier of Information Channel Record
     * 
     * @param informationChannelUID Long Unique Identifier of Information
     *            Channel Record to set
     */
    public void setInformationChannelUID(Long informationChannelUID) {
        this.informationChannelUID = informationChannelUID;
    }

    /**
     * Returns the value of Unique Identifier of Email Record
     * 
     * @return Long Unique Identifier of Email Record
     */
    public Long getEmailUID() {
        return emailUID;
    }

    /**
     * Sets the value of Unique Identifier of Email Record
     * 
     * @param emailUID Long Unique Identifier of Email Record to set
     */
    public void setEmailUID(Long emailUID) {
        this.emailUID = emailUID;
    }

    /**
     * Returns the value of Unique Identifier of Person record
     * 
     * @return Long Unique Identifier of Person record
     */
    public Long getPersonUID() {
        return personUID;
    }

    /**
     * Sets the value of Unique Identifier of Person record
     * 
     * @param personUID Long Unique Identifier of Person record to set
     */
    public void setPersonUID(Long personUID) {
        this.personUID = personUID;
    }

    /**
     * Returns the String representation of All notif Model
     * 
     * @return String String representation of All notif Model
     */
    @Override
    public String toString() {
        return "AllNotificationConfig [allNotificationConfigUID=" + allNotificationConfigUID
                + ", informationChannelUID=" + informationChannelUID + ", emailUID=" + emailUID + ", personUID="
                + personUID + "]";
    }

}
