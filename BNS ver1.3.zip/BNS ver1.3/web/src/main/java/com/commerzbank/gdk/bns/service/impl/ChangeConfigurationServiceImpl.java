package com.commerzbank.gdk.bns.service.impl;

import java.util.HashSet;
import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Agreements;
import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeConfigurationResponse;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.ChangeConfigurationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement the business logic to change
 * configuration.
 * 
 * @author ZE2BAUL
 * @since 21/12/2017
 * @version 1.06
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2BAUL    Initial Version
 * 28/12/2017        1.01       ZE2CRUH    Added response instantiation and removed final tag
 * 18/01/2018        1.02       ZE2BUEN    Modified implementation for requestForChangeConfiguration
 * 09/02/2018        1.03       ZE2BUEN    Added logging for requestForChangeConfiguration
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 * 19/02/2018        1.05       ZE2BUEN    Removed logging if there are no changes for notification configurations
 * 21/02/2018        1.06       ZE2MACL    Added required field/s validation
 *          </pre>
 */
@Service
@Transactional
public class ChangeConfigurationServiceImpl implements ChangeConfigurationService {

    /**
     * DAO of Person.
     */
    @Autowired
    private PersonDAO personDAO;

    /**
     * DAO of NotificationConfigPerosn.
     */
    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    /**
     * DAO of NotificationConfigAgreementDAO.
     */
    @Autowired
    private NotificationConfigAgreementDAO notifConfigAgreementDAO;

    /**
     * DAO of Agreement.
     */
    @Autowired
    private AgreementDAO agreementDAO;

    /**
     * DAO of Notification Text.
     */
    @Autowired
    private NotificationTextDAO notifTextDAO;

    /**
     * Used to access the values in the property files for ZSL constants.
     */
    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    /**
     * Logger
     */
    private static final Logger logger = LoggerFactory.getLogger(ChangeConfigurationServiceImpl.class);

    /**
     * Constant variable for ZSL_STATUS_OK.
     */
    private static final String STATUS_OK_SUCCESS = "ZSL_STATUS_OK";

    /**
     * Constant variable for ZSL_STATUS_NO_CHANGES_REQ.
     */
    private static final String STATUS_OK_NO_CHANGES_REQ = "ZSL_STATUS_NO_CHANGES_REQ";

    /**
     * Constant variable for ZSL_STATUS_FA_BPKENN_NOT_EXISTS".
     */
    private static final String STATUS_FA_BPKENN_NOT_EXIST = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";

    /**
     * Constant variable for ZSL_STATUS_FA_INVALID_REQUEST.
     */
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";

    /**
     * Constant variable for STATUS_FA_FAILED_CHANGE_CONFIG.
     */
    private static final String STATUS_FA_FAILED_CHANGE_CONFIG = "ZSL_STATUS_FA_FAILED_CHANGE_CONFIG";

    private static final String EMPTY_STRING = "";

    /**
     * Response of the Change Configuration Request.
     */
    private ChangeConfigurationResponse response = new ChangeConfigurationResponse();

    /**
     * Processes request for change configuration and returns change
     * configuration response
     * 
     * @param request ChangeConfigurationRequest Change Configuration Request
     *            sent by ZSL.
     * @return ChangeConfigurationResponse Change Configuration Response
     * @throws Exception if exception occur.
     * 
     */
    @Override
    public ChangeConfigurationResponse requestForChangeConfiguration(ChangeConfigurationRequest request) {
        String status = EMPTY_STRING;
        response = new ChangeConfigurationResponse();
        Boolean noUpdates = true;

        response.setBpkenn(request.getBpkenn());

        try {
            status = this.validateRequest(request);
            if (isNullOrEmpty(status)) {
                // Person Notification Configuration
                Person person = this.personDAO.findByBpkennIgnoreCase(request.getBpkenn());

                if (Objects.nonNull(person)) {
                    NotificationConfigPerson notifConfigPerson = this.notificationConfigPersonDAO
                                    .findByPersonUID(person.getPersonUID());
                    if (Objects.nonNull(notifConfigPerson)) {

                        if (!request.getActive().equals(notifConfigPerson.getActive())) {
                            notifConfigPerson.setActive(request.getActive());
                            this.notificationConfigPersonDAO.save(notifConfigPerson);

                            this.logNotifConfigPersonUpdate(notifConfigPerson.getNotifConfigPersonUID(), request);

                            response.setStatus(this.environment.getProperty((STATUS_OK_SUCCESS)));

                            noUpdates = false;
                        }

                    }

                    // Agreement Notification Configuration
                    if (Objects.nonNull(request.getAgreements())) {

                        for (Agreements agreements : request.getAgreements()) {

                            Agreement agreement = this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(
                                            person.getPersonUID(), agreements.getVereinbarungskennung(),
                                            agreements.getSparte());

                            if (Objects.nonNull(agreement)) {

                                if (agreements.getActive()) {
                                    NotificationConfigAgreement notificationConfigAgreement = this.notifConfigAgreementDAO
                                                    .findByAgreementUID(agreement.getAgreementUID());

                                    if (Objects.nonNull(notificationConfigAgreement)) {

                                        if (!agreements.getActive().equals(notificationConfigAgreement.getActive())) {
                                            notificationConfigAgreement.setActive(agreements.getActive());
                                            this.notifConfigAgreementDAO.save(notificationConfigAgreement);

                                            this.logNotifConfigAgreementUpdate(request.getBpkenn(),
                                                            notificationConfigAgreement.getNotifConfigAgreementUID(),
                                                            agreements);
                                            noUpdates = false;
                                        }

                                    }

                                } else {

                                    this.deleteAgreementRelated(agreement);
                                    this.logAgreementDeletion(request.getBpkenn(), agreement.getAgreementUID(),
                                                    agreements);

                                    noUpdates = false;
                                }

                            }

                        }
                    }

                } else {
                    response.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXIST));
                }

                if (noUpdates && Objects.isNull(response.getStatus())) {
                    response.setStatus(this.environment.getProperty(STATUS_OK_NO_CHANGES_REQ));
                } else if (Objects.isNull(response.getStatus())) {
                    response.setStatus(this.environment.getProperty(STATUS_OK_SUCCESS));
                }

            } else {
                response.setStatus(status.toString());
            }

        } catch (Exception ex) {
            response.setStatus(this.environment.getProperty(STATUS_FA_FAILED_CHANGE_CONFIG));
            logger.error(ex.getMessage(), ex);
        }

        return response;
    }

    /**
     * Validates request
     * 
     * @param request ChangeConfigurationRequest Request for Change
     *            Configuration
     * @return String
     * 
     */
    private String validateRequest(ChangeConfigurationRequest request) {
        HashSet<String> invalidFields = new HashSet<String>();
        String invalidMsg;

        if (isNullOrEmpty(request.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        if (Objects.isNull(request.getActive())) {
            invalidFields.add("active");
        }

        for (Agreements agreements : request.getAgreements()) {

            if (isNullOrEmpty(agreements.getVereinbarungskennung())) {
                invalidFields.add("vereinbarungskennung");
            }

            if (Objects.isNull(agreements.getSparte())) {
                invalidFields.add("sparte");
            }

            if (Objects.isNull(agreements.getActive())) {
                invalidFields.add("active");
            }

        }

        invalidMsg = requiredFieldValidation.requiredField(invalidFields);

        return invalidMsg;

    }

    /**
     * Method to check if string is null or empty.
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
    }

    /**
     * Deletes all agreement-related records
     * 
     * @param agreement Agreement Agreement record
     * 
     */
    private void deleteAgreementRelated(Agreement agreement) {

        if (Objects.nonNull(agreement)) {

            NotificationConfigAgreement notifConfigAgreement = this.notifConfigAgreementDAO
                            .getNotifConfigAgreement(agreement.getAgreementUID());

            if (Objects.nonNull(notifConfigAgreement)) {
                this.notifTextDAO.delete(notifConfigAgreement.getNotificationTextUID());
            }

            this.agreementDAO.delete(agreement);

        }

    }

    /**
     * Log Agreement Deletion
     * 
     * @param bpkenn String Bpkenn from Request
     * @param agreementUID Long Unique Identifier for Agreement record
     * @param agreement Agreements Agreements from Request
     * 
     */
    private void logAgreementDeletion(String bpkenn, Long agreementUID, Agreements agreement) {

        logger.info("=>> System [{}] - requestForChangeConfiguration - Delete Agreement ("
                        + "[bpkenn= {}, agreementUID= {}, vereinbarungskennung= {}, sparte= {}, active= {}])", "ZSL",
                        bpkenn, agreementUID, agreement.getVereinbarungskennung(), agreement.getSparte(),
                        agreement.getActive());

    }

    /**
     * Log Notification Configuration Agreement Update
     * 
     * @param bpkenn String Bpkenn from Request
     * @param notifConfigAgreementUID Long Unique Identifier for Notification
     *            Config Agreement record
     * @param agreement Agreements Agreement from Request
     * 
     */
    private void logNotifConfigAgreementUpdate(String bpkenn, Long notifConfigAgreementUID, Agreements agreement) {

        logger.info("=>> System [{}] - requestForChangeConfiguration - Update Notification Configuration Agreement ("
                        + "[bpkenn= {}, notifConfigAgreementUID= {}, vereinbarungskennung= {}, sparte= {}, active= {}])",
                        "ZSL", bpkenn, notifConfigAgreementUID, agreement.getVereinbarungskennung(),
                        agreement.getSparte(), agreement.getActive());

    }

    /**
     * Log Notification Config Person Update
     * 
     * @param notifConfigPersonUID Long Unique Identifier for Notification
     *            Config Person record
     * @param request ChangeConfigurationRequest Change Configuration Request
     * 
     */
    private void logNotifConfigPersonUpdate(Long notifConfigPersonUID, ChangeConfigurationRequest request) {

        logger.info("=>> System [{}] - requestForChangeConfiguration - Update Notification Configuration Person ("
                        + "[bpkenn= {}, notifConfigPersonUID= {}, active= {}])", "ZSL", request.getBpkenn(),
                        notifConfigPersonUID, request.getActive());

    }

}
