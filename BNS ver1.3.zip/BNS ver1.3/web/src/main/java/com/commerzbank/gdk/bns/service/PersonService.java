package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to access the Person
 * 
 * @since 07/08/2017
 * @author ZE2SARO
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 07/08/2017        1.00       ZE2SARO    Initial Version
 * 10/11/2017        1.01       ZE2MACL    Update method to user Response builder and add tokenizer parameter
 * 20/02/2018        1.02       ZE2FUEN    Updated implementation to CIF-Integration
 * 03/13/2018        1.03       ZE2RUBI    Add healthcheckBnsDB for DB schema checking
 * </pre>
 */
public interface PersonService {
	
	ResponseBuilder<Person> getPerson(Tokenizer token);
    ResponseBuilder<Long> getPersonCount();

}
