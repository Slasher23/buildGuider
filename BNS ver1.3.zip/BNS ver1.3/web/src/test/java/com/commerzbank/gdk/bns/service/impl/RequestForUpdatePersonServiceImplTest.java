package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchUpdatePersonResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePerson;
import com.commerzbank.gdk.bns.model.RequestForUpdatePersonRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePersonService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * JUnit test class for Request For Update Person Service Implementation.
 * 
 * @author ZE2MENY
 * @since 28/11/2017
 * @version 1.04
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2MENY    Initial Version
 * 29/11/2017        1.01       ZE2MENY    Added method for batchProcessing
 * 4/12/2017         1.02       ZE2MENY    Refactor to use BatchUpdatePersonResponse
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.04       ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForUpdatePersonServiceImplTest {

	@Mock
	RequestForUpdatePersonService requestForUpdServiceMock;

	@Mock
	PersonDAO personDAO;

	@Mock
	Environment environment;
	
	@Mock
	RequiredFieldValidation requiredFieldValidation;

	@InjectMocks
	RequestForUpdatePersonServiceImpl requestForUpdatePersonServiceImpl;

	private RequestForUpdatePersonRequest request;
	private Person person;

	List<RequestForUpdatePersonRequest> requestList;

	private static final String STATUS_OK = "ZSL_STATUS_OK";
	private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
	private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_NO_CHANGES_REQ = "ZSL_STATUS_NO_CHANGES_REQ";

	RequestForUpdatePersonRequest updatePersonrequest = new RequestForUpdatePersonRequest();
	RequestForBatchUpdatePerson reqBatch = new RequestForBatchUpdatePerson();
	BatchUpdatePersonResponse response = new BatchUpdatePersonResponse();
	ZslUpdateResponse updatePersonresponse = new ZslUpdateResponse();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		requestList = new ArrayList<RequestForUpdatePersonRequest>();
		request = new RequestForUpdatePersonRequest();
		request.setBpkenn("12345");
		request.setFirstName("Joy");
		request.setLastName("Mendoza");

		requestList.add(request);

	}

	@Test
	public void getResponseSuccessful_Test() throws Exception {
	    String invalidMsg = "";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("12345");
		responseExpected.setStatus("OK- No changes required");

		person = new Person();
		person.setBPKENN("12345");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_NO_CHANGES_REQ)).thenReturn("OK- No changes required");
		when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void getResponseSuccessful_Update_FirstName_Test() throws Exception {
	    String invalidMsg = "";
		request = new RequestForUpdatePersonRequest();
		request.setBpkenn("test");
		request.setFirstName("Joyss");
		request.setLastName("Mendoza");

		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("test");
		responseExpected.setStatus("OK- Successful");

		String success_mess = "OK- Successful";

		person = new Person();
		person.setBPKENN("test");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_OK)).thenReturn(success_mess);
		when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void getResponseSuccessful_Update_LastName_Test() throws Exception {
	    String invalidMsg = "";
		request = new RequestForUpdatePersonRequest();
		request.setBpkenn("test");
		request.setFirstName("Joy");
		request.setLastName("Mendozaa");

		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("test");
		responseExpected.setStatus("OK- Successful");
		String success_mess = "OK- Successful";

		person = new Person();
		person.setBPKENN("test");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_OK)).thenReturn(success_mess);
		when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void getResponseSuccessful_Update_Both_Test() throws Exception {
	    String invalidMsg = "";
		request = new RequestForUpdatePersonRequest();
		request.setBpkenn("test");
		request.setFirstName("Joyaa");
		request.setLastName("Mendozaa");

		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("test");
		responseExpected.setStatus("OK- Successful");
		String success_mess = "OK- Successful";

		person = new Person();
		person.setBPKENN("test");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_OK)).thenReturn(success_mess);
		when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void getResponseSuccessful_Update_Last_Test() throws Exception {
	    String invalidMsg = "";
		request = new RequestForUpdatePersonRequest();
		request.setBpkenn("12345");
		request.setFirstName("Joy");
		request.setLastName("Mendo");

		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("12345");
		responseExpected.setStatus("OK- Successful");

		String success_mess = "OK- Successful";

		person = new Person();
		person.setBPKENN("12345");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_OK)).thenReturn(success_mess);
		when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void getResponseBPKENNDOesNOTExist_Test() throws Exception {
	    String invalidMsg = "";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("12345");
		responseExpected.setStatus("FA- BPKENN does not exists in BNS");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
		when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);

		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void requestForUpdatePerson_Null_MANDATORY_FIELDS() throws Exception {
	    String invalidMsg = "FA- Invalid request - fields bpkenn, firstName,lastName are mandatory";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setStatus("FA- Invalid request - fields bpkenn, firstName,lastName are mandatory");

		request.setBpkenn(null);
		request.setFirstName(null);
		request.setLastName(null);
	
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);
		
		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void requestForUpdatePerson_Empty_Invalid_Request() throws Exception {
	    String invalidMsg = "FA- Invalid request - fields bpkenn, firstName,lastName are mandatory";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("");
		responseExpected.setStatus("FA- Invalid request - fields bpkenn, firstName,lastName are mandatory");

		request.setBpkenn("");
		request.setFirstName("");
		request.setLastName("");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		
		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);
		assertEquals(responseExpected.toString(), response.toString());

	}

	@Test
	public void requestForUpdatePerson_Null_BPKENN_Invalid_Request() throws Exception {
	    String invalidMsg = "FA- Invalid request - field bpkenn";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setStatus("FA- Invalid request - field bpkenn");

		request.setBpkenn(null);
		request.setFirstName("FIRTEST");
		request.setLastName("LASTTEST");
		
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);
		assertEquals(response.toString(), responseExpected.toString());

	}

	@Test
	public void requestForUpdatePerson_Null_FirstName_Invalid_Request() throws Exception {
	    String invalidMsg = "FA- Invalid request - field firstName";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("12345");
		responseExpected.setStatus("FA- Invalid request - field firstName");

		person = new Person();
		person.setBPKENN("12345");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");

		request.setBpkenn("12345");
		request.setFirstName(null);
		request.setLastName("LASTTEST");
		
		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person);
		
		when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);
		assertEquals(response.toString(), responseExpected.toString());
	}

	@Test
	public void requestForUpdatePerson_Null_LastName_Invalid_Request() throws Exception {
	    String invalidMsg = "FA- Invalid request - field lastName";
		ZslUpdateResponse responseExpected = new ZslUpdateResponse();
		responseExpected.setBpkenn("12345");
		responseExpected.setStatus("FA- Invalid request - field lastName");

		person = new Person();
		person.setBPKENN("12345");
		person.setGivenName("Joy");
		person.setLastName("Mendoza");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");

		request.setBpkenn("12345");
		request.setFirstName("FIRTEST");
		request.setLastName(null);

		when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person);
		
		ZslUpdateResponse response = this.requestForUpdatePersonServiceImpl.requestForUpdateResponse(this.request);
		assertEquals(response.toString(), responseExpected.toString());
	}

	@Test
	public void requestForBatchUpdatePerson_NoError_Test() throws Exception {

		ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
		zslUpdateResponse.setBpkenn("12345");
		zslUpdateResponse.setStatus("OK- No changes required");

		when(this.environment.getProperty(STATUS_NO_CHANGES_REQ)).thenReturn("OK- No changes required");

		Person person2 = new Person();
		person2.setBPKENN("12345");
		person2.setGivenName("Joy");
		person2.setLastName("Mendoza");
		person2.setPersonUID(1L);
		person2.setSalutation("01");
		person2.setTitle("01");

		reqBatch.setUpdatePersonRequest(requestList);

		BatchUpdatePersonResponse batchUpdatePersonResponse = new BatchUpdatePersonResponse();

		when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person2);

		List<ZslUpdateResponse> updatePersonResponse = new ArrayList<ZslUpdateResponse>();
		updatePersonResponse.add(zslUpdateResponse);
		batchUpdatePersonResponse.setUpdatePersonResponse(updatePersonResponse);

		when(this.requestForUpdServiceMock.requestForUpdateResponse(request)).thenReturn(zslUpdateResponse);

		BatchUpdatePersonResponse updateResponse = this.requestForUpdatePersonServiceImpl
						.requestForBatchUpdatePerson(reqBatch);

		assertEquals(updateResponse.getUpdatePersonResponse().toString(), updatePersonResponse.toString());

	}

	@Test
	
	public void requestForBatchUpdatePerson_WithError_Test() throws Exception {

		ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
		zslUpdateResponse.setBpkenn("12345");
		zslUpdateResponse.setStatus("FA- BPKENN does not exists in BNS");

		Person person2 = new Person();
		person2.setBPKENN("12345");
		person2.setGivenName("Joy");
		person2.setLastName("Mendoza");
		person2.setPersonUID(1L);
		person2.setSalutation("01");
		person2.setTitle("01");

		reqBatch.setUpdatePersonRequest(requestList);

		BatchUpdatePersonResponse batchUpdatePersonResponse = new BatchUpdatePersonResponse();

		when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person2);

		List<ZslUpdateResponse> updatePersonResponseWithErrors = new ArrayList<ZslUpdateResponse>();
		updatePersonResponseWithErrors.add(zslUpdateResponse);
		batchUpdatePersonResponse.setUpdatePersonResponseWithErrors(updatePersonResponseWithErrors);

		when(this.requestForUpdServiceMock.requestForUpdateResponse(request)).thenReturn(zslUpdateResponse);
		
		when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
		
		BatchUpdatePersonResponse updateResponse = this.requestForUpdatePersonServiceImpl
						.requestForBatchUpdatePerson(reqBatch);

		assertEquals(updateResponse.getUpdatePersonResponseWithErrors().toString(),
						updatePersonResponseWithErrors.toString());

	}

}
