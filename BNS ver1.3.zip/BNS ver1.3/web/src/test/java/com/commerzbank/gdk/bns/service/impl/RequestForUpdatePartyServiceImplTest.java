package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.ComplexElectronicAddress;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * 
 * JUnit Test Class for RequestForDeactivatePersonServiceImpl
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 11/12/2017      1.00      ZE2GOME    Initial Version
 * 14/12/2017      1.01      ZE2MENY    Change complexelectronicalAddress into electronicalAddress
 * 14/12/2017      1.02      ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForUpdatePartyServiceImplTest {

    @Mock
    private PersonDAO personDAO;

    @Mock
    private EmailDAO emailDao;

    @Mock
    private RequestForUpdatePartyService forUpdatePartyService;
    
    @Mock
    private Environment environment;
    
    @Mock
    private RequiredFieldValidation requiredFieldValidation;

    @InjectMocks
    private RequestForUpdatePartyServiceImpl forUpdatePartyServiceImpl;

    private Person person;
    private Email email;
    private ZslUpdateResponse response;
    private UpdatePartyRequest updatePartyRequest;
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_NO_CHANGES_REQ = "ZSL_STATUS_NO_CHANGES_REQ";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        person = new Person();

        person.setBPKENN("test");
        person.setGivenName("test");
        person.setLastName("test");
        person.setPersonUID(1L);
        person.setSalutation("01");
        person.setTitle("01");

        email = new Email();
        email.setAddressId(1L);
        email.setEmailAddress("test@test.com");
        email.setEmailUID(1L);
        email.setPersonUID(1L);

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("BPKENNTEST");
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("02");
        updatePartyRequest.setTitle("02");

        ComplexElectronicAddress cea = new ComplexElectronicAddress();
        cea.setAddressId(1L);
        cea.setEmailAddress("test@test.com");

        List<ComplexElectronicAddress> ceaList = new ArrayList<ComplexElectronicAddress>();
        ceaList.add(cea);

        updatePartyRequest.setElectronicalAddress(ceaList);

    }

    @Test
    public void requestForUpdateParty_Test() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForUpdateParty_Test_Bpkenn_Null() throws Exception {
        String invalidMsg ="FA- Invalid request - field bpkenn is mandatory";
        response = new ZslUpdateResponse();
        response.setBpkenn(null);
        response.setStatus("FA- Invalid request - field bpkenn is mandatory");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn(null);
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);
        
        when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
        when(this.personDAO.findByBpkennIgnoreCase(null)).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }
    
    @Test
    public void requestForUpdateParty_Test_Lastname_Null() throws Exception {
        String invalidMsg ="FA- Invalid request - field lastName is mandatory";
        response = new ZslUpdateResponse();
        response.setBpkenn("Bpkenn");
        response.setStatus("FA- Invalid request - field lastName is mandatory");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("Bpkenn");
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName(null);
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);
        
        when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
        when(this.personDAO.findByBpkennIgnoreCase(null)).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }
    
    @Test
    public void requestForUpdateParty_Test_Firstname_Null() throws Exception {
        String invalidMsg ="FA- Invalid request - field firstName is mandatory";
        response = new ZslUpdateResponse();
        response.setBpkenn("Bpkenn");
        response.setStatus("FA- Invalid request - field firstName is mandatory");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("Bpkenn");
        updatePartyRequest.setFirstName(null);
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);
        
        when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
        when(this.personDAO.findByBpkennIgnoreCase(null)).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }
    
    @Test
    public void requestForUpdateParty_Test_RequiredField_Null() throws Exception {
        String invalidMsg ="FA- Invalid request - field bpkenn, firstName, lastName are mandatory";
        response = new ZslUpdateResponse();
        response.setBpkenn(null);
        response.setStatus("FA- Invalid request - field bpkenn, firstName, lastName are mandatory");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn(null);
        updatePartyRequest.setFirstName(null);
        updatePartyRequest.setLastName(null);
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);
        
        when(requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
        when(this.personDAO.findByBpkennIgnoreCase(null)).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }
    
    

    @Test
    public void requestForUpdateParty_Test_Person_Null() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("FA- BPKENN does not exists in BNS");

        Person newPerson = null;

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(newPerson);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForUpdateParty_Test_Invalid_Request() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("FA- Invalid Request");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("BPKENNTEST");
        updatePartyRequest.setFirstName("");
        updatePartyRequest.setLastName(null);
        updatePartyRequest.setSalutation(null);
        updatePartyRequest.setTitle("");

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");
        
        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForUpdateParty_Test_Complex_Address_Null() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("BPKENNTEST");
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");

        Person newPerson = new Person();

        newPerson.setBPKENN("BPKENNTEST");
        newPerson.setGivenName("TestName");
        newPerson.setLastName("TestLastname");
        newPerson.setPersonUID(1L);
        newPerson.setSalutation("01");
        newPerson.setTitle("01");

        ComplexElectronicAddress cea = new ComplexElectronicAddress();
        cea.setAddressId(null);
        cea.setEmailAddress("test@test.com");

        List<ComplexElectronicAddress> ceaList = new ArrayList<ComplexElectronicAddress>();
        ceaList.add(cea);

        updatePartyRequest.setElectronicalAddress(ceaList);

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(newPerson);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(email);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForUpdateParty_Test_Equal_To_Db() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");
        
        Person newPerson = new Person();
        
        newPerson.setBPKENN("BPKENNTEST");
        newPerson.setGivenName("TestName");
        newPerson.setLastName("TestLastname");
        newPerson.setPersonUID(1L);
        newPerson.setSalutation("02");
        newPerson.setTitle("02");

        Email newEmail = new Email();
        newEmail.setAddressId(1L);
        newEmail.setEmailAddress("test@test.com");
        newEmail.setEmailUID(1L);
        newEmail.setPersonUID(1L);

        UpdatePartyRequest newPpdatePartyRequest = new UpdatePartyRequest();

        newPpdatePartyRequest.setBpkenn("BPKENNTEST");
        newPpdatePartyRequest.setFirstName("TestName");
        newPpdatePartyRequest.setLastName("TestLastname");
        newPpdatePartyRequest.setSalutation("02");
        newPpdatePartyRequest.setTitle("02");
        
        ComplexElectronicAddress cea = new ComplexElectronicAddress();
        cea.setAddressId(1L);
        cea.setEmailAddress("test@test.com1");

        List<ComplexElectronicAddress> ceaList = new ArrayList<ComplexElectronicAddress>();
        ceaList.add(cea);
        
        newPpdatePartyRequest.setElectronicalAddress(ceaList);

        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(newPerson);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(newEmail);
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        
        when(this.environment.getProperty(STATUS_NO_CHANGES_REQ)).thenReturn("OK- No changes required");
       
        ZslUpdateResponse responseActual = this.forUpdatePartyServiceImpl.requestForUpdateParty(newPpdatePartyRequest);

        assertEquals(response.toString(), responseActual.toString());

    }

    @Test
    public void requestForUpdateParty_Test_Email_Null() throws Exception {

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");

        Email newEmail = null;
        List<Email> emailList = new ArrayList<Email>();
        emailList.add(email);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(this.person);
        when(this.emailDao.findByPersonUID(any(Long.class))).thenReturn(emailList);
        when(this.emailDao.findByPersonUIDAndAddressId(any(Long.class), any(Long.class))).thenReturn(newEmail);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        ZslUpdateResponse responseExpected = this.forUpdatePartyServiceImpl.requestForUpdateParty(updatePartyRequest);

        assertEquals(responseExpected.toString(), response.toString());

    }

}
