package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.dao.DataRetrievalFailureException;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for AgreementServiceImpl test
 * 
 * @author 	ZE2MACL
 * @since 	14/11/2017
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Removed Participant Number
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class AgreementServiceImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;
    
	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
	
	@Mock
	private PersonDAO personDAO;
	
    @Mock
    private AgreementDAO agreementDAO;
	
    @InjectMocks
    private AgreementServiceImpl agreementServiceImpl;

    private Agreement agreement;
    
	private Person person;
    
    private List<Agreement> agreementList = new ArrayList<Agreement>();
    
    private Parameter parameter;

    private Tokenizer token;

    private ResponseBuilder<List<Agreement>> builder;
    
    private static final Logger logger = LoggerFactory.getLogger(AgreementServiceImpl.class);

    private Map<Integer, String> statusCodesMap;
   
    
    @Before
    public void init() {
    	MockitoAnnotations.initMocks(this);
    	
        parameter = new Parameter();
        parameter.setBpkenn("test");
        
        person = new Person();
        person.setBPKENN("test");
        person.setPersonUID(1L);
        
        agreement = new Agreement();
        agreement.setAgreementUID(1L);
        agreement.setAgreementID("test");
        agreement.setAgreementType("test");
        agreement.setBranch(100);
        agreement.setType("test");
        
        agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        token = new Tokenizer();
        token.setUserId("test");
        token.setError(false);

        statusCodesMap = this.globalRWrapper.getStatusCodesMap();

    }    
    
    @Test
    public void getAgreementList_Successful_Test() throws Exception{
        
        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);
        builder.OK(agreementList);
        
        when(personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(agreementDAO.getAgreementList(anyLong())).thenReturn(agreementList);
       
        assertEquals(builder.toString() , this.agreementServiceImpl.getAgreementList(token, parameter).toString());
    }
    
    @Test
    public void getAgreementList_SuccessNullResult_Test() throws Exception{
        
        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);
        builder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);
        
        when(personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(agreementDAO.getAgreementList(anyLong())).thenReturn(null);
       
        assertEquals(builder.toString() , this.agreementServiceImpl.getAgreementList(token, parameter).toString());
    }
    
    @Test
    public void getAgreementList_DataAccessException_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);
        builder.notOK(Response.DATA_ACCESS_EXCEPTION);
        
        when(personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(agreementDAO.getAgreementList(anyLong())).thenThrow(new DataRetrievalFailureException("test"));
     
        assertEquals(builder.toString() , this.agreementServiceImpl.getAgreementList(token, parameter).toString());
    }
    
    @Test
    public void getAgreementList_NullPointerException_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);
        builder.notOK(Response.NULL_POINTER_EXCEPTION);

        when(personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(agreementDAO.getAgreementList(anyLong())).thenThrow(new NullPointerException("error"));
       
        assertEquals(builder.toString() , this.agreementServiceImpl.getAgreementList(token, parameter).toString());
    }
    
    @Test
    public void getAgreementList_Exception_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);
        builder.notOK(Response.GENERAL_FUNCTION_ERROR);

        when(personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(agreementDAO.getAgreementList(anyLong())).thenThrow(new RuntimeException("error"));
       
        assertEquals(builder.toString() , this.agreementServiceImpl.getAgreementList(token, parameter).toString());
    }  

}
