package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.dao.DataRetrievalFailureException;

import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for InformationChannelServiceImpl Test
 * 
 * @author ZE2MORA
 * @since 28/11/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017	     1.00      ZE2MORA    Initial Version
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class InformationChannelServiceImplTest {
	
	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private InformationChannelDAO informationChannelDAO;

	@InjectMocks
	private InformationChannelServiceImpl informationChannelServiceImpl;

	private InformationChannel informationChannel;

	private List<InformationChannel> InformationChannelList = new ArrayList<InformationChannel>();

	private Tokenizer token;

	private ResponseBuilder<List<InformationChannel>> builder;

	private static final Logger logger = LoggerFactory.getLogger(InformationChannelServiceImpl.class);

	private Map<Integer, String> statusCodesMap;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		token = new Tokenizer();
		token.setUserId("test");
		token.setError(false);

		informationChannel = new InformationChannel();
		informationChannel.setInformationChannelType("test");
		informationChannel.setInformationChannelUID(1L);
		InformationChannelList.add(informationChannel);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		builder = new ResponseBuilder<List<InformationChannel>>(logger, token, globalRWrapper);
	}

	@Test
	public void getAgreementList_Successful_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder.OK(InformationChannelList);

		when(informationChannelDAO.getInformationChannelList()).thenReturn(InformationChannelList);

		assertEquals(builder.toString(),
				this.informationChannelServiceImpl.getInformationChannelList(token).toString());

	}

	@Test
	public void getAgreementList_SuccessfulNoResult_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(informationChannelDAO.getInformationChannelList()).thenReturn(null);

		assertEquals(builder.toString(),
				this.informationChannelServiceImpl.getInformationChannelList(token).toString());

	}

	@Test
	public void getAgreementList_DataAccessException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(informationChannelDAO.getInformationChannelList()).thenThrow(new DataRetrievalFailureException("test"));

		assertEquals(builder.toString(),
				this.informationChannelServiceImpl.getInformationChannelList(token).toString());

	}

	@Test
	public void getAgreementList_NullPointerException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(informationChannelDAO.getInformationChannelList()).thenThrow(new NullPointerException("test"));

		assertEquals(builder.toString(),
				this.informationChannelServiceImpl.getInformationChannelList(token).toString());

	}

	@Test
	public void getAgreementList_GeneralException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder.notOK(Response.GENERAL_FUNCTION_ERROR);

		when(informationChannelDAO.getInformationChannelList()).thenThrow(new RuntimeException());

		assertEquals(builder.toString(),
				this.informationChannelServiceImpl.getInformationChannelList(token).toString());

	}

}
