package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * JUnit test class for Change Email Address Service Impl
 * 
 * @since 09/11/2017
 * @author ZE2BUEN
 * @version 1.02
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 09/11/2017      1.00      ZE2BUEN    Initial Version
 * 23/11/2017      1.01      ZE2BUEN    Modified test cases to test actual implementation
 * 14/12/2017      1.02      ZE2BUEN    Refactor/ clean up for ZSL status messages
 * </pre>
 */

@RunWith(MockitoJUnitRunner.class)
public class ChangeEmailAddressServiceImplTest {

	@Mock
	private PersonDAO personDAO;

	@Mock
	private EmailDAO emailDAO;

	@Mock
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Mock
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Mock
	private AllNotificationConfigDAO allNotificationConfigDAO;

	@InjectMocks
	private ChangeEmailAddressServiceImpl changeEmailAddressServiceImpl;
	
	@Mock
	private Environment environment;
	
	@Mock
	private RequiredFieldValidation requiredFieldValidation;

	private ChangeEmailAddressRequest request;
	private Person person;

	private Email newEmailAddress;
	private Email updatedEmailAddress;
	private Email existingEmailAddress;

	private NotificationConfigAgreement notificationConfigAgreement1;
	private NotificationConfigAgreement notificationConfigAgreement2;
	private List<NotificationConfigAgreement> notificationConfigAgreementList;

	private NotificationConfigPerson notificationConfigPerson1;
	private List<NotificationConfigPerson> notificationConfigPersonList;

	private AllNotificationConfig allNotificationConfig1;
	private List<AllNotificationConfig> allNotificationConfigList;

	private ChangeEmailAddressResponse response;
	
	private static final String STATUS_OK = "ZSL_STATUS_OK";
	private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
	private static final String STATUS_FA_ADDRESS_ID_EXISTS = "ZSL_STATUS_FA_ADDRESS_ID_EXISTS";
	private static final String STATUS_FA_ADDRESS_ID_NOT_EXISTS = "ZSL_STATUS_FA_ADDRESS_ID_NOT_EXISTS";
	private static final String STATUS_FA_FAILED_CHANGE_EMAIL = "ZSL_STATUS_FA_FAILED_CHANGE_EMAIL";

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		person = new Person();
		person.setBPKENN("BPKENNTEST");
		person.setGivenName("GIVEN NAME TEST");
		person.setLastName("LAST NAME TEST");
		person.setPersonUID(1L);
		person.setSalutation("01");
		person.setTitle("01");

		newEmailAddress = new Email();
		newEmailAddress.setEmailAddress("new_email@coba.com");
		newEmailAddress.setPersonUID(1L);
		newEmailAddress.setEmailUID(2L);
		newEmailAddress.setAddressId(2L);

		updatedEmailAddress = new Email();
		updatedEmailAddress.setEmailAddress("new_email@coba.com");
		updatedEmailAddress.setPersonUID(1L);
		updatedEmailAddress.setEmailUID(1L);
		updatedEmailAddress.setAddressId(1L);

		existingEmailAddress = new Email();
		existingEmailAddress.setEmailAddress("existing_email@coba.com");
		existingEmailAddress.setPersonUID(1L);
		existingEmailAddress.setEmailUID(1L);
		existingEmailAddress.setAddressId(1L);

		notificationConfigAgreement1 = new NotificationConfigAgreement();
		notificationConfigAgreement1.setNotifConfigAgreementUID(1L);
		notificationConfigAgreement1.setNotificationTextUID(1L);
		notificationConfigAgreement1.setAgreementUID(1L);
		notificationConfigAgreement1.setEmailUID(1L);
		notificationConfigAgreement1.setActive(true);
		notificationConfigAgreement1.setInformationChannelUID(1L);

		notificationConfigAgreement2 = new NotificationConfigAgreement();
		notificationConfigAgreement2.setNotifConfigAgreementUID(2L);
		notificationConfigAgreement2.setNotificationTextUID(2L);
		notificationConfigAgreement2.setAgreementUID(2L);
		notificationConfigAgreement2.setEmailUID(1L);
		notificationConfigAgreement2.setActive(true);
		notificationConfigAgreement2.setInformationChannelUID(1L);

		notificationConfigPerson1 = new NotificationConfigPerson();
		notificationConfigPerson1.setNotifConfigPersonUID(1L);
		notificationConfigPerson1.setPersonUID(1L);
		notificationConfigPerson1.setNotificationTextUID(3L);
		notificationConfigPerson1.setInformationChannelUID(1L);
		notificationConfigPerson1.setEmailUID(1L);
		notificationConfigPerson1.setActive(true);

		notificationConfigPersonList = new ArrayList<>();
		notificationConfigPersonList.add(notificationConfigPerson1);

		allNotificationConfig1 = new AllNotificationConfig();
		allNotificationConfig1.setAllNotificationConfigUID(1L);
		allNotificationConfig1.setPersonUID(1L);
		allNotificationConfig1.setInformationChannelUID(1L);
		allNotificationConfig1.setEmailUID(1L);

		allNotificationConfigList = new ArrayList<>();
		allNotificationConfigList.add(allNotificationConfig1);

	}

	@Test
	public void requestForChangeEmailAddress_Successful_CreateAddressEvent_New_AddressId_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(3L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("CreateAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(3L);
		response.setStatus("OK- Successful");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(null);

		// create new email address record
		when(this.emailDAO.save(any(Email.class))).thenReturn(newEmailAddress);
		
		when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_CreateAddressEvent_Existing_AddressId_Test() throws Exception {
	    String invalidMsg = "";
		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("CreateAddressEvent");
		request.setEmailAddress("existing_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(1L);
		response.setStatus("FA- Address Id is existing in BNS");
		
		when(this.requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class)))
				.thenReturn(existingEmailAddress);
		
		when(this.environment.getProperty(STATUS_FA_ADDRESS_ID_EXISTS)).thenReturn("FA- Address Id is existing in BNS");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_UpdateAddressEvent_New_AddressId_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(3L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("UpdateAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(3L);
		response.setStatus("FA- Address Id does not exists in BNS");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_FA_ADDRESS_ID_NOT_EXISTS)).thenReturn("FA- Address Id does not exists in BNS");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Successful_UpdateAddressEvent_Existing_AddressId_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("UpdateAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(1L);
		response.setStatus("OK- Successful");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class)))
				.thenReturn(existingEmailAddress);

		// update the existing email record
		when(this.emailDAO.save(any(Email.class))).thenReturn(updatedEmailAddress);
		
		when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_DeleteAddressEvent_New_AddressId_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(3L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("DeleteAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(3L);
		response.setStatus("FA- Address Id does not exists in BNS");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_FA_ADDRESS_ID_NOT_EXISTS)).thenReturn("FA- Address Id does not exists in BNS");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Successful_DeleteAddressEvent_Existing_AddressId_With_Notif_Config_Test()
			throws Exception {
	    String invalidMsg = "";
		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("DeleteAddressEvent");
		request.setEmailAddress("existing_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(1L);
		response.setStatus("OK- Successful");
		
		when(this.requiredFieldValidation.requiredField(any())).thenReturn(invalidMsg);
		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(existingEmailAddress);

		// delete existing notif config
		when(this.notificationConfigAgreementDAO.findByEmailUID(any(Long.class)))
				.thenReturn(notificationConfigAgreementList).thenReturn(null);

		when(this.notificationConfigPersonDAO.findByEmailUID(any(Long.class))).thenReturn(notificationConfigPersonList)
				.thenReturn(null);

		when(this.allNotificationConfigDAO.findByEmailUID(any(Long.class))).thenReturn(allNotificationConfigList)
				.thenReturn(null);

		// delete the existing email record
		when(this.emailDAO.findByEmailUID(existingEmailAddress.getEmailUID())).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
		
		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Successful_DeleteAddressEvent_Existing_AddressId_Without_Notif_Config_Test()
			throws Exception {

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(existingEmailAddress);

		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("DeleteAddressEvent");
		request.setEmailAddress("existing_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNTEST");
		response.setAddressId(1L);
		response.setStatus("OK- Successful");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
		when(this.emailDAO.findByAddressId(any(Long.class))).thenReturn(existingEmailAddress);

		// delete the existing email record
		when(this.emailDAO.findByEmailUID(existingEmailAddress.getEmailUID())).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_NULL_BPKENN_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(null);
		request.setBpkenn(null);
		request.setChangeEventType(null);
		request.setEmailAddress(null);

		response = new ChangeEmailAddressResponse();
		response.setBpkenn(null);
		response.setAddressId(null);
		response.setStatus("FA- Invalid Request");
		
		when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_Empty_BPKENN_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(null);
		request.setBpkenn("");
		request.setChangeEventType("");
		request.setEmailAddress("");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("");
		response.setAddressId(null);
		response.setStatus("FA- Invalid Request");
		
		when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_Invalid_BPKENN_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNINVALID");
		request.setChangeEventType("CreateAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setBpkenn("BPKENNINVALID");
		response.setAddressId(1L);
		response.setStatus("FA- BPKENN does not exists in BNS");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@Test
	public void requestForChangeEmailAddress_Fail_Invalid_Change_Event_Type_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("INVALID");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setAddressId(1L);
		response.setBpkenn("BPKENNTEST");
		response.setStatus("FA- Invalid Request");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(null);
		
		when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void requestForChangeEmailAddress_Fail_Exception_Test() throws Exception {

		request = new ChangeEmailAddressRequest();
		request.setAddressId(1L);
		request.setBpkenn("BPKENNTEST");
		request.setChangeEventType("CreateAddressEvent");
		request.setEmailAddress("new_email@coba.com");

		response = new ChangeEmailAddressResponse();
		response.setAddressId(1L);
		response.setBpkenn("BPKENNTEST");
		response.setStatus("FA- Request for Change Email Address not processed");

		when(this.personDAO.getPerson(any(String.class))).thenReturn(person);

		// Throws exception
		when(this.emailDAO.findByAddressId(any(Long.class))).thenThrow(Exception.class);
		
		when(this.environment.getProperty(STATUS_FA_FAILED_CHANGE_EMAIL)).thenReturn("FA- Request for Change Email Address not processed");

		assertEquals(response.toString(),
				this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(request).toString());

	}

}
