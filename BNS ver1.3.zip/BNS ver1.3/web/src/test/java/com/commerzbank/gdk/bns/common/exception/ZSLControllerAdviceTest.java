package com.commerzbank.gdk.bns.common.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;

/** 
* JUnit class for GlobalExceptionHandler 
* 
* @since 28/02/2018
* @author ZE2BUEN
* @version 1.00
*
* Modified Date   Version   Author     Description
* 28/02/2018      1.00      ZE2BUEN    Initial Version
*/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/resources/configuration.xml")
public class ZSLControllerAdviceTest {

	@Autowired
	private GlobalResponseWrapper message;

	@InjectMocks
	private ZSLControllerAdvice zslControllerAdvice;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		Mockito.reset(globalResponseWrapper);

	}
	
	@SuppressWarnings("serial")
	@Test
	public void testReturnNotReadableException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.BAD_REQUEST.toString());
		responseMessage.setMessage("Caused by: HttpMessageNotReadableException");
		responseMessage.setData(null);
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.BAD_REQUEST);

		when(globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString())).thenReturn(responseMessage);
		assertEquals(rm, zslControllerAdvice.returnNotReadableException(
				new HttpMessageNotReadableException("Caused by: HttpMessageNotReadableException", null) {
				}));
	}
		
}
