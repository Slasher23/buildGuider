package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.mockito.Matchers.anyString;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.conf.security.AuthenticatedUser;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotifConfigPersonWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.PersonConfigWrapper;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AllNotificationConfigService;

/**
 * JUnit test class for AllNotificationConfig
 * 
 * @since 23/10/2017
 * @author ZE2CRUH
 * @version 1.04
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 23/10/2017      1.00      ZE2CRUH    Initial Version
 * 13/11/2017      1.01      ZE2MACL    Updated method to used response builder and added token parameter
 * 27/11/2017      1.02      ZE2CRUH    Removed Participant Number
 * 29/11/2017      1.03      ZE2BAUL    Implemented Status Codes update
 * 13/03/2018      1.04      ZE2BUEN    Update Junit
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class AllNotificationConfigControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private AllNotificationConfigService allNotificationConfigService;

	@InjectMocks
	private AllNotificationConfigController allNotificationConfigController;

	private MockMvc mockMvc;

	private AllNotificationConfig allNotificationConfig;

	private MainAgreementTypeWrapper mainAgreementTypeWrapper;

	private AgreementTypesWrapper agreementTypesWrapper;

	private List<AgreementTypesWrapper> agreementTypesWrapperList = new ArrayList<AgreementTypesWrapper>();

	private NotificationConfigAgreementWrapper notificationConfigAgreementWrapper;

	private List<NotificationConfigAgreementWrapper> notificationConfigAgreementWrapperList = new ArrayList<NotificationConfigAgreementWrapper>();

	private Email email;

	private List<Email> emailList = new ArrayList<Email>();

	private InformationChannel informationChannel;

	private List<InformationChannel> informationChannelList = new ArrayList<InformationChannel>();

	private PersonConfigWrapper personConfigWrapper;

	private NotifConfigPersonWrapper notifConfigPersonWrapper;

	private NotificationConfigPerson notificationConfigPerson;

	private Tokenizer token;
	
	private Tokenizer errorToken;
	
	private ResponseBuilder<AllNotificationConfig> allNotifConfigBuilder;

	private ResponseBuilder<MainAgreementTypeWrapper> mainAgreementTypeBuilder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(AllNotificationConfigController.class);

	private String authHeader = "comdirect role=[{\"name\":\"KUNDE\",\"publicData\":{\"01-03-64\":\"<ccb-authentication><protocolVersion>1.1</protocolVersion><recipient>01-03-64</recipient><userid>017WDY60T0QVTTWT;BPKENNTEST10</userid><useridType>TNVEKENN</useridType><issuedFrom>14-04-34</issuedFrom><requester>PK-WEB</requester><authenticationStrength>PIN</authenticationStrength><issueInstant>2018-02-14-11:07:26 UTC</issueInstant><notValidAfter>2018-02-14-11:33:56 UTC</notValidAfter><ticketId>a3f3a23d0ef41d3a</ticketId><sessionId>112EEAE892A3C6F2BB76E87CACB6FAB3</sessionId><signature>IIPICfqbdtDvv0i3AMBzrMZeJ9gmqhfo8/0jZtgNWgOBLz4UHIlMc33dOf29u6F0psh/3mnfGFpkW3haffch6Okd0HtinM6bnO7pRORv+SAzeicIO7MPsKYmSWdBY7+q4gFfeYgZmFR+3y6+8e9QkiJ93C81cwDpU9rVz6Rg9JGPq5sHqQQnMmTHNYH2CPyvS0jOgaggVaKHRdjtAFO+q0eT4VraXRXMlLe0hu8xg2k3exqUX5IQjLUw/DrEb2R7bvJ2X7x1eVT7rr4cmyqXqoCtdzBlA1tOH2wEUuX7QCrZbtBEWRArwuPElbaOvQ2ceVYQtOhq9qZ3whZbOAD/Mw==</signature><legacySignature>LEGACYSIGNATURENOLONGERPROVIDED++LEGACYSIGNATURENOLONGERPROVIDED</legacySignature></ccb-authentication>\"}}]";

	private HttpHeaders header;

	private UsernamePasswordAuthenticationToken authToken;
	
	private UsernamePasswordAuthenticationToken errorAuthToken;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(allNotificationConfigController).build();

		notificationConfigAgreementWrapper = new NotificationConfigAgreementWrapper();
		notificationConfigAgreementWrapper.setAgreement("Agreement Test");
		notificationConfigAgreementWrapper.setTextType("Test textype");
		notificationConfigAgreementWrapper.setType("Premuim");

		notificationConfigAgreementWrapperList.add(notificationConfigAgreementWrapper);

		agreementTypesWrapper = new AgreementTypesWrapper();
		agreementTypesWrapper.setAgreementType("KTO");
		agreementTypesWrapper.setAgreements(notificationConfigAgreementWrapperList);

		agreementTypesWrapperList.add(agreementTypesWrapper);

		allNotificationConfig = new AllNotificationConfig();
		allNotificationConfig.setAllNotificationConfigUID(1L);
		allNotificationConfig.setEmailUID(1L);
		allNotificationConfig.setInformationChannelUID(1L);
		allNotificationConfig.setPersonUID(1L);

		email = new Email();
		email.setEmailAddress("test email address");
		email.setEmailUID(1L);
		email.setPersonUID(1L);

		emailList.add(email);

		informationChannel = new InformationChannel();
		informationChannel.setInformationChannelType("test");
		informationChannel.setInformationChannelUID(1L);

		informationChannelList.add(informationChannel);

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(false);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		notifConfigPersonWrapper = new NotifConfigPersonWrapper();
		notifConfigPersonWrapper.setTextType("test");
		notifConfigPersonWrapper.setNotificationConfigPerson(notificationConfigPerson);

		personConfigWrapper = new PersonConfigWrapper();
		personConfigWrapper.setAgreementType("KTO");
		personConfigWrapper.setPersonAgreement(notifConfigPersonWrapper);

		mainAgreementTypeWrapper = new MainAgreementTypeWrapper();
		mainAgreementTypeWrapper.setAgreementTypes(agreementTypesWrapperList);
		mainAgreementTypeWrapper.setAllNotificationConfig(allNotificationConfig);
		mainAgreementTypeWrapper.setEmail(emailList);
		mainAgreementTypeWrapper.setInformationChannel(informationChannelList);
		mainAgreementTypeWrapper.setPersonConfigType(personConfigWrapper);

		token = new Tokenizer();
		token.setUserId("");
		token.setError(false);
		token.setBpkenn("bpkenntest10");
		token.setUserType("TNVEKENN");
		token.setRole("PK-WEB");
		
		errorToken = new Tokenizer();
		errorToken.setUserId("");
		errorToken.setError(true);
		
		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		allNotifConfigBuilder = new ResponseBuilder<AllNotificationConfig>(logger, token, globalRWrapper);
		mainAgreementTypeBuilder = new ResponseBuilder<MainAgreementTypeWrapper>(logger, token, globalRWrapper);

		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority("ROLE_PK-WEB"));
		AuthenticatedUser user = new AuthenticatedUser(1L, "user", token, authorities);
		authToken = new UsernamePasswordAuthenticationToken(user, "password");
		SecurityContextHolder.getContext().setAuthentication(authToken);
		
		AuthenticatedUser errorUser = new AuthenticatedUser(1L, "user", errorToken, authorities);
		errorAuthToken = new UsernamePasswordAuthenticationToken(errorUser, "password");
		SecurityContextHolder.getContext().setAuthentication(errorAuthToken);

		header = new HttpHeaders();
		header.set(HttpHeaders.AUTHORIZATION, authHeader);

	}

	@Test
	public void getAllNotifConfig_JSONResponseCode_Test() throws Exception {

		when(allNotificationConfigService.getAllNotifConfig(any(Tokenizer.class)))
				.thenReturn(allNotifConfigBuilder.OK(allNotificationConfig));

		mockMvc.perform(post("/api/allNotificationConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig))).andExpect(jsonPath("$.code", is(1001)))
				.andExpect(status().isOk());
	}

	@Test
	public void getAllNotifConfig_JSON_Test() throws Exception {

		when(allNotificationConfigService.getAllNotifConfig(any(Tokenizer.class)))
				.thenReturn(allNotifConfigBuilder.OK(allNotificationConfig));

		mockMvc.perform(post("/api/allNotificationConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}
	
	@Test
	public void getAllNotifConfig_JSON_ErrorToken_Test() throws Exception {

		mockMvc.perform(post("/api/allNotificationConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(errorAuthToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveAllNotifConfig_JSONResponseCode_Test() throws Exception {

		when(allNotificationConfigService.saveAllNotifConfig(any(Tokenizer.class), any(AllNotificationConfig.class),
				anyString())).thenReturn(mainAgreementTypeBuilder.OK(mainAgreementTypeWrapper));

		mockMvc.perform(post("/api/allNotificationConfig/save").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig))).andExpect(jsonPath("$.code", is(1001)))
				.andExpect(status().isOk());

	}

	@Test
	public void saveAllNotifConfig_JSON_Test() throws Exception {

		when(allNotificationConfigService.saveAllNotifConfig(any(Tokenizer.class), any(AllNotificationConfig.class),
				anyString())).thenReturn(mainAgreementTypeBuilder.OK(mainAgreementTypeWrapper));

		mockMvc.perform(post("/api/allNotificationConfig/save").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());

	}
	
	@Test
	public void saveAllNotifConfig_JSON_ErrorTokenTest() throws Exception {

		mockMvc.perform(post("/api/allNotificationConfig/save").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(errorAuthToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(allNotificationConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());

	}

}
