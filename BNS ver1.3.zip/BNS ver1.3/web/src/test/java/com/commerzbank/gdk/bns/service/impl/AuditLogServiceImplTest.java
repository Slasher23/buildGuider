package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for AuditLogServiceImpl test
 * 
 * @author ZE2MACL
 * @since 14/11/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 07/12/2017	     1.01       ZE2BUEN    Modified JUnit Test reflect changes for logging
 * 21/12/2017        1.02       ZE2MORA    Added bpkenn JUnit Test for logging
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class AuditLogServiceImplTest {

    @Autowired
    private GlobalResponseWrapper globalRWrapper;

    @Mock
    private GlobalResponseWrapper globalResponseWrapper;

    @Mock
    private GlobalEventTypeWrapper globalEventTypeWrapper;

    @InjectMocks
    private AuditLogServiceImpl auditLogServiceImpl;

    private Tokenizer token;

    private AuditLog auditLog;

    private ResponseBuilder<AuditLog> builder;

    private EventType eventType;

    private Map<Integer, String> statusCodesMap;

    private static final Logger logger = LoggerFactory.getLogger(AuditLogServiceImpl.class);

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        token = new Tokenizer();
        token.setUserId("test");
        token.setError(false);

        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        builder = new ResponseBuilder<AuditLog>(logger, token, globalRWrapper);

    }

    @Test
    public void saveAuditLog_Success_Test() {

        auditLog = new AuditLog();
        auditLog.setObjectType("1002");
        auditLog.setEventType("1002");
        auditLog.setDescription("test");
        auditLog.setBpkenn("BPKENNTEST");

        eventType = new EventType();
        eventType.setDescription("test");
        eventType.setObjectType("1002");
        eventType.setType("1002");

        when(this.globalEventTypeWrapper.get(any(String.class))).thenReturn(eventType);

        assertEquals(builder.OK(auditLog).toString(), this.auditLogServiceImpl.save(token, auditLog).toString());

    }

    @Test
    public void saveAuditLog_NullException_Test() {

        auditLog = new AuditLog();
        eventType = new EventType();

        when(this.globalEventTypeWrapper.get(any(String.class))).thenReturn(null);

        assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
                this.auditLogServiceImpl.save(token, auditLog).toString());

    }

    @Test
    public void saveAuditLog_GeneralException_Test() {

        auditLog = new AuditLog();
        eventType = new EventType();

        when(this.globalEventTypeWrapper.get(any(String.class))).thenThrow(new RuntimeException());

        assertEquals(builder.notOK(Response.GENERAL_FUNCTION_ERROR).toString(),
                this.auditLogServiceImpl.save(token, auditLog).toString());

    }

}
