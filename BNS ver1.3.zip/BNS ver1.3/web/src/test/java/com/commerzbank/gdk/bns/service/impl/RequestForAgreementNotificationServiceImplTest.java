package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementNotificationRequest;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Notification;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.model.RequestForAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotification;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Trigger;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.service.StoredProcedureService;
import com.commerzbank.gdk.bns.utils.Tools;

import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * JUnit Test Class for RequestForDeactivatePersonServiceImpl.
 * 
 * @since 12/12/2017
 * @author ZE2GOME
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 12/12/2017      1.00      ZE2GOME    Initial Version
 * 12/12/2017      1.01      ZE2JAVO    Added unit test for batch
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForAgreementNotificationServiceImplTest {

    @Mock
    private Environment environment;

    @Mock
    private NotificationConfigAgreementDAO notificationAgreementDao;

    @Mock
    private AgreementDAO agreementDAO;

    @Mock
    private PersonDAO personDao;

    @Mock
    private EmailDAO emailDao;

    @Mock
    private PushConfigurationDAO pushConfigDao;

    @Mock
    private NotificationTextDAO notificationTextDAO;
    
    @Mock
    private DailyReportLogDAO dailyReportLogDAO;

    @Mock
    private Settings settings;

    @Mock
    private KeyService schlusselService;

    @Mock
    private Configuration freemarkerConfig;

    @Mock
    private Tools tools;

    @Mock
    private StoredProcedureService storedProcedureService;

    @Mock
    private InformationChannelDAO infoChannelDAO;

    @Mock
    private KeyService KeyService;

    @InjectMocks
    private NotificationServiceImpl notificationServiceImpl;

    @InjectMocks
    private RequestForAgreementNotificationServiceImpl requestForAgreementNotificationServiceImpl;

    @InjectMocks
    private StoredProcedureServiceImpl serviceImpl;

    private RequestForAgreementNotificationResponse response;

    private Person person;

    private Agreement agreement;

    private NotificationConfigAgreement notifConfigAgreement;

    private NotificationText notificationText;

    private Notifications notifications;

    private NotificationResponse notificationResponse;

    private NotificationResponse notificationResponse1;

    private NotificationResponse notificationResponse2;

    private NotificationResponse notificationResponse3;

    private NotificationResponse notificationResponse4;

    private NotificationResponse notificationResponse5;

    private NotificationResponse notificationResponse6;

    private NotificationResponse notificationResponse7;

    private NotificationResponse notificationResponse8;

    private NotificationResponse notificationResponse9;

    private NotificationResponse notificationResponse10;

    private PushConfiguration pushConfiguration;

    private Email email;

    private List<Email> emailList = new ArrayList<Email>();

    private AgreementNotificationRequest agreementNotificationRequest;

    private RequestForBatchAgreementNotificationResponse responseForBatch;

    private RequestForBatchAgreementNotification agreementNotificationRequestList;

    private Key key;

    private static final String STATUS_FA_INVALID_REQUEST                       = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST           = "ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST";
    private static final String STATUS_FA_IST_UNGLEICH                          = "ZSL_STATUS_FA_IST_UNGLEICH";
    private static final String STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID = "ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID";
    private static final String STATUS_FA_BPKENN_NO_ONLINE_BANKING              = "ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING";
    private static final String STATUS_FA_AGREEMENT_CONFIG_DOES_NOT_EXIST       = "ZSL_STATUS_FA_AGREEMENT_CONFIG_DOES_NOT_EXIST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS                     = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String EMAIL_SUBJECT_KEY                               = "EMAIL_SUBJECT";
    private static final String STATUS_OK                                       = "ZSL_STATUS_OK";
    private static final String STATUS_FA_NOT_SENT                              = "ZSL_STATUS_FA_NOT_SENT";
    private static final String STATUS_FA_NO_AVAIL_NOTIF_CONFIG                 = "ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG";

    @Before
    public void init() {

        response = new RequestForAgreementNotificationResponse();

        this.person = new Person();
        this.person.setBPKENN("BPKENNTEST");
        this.person.setGivenName("GivenName");
        this.person.setLastName("LastName");
        this.person.setPersonUID(1L);
        this.person.setSalutation("01");
        this.person.setTitle("01");

        this.agreement = new Agreement();
        this.agreement.setAgreementID("VER01 1234 5678 9101");
        this.agreement.setAgreementType("KTO");
        this.agreement.setAgreementUID(1L);
        this.agreement.setBranch(100);
        this.agreement.setIban(null);
        this.agreement.setPersonUID(1L);
        this.agreement.setType("Premium Konto");
        this.agreement.setAgreementUID(1L);

        email = new Email();
        email.setEmailAddress("test");
        email.setEmailUID(1L);
        email.setPersonUID(1L);

        emailList.add(email);

        this.notifConfigAgreement = new NotificationConfigAgreement();
        this.notifConfigAgreement.setActive(true);
        this.notifConfigAgreement.setAgreementUID(1L);
        this.notifConfigAgreement.setEmailUID(1L);
        this.notifConfigAgreement.setInformationChannelUID(1L);
        this.notifConfigAgreement.setNotifConfigAgreementUID(1L);
        this.notifConfigAgreement.setNotificationTextUID(1L);

        agreementNotificationRequest = new AgreementNotificationRequest();
        agreementNotificationRequest.setSparte(1);
        agreementNotificationRequest.setVereinbarungskennung("test");

        responseForBatch = new RequestForBatchAgreementNotificationResponse();

        agreementNotificationRequestList = new RequestForBatchAgreementNotification();

        this.notificationText = new NotificationText();
        notificationText.setNotificationTextUID(1L);
        this.notificationText.setNotificationTextType("STD");
        this.notificationText.setText("This is a STD Text");

        this.pushConfiguration = new PushConfiguration();
        this.pushConfiguration.setActive(true);
        this.pushConfiguration.setAppID("test");
        this.pushConfiguration.setAppName("test");
        this.pushConfiguration.setAppVersion("test");
        this.pushConfiguration.setDeviceID("test");
        this.pushConfiguration.setPersonUID(1L);
        this.pushConfiguration.setPushConfigurationUID(1L);

        List<Notifications> notificationList = new ArrayList<Notifications>();
        List<Notifications> notificationListEmail = new ArrayList<Notifications>();
        List<Notifications> notificationListPush = new ArrayList<Notifications>();
        this.notifications = new Notifications();
        this.notifications.setNotificationPath("test");
        this.notifications.setNotificationSubject("New Document");
        this.notifications.setNotificationText("BASE64ENCODEDSTD");
        this.notifications.setNotificationType("EMAIL");

        Notifications pushNotifications = new Notifications();
        pushNotifications.setNotificationPath("test");
        pushNotifications.setNotificationSubject("New Document");
        pushNotifications.setNotificationText("BASE64ENCODEDSTD");
        pushNotifications.setNotificationType("PUSH");
        notificationList.add(notifications);
        notificationList.add(pushNotifications);

        notificationListEmail.add(notifications);
        notificationListPush.add(pushNotifications);

        List<Notifications> notificationListNull = new ArrayList<Notifications>();

        String successMessage = "OK- Successful";

        this.notificationResponse = new NotificationResponse();
        this.notificationResponse.setBPKENN(null);
        this.notificationResponse.setNotification(notificationListNull);
        this.notificationResponse.setStatus(null);

        this.notificationResponse1 = new NotificationResponse();
        this.notificationResponse1.setBPKENN(null);
        this.notificationResponse1.setNotification(notificationListNull);
        this.notificationResponse1.setStatus(STATUS_FA_BPKENN_NOT_EXISTS);

        this.notificationResponse2 = new NotificationResponse();
        this.notificationResponse2.setBPKENN(null);
        this.notificationResponse2.setNotification(notificationListNull);
        this.notificationResponse2.setStatus(STATUS_FA_AGREEMENT_CONFIG_DOES_NOT_EXIST);

        this.notificationResponse3 = new NotificationResponse();
        this.notificationResponse3.setBPKENN("BPKENNTEST");
        this.notificationResponse3.setNotification(notificationListNull);
        this.notificationResponse3.setStatus(STATUS_FA_BPKENN_NO_ONLINE_BANKING);

        this.notificationResponse4 = new NotificationResponse();
        this.notificationResponse4.setBPKENN("BPKENNTEST");
        this.notificationResponse4.setNotification(notificationListNull);
        this.notificationResponse4.setStatus(STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID);

        this.notificationResponse5 = new NotificationResponse();
        this.notificationResponse5.setBPKENN("BPKENNTEST");
        this.notificationResponse5.setNotification(notificationListNull);
        this.notificationResponse5.setStatus(STATUS_FA_NOT_SENT);

        this.notificationResponse6 = new NotificationResponse();
        this.notificationResponse6.setBPKENN("BPKENNTEST");
        this.notificationResponse6.setNotification(notificationListNull);
        this.notificationResponse6.setStatus(null);

        this.notificationResponse7 = new NotificationResponse();
        this.notificationResponse7.setBPKENN("BPKENNTEST");
        this.notificationResponse7.setNotification(notificationListNull);
        this.notificationResponse7.setStatus(STATUS_FA_NO_AVAIL_NOTIF_CONFIG);

        this.notificationResponse8 = new NotificationResponse();
        this.notificationResponse8.setBPKENN("BPKENNTEST");
        this.notificationResponse8.setNotification(notificationList);
        this.notificationResponse8.setStatus(successMessage);

        this.notificationResponse9 = new NotificationResponse();
        this.notificationResponse9.setBPKENN("BPKENNTEST");
        this.notificationResponse9.setNotification(notificationListPush);
        this.notificationResponse9.setStatus(successMessage);

        this.notificationResponse10 = new NotificationResponse();
        this.notificationResponse10.setBPKENN("BPKENNTEST");
        this.notificationResponse10.setNotification(notificationListEmail);
        this.notificationResponse10.setStatus(successMessage);

        this.key = new Key();
        key.setKeyTyp("BBANR");
        key.setLanguage("000");
        key.setKeyCode("01");
        key.setKeyShortText("Herrn");
        key.setKeyTyp("PAKTL");
        key.setLanguage("006");
        key.setKeyCode("01");
        key.setKeyShortText("Frau");
    }

    @Test
    public void requestForAgreementNotification_IsNull() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung(null);
        request.setSparte(null);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(null);
        expectedResponse.setStatus(null);
        expectedResponse.setVereinbarungskennung(null);

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        assertEquals(expectedResponse.toString(), response.toString());

    }

    @Test
    public void requestForAgreementNotification_StatusOk() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void requestForAgreementNotification_DoesNotExist() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        when(this.environment.getProperty(STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST))
                        .thenReturn("ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void requestForAgreementNotification_NotifConfigNonNull() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse6);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        Long email01 = 1L;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        NotificationConfigAgreement checkEmail = new NotificationConfigAgreement();
        checkEmail.setEmailUID(email01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(checkEmail);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("01");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void getAggreementNotifications_NotExisting() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse2);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_AGREEMENT_CONFIG_DOES_NOT_EXIST))
                        .thenReturn("ZSL_STATUS_FA_AGREEMENT_CONFIG_DOES_NOT_EXIST");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void getNotificationResponse_NotExistBpkenn() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse1);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(null);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(notifConfigAgreement);
        when(this.personDao.findOne(any(Long.class))).thenReturn(null);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("ZSL_STATUS_FA_BPKENN_NOT_EXISTS");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validateTnv_BpkennNoOnlineBank() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse3);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC02";
        String agreementId01 = "DE01 2345 6789 1011 1213 99";
        Integer sparte01 = 100;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(notifConfigAgreement);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("02");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_BPKENN_NO_ONLINE_BANKING))
                        .thenReturn("ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING");
        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("02", this.serviceImpl.validateAccount("STOREDPROC02", "DE01 2345 6789 1011 1213 99", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validateTnv_BpkennNoOnlineBankAgreeId() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse4);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC03";
        String agreementId01 = "DE01 2345 6789 1011 1213 98";
        Integer sparte01 = 100;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(notifConfigAgreement);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("03");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID))
                        .thenReturn("ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID");
        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("03", this.serviceImpl.validateAccount("STOREDPROC03", "DE01 2345 6789 1011 1213 98", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validateTnv_StatusNotSent() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse5);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC04";
        String agreementId01 = "DE01 2345 6789 1011 1213 97";
        Integer sparte01 = 100;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(notifConfigAgreement);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("04");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_NOT_SENT)).thenReturn("ZSL_STATUS_FA_NOT_SENT");
        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("04", this.serviceImpl.validateAccount("STOREDPROC04", "DE01 2345 6789 1011 1213 97", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void checkExistingEmail_NoNotifAvail() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();
        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse7);
        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setStatus("OK- Successful");
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        Long email01 = 1L;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        NotificationConfigAgreement checkEmail = new NotificationConfigAgreement();
        checkEmail.setEmailUID(email01);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(checkEmail);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("01");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(null);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG))
                        .thenReturn("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG");

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validatePushAndEmaillConfig_NotEmptyAndActive() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse8);
        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();

        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        String successMessage = "OK- Successful";

        expectedResponse.setStatus(successMessage);

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        Long email01 = 1L;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        NotificationConfigAgreement checkEmail = new NotificationConfigAgreement();
        checkEmail.setActive(true);
        checkEmail.setEmailUID(email01);

        Email email = new Email();
        email.setEmailUID(email01);
        email.setPersonUID(1L);
        email.setAddressId(1L);
        email.setEmailAddress("test");

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPersonUID(1L);
        pushConfiguration.setPushConfigurationUID(1L);
        pushConfigurationList.add(pushConfiguration);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(checkEmail);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("01");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);
        when(this.pushConfigDao.getPushConfiguration(anyLong())).thenReturn(pushConfigurationList);
        when(this.emailDao.findByEmailUID(anyLong())).thenReturn(email);

        when(this.notificationTextDAO.findOne(anyLong())).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText")).thenReturn("This is standard text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText")).thenReturn("This is standard text in EN");

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODEDSTD");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");

        when(this.KeyService.getShortTextValue(anyString(), anyString(), anyString())).thenReturn("Herrn");

        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validatePushAndEmaillConfig_ActiveEmail() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse10);
        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();

        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        String successMessage = "OK- Successful";

        expectedResponse.setStatus(successMessage);

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        Long email01 = 1L;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        NotificationConfigAgreement checkEmail = new NotificationConfigAgreement();
        checkEmail.setActive(true);
        checkEmail.setEmailUID(email01);

        Email email = new Email();
        email.setEmailUID(email01);
        email.setPersonUID(1L);
        email.setAddressId(1L);
        email.setEmailAddress("test");

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(false);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPersonUID(1L);
        pushConfiguration.setPushConfigurationUID(1L);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(checkEmail);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("01");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);
        when(this.pushConfigDao.getPushConfiguration(anyLong())).thenReturn(null);
        when(this.emailDao.findByEmailUID(anyLong())).thenReturn(email);

        when(this.notificationTextDAO.findOne(anyLong())).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText")).thenReturn("This is standard text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText")).thenReturn("This is standard text in EN");

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODEDSTD");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");

        when(this.KeyService.getShortTextValue(anyString(), anyString(), anyString())).thenReturn("Herrn");

        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }

    @Test
    public void validatePushAndEmaillConfig_Push() throws Exception {

        AgreementNotificationRequest request = new AgreementNotificationRequest();
        request.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        request.setSparte(100);

        List<NotificationResponse> notificationResponseList = new ArrayList<NotificationResponse>();
        notificationResponseList.add(notificationResponse9);
        RequestForAgreementNotificationResponse expectedResponse = new RequestForAgreementNotificationResponse();

        expectedResponse.setAgreementNotifications(notificationResponseList);
        expectedResponse.setSparte(100);
        expectedResponse.setVereinbarungskennung("DE01 2345 6789 1011 1213 14");
        String successMessage = "OK- Successful";

        expectedResponse.setStatus(successMessage);

        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        Long email01 = 1L;

        Person requestTNV = new Person();
        requestTNV.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        NotificationConfigAgreement checkEmail = new NotificationConfigAgreement();
        checkEmail.setActive(false);
        checkEmail.setEmailUID(email01);

        Email email = new Email();
        email.setEmailUID(email01);
        email.setPersonUID(1L);
        email.setAddressId(1L);
        email.setEmailAddress("test");

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPersonUID(1L);
        pushConfiguration.setPushConfigurationUID(1L);
        pushConfigurationList.add(pushConfiguration);

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(any(String.class), any(Integer.class)))
                        .thenReturn(agreementList);
        when(this.notificationAgreementDao.findByAgreementUID(any(Long.class))).thenReturn(checkEmail);
        when(this.personDao.findOne(any(Long.class))).thenReturn(person);
        when(this.storedProcedureService.validateAccount(anyString(), anyString(), anyInt())).thenReturn("01");
        when(this.emailDao.findByPersonUID(anyLong())).thenReturn(emailList);
        when(this.pushConfigDao.getPushConfiguration(anyLong())).thenReturn(pushConfigurationList);
        when(this.emailDao.findByEmailUID(anyLong())).thenReturn(email);

        when(this.notificationTextDAO.findOne(anyLong())).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText")).thenReturn("This is standard text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText")).thenReturn("This is standard text in EN");

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                        .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODEDSTD");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");

        when(this.KeyService.getShortTextValue(anyString(), anyString(), anyString())).thenReturn("Herrn");

        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        RequestForAgreementNotificationResponse response = this.requestForAgreementNotificationServiceImpl
                        .requestForAgreementNotification(request);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));
        assertEquals(expectedResponse.toString(), response.toString());
    }
    

}
