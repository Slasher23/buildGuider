package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.conf.security.AuthenticatedUser;
import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.IndividualConfigService;

/**
 * JUnit test for Informational Channel Controller
 * 
 * @author ZE2MACL
 * @since 13/11/2017
 * @version 1.03
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Removed Participant Number
 * 29/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 * 13/03/2018        1.03       ZE2BUEN    Update Junit Class
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class IndividualConfigControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private IndividualConfigService individualConfigService;

	@InjectMocks
	private IndividualConfigController individualConfigController;

	private MockMvc mockMvc;

	private NotifTextAgreementConfigWrapper notifTextAgreementConfigWrapper;

	private NotificationText notificationText;

	private NotificationConfigAgreement notificationConfigAgreement;

	private CustomNotifConfig customNotifConfig;

	private NotifTextPersonConfigWrapper notifTextPersonConfigWrapper;

	private NotificationConfigPerson notificationConfigPerson;

	private Tokenizer token;

	private Tokenizer errorToken;

	private ResponseBuilder<NotifTextAgreementConfigWrapper> notifTextAgreementBuilder;

	private ResponseBuilder<NotifTextPersonConfigWrapper> notifTextPersonBuilder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(IndividualConfigController.class);

	private String authHeader = "comdirect role=[{\"name\":\"KUNDE\",\"publicData\":{\"01-03-64\":\"<ccb-authentication><protocolVersion>1.1</protocolVersion><recipient>01-03-64</recipient><userid>017WDY60T0QVTTWT;BPKENNTEST10</userid><useridType>TNVEKENN</useridType><issuedFrom>14-04-34</issuedFrom><requester>PK-WEB</requester><authenticationStrength>PIN</authenticationStrength><issueInstant>2018-02-14-11:07:26 UTC</issueInstant><notValidAfter>2018-02-14-11:33:56 UTC</notValidAfter><ticketId>a3f3a23d0ef41d3a</ticketId><sessionId>112EEAE892A3C6F2BB76E87CACB6FAB3</sessionId><signature>IIPICfqbdtDvv0i3AMBzrMZeJ9gmqhfo8/0jZtgNWgOBLz4UHIlMc33dOf29u6F0psh/3mnfGFpkW3haffch6Okd0HtinM6bnO7pRORv+SAzeicIO7MPsKYmSWdBY7+q4gFfeYgZmFR+3y6+8e9QkiJ93C81cwDpU9rVz6Rg9JGPq5sHqQQnMmTHNYH2CPyvS0jOgaggVaKHRdjtAFO+q0eT4VraXRXMlLe0hu8xg2k3exqUX5IQjLUw/DrEb2R7bvJ2X7x1eVT7rr4cmyqXqoCtdzBlA1tOH2wEUuX7QCrZbtBEWRArwuPElbaOvQ2ceVYQtOhq9qZ3whZbOAD/Mw==</signature><legacySignature>LEGACYSIGNATURENOLONGERPROVIDED++LEGACYSIGNATURENOLONGERPROVIDED</legacySignature></ccb-authentication>\"}}]";

	private HttpHeaders header;

	private UsernamePasswordAuthenticationToken authToken;

	private UsernamePasswordAuthenticationToken errorAuthToken;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(individualConfigController).build();

		notificationText = new NotificationText();
		notificationText.setEventID(1L);
		notificationText.setEventType("test");
		notificationText.setNotificationTextType("test");
		notificationText.setNotificationTextUID(1L);
		notificationText.setText("testText");

		notificationConfigAgreement = new NotificationConfigAgreement();
		notificationConfigAgreement.setActive(true);
		notificationConfigAgreement.setAgreementUID(1L);
		notificationConfigAgreement.setEmailUID(1L);
		notificationConfigAgreement.setInformationChannelUID(1L);
		notificationConfigAgreement.setNotifConfigAgreementUID(1L);
		notificationConfigAgreement.setNotificationTextUID(1L);

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		notifTextAgreementConfigWrapper = new NotifTextAgreementConfigWrapper();
		notifTextAgreementConfigWrapper.setNotificationText(notificationText);
		notifTextAgreementConfigWrapper.setNotificationConfigAgreement(notificationConfigAgreement);

		notifTextPersonConfigWrapper = new NotifTextPersonConfigWrapper();
		notifTextPersonConfigWrapper.setNotificationText(notificationText);
		notifTextPersonConfigWrapper.setNotificationConfigPerson(notificationConfigPerson);

		customNotifConfig = new CustomNotifConfig();
		customNotifConfig.setActive(true);
		customNotifConfig.setAgreementUID(1L);
		customNotifConfig.setEmailUID(1L);
		customNotifConfig.setInformationChannelUID(1L);
		customNotifConfig.setPersonUID(1L);
		customNotifConfig.setText("Text");

		token = new Tokenizer();
		token.setUserId("");
		token.setError(false);
		token.setBpkenn("bpkenntest10");
		token.setUserType("TNVEKENN");
		token.setRole("PK-WEB");

		errorToken = new Tokenizer();
		errorToken.setUserId("");
		errorToken.setError(true);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		notifTextAgreementBuilder = new ResponseBuilder<NotifTextAgreementConfigWrapper>(logger, token, globalRWrapper);
		notifTextPersonBuilder = new ResponseBuilder<NotifTextPersonConfigWrapper>(logger, token, globalRWrapper);

		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority("ROLE_PK-WEB"));
		AuthenticatedUser user = new AuthenticatedUser(1L, "user", token, authorities);
		authToken = new UsernamePasswordAuthenticationToken(user, "password");
		SecurityContextHolder.getContext().setAuthentication(authToken);

		AuthenticatedUser errorUser = new AuthenticatedUser(1L, "user", errorToken, authorities);
		errorAuthToken = new UsernamePasswordAuthenticationToken(errorUser, "password");
		SecurityContextHolder.getContext().setAuthentication(errorAuthToken);

		header = new HttpHeaders();
		header.set(HttpHeaders.AUTHORIZATION, authHeader);

	}

	@Test
	public void saveNotifTextAndAgreementConfig_JSONResponseCode_Test() throws Exception {

		when(individualConfigService.saveNotifTextAndAgreementConfig(any(Tokenizer.class),
				any(CustomNotifConfig.class)))
						.thenReturn(notifTextAgreementBuilder.OK(notifTextAgreementConfigWrapper));

		mockMvc.perform(post("/api/notifText/agreementConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig))).andExpect(jsonPath("$.code", is(1001)))
				.andExpect(status().isOk());
	}

	@Test
	public void saveNotifTextAndAgreementConfig_JSON_Test() throws Exception {

		when(individualConfigService.saveNotifTextAndAgreementConfig(any(Tokenizer.class),
				any(CustomNotifConfig.class)))
						.thenReturn(notifTextAgreementBuilder.OK(notifTextAgreementConfigWrapper));

		mockMvc.perform(post("/api/notifText/agreementConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveNotifTextAndAgreementConfig_JSON_ErrorToken_Test() throws Exception {

		mockMvc.perform(post("/api/notifText/agreementConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(errorAuthToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveNotifTextAndPersonConfig_JSONResponseCode_Test() throws Exception {

		when(individualConfigService.saveNotifTextAndPersonConfig(any(Tokenizer.class), any(CustomNotifConfig.class)))
				.thenReturn(notifTextPersonBuilder.OK(notifTextPersonConfigWrapper));

		mockMvc.perform(post("/api/notifText/personConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig))).andExpect(jsonPath("$.code", is(1001)))
				.andExpect(status().isOk());
	}

	@Test
	public void saveNotifTextAndPersonConfig_JSON_Test() throws Exception {

		when(individualConfigService.saveNotifTextAndPersonConfig(any(Tokenizer.class), any(CustomNotifConfig.class)))
				.thenReturn(notifTextPersonBuilder.OK(notifTextPersonConfigWrapper));

		mockMvc.perform(post("/api/notifText/personConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(authToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

	@Test
	public void saveNotifTextAndPersonConfig_JSON_ErrorToken_Test() throws Exception {

		mockMvc.perform(post("/api/notifText/personConfig").contentType(MediaType.APPLICATION_JSON).headers(header)
				.principal(errorAuthToken).accept(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(customNotifConfig)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

}
