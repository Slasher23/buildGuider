package com.commerzbank.gdk.bns.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.service.DailyReportLogService;

/**
 * JUnit Test Class for DailyReportLogServiceImplTest.
 * 
 * @since 05/01/2017
 * @author ZE2RUBI
 * @version 1.00
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 05/01/2017      1.00      ZE2RUBI    Initial Version
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class DailyReportLogServiceImplTest {

    @Autowired
    private DailyReportLogService service;
    
    private DailyReportLog dailyReportLog;
    
    private List<DailyReportLog> dailyReportLogs;
    
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_REQ_NOTIF_NOT_SENT = "ZSL_STATUS_FA_REQ_NOTIF_NOT_SENT";

    @Before
    public void init() {
        dailyReportLog = new DailyReportLog();
        dailyReportLog.setBpkenn("BPKENNTEST");
        dailyReportLog.setDailyReportLogUID(1L);
        dailyReportLog.setStatus(STATUS_OK);
        dailyReportLog.setEventType("email");
        dailyReportLog.setTimestamp(new Date());
        
        dailyReportLogs.add(dailyReportLog);

    }
    
}
