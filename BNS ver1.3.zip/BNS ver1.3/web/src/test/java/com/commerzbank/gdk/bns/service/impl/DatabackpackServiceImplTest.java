package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * JUnit test class for Databackpack Service Impl
 * 
 * @since 21/11/2017
 * @author ZE2BUEN
 * @version 1.00
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 21/11/2017      1.00      ZE2BUEN    Initial Version
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class DatabackpackServiceImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private Tools tools;

	@Mock
	private DatabackpackServiceImpl databackpackServiceImplMock;

	@Mock
	private KeyServiceImpl keyServiceImpl;

	@InjectMocks
	private DatabackpackServiceImpl databackpackServiceImpl;

	private String encryptedDatabackpack;

	private String databackpackString;

	private Parameter parameter;

	private List<Customer> customerList;

	private Customer customer1;

	private Customer customer2;

	private List<Agreement> agreementList;

	private Agreement agreement1;

	private Agreement agreement2;

	private Person person;

	private NotificationConfigPerson notificationConfigPerson;

	private List<Email> emailList;

	private Email email1;

	private Email email2;

	private Databackpack databackpack;

	private Tokenizer token;

	private ResponseBuilder<Databackpack> databackpackBuilder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(DatabackpackServiceImpl.class);

	@Before
	public void init() {

		MockitoAnnotations.initMocks(this);

		encryptedDatabackpack = "a2Rucj0xMjM0NTY3ODkwO2tkbnI9MTIzNDU2Nzg5MTtwcm9kSWQ9REUwMSAyMzQ1IDY3ODkgMTAxMSAxMjEzIDE0LHByb2RjYXQ9S1RPLG5hbWU9UHJlbWl1bSBLb250byxpYmFuPURFMDEgMjM0NSA2Nzg5IDEwMTEgMTIxMyAxNDtwcm9kSWQ9MTIzNCA0NTY3IDg5MTAgMTExMyxwcm9kY2F0PUtBUixuYW1lPU1hc3RlcmNhcmQgUHJlbWl1bTtwZXJzb25Eb2N1bWVudHNBY3RpdmF0ZWQ9MDtmaXJzdG5hbWU9U2ltb24sbGFzdG5hbWU9TWVpZXIsdGl0bGU9UHJvZmVzc29yLHRpdGxlRXh0ZW5zaW9uPWFiYyx0aXRsZU9mTm9iaWxpdHk9LHNhbHV0YXRpb249SGVycmVuLHNhbHV0YXRpb25FeHRlbnNpb249LGluZGl2aWR1YWxTYWx1dGF0aW9uPTtlbWFpbGFkZD1lbWFpbEBjb2JhLmNvbSxhZGRJRD0xO2VtYWlsYWRkPWVtYWlsQGdtYWlsLmNvbSxhZGRJRD0yOw==";
		databackpackString = "kdnr=1234567890;kdnr=1234567891;prodId=DE01 2345 6789 1011 1213 14,prodcat=KTO,name=Premium Konto,iban=DE01 2345 6789 1011 1213 14;prodId=1234 4567 8910 1113,prodcat=KAR,name=Mastercard Premium;personDocumentsActivated=0;firstname=Simon,lastname=Meier,title=Professor,titleExtension=abc,titleOfNobility=,salutation=Herren,salutationExtension=,individualSalutation=;emailadd=email@coba.com,addID=1;emailadd=email@gmail.com,addID=2;";

		parameter = new Parameter();
		parameter.setDatabackpack(encryptedDatabackpack);

		token = new Tokenizer();
		token.setUserId("User Test");
		token.setError(false);

		customer1 = new Customer();
		customer1.setCustomerNumber("1234567890");

		customer2 = new Customer();
		customer2.setCustomerNumber("1234567891");

		customerList = new ArrayList<>();
		customerList.add(customer1);
		customerList.add(customer2);

		agreement1 = new Agreement();
		agreement1.setAgreementID("DE01 2345 6789 1011 1213 14");
		agreement1.setAgreementType("KTO");
		agreement1.setType("Premium Konto");
		agreement1.setIban("DE01 2345 6789 1011 1213 14");

		agreement2 = new Agreement();
		agreement2.setAgreementID("1234 4567 8910 1113");
		agreement2.setAgreementType("KAR");
		agreement2.setType("Mastercard Premium");

		agreementList = new ArrayList<>();
		agreementList.add(agreement1);
		agreementList.add(agreement2);

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(false);

		person = new Person();
		person.setGivenName("Simon");
		person.setLastName("Meier");
		person.setSalutation("02");
		person.setTitle("02");

		email1 = new Email();
		email1.setAddressId(1L);
		email1.setEmailAddress("email@coba.com");

		email2 = new Email();
		email2.setAddressId(2L);
		email2.setEmailAddress("email@gmail.com");

		emailList = new ArrayList<>();
		emailList.add(email1);
		emailList.add(email2);

		databackpack = new Databackpack();
		databackpack.setAgreementList(agreementList);
		databackpack.setCustomerList(customerList);
		databackpack.setEmailList(emailList);
		databackpack.setNotificationConfigPerson(notificationConfigPerson);
		databackpack.setPerson(person);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		databackpackBuilder = new ResponseBuilder<Databackpack>(logger, token, globalRWrapper);

	}

	@Test
	public void databackpackProcessor_Successful_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		databackpackBuilder.OK(databackpack);

		// Decrypt encrypted databackpack string
		when(this.tools.base64Decode(anyString())).thenReturn(databackpackString);

		// Deserialize Databackpack String to Databackpack BNS Object
		when(this.databackpackServiceImplMock.databackpackDeserializer(anyString())).thenReturn(databackpack);

		// Convert Title Value to Key Code
		when(this.keyServiceImpl.getKeyCodeByValue(anyString(), anyString())).thenReturn("02");

		// Convert Salutation to Key Code
		when(this.keyServiceImpl.getKeyCodeByValue(anyString(), anyString())).thenReturn("02");

		assertEquals(databackpackBuilder.toString(),
				this.databackpackServiceImpl.databackpackProcessor(token, parameter.getDatabackpack()).toString());

	}

	@Test
	public void databackpackProcessor_EmptyDatabackpackString_Fail_Test() throws Exception {

		encryptedDatabackpack = "";
		databackpackString = "";

		databackpack = new Databackpack();
		databackpack.setAgreementList(null);
		databackpack.setCustomerList(null);
		databackpack.setEmailList(null);
		databackpack.setNotificationConfigPerson(null);
		databackpack.setPerson(null);

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		databackpackBuilder.OK(databackpack);

		// Decrypt encrypted databackpack string
		when(this.tools.base64Decode(anyString())).thenReturn(databackpackString);

		// Deserialize Databackpack String to Databackpack BNS Object
		when(this.databackpackServiceImplMock.databackpackDeserializer(anyString())).thenReturn(databackpack);

		assertEquals(databackpackBuilder.toString(),
				this.databackpackServiceImpl.databackpackProcessor(token, parameter.getDatabackpack()).toString());

	}

	@Test
	public void databackpackProcessor_DataAccessException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		databackpackBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		// Decrypt encrypted databackpack string
		when(this.tools.base64Decode(anyString())).thenReturn(databackpackString);

		// Deserialize Databackpack String to Databackpack BNS Object
		when(this.databackpackServiceImplMock.databackpackDeserializer(anyString())).thenReturn(databackpack);

		// Convert Title Value to Key Code
		when(this.keyServiceImpl.getKeyCodeByValue(anyString(), anyString()))
				.thenThrow(new DataRetrievalFailureException("test"));

		assertEquals(databackpackBuilder.toString(),
				this.databackpackServiceImpl.databackpackProcessor(token, parameter.getDatabackpack()).toString());

	}

	@Test
	public void databackpackProcessor_NullPointerException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		databackpackBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		// Decrypt encrypted databackpack string
		when(this.tools.base64Decode(anyString())).thenThrow(new NullPointerException("test"));

		assertEquals(databackpackBuilder.toString(),
				this.databackpackServiceImpl.databackpackProcessor(token, parameter.getDatabackpack()).toString());

	}

	@Test
	public void databackpackProcessor_GeneralException_Test() throws Exception {

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		databackpackBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);

		// Decrypt encrypted databackpack string
		when(this.tools.base64Decode(anyString())).thenThrow(new RuntimeException());

		assertEquals(databackpackBuilder.toString(),
				this.databackpackServiceImpl.databackpackProcessor(token, parameter.getDatabackpack()).toString());

	}

}
