package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.rules.NotificationRuleBookImpl;
import com.commerzbank.gdk.bns.service.StoredProcedureService;

/**
 * JUnit test class for NotificationRuleBookImpl
 * 
 * @since 20/11/2017
 * @author ZE2GOME
 * @version 1.04
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2GOME    Initial Version
 * 20/11/2017      1.01      ZE2GOME    Update JUnit
 * 14/12/2017      1.02      ZE2BUEN    Refactor/ clean up for ZSL status messages
 * 11/01/2018      1.03      ZE2MACL    Implemented decision level two and updated methods to use decision level 2
 * 29/01/2018      1.04      ZE2BUEN    Updated test methods for notification rule book
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationRuleBookImplTest {

    @Mock
    private NotificationConfigPersonDAO notificationConfigPersonDao;

    @Mock
    private NotificationConfigAgreementDAO notificationAgreementDao;

    @Mock
    private EmailDAO emailDao;

    @Mock
    private PersonDAO personDao;

    @Mock
    private PushConfigurationDAO pushConfigDao;

    @Mock
    private Environment environment;

    @InjectMocks
    private NotificationRuleBookImpl notificationRuleBook;

    @Mock
    private StoredProcedureService storedProcedureService;

    private Person person;

    private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";

    @Before
    public void init() {
        this.person = new Person();
        this.person.setBPKENN("test");
        this.person.setGivenName("testGivenName");
        this.person.setLastName("testlastname");
        this.person.setPersonUID(1L);
        this.person.setSalutation("01");
        this.person.setTitle("01");
    }

    @Test
    public void checkDecisionLevelNull_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        when(this.personDao.findByBpkennIgnoreCase("test")).thenReturn(this.person);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        NotificationConfigAgreement notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(true);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(false);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);
        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        List<NotificationMatrixChannel> notificationMatrixChannelList = null;

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(null);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel(),
                        notificationMatrixResponse.getNotificationMatrixChannel());
        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());

    }

    @Test
    public void checkDecisionLevel_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;
        String status = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";

        NotificationConfigAgreement notificationConfigAgreement = null;

        List<PushConfiguration> pushConfigurationList = null;
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn(status);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel(),
                        notificationMatrixResponse.getNotificationMatrixChannel());

    }

    @Test
    public void checkDecisionLevelTwo_StoredProc02_Test() throws Exception {
        String bpkenn = "STOREDPROC02";
        int branch = 100;
        String agreementID = "DE01 2345 6789 1011 1213 99";
        boolean isAgreementRelated = false;
        String status = "ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING";

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setPersonUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("02");

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(notificationMatrixResponse.getStatus(), listOfNotificationMatrix.getStatus());
        assertEquals(notificationMatrixResponse.getNotificationMatrixChannel(),
                        listOfNotificationMatrix.getNotificationMatrixChannel());

    }

    @Test
    public void checkDecisionLevelTwo_StoredProc03_Test() throws Exception {
        String bpkenn = "STOREDPROC03";
        int branch = 100;
        String agreementID = "DE01 2345 6789 1011 1213 98";
        boolean isAgreementRelated = false;
        String status = "ZSL_STATUS_FA_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID";

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setPersonUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("03");

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(notificationMatrixResponse.getStatus(), listOfNotificationMatrix.getStatus());
        assertEquals(notificationMatrixResponse.getNotificationMatrixChannel(),
                        listOfNotificationMatrix.getNotificationMatrixChannel());

    }

    @Test
    public void checkDecisionLevelTwo_StoredProc04_Test() throws Exception {
        String bpkenn = "STOREDPROC04";
        int branch = 100;
        String agreementID = "DE01 2345 6789 1011 1213 97";
        boolean isAgreementRelated = false;
        String status = "ZSL_STATUS_FA_NOT_SENT";

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setPersonUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("04");

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(notificationMatrixResponse.getStatus(), listOfNotificationMatrix.getStatus());
        assertEquals(notificationMatrixResponse.getNotificationMatrixChannel(),
                        listOfNotificationMatrix.getNotificationMatrixChannel());

    }
    
    

    @Test
    public void checkDecisionLevelOneNull_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;
        String status = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";

        List<PushConfiguration> pushConfigurationList = null;
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        NotificationConfigPerson notifcationConfigPerson = null;

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn(status);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().toString(),
                        notificationMatrixResponse.getNotificationMatrixChannel().toString());

    }

    @Test
    public void checkDecisionLevelTwo_StoredProc05_Test() throws Exception {
        String bpkenn = "STOREDPROC05";
        int branch = 100;
        String agreementID = "DE01 2345 6789 1011 1213 00";
        boolean isAgreementRelated = false;
        String status = null;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setPersonUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("05");

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus(status);
        notificationMatrixResponse.setNotificationMatrixChannel(null);

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(notificationMatrixResponse.getStatus(), listOfNotificationMatrix.getStatus());
        assertEquals(notificationMatrixResponse.getNotificationMatrixChannel(),
                        listOfNotificationMatrix.getNotificationMatrixChannel());

    }

    @Test
    public void checkDecisionLevelThree_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        emaiListl.add(mail);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

    @Test
    public void checkDecisionLevelThree_Null_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());

    }

    @Test
    public void checkDecisionLevelThree_Null_2_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(false);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());

    }

    @Test
    public void checkDecisionLevelThree_Null_3_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());

    }

    @Test
    public void checkDecisionLevelFourNull_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        NotificationConfigAgreement notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(true);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannel.setNotificationPath("test@yahoo.com");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

    @Test
    public void checkDecisionLevelFourAgreementFalse_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = false;

        NotificationConfigPerson notifcationConfigPerson = new NotificationConfigPerson();
        notifcationConfigPerson.setActive(true);
        notifcationConfigPerson.setEmailUID(1L);
        notifcationConfigPerson.setInformationChannelUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);
        notifcationConfigPerson.setNotifConfigPersonUID(1L);
        notifcationConfigPerson.setNotificationTextUID(1L);

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(notifcationConfigPerson);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress(null);
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);
        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

    @Test
    public void checkDecisionLevelFourNull_1_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        NotificationConfigAgreement notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(true);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannel.setNotificationPath("test@yahoo.com");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

    @Test
    public void checkDecisionLevelFourNull_2_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        NotificationConfigAgreement notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(false);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationMatrixChannel.setNotificationPath("test");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

    @Test
    public void checkDecisionLevelFourNull_3_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        NotificationConfigAgreement notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(false);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(notificationConfigAgreement);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationMatrixChannel.setNotificationPath("test");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());

    }
    
    @Test
    public void checkDecisionLevelFour_WithoutAgreementConfig_test() throws Exception {
        String bpkenn = "BPKENNTEST";
        int branch = 100;
        String agreementID = "VEREINBARUNG1";
        boolean isAgreementRelated = true;

        when(this.notificationAgreementDao.findByAgreementUID(1L, branch, agreementID))
                        .thenReturn(null);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationMatrixChannel.setNotificationPath("test");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, agreementID, branch)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        branch, agreementID, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }
    
    @Test
    public void checkDecisionLevelFour_NoPersonConfig_test() throws Exception {
        String bpkenn = "BPKENNTEST";

        boolean isAgreementRelated = false;

        when(this.notificationConfigPersonDao.findByPersonUID(1L)).thenReturn(null);

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationMatrixChannel.setNotificationPath("test");
        notificationMatrixChannelList.add(notificationMatrixChannel);

        when(this.personDao.findByBpkennIgnoreCase(bpkenn)).thenReturn(this.person);

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setStatus("SUCCESSFUL");
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannelList);

        List<PushConfiguration> pushConfigurationList = new ArrayList<PushConfiguration>();
        PushConfiguration pushConfiguration = new PushConfiguration();
        pushConfiguration.setActive(true);
        pushConfiguration.setAppID("test");
        pushConfiguration.setAppName("test");
        pushConfiguration.setAppVersion("test");
        pushConfiguration.setDeviceID("test");
        pushConfiguration.setPushConfigurationUID(1L);

        pushConfigurationList.add(pushConfiguration);
        when(this.pushConfigDao.getPushConfiguration(1L)).thenReturn(pushConfigurationList);

        List<Email> emaiListl = new ArrayList<Email>();
        Email mail = new Email();
        mail.setEmailAddress("test@yahoo.com");
        mail.setAddressId(1L);
        mail.setEmailUID(1L);
        mail.setPersonUID(1L);

        emaiListl.add(mail);

        when(this.emailDao.findByPersonUID(1L)).thenReturn(emaiListl);

        when(this.emailDao.findByEmailUID(1L)).thenReturn(mail);
        
        when(storedProcedureService.validateAccount(bpkenn, null, null)).thenReturn("01");

        NotificationMatrixResponse listOfNotificationMatrix = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                        null, null, isAgreementRelated);

        assertEquals(listOfNotificationMatrix.getStatus(), notificationMatrixResponse.getStatus());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getNotificationPath(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getNotificationPath());
        assertEquals(listOfNotificationMatrix.getNotificationMatrixChannel().get(0).getInformationChannelType(),
                        notificationMatrixResponse.getNotificationMatrixChannel().get(0).getInformationChannelType());

    }

}
