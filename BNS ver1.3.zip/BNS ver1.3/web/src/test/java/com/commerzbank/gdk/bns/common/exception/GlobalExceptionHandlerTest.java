package com.commerzbank.gdk.bns.common.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.SQLException;

import javax.validation.ConstraintViolationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.commerzbank.frame.security.ticket.core.validator.TicketException;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;

import io.jsonwebtoken.SignatureException;

/** 
* JUnit class for GlobalExceptionHandler 
* 
* @since 09/08/2017
* @author ZE2CRUH
* @version 1.02
*
* Modified Date   Version   Author     Description
* 09/08/2017      1.00      ZE2CRUH    Initial Version
* 21/11/2017      1.01      ZE2MACL    Updated Http Statuses
* 28/02/2018      1.02      ZE2BUEN    Updated JUnit Class
* 
*/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/resources/configuration.xml")
public class GlobalExceptionHandlerTest {

	@Autowired
	private GlobalResponseWrapper message;

	@InjectMocks
	private GlobalExceptionHandler globalExceptionHandler;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
			
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		Mockito.reset(globalResponseWrapper);
		
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnDataAccessException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: DataAccessException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnDataAccessException(new DataAccessException("Caused by: DataAccessException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnIllegalArgumentsException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: IllegalArgumentException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnIllegalArgumentsException(new IllegalArgumentException("Caused by: IllegalArgumentException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnNullPointerException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: NullPointerException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnNullPointerException(new NullPointerException("Caused by: NullPointerException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnSQLException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.NOT_FOUND.toString());
		responseMessage.setMessage("Caused by: SQLException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.returnSQLException(new SQLException("Caused by: SQLException") {
		}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnConstraintViolationException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: ConstraintViolationException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.INTERNAL_SERVER_ERROR);

		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.returnConstraintViolationException(
				new ConstraintViolationException("Caused by: ConstraintViolationException", null) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testReturnNotReadableException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.BAD_REQUEST.toString());
		responseMessage.setMessage("Caused by: HttpMessageNotReadableException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.BAD_REQUEST);

		when(globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.returnNotReadableException(
				new HttpMessageNotReadableException("Caused by: HttpMessageNotReadableException", null) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testHandleNoHandlerFoundException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.SERVICE_UNAVAILABLE.toString());
		responseMessage.setMessage("Caused by: NoHandlerFoundException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.SERVICE_UNAVAILABLE);

		when(globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.handleNoHandlerFoundException(
				new NoHandlerFoundException("Caused by: NoHandlerFoundException", null, headers) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testHandleSignatureException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.SERVICE_UNAVAILABLE.toString());
		responseMessage.setMessage("Caused by: SignatureException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.SERVICE_UNAVAILABLE);

		when(globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.handleSignatureException(
				new SignatureException("Caused by: SignatureException", null) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testHandleTicketException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.SERVICE_UNAVAILABLE.toString());
		responseMessage.setMessage("Caused by: TicketException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.SERVICE_UNAVAILABLE);

		when(globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.handleTicketException(
				new TicketException("Caused by: TicketException", null) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testHandleValidationException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.SERVICE_UNAVAILABLE.toString());
		responseMessage.setMessage("Caused by: ValidationException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.SERVICE_UNAVAILABLE);

		when(globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.handleValidationException(
				new TicketException("Caused by: ValidationException", null) {
				}));
	}
	
	@SuppressWarnings("serial")
	@Test
	public void testHandleSystemException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.SERVICE_UNAVAILABLE.toString());
		responseMessage.setMessage("Caused by: SystemException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.SERVICE_UNAVAILABLE);

		when(globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.handleSystemException(
				new TicketException("Caused by: SystemException", null) {
				}));
	}
		
}
