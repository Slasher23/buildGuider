package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.KeyDAO;
import com.commerzbank.gdk.bns.model.Key;

/**
 * JUnit test class for KeyServiceImpl
 * 
 * @since 21/12/2017
 * @author ZE2MACL
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 21/12/2017      1.00      ZE2MACL    Initial Version
 *          </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
public class KeyServiceImplTest {

	@Mock
	private KeyDAO keyDAO;

	@InjectMocks
	private KeyServiceImpl keyServiceImpl;

	private Key key;
	
	private List<Key> keyList;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		keyList = new ArrayList<Key>();
		key = new Key();
		key.setKeyUID(1L);
		key.setKeyTyp("BBANR");
		key.setLanguage("006");
		key.setKeyShortText("Mr");
		key.setKeyLongText("test long text");
		key.setKeyCode("01");

	}

	@Test
	public void shortTextValue_Success_Test() throws Exception {

		keyList.add(key);
		
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyCodeIgnoreCaseAndLanguage(anyString(), anyString(), anyString()))
				.thenReturn(key);
		assertEquals(key.getKeyShortText(),
				keyServiceImpl.getShortTextValue(key.getKeyTyp(), key.getKeyCode(), key.getLanguage()));
	}

	@Test
	public void longTextValue_Success_Test() throws Exception {

		keyList.add(key);
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyCodeIgnoreCaseAndLanguage(anyString(), anyString(), anyString()))
				.thenReturn(key);
		assertEquals(key.getKeyLongText(),
				keyServiceImpl.getLongTextValue(key.getKeyTyp(), key.getKeyCode(), key.getLanguage()));
	}

	@Test
	public void keyCodeByValue_shortText_Success_Test() throws Exception {

		keyList.add(key);
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyShortText(anyString(), anyString())).thenReturn(keyList);
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyLongText(anyString(), anyString())).thenReturn(new ArrayList<Key>());
		assertEquals(key.getKeyCode().toString(), keyServiceImpl.getKeyCodeByValue(key.getKeyTyp(), "Mr"));

	}

	@Test
	public void keyCodeByValue_longText_Success_Test() throws Exception {

		keyList.add(key);
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyShortText(anyString(), anyString())).thenReturn(new ArrayList<Key>());
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyLongText(anyString(), anyString())).thenReturn(keyList);
		assertEquals(key.getKeyCode().toString(), keyServiceImpl.getKeyCodeByValue(key.getKeyTyp(), "test long text"));

	}

	@Test
	public void keyCodeByValue_not_found_salutation_Success_Test() throws Exception {
		String defaultCode = "09";
		key.setKeyCode(defaultCode);

		keyList.add(key);
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyShortText(anyString(), anyString())).thenReturn(new ArrayList<Key>());
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyLongText(anyString(), anyString())).thenReturn(keyList);
		assertEquals(key.getKeyCode().toString(), keyServiceImpl.getKeyCodeByValue(key.getKeyTyp(), "test long"));

	}

	@Test
	public void keyCodeByValue_not_found_title_Success_Test() throws Exception {
		String keyCode = "";
		key.setKeyCode(keyCode);
		key.setKeyTyp("PAKTL");

		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyShortText(anyString(), anyString())).thenReturn(new ArrayList<Key>());
		when(this.keyDAO.findByKeyTypIgnoreCaseAndKeyLongText(anyString(), anyString())).thenReturn(new ArrayList<Key>());
		assertEquals(key.getKeyCode().toString(), keyServiceImpl.getKeyCodeByValue(key.getKeyTyp(), "test long"));

	}

}
