package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.model.BatchNotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.RequestForBatchNotification;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.service.NotificationService;

/**
 * JUnit test class for BatchNotificationServiceImpl
 * 
 * @author ZE2GOME  
 * @since 13/11/2017
 * @version 1.03
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017        1.00       ZE2GOME    Initial Version
 * 04/12/2017        1.01       ZE2GOME    Fixed JUnit
 * 12/12/2017        1.02       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.03       ZE2BUEN    Refactor/ clean up for ZSL status messages
 * </pre>
 */

@RunWith(MockitoJUnitRunner.class)
public class BatchNotificationServiceImplTest {
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    
    @Mock
    private NotificationService notificationService;
    
    @Mock
    private Environment enviroment;
    
    @InjectMocks
    private BatchNotificationServiceImpl batchNotificationServiceImpl;
    
    private List<NotificationRequest> notificationRequestList = new ArrayList<NotificationRequest>();
    
    private NotificationRequest notificationRequest = new NotificationRequest();
    
    private NotificationResponse  response = new NotificationResponse();
    
    private RequestForBatchNotification reqBatch = new RequestForBatchNotification();
    
    @Before
    public void init() {
        notificationRequest.setBpkenn("BPKENNTEST");
        notificationRequest.setSparte(100);
        notificationRequest.setVereinbarungskennung("");
        
        notificationRequestList.add(notificationRequest);
        reqBatch.setNotificationRequest(notificationRequestList);
        
    }
    
    @Test
    public void requestForBatchNotification_Test() throws Exception {
        
        Notifications notif = new Notifications();
        notif.setNotificationPath("email@test.com");
        notif.setNotificationSubject("None");
        notif.setNotificationText("Notif Test");
        notif.setNotificationType("Email");
        
        String successMessage = "OK- Successful";
        
        List<Notifications> notificationList = new ArrayList<Notifications>();
        notificationList.add(notif);
        
        when(this.enviroment.getProperty(STATUS_OK)).thenReturn(successMessage);
        
        response.setBPKENN("BPKENNTEST");
        response.setNotification(notificationList);
        response.setStatus("OK- Successful");
        
        List<NotificationResponse> notificationResponseNoError = new ArrayList<NotificationResponse>();
        notificationResponseNoError.add(response);
        
        when(this.notificationService.sendNotification(notificationRequest)).thenReturn(response);
        
        BatchNotificationResponse  response = this.batchNotificationServiceImpl.requestForBatchNotification(reqBatch);
        
        assertEquals(response.getNotificationResponse().toString(), notificationResponseNoError.toString());
        
    }
    
    @Test
    public void requestForBatchNotificationError_Test() throws Exception {
        
        Notifications notif = new Notifications();
        notif.setNotificationPath("email@test.com");
        notif.setNotificationSubject("None");
        notif.setNotificationText("Notif Test");
        notif.setNotificationType("Email");
        
        List<Notifications> notificationList = new ArrayList<Notifications>();
        notificationList.add(notif);
        
        response.setBPKENN("BPKENNTEST");
        response.setNotification(notificationList);
        response.setStatus("ERROR");
        
        List<NotificationResponse> notificationResponseError = new ArrayList<NotificationResponse>();
        notificationResponseError.add(response);
        
        when(this.notificationService.sendNotification(notificationRequest)).thenReturn(response);
        
        BatchNotificationResponse  response = this.batchNotificationServiceImpl.requestForBatchNotification(reqBatch);
        
        assertEquals(response.getNotificationResponseWithErrors().toString(), notificationResponseError.toString());
        
    }
    
}
