/**
 * 
 *
 */
package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Junit for IndividualConfigServiceImpl test
 * 
 * @author 	ZE2MACl
 * @since 	14/11/2017
 * @version 1.02
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Removed Participant Number
 * 28/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class IndividualConfigServieImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;
	
    @Mock
    private NotificationTextDAO notificationTextDAO;
    
    @Mock
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;
    
    @Mock
    private NotificationConfigPersonDAO notificationConfigPersonDAO;
    
    @Mock
    private InformationChannelDAO informationChannelDAO;
    
    @Mock
    private Environment environment;
    
	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
    
    @InjectMocks
    private IndividualConfigServiceImpl individualConfigServiceImpl;
    
    private NotifTextAgreementConfigWrapper notifTextAgreementConfigWrapper;
    private NotificationText notificationText; 
    private NotificationConfigAgreement notificationConfigAgreement;
    private CustomNotifConfig customNotifConfig;
    private NotificationConfigPerson notificationConfigPerson;
    private Tokenizer token;
    
    private NotifTextPersonConfigWrapper notifTextPersonConfigWrapper;
    private ResponseBuilder<NotifTextAgreementConfigWrapper> notifAgreementConfigBuilder;
    private ResponseBuilder<NotifTextPersonConfigWrapper> notifPersonConfigBuilder;
    private static final Logger logger = LoggerFactory.getLogger(IndividualConfigServiceImpl.class);
    private Map<Integer, String> statusCodesMap;
    
    @Before
    public void init(){
        
        notificationText = new NotificationText();
        notificationText.setEventID(1L);
        notificationText.setEventType("eventType");
        notificationText.setNotificationTextType("FREE");
        notificationText.setNotificationTextUID(1L);
        notificationText.setText("test");
        
        notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setActive(false);
        notificationConfigAgreement.setAgreementUID(1L);
        notificationConfigAgreement.setEmailUID(1L);
        notificationConfigAgreement.setInformationChannelUID(1L);
        notificationConfigAgreement.setNotifConfigAgreementUID(1L);
        notificationConfigAgreement.setNotificationTextUID(1L);
        
        notificationConfigPerson = new NotificationConfigPerson();
        notificationConfigPerson.setActive(false);
        notificationConfigPerson.setEmailUID(1L);
        notificationConfigPerson.setInformationChannelUID(1L);
        notificationConfigPerson.setNotifConfigPersonUID(1L);
        notificationConfigPerson.setNotificationTextUID(1L);
        notificationConfigPerson.setPersonUID(1L);
        
        notifTextPersonConfigWrapper = new NotifTextPersonConfigWrapper();
        notifTextPersonConfigWrapper.setNotificationConfigPerson(notificationConfigPerson);
        notifTextPersonConfigWrapper.setNotificationText(notificationText);
        
        notifTextAgreementConfigWrapper = new NotifTextAgreementConfigWrapper();
        notifTextAgreementConfigWrapper.setNotificationConfigAgreement(notificationConfigAgreement);
        notifTextAgreementConfigWrapper.setNotificationText(notificationText);
        
        customNotifConfig = new CustomNotifConfig();
        customNotifConfig.setActive(false);
        customNotifConfig.setAgreementUID(1L);
        customNotifConfig.setEmailUID(1L);
        customNotifConfig.setInformationChannelUID(1L);
        customNotifConfig.setText("test");
        customNotifConfig.setPersonUID(1L);
        
        token = new Tokenizer();
        token.setError(false);
        token.setUserId("Sharky");
        
        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        notifPersonConfigBuilder = new ResponseBuilder<NotifTextPersonConfigWrapper>(logger, token, globalResponseWrapper);
        notifAgreementConfigBuilder = new ResponseBuilder<NotifTextAgreementConfigWrapper>(logger, token, globalResponseWrapper);
    }
    
    @Test
    public void saveNotifTextAndPersonConfig_SuccessInfoChannelUIDNotNull_Test(){
        
        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);
        when(notificationConfigPersonDAO.findByPersonUID(any(Long.class))).thenReturn(notificationConfigPerson);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notificationText);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(1L);
        
        when(notificationConfigPersonDAO.save(any(NotificationConfigPerson.class))).thenReturn(notificationConfigPerson);
        
        assertEquals(notifPersonConfigBuilder.OK(notifTextPersonConfigWrapper).toString(), individualConfigServiceImpl.saveNotifTextAndPersonConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndPersonConfig_DataAccessException_Test(){
        
        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);
        when(notificationConfigPersonDAO.findByPersonUID(any(Long.class))).thenReturn(notificationConfigPerson);
        when(notificationTextDAO.save(any(NotificationText.class))).thenThrow(new DataRetrievalFailureException("error"));
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(1L);
        
        when(notificationConfigPersonDAO.save(any(NotificationConfigPerson.class))).thenReturn(notificationConfigPerson);
        
        assertEquals(notifPersonConfigBuilder.notOK(Response.DATA_ACCESS_EXCEPTION).toString(), individualConfigServiceImpl.saveNotifTextAndPersonConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndPersonConfig_NullPointerException_Test(){
        
        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(null);
        when(notificationConfigPersonDAO.findByPersonUID(1L)).thenReturn(null);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(null);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(null);
        when(notificationConfigPersonDAO.save(any(NotificationConfigPerson.class))).thenReturn(null);
        
        assertEquals(notifPersonConfigBuilder.notOK(Response.NULL_POINTER_EXCEPTION).toString(), individualConfigServiceImpl.saveNotifTextAndPersonConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndPersonConfig_Exception_Test(){
        
        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenThrow(new RuntimeException("error"));
        when(notificationConfigPersonDAO.findByPersonUID(1L)).thenReturn(null);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(null);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(null);
        when(notificationConfigPersonDAO.save(any(NotificationConfigPerson.class))).thenReturn(null);
        
        assertEquals(notifPersonConfigBuilder.notOK(Response.GENERAL_FUNCTION_ERROR).toString(), individualConfigServiceImpl.saveNotifTextAndPersonConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndAgreementConfig_Success_Test(){

        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);
        when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(notificationConfigAgreement);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notificationText);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(1L);
        when(notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class))).thenReturn(notificationConfigAgreement);
        
        assertEquals(notifAgreementConfigBuilder.OK(notifTextAgreementConfigWrapper).toString(), individualConfigServiceImpl.saveNotifTextAndAgreementConfig(token, customNotifConfig).toString());
        
    }
     
    
    @Test
    public void saveNotifTextAndAgreementConfig_DataAccessException_Test(){

        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenThrow(new DataRetrievalFailureException("error"));
        when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(null);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(null);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(null);
        when(notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class))).thenReturn(null);
        
        assertEquals(notifAgreementConfigBuilder.notOK(Response.DATA_ACCESS_EXCEPTION).toString(), individualConfigServiceImpl.saveNotifTextAndAgreementConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndAgreementConfig_NullPointerException_Test(){

        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(null);
        when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(null);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(null);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(null);
        when(notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class))).thenReturn(null);
        
        assertEquals(notifAgreementConfigBuilder.notOK(Response.NULL_POINTER_EXCEPTION).toString(), individualConfigServiceImpl.saveNotifTextAndAgreementConfig(token, customNotifConfig).toString());
        
    }
    
    @Test
    public void saveNotifTextAndAgreementConfig_Exception_Test(){

        when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenThrow(new RuntimeException("error"));
        when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(null);
        when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(null);
        
        when(informationChannelDAO.getInformationChannelUID(anyString())).thenReturn(null);
        when(notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class))).thenReturn(null);
        
        assertEquals(notifAgreementConfigBuilder.notOK(Response.GENERAL_FUNCTION_ERROR).toString(), individualConfigServiceImpl.saveNotifTextAndAgreementConfig(token, customNotifConfig).toString());
        
    }

}
