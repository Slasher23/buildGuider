package initial;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * This class can be executed on initial setup of the development environment.
 * This will Extract the coba-* jars version 16.61.0 for cryoto-services in the maven local repository.
 * 
 * 
 * @author ZE2RUBI
 * @since 20/02/2018
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 20/02/2018        1.00       ZE2RUBI    Initial Version
 * </pre>
 */
public class InitialSetup {

    /**
     * Please supply the maven local repository setup in your IDE/environment 
     * */
    private static final String localRepository = "C:/Program Files (x86)/Maven/local-repository/";

    /**
     * Main method that accepts the path of the local repository
     * 
     * @param args the path of the local repository
     * */
    public static void main(String[] args) {

        String filePath = ResourceManager.extract("../coba.zip");
        
        System.out.println(filePath);
        if(args.length > 0){
            
            unzip(filePath, args[0]);
            
        }else{
            
            unzip(filePath, localRepository);

        }
        
        System.out.println();
        System.out.println("Done! Please rebuild the bns/web project to check for inserted dependencies.");
   
    }

    
    /**
     * Method for extracting zip file.
     * 
     * @param zipFilePath the zip source
     * @param destDir the destination directory of the extraction
     * */
    private static void unzip(String zipFilePath, String destDir) {
        File dir = new File(destDir);
        // create output directory if it doesn't exist
        if (!dir.exists())
            dir.mkdirs();
        FileInputStream fis;
        // buffer for read and write data to file
        byte[] buffer = new byte[1024];
        try {
            fis = new FileInputStream(zipFilePath);
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while (ze != null) {
                String fileName = ze.getName();
                File newFile = new File(destDir + File.separator + fileName);
                System.out.println("Unzipping to " + newFile.getAbsolutePath());
                // create directories for sub directories in zip
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
                // close this ZipEntry
                zis.closeEntry();
                ze = zis.getNextEntry();
            }
            // close last ZipEntry
            zis.closeEntry();
            zis.close();
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
