--------------------------------------------------------
--  File created - Wednesday-December-13-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SCHLUSSEL_DB
--------------------------------------------------------

  CREATE TABLE "SCHLUSSEL_DB" 
   (	"SCHLTYP" VARCHAR2(5 CHAR), 
	"SCHLCODE" VARCHAR2(2 CHAR), 
	"SPRACHE" VARCHAR2(3 CHAR), 
	"SCHLKTXT" VARCHAR2(65 CHAR), 
	"SCHLLTXT" VARCHAR2(200 CHAR), 
	"SCHLUSSEL_UID" VARCHAR2(11 CHAR)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  ;

   COMMENT ON COLUMN "SCHLUSSEL_DB"."SCHLTYP" IS 'Key Type';
   COMMENT ON COLUMN "SCHLUSSEL_DB"."SCHLCODE" IS 'Key Code';
   COMMENT ON COLUMN "SCHLUSSEL_DB"."SPRACHE" IS 'Language';
   COMMENT ON COLUMN "SCHLUSSEL_DB"."SCHLKTXT" IS 'Short text of the respective key code ';
   COMMENT ON COLUMN "SCHLUSSEL_DB"."SCHLLTXT" IS 'Long text of the respective key code ';
   COMMENT ON COLUMN "SCHLUSSEL_DB"."SCHLUSSEL_UID" IS 'Unique ID';
--------------------------------------------------------
--  DDL for Index SCHLUSSEL_DB_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCHLUSSEL_DB_UK" ON "SCHLUSSEL_DB" ("SCHLUSSEL_UID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;

--------------------------------------------------------
--  DDL for Index SCHLUSSEL_DB_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCHLUSSEL_DB_UK1" ON "SCHLUSSEL_DB" ("SCHLTYP", "SCHLCODE", "SPRACHE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
  
--------------------------------------------------------
--  DDL for Index SCHLUSSEL_DB_IDX
--------------------------------------------------------

  CREATE INDEX "SCHLUSSEL_DB_IDX" ON "SCHLUSSEL_DB" ("SCHLTYP", "SCHLKTXT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
  
--------------------------------------------------------
--  DDL for Index SCHLUSSEL_DB_IDX2
--------------------------------------------------------

  CREATE INDEX "SCHLUSSEL_DB_IDX2" ON "SCHLUSSEL_DB" ("SCHLTYP", "SCHLLTXT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
  
  
--------------------------------------------------------
--  DDL for Trigger SCHLUSSEL_DB_TRG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "SCHLUSSEL_DB_TRG" 
BEFORE INSERT ON SCHLUSSEL_DB 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.SCHLUSSEL_UID IS NULL THEN
      SELECT SCHLUSSEL_SEQ.NEXTVAL INTO :NEW.SCHLUSSEL_UID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "SCHLUSSEL_DB_TRG" ENABLE;
--------------------------------------------------------
--  Constraints for Table SCHLUSSEL_DB
--------------------------------------------------------

  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SCHLUSSEL_UID" NOT NULL ENABLE);
  ALTER TABLE "SCHLUSSEL_DB" ADD CONSTRAINT "SCHLUSSEL_DB_PK" PRIMARY KEY ("SCHLUSSEL_UID")
  USING INDEX "SCHLUSSEL_DB_UK" ENABLE;
  ALTER TABLE "SCHLUSSEL_DB" ADD CONSTRAINT "SCHLUSSEL_DB_UK1" UNIQUE ("SCHLTYP", "SCHLCODE", "SPRACHE") ENABLE;
  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SCHLLTXT" NOT NULL ENABLE);
  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SCHLKTXT" NOT NULL ENABLE);
  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SPRACHE" NOT NULL ENABLE);
  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SCHLCODE" NOT NULL ENABLE);
  ALTER TABLE "SCHLUSSEL_DB" MODIFY ("SCHLTYP" NOT NULL ENABLE);
