--------------------------------------------------------
--  DDL for Table REPORT
--------------------------------------------------------

  CREATE TABLE "REPORT" 
   (	"REPORT_UID" NUMBER, 
	"REPORT_TYPE" VARCHAR2(30 CHAR), 
	"COUNT" NUMBER, 
	"PERCENTAGE" NUMBER(5,2), 
	"REPORT_DATE" DATE, 
	"REPORT_TIME" TIMESTAMP (6)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT);

   COMMENT ON COLUMN "REPORT"."REPORT_UID" IS 'Report UID';
   COMMENT ON COLUMN "REPORT"."REPORT_TYPE" IS 'Report Type';
   COMMENT ON COLUMN "REPORT"."COUNT" IS 'Count';
   COMMENT ON COLUMN "REPORT"."PERCENTAGE" IS 'Percentage';
   COMMENT ON COLUMN "REPORT"."REPORT_DATE" IS 'Report Date';
   COMMENT ON COLUMN "REPORT"."REPORT_TIME" IS 'Report Time';
--------------------------------------------------------
--  DDL for Index REPORT_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "REPORT_UK" ON "REPORT" ("REPORT_UID");
  
--------------------------------------------------------
--  DDL for Index REPORT_TYPE_INDEX
--------------------------------------------------------

  CREATE INDEX "REPORT_IDX" ON "REPORT" ("REPORT_DATE","REPORT_TYPE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;   

--------------------------------------------------------
--  DDL for Trigger REPORT_TRG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "REPORT_TRG" 
BEFORE INSERT ON REPORT 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.REPORT_UID IS NULL THEN
      SELECT REPORT_SEQ.NEXTVAL INTO :NEW.REPORT_UID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "REPORT_TRG" ENABLE;
--------------------------------------------------------
--  Constraints for Table REPORT
--------------------------------------------------------

  ALTER TABLE "REPORT" ADD CONSTRAINT "REPORT_PK" PRIMARY KEY ("REPORT_UID");
  ALTER TABLE "REPORT" MODIFY ("REPORT_UID" NOT NULL ENABLE);
