--------------------------------------------------------
--  File created - Thursday-February-22-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SCHEDULE_LOCKER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE "SCHEDULE_LOCKER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999 INCREMENT BY 1 START WITH 32 NOCACHE  NOORDER  CYCLE  NOPARTITION ;
