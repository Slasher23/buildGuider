# Initial Database Setup

This instruction is for the initial database setup of the BNS project.

## Location of the Database SQL Scripts

	bns-setup/src/main/sql/

## Order of Execution of the Database SQL Scripts

1. PERSON_SEQ.sql
2. PERSON.sql
3. INFORMATIONS_KANAL_SEQ.sql
4. INFORMATIONS_KANAL.sql
5. EMAIL_SEQ.sql
6. EMAIL.sql
7. KUNDE_SEQ.sql
8. KUNDE.sql
9. VEREINBARUNG_SEQ.sql
10. VEREINBARUNG.sql
11. PUSH_KONFIG_SEQ.sql
12. PUSH_KONFIG.sql
13. BENACHRICHTIGUNGS_TEXT_SEQ.sql
14. BENACHRICHTIGUNGS_TEXT.sql
15. BENACH_KONFIG_ALLE_SEQ.sql
16. BENACH_KONFIG_ALLE.sql
17. BENACH_KONFIG_PERSON_SEQ.sql
18. BENACH_KONFIG_PERSON.sql
19. BENACH_KONFIG_VEREINBARUNG_SEQ.sql
20. BENACH_KONFIG_VEREINBARUNG.sql
21. DAILY_REPORT_LOG_SEQ.sql
22. DAILY_REPORT_LOG.sql
23. REPORT_SEQ.sql
24. REPORT.sql
25. SCHEDULE_LOCKER_SEQ.sql
26. SCHEDULE_LOCKER.sql
27. SCHLUSSEL_SEQ.sql
28. SCHLUSSEL_DB.sql

## NOTE:
* Execute first the Sequence SQL Script before the Table SQL Script.
  e.g. For PERSON table, PERSON_SEQ.sql must be executed first before PERSON.sql.
* SQL Scripts must be executed on the above order to be able to apply the correct parent-child relationships of the tables.

## -END-