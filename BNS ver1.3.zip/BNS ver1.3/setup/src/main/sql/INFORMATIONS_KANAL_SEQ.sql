--------------------------------------------------------
--  File created - Friday-June-30-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence INFORMATIONS_KANAL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "INFORMATIONS_KANAL_SEQ"  MINVALUE 1 MAXVALUE 99999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
