--------------------------------------------------------
--  File created - Monday-March-05-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table SCHEDULE_LOCKER
--------------------------------------------------------

  CREATE TABLE "SCHEDULE_LOCKER" 
   (	"NODE_NAME" VARCHAR2(100 CHAR), 
	"RANDOM" NUMBER, 
	"UPDATE_AT" TIMESTAMP (6), 
	"SCHEDULE_LOCKER_UID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT);
  
  COMMENT ON COLUMN "SCHEDULE_LOCKER"."NODE_NAME" IS 'Node name';
  COMMENT ON COLUMN "SCHEDULE_LOCKER"."RANDOM" IS 'Random';
  COMMENT ON COLUMN "SCHEDULE_LOCKER"."UPDATE_AT" IS 'Update at';
  COMMENT ON COLUMN "SCHEDULE_LOCKER"."SCHEDULE_LOCKER_UID" IS 'Schedule Locker UID';
  
--------------------------------------------------------
--  DDL for Index SCHEDULE_LOCKER_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SCHEDULE_LOCKER_PK" ON "SCHEDULE_LOCKER" ("SCHEDULE_LOCKER_UID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
  
--------------------------------------------------------
--  DDL for Trigger SCHEDULE_LOCKER_TRG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "SCHEDULE_LOCKER_TRG"
BEFORE INSERT ON SCHEDULE_LOCKER 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.SCHEDULE_LOCKER_UID IS NULL THEN
      SELECT SCHEDULE_LOCKER_SEQ.NEXTVAL INTO :NEW.SCHEDULE_LOCKER_UID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "SCHEDULE_LOCKER_TRG" ENABLE;

  
--------------------------------------------------------
--  Constraints for Table SCHEDULE_LOCKER
--------------------------------------------------------

  ALTER TABLE "SCHEDULE_LOCKER" MODIFY ("SCHEDULE_LOCKER_UID" NOT NULL ENABLE);
  ALTER TABLE "SCHEDULE_LOCKER" ADD CONSTRAINT "SCHEDULE_LOCKER_PK" PRIMARY KEY ("SCHEDULE_LOCKER_UID");
