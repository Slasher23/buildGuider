--------------------------------------------------------
--  File created - Monday-December-27-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table KUNDE
--------------------------------------------------------

  CREATE TABLE "KUNDE" 
   (	"KUNDE_UID" NUMBER(11,0), 
	"KUNDEN_NUMMER" VARCHAR2(10 CHAR), 
	"LANGZEIT_KUNDEN_NUMMER" VARCHAR2(16 CHAR), 
	"PERSON_UID" NUMBER(11,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT);

   COMMENT ON COLUMN "KUNDE"."KUNDE_UID" IS 'Customer UID';
   COMMENT ON COLUMN "KUNDE"."KUNDEN_NUMMER" IS 'Customer Number';
   COMMENT ON COLUMN "KUNDE"."LANGZEIT_KUNDEN_NUMMER" IS 'Long-term Customer Number';
   COMMENT ON COLUMN "KUNDE"."PERSON_UID" IS 'Person UID';
--------------------------------------------------------
--  DDL for Index KUNDE_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "KUNDE_UK" ON "KUNDE" ("KUNDE_UID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
--------------------------------------------------------
--  DDL for Index KUNDE_UK1
--------------------------------------------------------

  CREATE UNIQUE INDEX "KUNDE_UK1" ON "KUNDE" ("PERSON_UID", "KUNDEN_NUMMER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;
  
--------------------------------------------------------
--  DDL for Index KUNDE_IDX
--------------------------------------------------------

  CREATE INDEX "KUNDE_IDX" ON "KUNDE" ("KUNDEN_NUMMER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS;  

--------------------------------------------------------
--  DDL for Trigger KUNDE_TRG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "KUNDE_TRG" 
BEFORE INSERT ON KUNDE 
FOR EACH ROW 
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.KUNDE_UID IS NULL THEN
      SELECT KUNDE_SEQ.NEXTVAL INTO :NEW.KUNDE_UID FROM SYS.DUAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/
ALTER TRIGGER "KUNDE_TRG" ENABLE;
--------------------------------------------------------
--  Constraints for Table KUNDE
--------------------------------------------------------

  ALTER TABLE "KUNDE" MODIFY ("KUNDE_UID" NOT NULL ENABLE);
  ALTER TABLE "KUNDE" ADD CONSTRAINT "KUNDE_PK" PRIMARY KEY ("KUNDE_UID")
  USING INDEX "KUNDE_UK" ENABLE;
  ALTER TABLE "KUNDE" MODIFY ("PERSON_UID" NOT NULL ENABLE);
  ALTER TABLE "KUNDE" MODIFY ("KUNDEN_NUMMER" NOT NULL ENABLE);
  ALTER TABLE "KUNDE" ADD CONSTRAINT "KUNDE_CHK" CHECK (NOT REGEXP_LIKE(LANGZEIT_KUNDEN_NUMMER, '[^A-Za-z0-9. \-]{1}')) ENABLE;
  ALTER TABLE "KUNDE" ADD CONSTRAINT "KUNDE_PERSON_FK" FOREIGN KEY ("PERSON_UID")
	  REFERENCES "PERSON" ("PERSON_UID") 
	  ON DELETE CASCADE ENABLE;
  ALTER TABLE "KUNDE" ADD CONSTRAINT "KUNDE_UK1" UNIQUE ("PERSON_UID", "KUNDEN_NUMMER") ENABLE;
