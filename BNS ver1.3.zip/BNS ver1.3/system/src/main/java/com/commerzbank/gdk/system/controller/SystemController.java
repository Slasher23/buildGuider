package com.commerzbank.gdk.system.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * This class handles the controller service that will handle the redirection to
 * index.html upon successful registration of the databackpack
 * 
 * @author ZE2FUEN
 * @since 13/03/2018
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/03/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */
@Controller
public class SystemController {
    
    private static final Logger logger = LoggerFactory.getLogger(SystemController.class);

    @RequestMapping(value ="/healthcheck", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    public String healthcheck(HttpServletRequest request, HttpServletResponse response) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] healthcheck()", system);
        
        return "healthcheck";
    }
    
    @RequestMapping(value ="/invalidate", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    public String invalidate(HttpServletRequest request, HttpServletResponse response) {
        
        String system = "SYSTEM";

        logger.info("=>> System [{}] keepalive()", system);
        
        return "invalidate";
    }
    
    @RequestMapping(value ="/keepalive", method = RequestMethod.GET, produces = MediaType.TEXT_HTML_VALUE)
    public String keepalive(HttpServletRequest request, HttpServletResponse response) {

        String system = "SYSTEM";

        logger.info("=>> System [{}] invalidate()", system);
        
        return "keepalive";
    }

}
