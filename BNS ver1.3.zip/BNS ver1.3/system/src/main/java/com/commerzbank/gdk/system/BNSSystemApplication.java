package com.commerzbank.gdk.system;

import org.apache.log4j.Logger;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * This class is the Entry Point of the application. All configuration will be
 * initialised in here upon starting of the application.
 * 
 * @author ZE2FUEN
 * @since 13/03/2018
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 13/03/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */

@SpringBootApplication
@EnableAutoConfiguration(exclude = {SecurityAutoConfiguration.class})
public class BNSSystemApplication extends SpringBootServletInitializer implements CommandLineRunner {

    private static Logger  logger = Logger.getLogger(BNSSystemApplication.class);
       
    public static void main(String[] args) {
        SpringApplication.run(BNSSystemApplication.class, args);
    }

    @Override
    public void run(String... arg0) throws Exception {

        logger.info("============================");
        logger.info("Initializing BNS System...");
        logger.info("BNS System Started Successfully!");
        logger.info("============================");
               
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*");
            }
        };
    }

    
}
