﻿ï»¿# Initial Project Dependency Setup

This instruction is for initial dependency setup of the BNS project.

## CCB Dependencies

BNS is using CCB artifacts for its encryption and request validation.
Due to the fact that CCB does not currently(end of development of BNS) have a stable release in the nexus. 
We opted to extract artifacts from nexus with the details below, and stored it via zip inside this project under setup module.

		<dependency>
			<groupId>coba.ccb.sc.crypto</groupId>
			<artifactId>sc-crypto-service</artifactId>
			<version>16.61.0</version>
		</dependency>

## How to use this dependencies in your local development

If the above  artifact is still present in the nexus, you don't neeed to execute this procedure and you can continue in your development.
If maven is returning an error of missing dependency remotely and locally, you can execute the below procedure:

### 1. Determine the current maven local repository in your environment/eclipse. By going to Window>Preferences>Maven>User Settings; 
### 2. Open bns-setup module and open file IntialiSetup in [initial] package;
### 3. In line number 29, Update variable [localRepository] value with your current local repository path;
### 4. Run/Execute the InitialSetup class, and wait for the console confirmation that is it is done; and
### 5. Go back to bns-web, right click the project and execute maven goal clean install and wait for the result.


## How to use this in Jenkins environment

Execute Jenkins build BNS, if there are no issues found upon compilation you don't need to execute this procedure. Otherwise,
If maven is returning an error of missing dependency remotely and locally regaring libraries with version 16.61.0, 
you can execute the below procedure inside Jenkins via terminal/console:

### 1. Pull the latest head in the Git repository;
### 2. cd to development branch;
### 3. cd to ../BNS/setup/src/main/resources;
### 4. execute the following: 

		java -jar bns-setup-coba-lib.jar "{localPath}";

Note: 
			
localPath = location of the maven local repository i.e [../Maven/local-repository/]

### 5. check maven local library if coba packages with version 16.61.0 is existing ;
### 4. Execute Jenkins build;


## NOTE:

If CCB has already release a stable artifact on nexus and they require BNS to use the new artifact, please disregard this procedure and update the pom dependency version as required.
This needs further testing if there are BNS codes that was affected due to the change of artifact version. 


## -END-