package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Person;

/**
 * JUnit for StoredProcedureServiceImpl Test
 * 
 * @author ZE2MENY
 * @since 22/12/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/12/2017        1.00       ZE2MENY    Initial Version
 * 27/12/2017        1.01       ZE2MACL    Update test method
 *          </pre>
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class StoredProcedureServiceImplTest {

    @Mock
    private PersonDAO personDAO;

    @Mock
    private AgreementDAO agreementDAO;

    @InjectMocks
    private StoredProcedureServiceImpl serviceImpl;

    private Person person;

    private Agreement agreement;

    private List<Agreement> agreementList = new ArrayList<Agreement>();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        this.person = new Person();
        this.person.setBPKENN("BPKENNTEST");
        this.person.setPersonUID(1L);

        this.agreement = new Agreement();
        this.agreement.setAgreementUID(1L);
        this.agreement.setAgreementID("test");
        this.agreement.setBranch(100);
        this.agreement.setPersonUID(1L);

        agreementList.add(agreement);
        

    }
    
    @Test
    public void Validate_Account_StoredProc01() throws Exception {
        
        String bpkenn01 = "STOREDPROC01";
        String agreementId01 = "DE01 2345 6789 1011 1213 96";
        Integer sparte01 = 100;
        
        Person request = new Person();
        request.setBPKENN(bpkenn01);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId01);
        request1.setBranch(sparte01);

        assertEquals("01", this.serviceImpl.validateAccount("STOREDPROC01", "DE01 2345 6789 1011 1213 96", 100));

    }

    @Test
    public void Validate_Account_StoredProc02() throws Exception {
        
        String bpkenn02 = "STOREDPROC02";
        String agreementId02 = "DE01 2345 6789 1011 1213 99";
        Integer sparte02 = 100;
        
        Person request = new Person();
        request.setBPKENN(bpkenn02);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId02);
        request1.setBranch(sparte02);

        assertEquals("02", this.serviceImpl.validateAccount("STOREDPROC02", "DE01 2345 6789 1011 1213 99", 100));

    }
    
    @Test
    public void Validate_Account_StoredProc03() throws Exception {
        
        String bpkenn03 = "STOREDPROC03";
        String agreementId03 = "DE01 2345 6789 1011 1213 98";
        Integer sparte03 = 100;
        
        Person request = new Person();
        request.setBPKENN(bpkenn03);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId03);
        request1.setBranch(sparte03);

        assertEquals("03", this.serviceImpl.validateAccount("STOREDPROC03", "DE01 2345 6789 1011 1213 98", 100));

    }
    
    @Test
    public void Validate_Account_StoredProc04() throws Exception {
        
        String bpkenn04 = "STOREDPROC04";
        String agreementId04 = "DE01 2345 6789 1011 1213 97";
        Integer sparte04 = 100;
        
        Person request = new Person();
        request.setBPKENN(bpkenn04);

        Agreement request1 = new Agreement();
        request1.setAgreementID(agreementId04);
        request1.setBranch(sparte04);

        assertEquals("04", this.serviceImpl.validateAccount("STOREDPROC04", "DE01 2345 6789 1011 1213 97", 100));

    }

    @Test
    public void delete_PersonRelated() throws Exception {

        when(this.personDAO.findByBpkennIgnoreCase(anyString())).thenReturn(person);
        when(this.agreementDAO.findByPersonUID(anyLong())).thenReturn(agreementList);

    }

    @Test
    public void delete_AgreementRelated() throws Exception {

        when(this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(anyString(), anyInt())).thenReturn(agreementList);

    }

}
