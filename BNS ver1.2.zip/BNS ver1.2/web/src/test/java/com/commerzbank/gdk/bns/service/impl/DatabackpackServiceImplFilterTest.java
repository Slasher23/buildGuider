package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.DatabackpackLog;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit test class for Databackpack Service Impl
 * 
 * @since 21/11/2017
 * @author ZE2BUEN
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 21/11/2017      1.00      ZE2BUEN    Initial Version
 * 06/02/2018      1.01      ZE2BUEN    Updated databackpack deserializer implementation
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class DatabackpackServiceImplFilterTest {

    @Mock
    private DatabackpackServiceImpl databackpackServiceImplMock;

    @InjectMocks
    private DatabackpackServiceImpl databackpackServiceImpl;
    
    @Mock
    private GlobalEventTypeWrapper globalEventTypeWrapper;
    
    @Autowired
    private GlobalEventTypeWrapper globalETWrapper;
    
    private Map<String, EventType> eventTypesMap;

    private List<Agreement> agreementList, agreementListDB;

    private Agreement agreement1, agreement2, agreement3, agreement4;

    private Person person;

    private NotificationConfigPerson notificationConfigPerson;

    private List<Email> emailList;

    private Email email1;

    private Email email2;

    private Databackpack databackpack;

    private Tokenizer token;

    private ResponseBuilder<Databackpack> databackpackBuilder;
    
    private static final Logger logger = LoggerFactory.getLogger(DatabackpackServiceImpl.class);

    @Before
    public void init() {

        MockitoAnnotations.initMocks(this);

        token = new Tokenizer();
        token.setUserId("User Test");
        token.setError(false);
        token.setBpkenn("BPKENNTEST");
        
        person = new Person();
        person.setPersonUID((long) 1);
        person.setGivenName("Simon");
        person.setLastName("Meier");
        person.setSalutation("02");
        person.setTitle("02");
        person.setBPKENN("BPKENNTEST");

        agreement1 = new Agreement(null, "DE02234567891011121351", 100, "WP", "Premium", "Chris Test",
                person.getPersonUID(), "DE02234567891011121351");
        agreement2 = new Agreement(null, "DE02234567891011121352", 100, "KRE", "Premium", "Max Mustermann",
                person.getPersonUID(), "DE02234567891011121352");
        agreement3 = new Agreement(null, "100527389113100CHF", 100, "VOR", "Premium", "Pdcafca",
                person.getPersonUID(), "");

        agreementList = new ArrayList<>();
        agreementList.add(agreement1);
        agreementList.add(agreement2);
        agreementList.add(agreement3);

        agreementListDB = new ArrayList<>();

        agreement1 = new Agreement(Long.valueOf(1), "DE02234567891011121351", 100, "WP", "Premium", "Chris Test",
                person.getPersonUID(), "DE02234567891011121351");
        agreement2 = new Agreement(Long.valueOf(2), "DE02234567891011121352", 100, "KRE", "Premium", "Max Mustermann",
                person.getPersonUID(), "DE02234567891011121352");
        agreement3 = new Agreement(Long.valueOf(3), "100527389113100CHF", 100, "VOR", "Premium", "Pdcafca",
                person.getPersonUID(), "");
        agreement4 = new Agreement(Long.valueOf(4), "1234456789101150", 400, "KAR", "Premium", "USER224 KU01KK01",
                person.getPersonUID(), "");

        agreementListDB.add(agreement1);
        agreementListDB.add(agreement2);
        agreementListDB.add(agreement3);
        agreementListDB.add(agreement4);

        notificationConfigPerson = new NotificationConfigPerson();
        notificationConfigPerson.setActive(false);

        email1 = new Email();
        email1.setAddressId(1L);
        email1.setEmailAddress("email@coba.com");

        email2 = new Email();
        email2.setAddressId(2L);
        email2.setEmailAddress("email@gmail.com");

        emailList = new ArrayList<>();
        emailList.add(email1);
        emailList.add(email2);

        databackpack = new Databackpack();
        databackpack.setAgreementList(agreementList);
        // databackpack.setCustomerList(customerList);
        databackpack.setEmailList(emailList);
        databackpack.setNotificationConfigPerson(notificationConfigPerson);
        databackpack.setPerson(person);
        
        eventTypesMap = this.globalETWrapper.getEventTypeMap();
               
    }

    @Test
    public void agreementFilter_Successful_Test() throws Exception {

        List<Agreement> result = this.databackpackServiceImpl.agreementFilter(token, databackpack, agreementListDB,
                person.getPersonUID());

        assertEquals(3, result.size());

    }

    @Test
    public void agreementFilter_Null_Test() throws Exception {
    	
		EventType eventType = new EventType();
		eventType.setDescription("Agreement Added");
		eventType.setType("2008");

		DatabackpackLog dbpLog1 = new DatabackpackLog();
		dbpLog1.setBpkenn("BPKENNTEST");
		dbpLog1.setEventType("2008");
		dbpLog1.setOldValue(null);
		dbpLog1.setNewValue(agreement1.toString());
		dbpLog1.setUser("User Test");

		when(this.globalEventTypeWrapper.getEventTypeMap()).thenReturn(eventTypesMap);

		when(this.globalEventTypeWrapper.get(anyString())).thenReturn(eventType);

		DatabackpackLog dbpLog2 = new DatabackpackLog();
		dbpLog2.setBpkenn("BPKENNTEST");
		dbpLog2.setEventType("2008");
		dbpLog2.setOldValue(null);
		dbpLog2.setNewValue(agreement2.toString());
		dbpLog2.setUser("User Test");

		when(this.globalEventTypeWrapper.get(anyString())).thenReturn(eventType);

		DatabackpackLog dbpLog3 = new DatabackpackLog();
		dbpLog3.setBpkenn("BPKENNTEST");
		dbpLog3.setEventType("2008");
		dbpLog3.setOldValue(null);
		dbpLog3.setNewValue(agreement3.toString());
		dbpLog3.setUser("User Test");

		when(this.globalEventTypeWrapper.get(anyString())).thenReturn(eventType);

        List<Agreement> result = this.databackpackServiceImpl.agreementFilter(token, databackpack, null,
                person.getPersonUID());

        assertEquals(3, result.size());
       
        databackpack.setAgreementList(null);
        
        result = this.databackpackServiceImpl.agreementFilter(token, databackpack, agreementListDB,
                person.getPersonUID());

        assertEquals(0, result.size());
        databackpack.setAgreementList(agreementList);

    }
    
    @Test
    public void agreementFilterByDatabackpack_Successtful_Test() throws Exception {

        List<Agreement> result = this.databackpackServiceImpl.agreementFilterByDatabackpack(databackpack, agreementListDB,
                person.getPersonUID());

        assertEquals(3, result.size());
  
    }
    
}
