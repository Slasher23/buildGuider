package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * 
 * JUnit test class for PersonConfigServiceImpl
 * 
 * @since 23/10/2017
 * @author ZE2CRUH
 * @version 1.02
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 23/10/2017      1.00      ZE2CRUH    Initial Version
 * 27/11/2017      1.01      ZE2CRUH    Removed Participant Number
 * 28/11/2017      1.02      ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class PersonConfigServiceImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Mock
	private Environment environment;

	@Mock
	private NotificationTextDAO notificationTextDAO;

	@InjectMocks
	private PersonConfigServiceImpl personConfigServiceImpl;

	private PersonConfig personConfig;

	private NotificationConfigPerson notificationConfigPerson;

	private Tokenizer token;

	private ResponseBuilder<PersonConfig> personBuilder;

	private ResponseBuilder<NotificationConfigPerson> notifConfPersonBuilder;

	private ResponseBuilder<List<NotificationConfigPerson>> notifConfPersonListBuilder;

	private static final Logger logger = LoggerFactory.getLogger(PersonConfigServiceImpl.class);

	private Map<Integer, String> statusCodesMap;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		token = new Tokenizer();
		token.setUserId("test");
		token.setError(false);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

	}

	@Test
	public void getNotificationConfigPersonById_SuccessfulWithResult_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.OK(notificationConfigPerson);

		when(notificationConfigPersonDAO.findOne(1L)).thenReturn(notificationConfigPerson);

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonById(token, 1L).toString());

	}

	@Test
	public void getNotificationConfigPersonById_SuccessfulWithNullResult_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(notificationConfigPersonDAO.findOne(1L)).thenReturn(null);

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonById(token, 1L).toString());

	}

	@Test
	public void getNotificationConfigPersonById_DataAccessException_Test() throws Exception {

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(notificationConfigPersonDAO.findOne(1L)).thenThrow(new DataRetrievalFailureException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonById(token, 1L).toString());

	}

	@Test
	public void getNotificationConfigPersonById_NullPointerException_Test() throws Exception {

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(notificationConfigPersonDAO.findOne(1L)).thenThrow(new NullPointerException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonById(token, 1L).toString());

	}

	@Test
	public void getNotifConfigPersonById_Exception_Test() throws Exception {

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);

		when(notificationConfigPersonDAO.findOne(1L)).thenThrow(new RuntimeException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonById(token, 1L).toString());

	}
	// asasa

	@Test
	public void postCustomer_SuccessfulWithResult_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.OK(notificationConfigPerson);

		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenReturn(notificationConfigPerson);

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.postCustomer(token, notificationConfigPerson).toString());

	}

	@Test
	public void postCustomer_DataAccessException_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		
		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenThrow(new DataRetrievalFailureException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.postCustomer(token, notificationConfigPerson).toString());

	}

	@Test
	public void postCustomer_NullPointerException_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		
		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenThrow(new NullPointerException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.postCustomer(token, notificationConfigPerson).toString());

	}

	@Test
	public void postCustomer_Exception_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		
		notifConfPersonBuilder = new ResponseBuilder<NotificationConfigPerson>(logger, token, globalResponseWrapper);
		notifConfPersonBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);

		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenThrow(new RuntimeException("error"));

		assertEquals(notifConfPersonBuilder.toString(),
				personConfigServiceImpl.postCustomer(token, notificationConfigPerson).toString());

	}
	// asasa
	@Test
	public void getNotifConfigPersonList_SuccessfulWithResult_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		List<NotificationConfigPerson> listNotifConfigPerson = new ArrayList<NotificationConfigPerson>();
		listNotifConfigPerson.add(notificationConfigPerson);

		notifConfPersonListBuilder = new ResponseBuilder<List<NotificationConfigPerson>>(logger, token,
				globalResponseWrapper);
		notifConfPersonListBuilder.OK(listNotifConfigPerson);

		when(notificationConfigPersonDAO.findAll()).thenReturn(listNotifConfigPerson);

		assertEquals(notifConfPersonListBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonList(token).toString());

	}

	@Test
	public void getNotifConfigPersonList_SuccessfulWithNullResult_Test() throws Exception {

		notifConfPersonListBuilder = new ResponseBuilder<List<NotificationConfigPerson>>(logger, token,
				globalResponseWrapper);
		notifConfPersonListBuilder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(notificationConfigPersonDAO.findAll()).thenReturn(null);

		assertEquals(notifConfPersonListBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonList(token).toString());

	}

	@Test
	public void getNotifConfigPersonList_DataAccessException_Test() throws Exception {

		notifConfPersonListBuilder = new ResponseBuilder<List<NotificationConfigPerson>>(logger, token,
				globalResponseWrapper);
		notifConfPersonListBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(notificationConfigPersonDAO.findAll()).thenThrow(new DataRetrievalFailureException("error"));

		assertEquals(notifConfPersonListBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonList(token).toString());
	}

	@Test
	public void getNotifConfigPersonList_NullPointerException_Test() throws Exception {

		notifConfPersonListBuilder = new ResponseBuilder<List<NotificationConfigPerson>>(logger, token,
				globalResponseWrapper);
		notifConfPersonListBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(notificationConfigPersonDAO.findAll()).thenThrow(new NullPointerException());

		assertEquals(notifConfPersonListBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonList(token).toString());
	}

	@Test
	public void getNotifConfigPersonList_Exception_Test() throws Exception {

		notifConfPersonListBuilder = new ResponseBuilder<List<NotificationConfigPerson>>(logger, token,
				globalResponseWrapper);
		notifConfPersonListBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);

		when(notificationConfigPersonDAO.findAll()).thenThrow(new RuntimeException("error"));

		assertEquals(notifConfPersonListBuilder.toString(),
				personConfigServiceImpl.getNotifConfigPersonList(token).toString());
	}

	@Test
	public void postNotificationConfigPerson_SuccessfulNotifTextUIDNull_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(null);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(null);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.OK(personConfig);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenReturn(notificationConfigPerson);

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

	@Test
	public void postNotificationConfigPerson_SuccessfulNotifTextUIDZero_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(0L);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(0L);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.OK(personConfig);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenReturn(notificationConfigPerson);

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

	@Test
	public void postNotificationConfigPerson_SuccessfulNotifTextUIDOne_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.OK(personConfig);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenReturn(notificationConfigPerson);

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

	@Test
	public void postNotificationConfigPerson_DataAccessException_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson))
				.thenThrow(new DataRetrievalFailureException("error"));

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

	@Test
	public void postNotificationConfigPerson_NullPointerException_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.notOK(Response.NULL_POINTER_EXCEPTION);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenThrow(new NullPointerException("error"));

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

	@Test
	public void postNotificationConfigPerson_Exception_Test() throws Exception {
		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);
		personConfig = new PersonConfig();

		personConfig.setNotificationConfigPerson(notificationConfigPerson);

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("PER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);

		personBuilder = new ResponseBuilder<PersonConfig>(logger, token, globalResponseWrapper);
		personBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);
		when(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY)).thenReturn("PER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigPersonDAO.save(notificationConfigPerson)).thenThrow(new RuntimeException("error"));

		assertEquals(personBuilder.toString(),
				personConfigServiceImpl.postNotifConfigPerson(token, personConfig).toString());

	}

}
