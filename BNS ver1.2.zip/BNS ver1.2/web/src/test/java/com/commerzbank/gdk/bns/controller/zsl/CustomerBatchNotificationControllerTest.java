package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.service.CustomerBatchNotificationService;

/**
 * JUnit test class for CustomerBatchNotificationController 
 * 
 * @since 20/11/2017
 * @author ZE2GOME
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2GOME    Initial Version
 *          </pre>
 */

@EnableWebMvc
public class CustomerBatchNotificationControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CustomerBatchNotificationService serviceMock;

    @InjectMocks
    private CustomerBatchNotificationController custBatchNotifMock;

    private CustomerBatchNotificationsRequest request = new CustomerBatchNotificationsRequest();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(this.custBatchNotifMock).build();

        List<CustomerNotificationRequest> listCustRequest = new ArrayList<CustomerNotificationRequest>();
        CustomerNotificationRequest custRequest = new CustomerNotificationRequest();
        custRequest.setKundennummer("12345");
        listCustRequest.add(custRequest);
        request.setCustomerNotificationsRequest(listCustRequest);
    }

    @Test
    public void requestForBatchCustomerNotification_Json_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchCustomerNotification")
                .contentType(MediaType.APPLICATION_JSON).content(Parser.asJsonString(request)))
                .andExpect(status().isOk());

    }

    @Test
    public void requestForBatchCustomerNotification_Xml_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchCustomerNotification").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(request))).andExpect(status().isOk());

    }

}
