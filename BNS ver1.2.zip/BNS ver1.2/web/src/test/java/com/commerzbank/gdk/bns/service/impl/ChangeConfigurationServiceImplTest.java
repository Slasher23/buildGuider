package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.mock.env.MockEnvironment;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Agreements;
import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeConfigurationResponse;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;

/**
 * JUnit test class for Change Configuration Service Implementation.
 * 
 * @author ZE2BAUL
 * @since 26/12/2017
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/12/2017        1.00       ZE2BAUL    Initial Version
 * 18/01/2018        1.01       ZE2BUEN    Modified JUnit to reflect changes on the implementation
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class ChangeConfigurationServiceImplTest {

	@Mock
	private PersonDAO personDAO;

	@Mock
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Mock
	private NotificationConfigAgreementDAO notifConfigAgreementDAO;

	@Mock
	private NotificationTextDAO notificationTextDAO;

	@Mock
	private AgreementDAO agreementDAO;

	@Mock
	private Environment environmentMock;

	@InjectMocks
	private ChangeConfigurationServiceImpl changeConfigurationServiceImpl;

	private ChangeConfigurationRequest changeConfigRequest;
	private Agreements agreements;
	private List<Agreements> agreementsList;
	private ChangeConfigurationResponse expectedResponse;
	private Person person;
	private NotificationConfigPerson notificationConfigPerson;
	private Agreement agreement;
	private NotificationConfigAgreement notificationConfigAgreement;
	private AnnotationConfigWebApplicationContext context;

	private static final String KEY_STATUS_OK_SUCCESS = "ZSL_STATUS_OK";
	private static final String KEY_STATUS_OK_NO_CHANGES_REQ = "ZSL_STATUS_NO_CHANGES_REQ";
	private static final String KEY_STATUS_FA_BPKENN_NOT_EXIST = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
	private static final String KEY_STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String KEY_STATUS_FA_FAILED_CHANGE_CONFIG = "ZSL_STATUS_FA_FAILED_CHANGE_CONFIG";

	private static final String VALUE_STATUS_OK_SUCCESS = "OK- Successful";
	private static final String VALUE_STATUS_OK_NO_CHANGES_REQ = "OK- No changes required";
	private static final String VALUE_STATUS_FA_BPKENN_NOT_EXIST = "FA- BPKENN does not exist in BNS";
	private static final String VALUE_STATUS_FA_INVALID_REQUEST = "FA- Invalid Request";
	private static final String VALUE_STATUS_FA_FAILED_CHANGE_CONFIG = "FA- Request for Change Configuration not processed";

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		MockEnvironment env = new MockEnvironment();
		env.setProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS);
		env.setProperty(KEY_STATUS_OK_NO_CHANGES_REQ, VALUE_STATUS_OK_NO_CHANGES_REQ);
		env.setProperty(KEY_STATUS_FA_BPKENN_NOT_EXIST, VALUE_STATUS_FA_BPKENN_NOT_EXIST);
		env.setProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST);
		env.setProperty(KEY_STATUS_FA_FAILED_CHANGE_CONFIG, VALUE_STATUS_FA_FAILED_CHANGE_CONFIG);

		context = new AnnotationConfigWebApplicationContext();
		context.setEnvironment(env);

		agreements = new Agreements();
		agreements.setActive(true);
		agreements.setSparte(100);
		agreements.setVereinbarungskennung("DE72938910231");

		agreementsList = new ArrayList<Agreements>();
		agreementsList.add(agreements);

		changeConfigRequest = new ChangeConfigurationRequest();
		changeConfigRequest.setBpkenn("BPKENN");
		changeConfigRequest.setActive(true);
		changeConfigRequest.setAgreements(agreementsList);

		person = new Person();
		person.setBPKENN("BPKENN");
		person.setGivenName("Lotty");
		person.setLastName("Spears");
		person.setPersonUID(1L);
		person.setSalutation("Sal");
		person.setTitle("Ms");

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(true);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);
		notificationConfigPerson.setPersonUID(1L);

		agreement = new Agreement();
		agreement.setAgreementID("DE72938910231");
		agreement.setAgreementType("KTO");
		agreement.setAgreementUID(1L);
		agreement.setBranch(100);
		agreement.setPersonUID(1L);
		agreement.setType("Premium Konto");

		notificationConfigAgreement = new NotificationConfigAgreement();
		notificationConfigAgreement.setActive(true);
		notificationConfigAgreement.setAgreementUID(1L);
		notificationConfigAgreement.setEmailUID(1L);
		notificationConfigAgreement.setInformationChannelUID(1L);
		notificationConfigAgreement.setNotifConfigAgreementUID(1L);
		notificationConfigAgreement.setNotificationTextUID(1L);

		when(this.environmentMock.getProperty(KEY_STATUS_FA_BPKENN_NOT_EXIST))
				.thenReturn(VALUE_STATUS_FA_BPKENN_NOT_EXIST);
		when(this.environmentMock.getProperty(KEY_STATUS_OK_NO_CHANGES_REQ)).thenReturn(VALUE_STATUS_OK_NO_CHANGES_REQ);
		when(this.environmentMock.getProperty(KEY_STATUS_OK_SUCCESS)).thenReturn(VALUE_STATUS_OK_SUCCESS);
		when(this.environmentMock.getProperty(KEY_STATUS_FA_INVALID_REQUEST))
				.thenReturn(VALUE_STATUS_FA_INVALID_REQUEST);
		when(this.environmentMock.getProperty(KEY_STATUS_FA_FAILED_CHANGE_CONFIG))
				.thenReturn(VALUE_STATUS_FA_FAILED_CHANGE_CONFIG);
	}

	@Test
	public void requestForChangeConfiguration_HappyPath_Test() throws Exception {
		// Valid request with valid Agreement with Modifications made

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(this.agreement);
		when(this.notifConfigAgreementDAO.findByAgreementUID(agreement.getAgreementUID()))
				.thenReturn(this.notificationConfigAgreement);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_BPKENNIsNull_Test() throws Exception {
		// Invalid Request - BPKENN null, agreements empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn(null);
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		changeConfigRequest.setBpkenn(null);
		changeConfigRequest.setAgreements(null);
		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_BPKENNIsEmpty_Test() throws Exception {
		// Invalid Request - BPKENN empty, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		changeConfigRequest.setBpkenn("");
		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_ParentActiveIsEmpty_Test() throws Exception {
		// Invalid Request - Parent Active null, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		changeConfigRequest.setActive(null);
		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_AgreementIDIsNull_Test() throws Exception {
		// Invalid Request - Vereinbarungskennung null, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		agreements.setVereinbarungskennung(null);
		agreementsList.add(agreements);

		changeConfigRequest.setAgreements(agreementsList);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_AgreementIDIsEmpty_Test() throws Exception {
		// Invalid Request - Vereinbarungskennung empty, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		agreements.setVereinbarungskennung("");
		agreementsList.add(agreements);

		changeConfigRequest.setAgreements(agreementsList);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_SparteIsNull_Test() throws Exception {
		// Invalid Request - Sparte null, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		agreements.setSparte(null);
		agreementsList.add(agreements);

		changeConfigRequest.setAgreements(agreementsList);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_ChildActiveIsNull_Test() throws Exception {
		// Invalid Request - Child Active null, agreements not empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		agreements.setActive(null);
		agreementsList.add(agreements);

		changeConfigRequest.setAgreements(agreementsList);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_AgreementsEmpty_Test() throws Exception {
		// Invalid Request - agreements is empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_INVALID_REQUEST, VALUE_STATUS_FA_INVALID_REQUEST));

		agreements = new Agreements();
		agreementsList = new ArrayList<Agreements>();
		agreementsList.add(agreements);

		changeConfigRequest.setAgreements(agreementsList);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_BPKENNNotExist_Test() throws Exception {
		// BPKENN Not Exist - BPKENN does not exist, agreements is empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(
				context.getEnvironment().getProperty(KEY_STATUS_FA_BPKENN_NOT_EXIST, VALUE_STATUS_FA_BPKENN_NOT_EXIST));

		agreements = new Agreements();
		agreementsList.add(agreements);

		changeConfigRequest.setBpkenn("BPKENN");
		changeConfigRequest.setAgreements(agreementsList);

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(null);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_PersonConfigExist_Test() throws Exception {
		// OK- Successful - Person Configuration exist, agreements is empty

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		changeConfigRequest.setBpkenn("BPKENN");
		changeConfigRequest.setAgreements(null);

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_PersonConfigNotExistAndAgreementConfigExist_Test() throws Exception {
		// OK- No changes required - Person Configuration does not exist,
		// agreements has value and exist in Benach_Konfig_Vereinbarung

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID())).thenReturn(null);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(this.agreement);
		when(this.notifConfigAgreementDAO.findByAgreementUID(agreement.getAgreementUID()))
				.thenReturn(this.notificationConfigAgreement);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_PersonConfigExistAndAgreementIDNotExist_Test() throws Exception {
		// OK- Success - Person Configuration does not exist,
		// agreements has value but AgreementID does not exist

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(null);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_PersonConfigExistAndAgreementConfigNotExist_Test() throws Exception {
		// OK- Success - Person Configuration exist,
		// agreements has value but does not exist in Benach_Konfig_Vereinbarung

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(this.agreement);
		when(this.notifConfigAgreementDAO.findByAgreementUID(agreement.getAgreementUID())).thenReturn(null);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_Exception_Test() throws Exception {
		// Exception Test

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse.setStatus(context.getEnvironment().getProperty(KEY_STATUS_FA_FAILED_CHANGE_CONFIG,
				VALUE_STATUS_FA_FAILED_CHANGE_CONFIG));

		// Throws exception
		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenThrow(Exception.class);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());
	}

	@Test
	public void requestForChangeConfiguration_ChildActiveFalse_AgreementConfigExist_Test() throws Exception {
		// OK- Success
		// agreements has value with active flag value false, with agreement config records

		agreements = new Agreements();
		agreements.setActive(false);
		agreements.setSparte(100);
		agreements.setVereinbarungskennung("DE72938910231");

		agreementsList = new ArrayList<Agreements>();
		agreementsList.add(agreements);

		changeConfigRequest = new ChangeConfigurationRequest();
		changeConfigRequest.setBpkenn("BPKENN");
		changeConfigRequest.setActive(true);
		changeConfigRequest.setAgreements(agreementsList);

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(this.agreement);
		when(this.notifConfigAgreementDAO.findByAgreementUID(agreement.getAgreementUID()))
				.thenReturn(this.notificationConfigAgreement);

		// delete agreement related records
		when(this.notificationTextDAO.findByNotificationTextUID(this.notificationConfigAgreement.getNotificationTextUID()))
							.thenReturn(null);
		when(this.notifConfigAgreementDAO.findByAgreementUID(this.agreement.getAgreementUID())).thenReturn(null);
		when(this.agreementDAO.findByAgreementUID(this.agreement.getAgreementUID())).thenReturn(null);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());

	}
	
	@Test
	public void requestForChangeConfiguration_ChildActiveFalse_AgreementConfigNotExist_Test() throws Exception {
		// OK- Success
		// agreements has value with active flag value false, without notif agreement config records

		agreements = new Agreements();
		agreements.setActive(false);
		agreements.setSparte(100);
		agreements.setVereinbarungskennung("DE72938910231");

		agreementsList = new ArrayList<Agreements>();
		agreementsList.add(agreements);

		changeConfigRequest = new ChangeConfigurationRequest();
		changeConfigRequest.setBpkenn("BPKENN");
		changeConfigRequest.setActive(true);
		changeConfigRequest.setAgreements(agreementsList);

		expectedResponse = new ChangeConfigurationResponse();
		expectedResponse.setBpkenn("BPKENN");
		expectedResponse
				.setStatus(context.getEnvironment().getProperty(KEY_STATUS_OK_SUCCESS, VALUE_STATUS_OK_SUCCESS));

		when(this.personDAO.findByBpkennIgnoreCase(changeConfigRequest.getBpkenn())).thenReturn(this.person);
		when(this.notificationConfigPersonDAO.findByPersonUID(this.person.getPersonUID()))
				.thenReturn(this.notificationConfigPerson);
		when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(this.person.getPersonUID(),
				agreements.getVereinbarungskennung(), agreements.getSparte())).thenReturn(this.agreement);
		when(this.notifConfigAgreementDAO.findByAgreementUID(agreement.getAgreementUID()))
				.thenReturn(null);

		// delete agreement related records
		when(this.agreementDAO.findByAgreementUID(this.agreement.getAgreementUID())).thenReturn(null);

		ChangeConfigurationResponse actualResponse = this.changeConfigurationServiceImpl
				.requestForChangeConfiguration(changeConfigRequest);

		assertEquals(expectedResponse.toString(), actualResponse.toString());

	}

}
