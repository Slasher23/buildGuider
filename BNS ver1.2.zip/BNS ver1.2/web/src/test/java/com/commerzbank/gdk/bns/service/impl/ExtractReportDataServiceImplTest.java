package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit test class for ExtractReportDataServiceImplTest
 * 
 * @since 09/01/2018
 * @author ZE2BUEN
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 09/01/2018      1.00      ZE2BUEN    Initial Version
 * 15/01/2018      1.01      ZE2RUBI    U[date Implement parameter
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
public class ExtractReportDataServiceImplTest {
    
    @Mock
    private PersonDAO personDAO;
    
    @Mock
    private AgreementDAO agreementDAO;
    
    @Mock
    private NotificationConfigAgreementDAO notifConfigAgreementDAO;
    
    @Mock
    private NotificationConfigPersonDAO notifConfigPersonDAO;
    
    @Mock
    private NotificationTextDAO notifTextDAO;
    
    @InjectMocks
    private ExtractReportDataServiceImpl extractReportDataServiceImpl;
    
    private Tokenizer token;
    
    private NotificationConfigAgreement notifConfigAgreement1;
    private NotificationConfigAgreement notifConfigAgreement2;
    private NotificationConfigAgreement notifConfigAgreement3;
    private NotificationConfigAgreement notifConfigAgreement4;
    private NotificationConfigAgreement notifConfigAgreement5;
    private NotificationConfigAgreement notifConfigAgreement6;
    private NotificationConfigAgreement notifConfigAgreement7;
    private NotificationConfigAgreement notifConfigAgreement8;
    
    private List<NotificationConfigAgreement> notifConfigAgreementList1;
    private List<NotificationConfigAgreement> notifConfigAgreementList2;
    private List<NotificationConfigAgreement> notifConfigAgreementList3;
    private List<NotificationConfigAgreement> notifConfigAgreementList4;
    private List<NotificationConfigAgreement> notifConfigAgreementList5;

    private Agreement agreement1;
    private Agreement agreement2;
    private Agreement agreement3;
    private Agreement agreement4;
    private Agreement agreement5;
    private Agreement agreement6;
    private Agreement agreement7;
    private Agreement agreement8;
    
    private List<Long> agreementUIDList1;
    private List<Long> agreementUIDList2;
    private List<Long> agreementUIDList3;
    private List<Long> agreementUIDList4;
    private List<Long> agreementUIDList5;
    
    private List<Agreement> agreementList1;
    private List<Agreement> agreementList2;
    private List<Agreement> agreementList3;
    private List<Agreement> agreementList4;
    private List<Agreement> agreementList5;
    
    private NotificationConfigPerson notifConfigPerson1;
    private NotificationConfigPerson notifConfigPerson2;
    private NotificationConfigPerson notifConfigPerson3;
    private NotificationConfigPerson notifConfigPerson4;
    private NotificationConfigPerson notifConfigPerson5;
    
    private List<NotificationConfigPerson> notifConfigPersonList1;
    private List<NotificationConfigPerson> notifConfigPersonList2;
    private List<NotificationConfigPerson> notifConfigPersonList3;
    private List<NotificationConfigPerson> notifConfigPersonList4;
    private List<NotificationConfigPerson> notifConfigPersonList5;
    
    private Person person1;
    private Person person2;
    private Person person3;
    private Person person4;
    private Person person5;
    
    private NotificationText notificationText;
    
    private List<NotificationText> notificationTextList;
    
    private ArrayList<Person> personList;
    
    private Report report;
    
    private Date reportDate;
    
    private static final String RPT001 = "RPT001";
    private static final String RPT005 = "RPT005";
    private static final String RPT003 = "RPT003";
    
    @Before
    public void init() throws ParseException {
        
        MockitoAnnotations.initMocks(this);
        
        token = new Tokenizer();
        token.setUserId("123");
       
        person1 = new Person();
        person1.setBPKENN("BPKENNTEST1");
        person1.setGivenName("Given Name 1");
        person1.setLastName("Last Name 1");
        person1.setPersonUID(1L);
        person1.setSalutation("01");
        person1.setTitle("01");
        
        person2 = new Person();
        person2.setBPKENN("BPKENNTEST2");
        person2.setGivenName("Given Name 2");
        person2.setLastName("Last Name 2");
        person2.setPersonUID(2L);
        person2.setSalutation("01");
        person2.setTitle("01");
        
        person3 = new Person();
        person3.setBPKENN("BPKENNTEST3");
        person3.setGivenName("Given Name 3");
        person3.setLastName("Last Name 3");
        person3.setPersonUID(3L);
        person3.setSalutation("01");
        person3.setTitle("01");
       
        person4 = new Person();
        person4.setBPKENN("BPKENNTEST4");
        person4.setGivenName("Given Name 4");
        person4.setLastName("Last Name 4");
        person4.setPersonUID(4L);
        person4.setSalutation("01");
        person4.setTitle("01");
        
        person5 = new Person();
        person5.setBPKENN("BPKENNTEST5");
        person5.setGivenName("Given Name 5");
        person5.setLastName("Last Name 5");
        person5.setPersonUID(5L);
        person5.setSalutation("01");
        person5.setTitle("01");
        
        personList = new ArrayList<>();
        personList.add(person1);
        personList.add(person2);
        personList.add(person3);
        personList.add(person4);
        personList.add(person5);
        
        agreement1 = new Agreement();
        agreement1.setAgreementUID(1L);
        agreement1.setPersonUID(1L);
        agreement1.setAgreementID("Agr ID 1");
        agreement1.setAgreementType("Agr Type 1");
        agreement1.setBranch(1);
        agreement1.setType("Type 1");
        
        agreement2 = new Agreement();
        agreement2.setAgreementUID(2L);
        agreement2.setPersonUID(2L);
        agreement2.setAgreementID("Agr ID 2");
        agreement2.setAgreementType("Agr Type 2");
        agreement2.setBranch(2);
        agreement2.setType("Type 2");
        
        agreement3 = new Agreement();
        agreement3.setAgreementUID(3L);
        agreement3.setPersonUID(3L);
        agreement3.setAgreementID("Agr ID 3");
        agreement3.setAgreementType("Agr Type 3");
        agreement3.setBranch(3);
        agreement3.setType("Type 3");
        
        agreement4 = new Agreement();
        agreement4.setAgreementUID(4L);
        agreement4.setPersonUID(3L);
        agreement4.setAgreementID("Agr ID 4");
        agreement4.setAgreementType("Agr Type 4");
        agreement4.setBranch(4);
        agreement4.setType("Type 4");
        
        agreement5 = new Agreement();
        agreement5.setAgreementUID(5L);
        agreement5.setPersonUID(4L);
        agreement5.setAgreementID("Agr ID 5");
        agreement5.setAgreementType("Agr Type 5");
        agreement5.setBranch(5);
        agreement5.setType("Type 5");
        
        agreement6 = new Agreement();
        agreement6.setAgreementUID(6L);
        agreement6.setPersonUID(4L);
        agreement6.setAgreementID("Agr ID 6");
        agreement6.setAgreementType("Agr Type 6");
        agreement6.setBranch(6);
        agreement6.setType("Type 6");
        
        agreement7 = new Agreement();
        agreement7.setAgreementUID(7L);
        agreement7.setPersonUID(5L);
        agreement7.setAgreementID("Agr ID 7");
        agreement7.setAgreementType("Agr Type 7");
        agreement7.setBranch(7);
        agreement7.setType("Type 7");

        agreement8 = new Agreement();
        agreement8.setAgreementUID(8L);
        agreement8.setPersonUID(5L);
        agreement8.setAgreementID("Agr ID 8");
        agreement8.setAgreementType("Agr Type 8");
        agreement8.setBranch(8);
        agreement8.setType("Type 8");
        
        agreementUIDList1 = new ArrayList<>();
        agreementUIDList1.add(1L);
        
        agreementUIDList2 = new ArrayList<>();
        agreementUIDList2.add(2L);
        
        agreementUIDList3 = new ArrayList<>();
        agreementUIDList3.add(3L);
        agreementUIDList3.add(4L);
        
        agreementUIDList4 = new ArrayList<>();
        agreementUIDList4.add(5L);
        agreementUIDList4.add(6L);
        
        agreementUIDList5 = new ArrayList<>();
        agreementUIDList5.add(7L);
        agreementUIDList5.add(8L);
        
        agreementList1 = new ArrayList<>();
        agreementList1.add(agreement1);
        
        agreementList2 = new ArrayList<>();
        agreementList2.add(agreement2);
        
        agreementList3 = new ArrayList<>();
        agreementList3.add(agreement3);
        agreementList3.add(agreement4);
        
        agreementList4 = new ArrayList<>();
        agreementList4.add(agreement5);
        agreementList4.add(agreement6);
        
        agreementList5 = new ArrayList<>();
        agreementList5.add(agreement7);
        agreementList5.add(agreement8);
        
        notifConfigAgreement1 = new NotificationConfigAgreement();
        notifConfigAgreement1.setActive(true);
        notifConfigAgreement1.setAgreementUID(1L);
        notifConfigAgreement1.setEmailUID(1L);
        notifConfigAgreement1.setInformationChannelUID(1L);
        notifConfigAgreement1.setNotificationTextUID(1L);
        
        notifConfigAgreement2 = new NotificationConfigAgreement();
        notifConfigAgreement2.setActive(false);
        notifConfigAgreement2.setAgreementUID(2L);
        notifConfigAgreement2.setEmailUID(2L);
        notifConfigAgreement2.setInformationChannelUID(1L);
        notifConfigAgreement2.setNotificationTextUID(2L);
        
        notifConfigAgreement3 = new NotificationConfigAgreement();
        notifConfigAgreement3.setActive(true);
        notifConfigAgreement3.setAgreementUID(3L);
        notifConfigAgreement3.setEmailUID(3L);
        notifConfigAgreement3.setInformationChannelUID(1L);
        notifConfigAgreement3.setNotificationTextUID(3L);
        
        notifConfigAgreement4 = new NotificationConfigAgreement();
        notifConfigAgreement4.setActive(false);
        notifConfigAgreement4.setAgreementUID(4L);
        notifConfigAgreement4.setEmailUID(4L);
        notifConfigAgreement4.setInformationChannelUID(1L);
        notifConfigAgreement4.setNotificationTextUID(4L);
        
        notifConfigAgreement5 = new NotificationConfigAgreement();
        notifConfigAgreement5.setActive(true);
        notifConfigAgreement5.setAgreementUID(5L);
        notifConfigAgreement5.setEmailUID(5L);
        notifConfigAgreement5.setInformationChannelUID(1L);
        notifConfigAgreement5.setNotificationTextUID(5L);
        
        notifConfigAgreement6 = new NotificationConfigAgreement();
        notifConfigAgreement6.setActive(true);
        notifConfigAgreement6.setAgreementUID(6L);
        notifConfigAgreement6.setEmailUID(6L);
        notifConfigAgreement6.setInformationChannelUID(1L);
        notifConfigAgreement6.setNotificationTextUID(6L);
        
        notifConfigAgreement7 = new NotificationConfigAgreement();
        notifConfigAgreement7.setActive(false);
        notifConfigAgreement7.setAgreementUID(7L);
        notifConfigAgreement7.setEmailUID(7L);
        notifConfigAgreement7.setInformationChannelUID(1L);
        notifConfigAgreement7.setNotificationTextUID(7L);
        
        notifConfigAgreement8 = new NotificationConfigAgreement();
        notifConfigAgreement8.setActive(false);
        notifConfigAgreement8.setAgreementUID(8L);
        notifConfigAgreement8.setEmailUID(8L);
        notifConfigAgreement8.setInformationChannelUID(1L);
        notifConfigAgreement8.setNotificationTextUID(8L);
        
        notifConfigAgreementList1 = new ArrayList<>();
        notifConfigAgreementList1.add(notifConfigAgreement1);
        
        notifConfigAgreementList3 = new ArrayList<>();
        notifConfigAgreementList3.add(notifConfigAgreement3);
        
        notifConfigAgreementList4 = new ArrayList<>();
        notifConfigAgreementList4.add(notifConfigAgreement5);
        notifConfigAgreementList4.add(notifConfigAgreement6);    
                
        notifConfigPerson1 = new NotificationConfigPerson();
        notifConfigPerson1.setActive(true);
        notifConfigPerson1.setEmailUID(1L);
        notifConfigPerson1.setInformationChannelUID(1L);
        notifConfigPerson1.setNotifConfigPersonUID(1L);
        notifConfigPerson1.setNotificationTextUID(9L);
        notifConfigPerson1.setPersonUID(1L);
        
        notifConfigPerson2 = new NotificationConfigPerson();
        notifConfigPerson2.setActive(true);
        notifConfigPerson2.setEmailUID(2L);
        notifConfigPerson2.setInformationChannelUID(1L);
        notifConfigPerson2.setNotifConfigPersonUID(2L);
        notifConfigPerson2.setNotificationTextUID(10L);
        notifConfigPerson2.setPersonUID(2L);
        
        notifConfigPerson3 = new NotificationConfigPerson();
        notifConfigPerson3.setActive(false);
        notifConfigPerson3.setEmailUID(3L);
        notifConfigPerson3.setInformationChannelUID(1L);
        notifConfigPerson3.setNotifConfigPersonUID(3L);
        notifConfigPerson3.setNotificationTextUID(11L);
        notifConfigPerson3.setPersonUID(3L);
        
        notifConfigPerson4 = new NotificationConfigPerson();
        notifConfigPerson4.setActive(false);
        notifConfigPerson4.setEmailUID(4L);
        notifConfigPerson4.setInformationChannelUID(1L);
        notifConfigPerson4.setNotifConfigPersonUID(4L);
        notifConfigPerson4.setNotificationTextUID(12L);
        notifConfigPerson4.setPersonUID(4L);
        
        notifConfigPerson5 = new NotificationConfigPerson();
        notifConfigPerson5.setActive(false);
        notifConfigPerson5.setEmailUID(5L);
        notifConfigPerson5.setInformationChannelUID(1L);
        notifConfigPerson5.setNotifConfigPersonUID(5L);
        notifConfigPerson5.setNotificationTextUID(13L);
        notifConfigPerson5.setPersonUID(5L);
        
        notifConfigPersonList1 = new ArrayList<>();
        notifConfigPersonList1.add(notifConfigPerson1);
        
        notifConfigPersonList2 = new ArrayList<>();
        notifConfigPersonList2.add(notifConfigPerson2);
        
        notificationText = new NotificationText();
        notificationText.setNotificationTextUID(1L);
        notificationText.setNotificationTextType("FREE");
        
        notificationTextList = new ArrayList<NotificationText>();
        notificationTextList.add(notificationText);
             
        reportDate = new Date();

    }
    
    @Test
    public void extractActiveNotificationReport_Successful() throws Exception {
        
        report = new Report();
        report.setCount(4.0);
        report.setDate(reportDate);
        report.setPercentage(null);
        report.setTime(null);
        report.setReportUID(null);
        report.setReportType(RPT001);
        
        when(Lists.newArrayList(this.personDAO.findAll())).thenReturn(personList);
        
        when(this.agreementDAO.findByPersonUID(1L)).thenReturn(agreementList1);
        
        when(this.agreementDAO.findByPersonUID(2L)).thenReturn(agreementList2);
        
        when(this.agreementDAO.findByPersonUID(3L)).thenReturn(agreementList3);
        
        when(this.agreementDAO.findByPersonUID(4L)).thenReturn(agreementList4);
        
        when(this.agreementDAO.findByPersonUID(5L)).thenReturn(agreementList5);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true,
                agreementUIDList1)).thenReturn(notifConfigAgreementList1);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true,
                agreementUIDList2)).thenReturn(notifConfigAgreementList2);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true,
                agreementUIDList3)).thenReturn(notifConfigAgreementList3);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true,
                agreementUIDList4)).thenReturn(notifConfigAgreementList4);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(true,
                agreementUIDList5)).thenReturn(notifConfigAgreementList5);
        
        when(this.notifConfigPersonDAO.findByPersonUIDAndActive(1L, true)).thenReturn(notifConfigPersonList1);
        
        when(this.notifConfigPersonDAO.findByPersonUIDAndActive(2L, true)).thenReturn(notifConfigPersonList2);
        
        when(this.notifConfigPersonDAO.findByPersonUIDAndActive(3L, true)).thenReturn(notifConfigPersonList3);
        
        when(this.notifConfigPersonDAO.findByPersonUIDAndActive(4L, true)).thenReturn(notifConfigPersonList4);
        
        when(this.notifConfigPersonDAO.findByPersonUIDAndActive(5L, true)).thenReturn(notifConfigPersonList5);
       
        Date date = new Date();
        
        date = DateUtils.addDays(date, -1);
        
        assertEquals(report.toString(),
                this.extractReportDataServiceImpl.extractActiveNotificationReport(token,date).toString());
        
    }
    
    @Test
    public void extractOneIndividualConfiguredNotificationReport_Successful() throws Exception {
        
        report = new Report();
        report.setCount(5.0);
        report.setDate(reportDate);
        report.setPercentage(100.0);
        report.setTime(null);
        report.setReportUID(null);
        report.setReportType(RPT005);
        
        when(Lists.newArrayList(this.personDAO.findAll())).thenReturn(personList);
        
        when(this.agreementDAO.findByPersonUID(anyLong())).thenReturn(agreementList1);
        
        when(this.notifConfigAgreementDAO.findByActiveAndAgreementUIDIn(anyBoolean(), anyListOf(Long.class))).thenReturn(notifConfigAgreementList1);

       when(this.notifConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notifConfigPerson1);
       
       when(this.notifTextDAO.findByNotificationTextUID(anyLong())).thenReturn(notificationText);
       
       Date date = new Date();
       
       date = DateUtils.addDays(date, -1);
       
        assertEquals(report.toString(),
                this.extractReportDataServiceImpl.extractOneIndividualConfiguredNotificationReport(token,date).toString());
        
    }
    
    @Test
    public void extractAllUsersWithAllActiveProducts_Successful() throws Exception {
        
        report = new Report();
        report.setCount(0.0);
        report.setDate(reportDate);
        report.setPercentage(0.0);
        report.setTime(null);
        report.setReportUID(null);
        report.setReportType(RPT003);
        
        when(Lists.newArrayList(this.personDAO.findAll())).thenReturn(personList);
        
        when(this.agreementDAO.findByPersonUID(anyLong())).thenReturn(agreementList1);
        
        when(this.notifConfigAgreementDAO.findByAgreementUIDIn(anyListOf(Long.class))).thenReturn(notifConfigAgreementList1);
        
        when(this.notifTextDAO.findByNotificationTextUIDIn(anyLong())).thenReturn(notificationTextList);

       when(this.notifConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notifConfigPerson1);
       
       Date date = new Date();
       
       date = DateUtils.addDays(date, -1);
       
        assertEquals(report.toString(),
                this.extractReportDataServiceImpl.extractAllUsersWithAllActiveProducts(token,date).toString());
        
    }
    
}
