package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.controller.zsl.RequestForRequiredNotificationController;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.service.RequestForRequiredNotificationService;

/**
 * JUnit test class for Request For Required Notification Controller
 * 
 * @author 	ZE2BAUL
 * @since 	09/11/2017
 * @version 1.02
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 09/11/2017	     1.01       ZE2BAUL    Initial Version
 * 07/12/2017        1.02       ZE2CRUH    Updated RequiredNotification to include UUID
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@EnableWebMvc
public class RequestForRequiredNotificationControllerTest {

	MockMvc mockMvc;
	
	@Mock
	private RequestForRequiredNotificationService requestForRequiredNotificationService;
	
	@InjectMocks
	private RequestForRequiredNotificationController requestForRequiredNotificationController;
	
	private RequiredNotificationRequest requiredNotifRequest;
	
	List<RequiredNotificationRequest> requiredBatchNotificationList = Lists.newArrayList();
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(requestForRequiredNotificationController).build();
		
		requiredNotifRequest = new RequiredNotificationRequest();
		requiredNotifRequest.setBpkenn("BPKENNTEST");
		requiredNotifRequest.setNotificationpath("email@email.com");
		requiredNotifRequest.setNotificationsubject("subject test");
		requiredNotifRequest.setNotificationtext("notification text test");
		requiredNotifRequest.setNotificationtype("email");
		requiredNotifRequest.setUuid("test");
		requiredBatchNotificationList.add(requiredNotifRequest);
	}
	
	@Test
	public void requestForRequiredNotification_JSON_Test() throws Exception {
		
		mockMvc.perform(post("/api/zsl/requestForRequiredNotification").contentType(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(requiredNotifRequest)))
				.andExpect(status().isOk());
	}
	
	@Test
	public void requestForRequiredNotification_RequestNull_Test() throws Exception {
		requiredNotifRequest = null;
		mockMvc.perform(post("/api/zsl/requestForRequiredNotification").contentType(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(requiredNotifRequest)))
				.andExpect(status().isBadRequest());
	}
	
	@Test
	public void requestForRequiredNotification_XML_Test() throws Exception {
		
		mockMvc.perform(post("/api/zsl/requestForRequiredNotification").contentType(MediaType.APPLICATION_XML)
				.content(Parser.jaxbObjectToXML(requiredNotifRequest, RequiredNotificationRequest.class)))
				.andExpect(status().isOk());
	}
	
	@Test
	public void requestForRequiredBatchNotification_JSON_Test() throws Exception {
		
	    RequestForRequiredBatchNotification batchRequest = new RequestForRequiredBatchNotification();
	    batchRequest.setRequiredNotificationRequest(requiredBatchNotificationList);
		mockMvc.perform(post("/api/zsl/requestForRequiredBatchNotification").contentType(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(batchRequest)))
				.andExpect(status().isOk());
	}
	
	   @Test
	    public void requestForRequiredBatchNotification_XML_Test() throws Exception {
	        
	        RequestForRequiredBatchNotification batchRequest = new RequestForRequiredBatchNotification();
	        batchRequest.setRequiredNotificationRequest(requiredBatchNotificationList);
	        mockMvc.perform(post("/api/zsl/requestForRequiredBatchNotification").contentType(MediaType.APPLICATION_XML)
	                .content(Parser.xmlConverter(batchRequest)))
	                .andExpect(status().isOk());
	    }
	
}
