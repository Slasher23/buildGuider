package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;

/**
 * JUnit test class for Push Configuration Service Impl
 * 
 * @since 27/10/2017
 * @author ZE2BUEN
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 27/10/2017      1.00      ZE2BUEN    Initial Version
 * 23/11/2017      1.01      ZE2SARO    Remove Participant
 * 14/12/2017      1.02      ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 * 
 */
@RunWith(MockitoJUnitRunner.class)
public class PushConfigurationServiceImplTest {

    @Mock
    private PersonDAO personDAO;

    @Mock
    private PushConfigurationDAO pushConfigurationDAO;
    
    @Mock
    private Environment environment;

    @InjectMocks
    private PushConfigurationServiceImpl pushConfigurationServiceImpl;

    private PushConfigurationRequest request;
    private Person person;
    private PushConfiguration pushConfiguration;
    private PushConfigurationResponse response;
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_FAILED_PUSH_CONFIG = "ZSL_STATUS_FA_FAILED_PUSH_CONFIG";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        request = new PushConfigurationRequest();
        request.setBpkenn("BPKENNTEST");
        request.setAppId("APP ID TEST");
        request.setAppName("APP NAME TEST");
        request.setAppVersion("APP VERSION TEST");
        request.setDeviceId("DEVICE ID TEST");
        request.setActivate(true);

        person = new Person();
        person.setBPKENN("BPKENNTEST");
        person.setGivenName("GIVEN NAME TEST");
        person.setLastName("LAST NAME TEST");
        person.setPersonUID(1L);
        person.setSalutation("01");
        person.setTitle("01");

        pushConfiguration = new PushConfiguration();
        pushConfiguration.setPersonUID(1L);
        pushConfiguration.setPushConfigurationUID(1L);
        pushConfiguration.setAppID("APP ID TEST");
        pushConfiguration.setAppName("APP NAME TEST");
        pushConfiguration.setAppVersion("APP VERSION TEST");
        pushConfiguration.setDeviceID("DEVICE TEST");
        pushConfiguration.setActive(true);

        response = new PushConfigurationResponse();
        response.setStatus("OK- Successful");

    }

    @Test
    public void requestForPushConfiguration_Successful_Save_Test() throws Exception {

        when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
        when(this.pushConfigurationDAO.save(any(PushConfiguration.class))).thenReturn(pushConfiguration);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @Test
    public void requestForPushConfiguration_Successful_Update_Test() throws Exception {

        when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
        when(this.pushConfigurationDAO.getPushConfiguration(any(Long.class), any(String.class)))
                .thenReturn(pushConfiguration);

        PushConfiguration updatePushConfiguration = new PushConfiguration();
        updatePushConfiguration.setPersonUID(1L);
        updatePushConfiguration.setPushConfigurationUID(1L);
        updatePushConfiguration.setAppID("APP ID TEST");
        updatePushConfiguration.setAppName("APP NAME TEST");
        updatePushConfiguration.setAppVersion("APP VERSION TEST");
        updatePushConfiguration.setDeviceID("DEVICE TEST");
        updatePushConfiguration.setActive(false);

        when(this.pushConfigurationDAO.save(any(PushConfiguration.class))).thenReturn(updatePushConfiguration);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @Test
    public void requestForPushConfiguration_Fail_Null_Invalid_Request() throws Exception {

        response.setStatus("FA- Invalid Request");

        request.setBpkenn(null);
        request.setAppId(null);
        request.setAppName(null);
        request.setAppVersion(null);
        request.setDeviceId(null);
        request.setActivate(null);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @Test
    public void requestForPushConfiguration_Fail_Blank_Invalid_Request() throws Exception {

        response.setStatus("FA- Invalid Request");

        request.setBpkenn("");
        request.setAppId("");
        request.setAppName("");
        request.setAppVersion("");
        request.setDeviceId("");
        request.setActivate(true);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @Test
    public void requestForPushConfiguration_Fail_BPKENN_doesnt_exists_Test() throws Exception {

        response.setStatus("FA- BPKENN does not exists in BNS");

        when(this.personDAO.getPerson(any(String.class))).thenReturn(null);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @Test
    public void requestForPushConfiguration_Fail_Save_Test() throws Exception {

        response.setStatus("FA- Push Configuration not processed");

        when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
        when(this.pushConfigurationDAO.save(any(PushConfiguration.class))).thenReturn(null);
        
        when(this.environment.getProperty(STATUS_FA_FAILED_PUSH_CONFIG)).thenReturn("FA- Push Configuration not processed");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void requestForPushConfiguration_Fail_Save_Exception_Test() throws Exception {

        response.setStatus("FA- Push Configuration not processed");

        when(this.personDAO.getPerson(any(String.class))).thenReturn(person);
        when(this.pushConfigurationDAO.save(any(PushConfiguration.class))).thenThrow(Exception.class);
        
        when(this.environment.getProperty(STATUS_FA_FAILED_PUSH_CONFIG)).thenReturn("FA- Push Configuration not processed");
        
        assertEquals(response.toString(),
                this.pushConfigurationServiceImpl.requestForPushConfiguration(request).toString());

    }

}
