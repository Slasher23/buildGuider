package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForBatchDeactivatePerson;
import com.commerzbank.gdk.bns.model.RequestForDeactivatePersonResponse;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForDeactivatePersonService;

/**
 * 
 * JUnit Test Class for RequestForDeactivatePersonServiceImpl.
 * 
 * @since 28/11/2017
 * @author ZE2GOME
 * @version 1.04
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 28/11/2017      1.00      ZE2GOME    Initial Version
 * 29/11/2017      1.01      ZE2GOME    Add test for method requestForBatchDeactivatePerson
 * 04/12/2017      1.02      ZE2GOME    Change response of batch to RequestForDeactivatePersonResponse
 * 12/12/2017      1.03      ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 12/12/2017      1.04      ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForDeactivatePersonServiceImplTest {

    @Mock
    private PersonDAO personDAO;

    @Mock
    private Environment environment;

    @InjectMocks
    private RequestForDeactivatePersonServiceImpl deactivatePersonServiceImpl;
    
    @Mock
    private RequestForDeactivatePersonService requestForDeactivatePersonService;

    private Person person;
    private ZslUpdateResponse response;
    private ZslUpdateResponse zslUpdateResponse;
    private Parameter param;
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    
    private RequestForBatchDeactivatePerson reqBatch = new RequestForBatchDeactivatePerson();
    
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        person = new Person();

        person.setBPKENN("test");
        person.setGivenName("test");
        person.setLastName("test");
        person.setPersonUID(1L);
        person.setSalutation("01");
        person.setTitle("01");

    }

    @Test
    public void requestForDeativatePerson_Test() throws Exception {

        param = new Parameter();
        param.setBpkenn("test");

        response = new ZslUpdateResponse();
        response.setBpkenn("test");
        response.setStatus("OK- Successful");

        String succes_mess = "OK- Successful";
        when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(this.person);
        when(this.environment.getProperty(STATUS_OK)).thenReturn(succes_mess);

        ZslUpdateResponse responseExpected = this.deactivatePersonServiceImpl.requestForDeactivatePerson(param);

        assertEquals(responseExpected.toString(), response.toString());
    }

    @Test
    public void requestForDeativatePerson_Null_Test() throws Exception {

        param = new Parameter();
        param.setBpkenn("test");

        response = new ZslUpdateResponse();
        response.setBpkenn("test");
        response.setStatus("FA- BPKENN does not exists in BNS");

        Person personEmpty = null;
        when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(personEmpty);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");

        ZslUpdateResponse responseExpected = this.deactivatePersonServiceImpl.requestForDeactivatePerson(param);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForDeativatePerson_BpkennNull_Test() throws Exception {

        param = new Parameter();

        response = new ZslUpdateResponse();
        response.setBpkenn(null);
        response.setStatus("FA- Invalid Request");

        when(this.personDAO.findByBpkennIgnoreCase(null)).thenReturn(this.person);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        ZslUpdateResponse responseExpected = this.deactivatePersonServiceImpl.requestForDeactivatePerson(param);

        assertEquals(responseExpected.toString(), response.toString());

    }

    @Test
    public void requestForDeativatePerson_BpkennEmpty_Test() throws Exception {

        param = new Parameter();
        param.setBpkenn("");

        response = new ZslUpdateResponse();
        response.setBpkenn("");
        response.setStatus("FA- Invalid Request");

        when(this.personDAO.findByBpkennIgnoreCase("")).thenReturn(this.person);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        ZslUpdateResponse responseExpected = this.deactivatePersonServiceImpl.requestForDeactivatePerson(param);

        assertEquals(responseExpected.toString(), response.toString());

    }
    
    @Test
    public void RequestForBatchDeactivatePerson_Test() throws Exception {

        Parameter paramNew = new Parameter();
        paramNew.setBpkenn("BPKENNTEST");
        
        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST");
        zslUpdateResponse.setStatus("OK- Successful");
        
        String success_mess = "OK- Successful";
        when(this.environment.getProperty(STATUS_OK)).thenReturn(success_mess);
        
        List<Parameter> listParam = new ArrayList<Parameter>();
        listParam.add(paramNew);
        reqBatch.setDeactivatePersonRequest(listParam);
        
        when(this.personDAO.findByBpkennIgnoreCase("BPKENNTEST")).thenReturn(this.person);
        
        List<ZslUpdateResponse> zslUpdateResponseNoError = new ArrayList<ZslUpdateResponse>();
        zslUpdateResponseNoError.add(zslUpdateResponse);
        
        when(this.requestForDeactivatePersonService.requestForDeactivatePerson(paramNew)).thenReturn(zslUpdateResponse);
        
        RequestForDeactivatePersonResponse response = this.deactivatePersonServiceImpl.requestFordeactivatePersonList(reqBatch);
        
        assertEquals(zslUpdateResponseNoError.toString(), response.getDeactivatePersonResponse().toString());
    }
    
    @Test
    public void RequestForBatchDeactivatePerson_Error_Test() throws Exception {

        this.param = new Parameter();
        this.param.setBpkenn("BPKENNTEST");
        
        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST");
        zslUpdateResponse.setStatus("FA- BPKENN does not exists in BNS");
        
        List<Parameter> listParam = new ArrayList<Parameter>();
        listParam.add(this.param);
        reqBatch.setDeactivatePersonRequest(listParam);
        
        List<ZslUpdateResponse> zslUpdateResponseWithError = new ArrayList<ZslUpdateResponse>();
        zslUpdateResponseWithError.add(zslUpdateResponse);
        
        when(this.requestForDeactivatePersonService.requestForDeactivatePerson(this.param)).thenReturn(zslUpdateResponse);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
        
        RequestForDeactivatePersonResponse response = this.deactivatePersonServiceImpl.requestFordeactivatePersonList(reqBatch);
        
        assertEquals(zslUpdateResponseWithError.toString(), 
                response.getDeactivatePersonResponseWithErrors().toString());
    }

}
