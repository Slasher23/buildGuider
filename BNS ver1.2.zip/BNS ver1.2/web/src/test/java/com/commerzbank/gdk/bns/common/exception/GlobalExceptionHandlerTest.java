package com.commerzbank.gdk.bns.common.exception;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.SQLException;

import javax.validation.ConstraintViolationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.common.exception.GlobalExceptionHandler;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseMessage;
import com.fasterxml.jackson.databind.ObjectMapper;

/** 
* JUnit class for GlobalExceptionHandler 
* 
* @since 09/08/2017
* @author ZE2CRUH
* @version 1.01
*
* Modified Date   Version   Author     Description
* 09/08/2017      1.00      ZE2CRUH    Initial Version
* 21/11/2017      1.01      ZE2MACL    Updated Http Statuses
* 
*/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/resources/configuration.xml")
public class GlobalExceptionHandlerTest {

	@Autowired
	private GlobalResponseWrapper message;

	@InjectMocks
	private GlobalExceptionHandler globalExceptionHandler;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	Customer customer = new Customer();
	NotificationText notifText = new NotificationText();
	Email email = new Email();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		Mockito.reset(globalResponseWrapper);

		notifText.setEventID(1L);
		notifText.setEventType("ASZ");
		notifText.setNotificationTextType("A B C");
		notifText.setText("QWER");
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnDataAccessException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: DataAccessException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnDataAccessException(new DataAccessException("Caused by: DataAccessException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnIllegalArgumentsException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: IllegalArgumentException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnIllegalArgumentsException(new IllegalArgumentException("Caused by: IllegalArgumentException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnNullPointerException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: NullPointerException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler
				.returnNullPointerException(new NullPointerException("Caused by: NullPointerException") {
				}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnSQLException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.NOT_FOUND.toString());
		responseMessage.setMessage("Caused by: SQLException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.returnSQLException(new SQLException("Caused by: SQLException") {
		}));
	}

	@SuppressWarnings("serial")
	@Test
	public void testReturnConstraintViolationException() throws Exception {
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> responseMessage = message.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		responseMessage.setMessage("Caused by: ConstraintViolationException");
		ResponseEntity<Response<String>> rm = new ResponseEntity<Response<String>>(responseMessage, headers,
		        HttpStatus.INTERNAL_SERVER_ERROR);

		when(globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString())).thenReturn(responseMessage);
		assertEquals(rm, globalExceptionHandler.returnConstraintViolationException(
				new ConstraintViolationException("Caused by: ConstraintViolationException", null) {
				}));
	}

	public static String asJsonString(final Object jsonObj) {
		try {
			return new ObjectMapper().writeValueAsString(jsonObj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
