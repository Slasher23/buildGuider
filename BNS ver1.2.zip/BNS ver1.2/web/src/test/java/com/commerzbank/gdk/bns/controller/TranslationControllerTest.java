package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * Junit for translation controller
 * 
 * @author ZE2MACL
 * @since 14/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 29/11/2017        1.01       ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class TranslationControllerTest {

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

    @Mock
    private Settings settings;

    @InjectMocks
    private TranslationController translationController;

    private MockMvc mockMvc;

    private Parameter parameter;

    private Tokenizer token;

    @Before
    public void initTest() throws JsonParseException, JsonMappingException, IOException {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(translationController).build();

        parameter = new Parameter();
        parameter.setLang("DE");

        token = new Tokenizer();
        token.setUserId("test");
        token.setProcessRunID("test123");
        token.setError(false);
        
    }

    @Test
    public void getTranslation_Successful_Test() throws Exception {

        when(this.settings.getLocale("DE")).thenReturn(getTranslatedStringEN());

        mockMvc.perform(post("/api/translatedTexts").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());
    }

    @Test
    public void getTranslation_Null_Test() throws Exception {

        mockMvc.perform(post("/api/translatedTexts").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(jsonPath("$.code", is(2001)));
    }

    private String getTranslatedStringEN() {
        String translatedText = "{\"sample\":\"sample\"}";

        return translatedText;
    }

}
