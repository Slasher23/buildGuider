package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for NotificationTextServiceImpl test
 * 
 * @author ZE2MACL
 * @since 14/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 29/11/2017        1.01       ZE2MORA    Updated Status Code
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class NotificationTextServiceImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private NotificationTextDAO notificationTextDAO;

	@InjectMocks
	private NotificationTextServiceImpl notificationTextServiceImpl;

	private NotificationText notificationText;

	private List<NotificationText> notificationTextList = new ArrayList<NotificationText>();

	private Tokenizer token;

	private ResponseBuilder<NotificationText> builder;

	private static final Logger logger = LoggerFactory.getLogger(NotificationTextServiceImpl.class);

	private Map<Integer, String> statusCodesMap;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		token = new Tokenizer();
		token.setUserId("test");
		token.setError(false);

		notificationText = new NotificationText();
		notificationText.setEventID(1L);
		notificationText.setEventType("test");
		notificationText.setNotificationTextType("test");
		notificationText.setNotificationTextUID(1L);
		notificationText.setText("test");

		notificationTextList.add(notificationText);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<NotificationText>(logger, token, globalRWrapper);

	}

	@Test
	public void getNotifText_Success_Test() {

		builder.OK(notificationText);

		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);
		assertEquals(builder.toString(), this.notificationTextServiceImpl.getNotifText(token, "test", 1L).toString());
	}

	@Test
	public void getNotifText_SuccessNoResult_Test() {

		builder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(null);
		assertEquals(builder.toString(), this.notificationTextServiceImpl.getNotifText(token, "test", 1L).toString());
	}

	@Test
	public void getNotifText_DataAccessException_Test() {

		builder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(notificationTextDAO.getNotifText(anyString(), anyLong()))
				.thenThrow(new DataRetrievalFailureException("test"));
		assertEquals(builder.toString(), this.notificationTextServiceImpl.getNotifText(token, "test", 1L).toString());
	}

	@Test
	public void getNotifText_NullPointerException_Test() {

		builder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenThrow(new NullPointerException("test"));
		assertEquals(builder.toString(), this.notificationTextServiceImpl.getNotifText(token, "test", 1L).toString());
	}

	@Test
	public void getNotifText_GeneralException_Test() {

		builder.notOK(Response.GENERAL_FUNCTION_ERROR);

		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenThrow(new RuntimeException());
		assertEquals(builder.toString(), this.notificationTextServiceImpl.getNotifText(token, "test", 1L).toString());
	}

}
