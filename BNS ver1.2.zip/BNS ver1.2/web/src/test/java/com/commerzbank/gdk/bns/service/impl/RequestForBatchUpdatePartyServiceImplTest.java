package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.model.BatchUpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ComplexElectronicAddress;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePartyResponse;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForBatchUpdatePartyService;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;

/**
 * 
 * JUnit Test Class for RequestForBatchUpdatePartyServiceImpl
 * 
 * @since 12/11/2017
 * @author ZE2GOME
 * @version 1.02
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 12/11/2017      1.00      ZE2GOME    Initial Version
 * 14/12/2017      1.01      ZE2MENY    Change complexelectronicalAddress into electronicalAddress
 * 14/12/2017      1.02      ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForBatchUpdatePartyServiceImplTest {

    @Mock
    private Environment environment;

    @Mock
    private RequestForUpdatePartyService requestForUpdatePartyServiceMock;
    
    @Mock
    private RequestForBatchUpdatePartyService requestForBatchUpdatePartyServiceMock;

    @InjectMocks
    private RequestForBatchUpdatePartyServiceImpl requestForBatchUpdatePartyServiceImpl;

    private UpdatePartyRequest updatePartyRequest;
    private UpdatePartyRequest updatePartyRequest2;

    private BatchUpdatePartyRequest batchUpdatePartyRequest;

    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";

    @Before
    public void init() {

        updatePartyRequest = new UpdatePartyRequest();

        updatePartyRequest.setBpkenn("BPKENNTEST");
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("01");
        updatePartyRequest.setTitle("01");
        
        updatePartyRequest2 = new UpdatePartyRequest();

        updatePartyRequest2.setBpkenn("BPKENNTEST2");
        updatePartyRequest2.setFirstName("TestName2");
        updatePartyRequest2.setLastName("TestLastname2");
        updatePartyRequest2.setSalutation("02");
        updatePartyRequest2.setTitle("02");

        ComplexElectronicAddress cea = new ComplexElectronicAddress();
        cea.setAddressId(1L);
        cea.setEmailAddress("test@test.com");

        List<ComplexElectronicAddress> ceaList = new ArrayList<>();
        ceaList.add(cea);

        updatePartyRequest.setElectronicalAddress(ceaList);
        updatePartyRequest2.setElectronicalAddress(ceaList);

        List<UpdatePartyRequest> listUpdatePartyRequest = new ArrayList<>();
        listUpdatePartyRequest.add(updatePartyRequest);
        listUpdatePartyRequest.add(updatePartyRequest2);

        batchUpdatePartyRequest = new BatchUpdatePartyRequest();
        batchUpdatePartyRequest.setUpdatePartyRequest(listUpdatePartyRequest);

    }

    @Test
    public void requestForUpdateParty_Test() throws Exception {
        
        RequestForBatchUpdatePartyResponse response = new RequestForBatchUpdatePartyResponse();

        List<ZslUpdateResponse> withoutErrors = new ArrayList<>();
        List<ZslUpdateResponse> withErrors = new ArrayList<>();

        ZslUpdateResponse withoutError = new ZslUpdateResponse();
        withoutError.setBpkenn("BPKENNTEST");
        withoutError.setStatus("OK- Successful");

        ZslUpdateResponse withError = new ZslUpdateResponse();
        withError.setBpkenn("BPKENNTEST3");
        withError.setStatus("FA- BPKENN does not exists in BNS");

        withoutErrors.add(withoutError);
        withErrors.add(withError);

        response.setUpdatePartyResponse(withoutErrors);
        response.setUpdatePartyResponseWithErrors(withErrors);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- BPKENN does not exists in BNS");
        when(this.requestForUpdatePartyServiceMock.requestForUpdateParty(any(UpdatePartyRequest.class))).thenReturn(withError, withoutError);
        
        
        assertEquals(this.requestForBatchUpdatePartyServiceImpl
                .requestForBatchUpdateParty(batchUpdatePartyRequest).toString(), response.toString());

    }

}
