package com.commerzbank.gdk.bns.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.controller.EmailController;

/**
 * 
 * JUnit Test Class for ResponseBuilder
 * 
 * @since 24/10/2017
 * @author ZE2RUBI
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 24/10/2017      1.00      ZE2RUBI    Initial Version
 * 29/11/2017      1.01      ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class ResponseBuilderTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

    private ResponseBuilder<Person> responseBuilder;
    
    private Person                  person;

    private Tokenizer token;
    
    private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Before
    public void init() {
        person = new Person();
        person.setGivenName("Daryl");
        person.setLastName("Rubinos");

        token = new Tokenizer();
        token.setUserId("test");
        token.setError(false);

        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        responseBuilder = new ResponseBuilder<Person>(logger, token, globalRWrapper);
    }
    
    @Test
    public void checkOkwithNullData() {
        responseBuilder.OK(Response.SUCCESS_RESULTS_FOUND);
        assertEquals(responseBuilder.getData(),null);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void checkOkEmptyCode() {
        responseBuilder.OK(150);
        assertEquals(responseBuilder.getData(),null);
    }

//    @Test(expected=IllegalArgumentException.class)
//    public void checkOkGreaterThanFourCode() {
//        responseBuilder.OK(135234);
//        assertEquals(responseBuilder.getData(),null);
//    }
//    
//    @Test(expected=IllegalArgumentException.class)
//    public void checkOkContainsLetterCode() {
//        responseBuilder.OK("ae45");
//        assertEquals(responseBuilder.getData(),null);
//    }
    
    @Test
    public void checkOkData() {
        responseBuilder.OK(person);
        assertEquals(Response.SUCCESS_RESULTS_FOUND, responseBuilder.getCode().intValue());
        
    }
    
    @Test
    public void initResponseBuilder() throws Exception {
        responseBuilder.build(person);
        assertNotNull(responseBuilder.getData());
        assertEquals(person, responseBuilder.getData());

    }

    @Test
    public void checkNotOkwithData() throws Exception {
        responseBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);
        assertEquals("2001 - General exception has occurred.", responseBuilder.getMessage());
    }
    @Test
    public void checkNotOkwithCode() throws Exception {
        responseBuilder.notOK( Response.GENERAL_FUNCTION_ERROR);
        assertEquals("2001 - General exception has occurred.", responseBuilder.getMessage());
    }
    
//    @Test(expected=IllegalArgumentException.class)
//    public void checkNotOkEmptyCode() {
//        responseBuilder.notOK("");
//        assertEquals(responseBuilder.getData(),null);
//    }
    
//    @Test(expected=IllegalArgumentException.class)
//    public void checkNotOkGreaterThanFourCode() {
//        responseBuilder.notOK( Response.GENERAL_FUNCTION_ERROR);
//        assertEquals(responseBuilder.getData(),null);
//    }
//    @Test(expected=IllegalArgumentException.class)
//    public void checkNotOkContainsLetterCode() {
//        responseBuilder.notOK("rt54");
//        assertEquals(responseBuilder.getData(),null);
//    }
    
    @Test
    public void getResponse() {
        responseBuilder.OK(person);
        assertEquals(responseBuilder.response().getData(),person);
    }
    
    @Test
    public void getResponseEntity() {
        responseBuilder.OK(person);
        assertEquals(responseBuilder.responseEntity().getBody().getData(),person);
        assertEquals(responseBuilder.responseEntity().getStatusCode(),HttpStatus.OK);
    }
    
    @Test
    public void getResponseEntityNotOk() {
        responseBuilder.notOK( Response.GENERAL_FUNCTION_ERROR);
        assertEquals(responseBuilder.responseEntity().getBody().getData(),null);
        assertEquals(responseBuilder.responseEntity().getStatusCode(),HttpStatus.OK);
    }
    
//    @Test(expected=IllegalArgumentException.class)
//    public void getResponseEntityNotInitialized() {
//        assertEquals(responseBuilder.responseEntity(),null);
//    }
    
    @Test
    public void getResponseEntityWithHeader() {
        responseBuilder.OK(person);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Coba-user", "user");
        
        assertEquals(responseBuilder.responseEntity(headers).getHeaders(),headers);
    }
}
