package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.BatchPersonExistsRequest;
import com.commerzbank.gdk.bns.model.BatchPersonExistsResponse;
import com.commerzbank.gdk.bns.model.PersonExistsRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForPersonExistsService;

/**
 * JUnit test class for RequestForPersonExistsController
 * 
 * @since 7/12/2017
 * @author ZE2MENY
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 7/12/2017       1.00      ZE2MENY    Initial Version
 * 11/12/2017      1.01      ZE2MENY    Implementation of BatchProcessing
 *          </pre>
 */

@EnableWebMvc
public class RequestForPersonExistsControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RequestForPersonExistsService requestForUpdatePersonServiceMock;

    @InjectMocks
    private RequestForPersonExistsController requestForPersonExistsControllerMock;

    PersonExistsRequest request = new PersonExistsRequest();

    BatchPersonExistsResponse         response = new BatchPersonExistsResponse();
    private List<PersonExistsRequest> requestList;

    private ZslUpdateResponse zslUpdateResponse;

    private BatchPersonExistsRequest batchPersonExistsRequest = new BatchPersonExistsRequest();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(requestForPersonExistsControllerMock).build();

        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST");

        request.setBpkenn("BPKENNTEST");

        requestList = new ArrayList<PersonExistsRequest>();
        requestList.add(request);

        batchPersonExistsRequest = new BatchPersonExistsRequest();
        batchPersonExistsRequest.setPersonExistsRequest(requestList);

    }

    @Test
    public void requestForPersonExists_Json_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForPersonExists").contentType(MediaType.APPLICATION_JSON)
                .content(Parser.asJsonString(request))).andExpect(status().isOk());

    }

    @Test
    public void requestForPersonExists_Xml_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForPersonExists").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(request))).andExpect(status().isOk());

    }

    @Test
    public void requestForBatchPersonExists_JSON_Test() throws Exception {

        this.mockMvc
                .perform(post("/api/zsl/requestForBatchPersonExists")
                        .content(Parser.asJsonString(batchPersonExistsRequest)).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    public void requestForBatchPersonExists_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchPersonExists").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(requestList))).andExpect(status().isOk());

    }
}
