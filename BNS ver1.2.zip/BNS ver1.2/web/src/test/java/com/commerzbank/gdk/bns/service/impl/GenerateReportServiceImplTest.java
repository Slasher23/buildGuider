package com.commerzbank.gdk.bns.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.ReportDAO;
import com.commerzbank.gdk.bns.model.GenerateReportRequest;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit test class for GenerateReportServiceImplTest
 * 
 * @since 09/01/2018
 * @author ZE2BUEN
 * @version 1.00
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 09/01/2018      1.00      ZE2BUEN    Initial Version
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class GenerateReportServiceImplTest {

    @Autowired
    private GlobalResponseWrapper globalRWrapper;

    @Mock
    private GlobalResponseWrapper globalResponseWrapper;

    @Mock
    private ReportDAO reportDAO;

    @InjectMocks
    private GenerateReportServiceImpl generateReportServiceImpl;

    private Tokenizer token;

    private Report report001_1;
    private Report report001_2;
    private Report report002_1;
    private Report report002_2;
    private Report report003_1;
    private Report report003_2;
    private Report report004_1;
    private Report report004_2;
    private Report report005_1;
    private Report report005_2;
    private Report report006_1;
    private Report report006_2;
    private Report report006_3;
    private Report report006_4;
    private Report report007_1;
    private Report report007_2;
    private Report report007_3;
    private Report report007_4;

    private List<Report> report001List;
    private List<Report> report002List;
    private List<Report> report003List;
    private List<Report> report004List;
    private List<Report> report005List;
    private List<Report> report006List;
    private List<Report> report007List;

    private static final String RPT001 = "RPT001";
    private static final String RPT002 = "RPT002";
    private static final String RPT003 = "RPT003";
    private static final String RPT004 = "RPT004";
    private static final String RPT005 = "RPT005";
    private static final String RPT006 = "RPT006";
    private static final String RPT007 = "RPT007";

    private static final String strReportDate1 = "26.02.2018";
    private static final String strReportDate2 = "27.02.2018";

    private Date reportDate1;
    private Date reportDate2;

    private Date reportDateTime1;
    private Date reportDateTime2;
    private Date reportDateTime3;
    private Date reportDateTime4;

    private GenerateReportRequest generateReportRequest;

    private ResponseBuilder<List<Report>> reportListBuilder;

    private Map<Integer, String> statusCodesMap;

    private static final Logger logger = LoggerFactory.getLogger(GenerateReportServiceImpl.class);

    @Before
    public void init() throws ParseException {

        MockitoAnnotations.initMocks(this);

        token = new Tokenizer();
        token.setUserId("123");

        SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
        reportDate1 = sdf1.parse("26-02-2018");
        reportDate2 = sdf1.parse("27-02-2018");

        SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        reportDateTime1 = sdf2.parse("26-02-2018 12:00");
        reportDateTime2 = sdf2.parse("26-02-2018 12:30");
        reportDateTime3 = sdf2.parse("27-02-2018 12:00");
        reportDateTime4 = sdf2.parse("27-02-2018 12:30");

        report001_1 = new Report();
        report001_1.setCount(1111.0);
        report001_1.setDate(reportDate1);
        report001_1.setReportType(RPT001);

        report001_2 = new Report();
        report001_2.setCount(2222.0);
        report001_2.setDate(reportDate2);
        report001_2.setReportType(RPT001);

        report001List = new ArrayList<>();
        report001List.add(report001_1);
        report001List.add(report001_2);

        report002_1 = new Report();
        report002_1.setCount(3333.0);
        report002_1.setDate(reportDate1);
        report002_1.setReportType(RPT001);
        report002_1.setPercentage(33.33);

        report002_2 = new Report();
        report002_2.setCount(4444.0);
        report002_2.setDate(reportDate2);
        report002_2.setReportType(RPT002);
        report002_2.setPercentage(44.44);

        report002List = new ArrayList<>();
        report002List.add(report002_1);
        report002List.add(report002_2);

        report003_1 = new Report();
        report003_1.setCount(5555.0);
        report003_1.setDate(reportDate1);
        report003_1.setReportType(RPT003);
        report003_1.setPercentage(55.55);

        report003_2 = new Report();
        report003_2.setCount(6666.0);
        report003_2.setDate(reportDate2);
        report003_2.setReportType(RPT003);
        report003_2.setPercentage(66.66);

        report003List = new ArrayList<>();
        report003List.add(report003_1);
        report003List.add(report003_2);

        report004_1 = new Report();
        report004_1.setCount(7777.0);
        report004_1.setDate(reportDate1);
        report004_1.setReportType(RPT004);
        report004_1.setPercentage(77.77);

        report004_2 = new Report();
        report004_2.setCount(8888.0);
        report004_2.setDate(reportDate2);
        report004_2.setReportType(RPT004);
        report004_2.setPercentage(88.88);

        report004List = new ArrayList<>();
        report004List.add(report004_1);
        report004List.add(report004_2);

        report005_1 = new Report();
        report005_1.setCount(9999.0);
        report005_1.setDate(reportDate1);
        report005_1.setReportType(RPT005);
        report005_1.setPercentage(99.99);

        report005_2 = new Report();
        report005_2.setCount(10000.0);
        report005_2.setDate(reportDate2);
        report005_2.setReportType(RPT005);
        report005_2.setPercentage(100.00);

        report005List = new ArrayList<>();
        report005List.add(report005_1);
        report005List.add(report005_2);

        report006_1 = new Report();
        report006_1.setCount(10.0);
        report006_1.setDate(reportDate1);
        report006_1.setTime(reportDateTime1);
        report006_1.setReportType(RPT006);
        report006_1.setPercentage(10.00);

        report006_2 = new Report();
        report006_2.setCount(20.0);
        report006_2.setDate(reportDate1);
        report006_2.setTime(reportDateTime2);
        report006_2.setReportType(RPT006);
        report006_2.setPercentage(20.00);

        report006_3 = new Report();
        report006_3.setCount(30.0);
        report006_3.setDate(reportDate1);
        report006_3.setTime(reportDateTime3);
        report006_3.setReportType(RPT006);
        report006_3.setPercentage(30.00);

        report006_4 = new Report();
        report006_4.setCount(40.0);
        report006_4.setDate(reportDate1);
        report006_4.setTime(reportDateTime4);
        report006_4.setReportType(RPT006);
        report006_4.setPercentage(40.00);

        report006List = new ArrayList<>();
        report006List.add(report006_1);
        report006List.add(report006_2);
        report006List.add(report006_3);
        report006List.add(report006_4);

        report007_1 = new Report();
        report007_1.setCount(10.0);
        report007_1.setDate(reportDate1);
        report007_1.setTime(reportDateTime1);
        report007_1.setReportType(RPT007);
        report007_1.setPercentage(10.00);

        report007_2 = new Report();
        report007_2.setCount(20.0);
        report007_2.setDate(reportDate1);
        report007_2.setTime(reportDateTime2);
        report007_2.setReportType(RPT007);
        report007_2.setPercentage(20.00);

        report007_3 = new Report();
        report007_3.setCount(30.0);
        report007_3.setDate(reportDate1);
        report007_3.setTime(reportDateTime3);
        report007_3.setReportType(RPT007);
        report007_3.setPercentage(30.00);

        report007_4 = new Report();
        report007_4.setCount(40.0);
        report007_4.setDate(reportDate1);
        report007_4.setTime(reportDateTime4);
        report007_4.setReportType(RPT007);
        report007_4.setPercentage(40.00);

        report007List = new ArrayList<>();
        report007List.add(report007_1);
        report007List.add(report007_2);
        report007List.add(report007_3);
        report007List.add(report007_4);

        statusCodesMap = this.globalRWrapper.getStatusCodesMap();

    }

    @Test
    public void retrieveReportData_RPT001_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT001);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT001)).thenReturn(report001List);

        reportListBuilder.OK(report001List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT002_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT002);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT002)).thenReturn(report002List);

        reportListBuilder.OK(report002List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT003_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT003);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT003)).thenReturn(report003List);

        reportListBuilder.OK(report003List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT004_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT004);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT004)).thenReturn(report004List);

        reportListBuilder.OK(report004List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT005_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT005);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT005)).thenReturn(report005List);

        reportListBuilder.OK(report005List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT006_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT006);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT006)).thenReturn(report006List);

        reportListBuilder.OK(report006List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_RPT007_Successful() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT007);

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT007)).thenReturn(report007List);

        reportListBuilder.OK(report007List);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_Invalid_EndDate_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate("14.02.2018");
        generateReportRequest.setReportType("RPT001");

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.OK(report001List, Response.SUCCESS_NO_RESULTS_FOUND);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_Invalid_Request_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(null);
        generateReportRequest.setEndDate(null);
        generateReportRequest.setReportType(null);

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.OK(report001List, Response.SUCCESS_NO_RESULTS_FOUND);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_Invalid_Dates_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate("02.31.2018");
        generateReportRequest.setEndDate("02.55.2018");
        generateReportRequest.setReportType(RPT001);

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.OK(report001List, Response.SUCCESS_NO_RESULTS_FOUND);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_DataAccessException_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT001);

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT001))
                .thenThrow(new DataAccessException("DataAccessException") {
                    private static final long serialVersionUID = 1L;
                });

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_NullPointerException_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT001);

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT001))
                .thenThrow(new NullPointerException("NullPointerException") {
                    private static final long serialVersionUID = 1L;
                });

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

    @Test
    public void retrieveReportData_Exception_Fail() throws Exception {

        generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(strReportDate1);
        generateReportRequest.setEndDate(strReportDate2);
        generateReportRequest.setReportType(RPT001);

        report001List = new ArrayList<>();

        reportListBuilder = new ResponseBuilder<List<Report>>(logger, token, globalRWrapper);

        reportListBuilder.notOK(Response.GENERAL_FUNCTION_ERROR);

        when(this.reportDAO.getReportList(reportDate1, reportDate2, RPT001)).thenThrow(Exception.class);

        when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

        assertEquals(reportListBuilder.toString(),
                this.generateReportServiceImpl.retrieveReportData(token, generateReportRequest).toString());

    }

}
