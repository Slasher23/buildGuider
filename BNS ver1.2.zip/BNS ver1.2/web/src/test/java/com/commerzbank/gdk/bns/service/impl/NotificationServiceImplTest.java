package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Notification;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Trigger;
import com.commerzbank.gdk.bns.rules.NotificationRuleBookImpl;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.utils.Tools;

import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * 
 * JUnit Test Class for NotificationServiceImpl
 * 
 * @since 26/10/2017
 * @author ZE2FUEN
 * @version 1.03
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 26/10/2017      1.00      ZE2FUEN    Initial Version
 * 23/11/2017      1.01      ZE2SARO    Remove Participant
 * 07/12/2017      1.02      ZE2BUEN    Modified JUnit Test to reflect changes for logging
 * 14/12/2017      1.03      ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationServiceImplTest {

    @Mock
    private KeyService KeyService;
    
    @Mock
    private PersonDAO personDAO;

    @Mock
    private AgreementDAO agreementDAO;

    @Mock
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Mock
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Mock
    private NotificationTextDAO notificationTextDAO;

    @Mock
    private EmailDAO emailDAO;

    @Mock
    private InformationChannelDAO infoChannelDAO;
    
    @Mock
    private DailyReportLogDAO dailyReportLogDAO;

    @Mock
    private NotificationRuleBookImpl notificationRuleBook;

    @Mock
    private Environment environment;

    @Mock
    private Settings settings;

    @Mock
    private Configuration freemarkerConfig;

    @Mock
    private Tools tools;

    @InjectMocks
    private NotificationServiceImpl notificationServiceImpl;

    private Person person;
    
    private Trigger trigger;
    
    private Agreement agreement1;
    
    private Agreement agreement2;
    
    private Agreement agreement3;
    
    private NotificationConfigAgreement notifConfigAgreement1;
    
    private NotificationConfigAgreement notifConfigAgreement2;
    
    private NotificationConfigAgreement notifConfigAgreement3;
    
    private NotificationConfigPerson notifConfigPerson1;
    
    private NotificationConfigPerson notifConfigPerson2;
    
    private NotificationConfigPerson notifConfigPerson3;
    
    private NotificationText notificationText;
    
    private Notification notification;
    
    private Key key;
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
	private static final String STATUS_FA_NO_AVAIL_NOTIF_CONFIG = "ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        this.person = new Person();
        this.person.setBPKENN("BPKENNTEST");
        this.person.setGivenName("GivenName");
        this.person.setLastName("LastName");
        this.person.setPersonUID(1L);
        this.person.setSalutation("01");
        this.person.setTitle("01");

        this.trigger = new Trigger();

        this.agreement1 = new Agreement();
        this.agreement1.setAgreementUID(1L);

        this.agreement2 = new Agreement();
        this.agreement2.setAgreementUID(2L);

        this.agreement3 = new Agreement();
        this.agreement3.setAgreementUID(3L);

        this.notifConfigAgreement1 = new NotificationConfigAgreement();
        this.notifConfigAgreement1.setActive(true);
        this.notifConfigAgreement1.setAgreementUID(1L);
        this.notifConfigAgreement1.setEmailUID(1L);
        this.notifConfigAgreement1.setInformationChannelUID(1L);
        this.notifConfigAgreement1.setNotifConfigAgreementUID(1L);
        this.notifConfigAgreement1.setNotificationTextUID(1L);

        this.notifConfigAgreement2 = new NotificationConfigAgreement();
        this.notifConfigAgreement2.setActive(true);
        this.notifConfigAgreement2.setAgreementUID(1L);
        this.notifConfigAgreement2.setEmailUID(1L);
        this.notifConfigAgreement2.setInformationChannelUID(1L);
        this.notifConfigAgreement2.setNotifConfigAgreementUID(1L);
        this.notifConfigAgreement2.setNotificationTextUID(1L);

        this.notifConfigAgreement3 = new NotificationConfigAgreement();
        this.notifConfigAgreement3.setActive(true);
        this.notifConfigAgreement3.setAgreementUID(1L);
        this.notifConfigAgreement3.setEmailUID(1L);
        this.notifConfigAgreement3.setInformationChannelUID(1L);
        this.notifConfigAgreement3.setNotifConfigAgreementUID(1L);
        this.notifConfigAgreement3.setNotificationTextUID(1L);

        this.notifConfigPerson1 = new NotificationConfigPerson();
        this.notifConfigPerson1.setActive(true);
        this.notifConfigPerson1.setEmailUID(1L);
        this.notifConfigPerson1.setInformationChannelUID(1L);
        this.notifConfigPerson1.setNotifConfigPersonUID(1L);
        this.notifConfigPerson1.setNotificationTextUID(1L);
        this.notifConfigPerson1.setPersonUID(1L);

        this.notifConfigPerson2 = new NotificationConfigPerson();
        this.notifConfigPerson2.setActive(true);
        this.notifConfigPerson2.setEmailUID(1L);
        this.notifConfigPerson2.setInformationChannelUID(1L);
        this.notifConfigPerson2.setNotifConfigPersonUID(1L);
        this.notifConfigPerson2.setNotificationTextUID(1L);
        this.notifConfigPerson2.setPersonUID(2L);

        this.notifConfigPerson3 = new NotificationConfigPerson();
        this.notifConfigPerson3.setActive(true);
        this.notifConfigPerson3.setEmailUID(1L);
        this.notifConfigPerson3.setInformationChannelUID(1L);
        this.notifConfigPerson3.setNotifConfigPersonUID(1L);
        this.notifConfigPerson3.setNotificationTextUID(1L);
        this.notifConfigPerson3.setPersonUID(3L);

        this.notificationText = new NotificationText();
        this.notificationText.setNotificationTextType("STD");
        this.notificationText.setText("This is a STD Text");

        this.notification = new Notification();
        this.notification.setInformationChannelUID(1L);
        
        this.key = new Key();
        key.setKeyTyp("BBANR");
        key.setLanguage("000");
        key.setKeyCode("01");
        key.setKeyShortText("Herrn");
        key.setKeyTyp("PAKTL");
        key.setLanguage("006");
        key.setKeyCode("01");
        key.setKeyShortText("Frau");

    }

    @Test
    public void SCN001_InvalidRequest_MissingBPKENN_Empty() throws Exception {

        String bpkenn = "";
        String agreementID = "VEREINBARUNG1";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- Invalid Request");
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN002_InvalidRequest_MissingAgreementID_Empty() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = "";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- Invalid Request");
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN003_InvalidRequest_MissingBPKENN_Null() throws Exception {

        String bpkenn = null;
        String agreementID = "VEREINBARUNG1";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- Invalid Request");
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN004_InvalidRequest_MissingAgreementID_Null() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = null;
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- Invalid Request");
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");
        
        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN005_InvalidRequest_MissingBranch_Null() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = "VEREINBARUNG1";
        Integer branch = null;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- Invalid Request");
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN006_InvalidBPKENN() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = "VEREINBARUNG1";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- BPKENN does not exist on BNS");

        when(this.personDAO.getPerson(bpkenn)).thenReturn(null);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exist on BNS");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN007_PersonNotification_MissingConfig() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = null;
        Integer branch = null;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- No available e-mail address and no activated push configuration");

        NotificationMatrixResponse matrix1 = new NotificationMatrixResponse();
        List<NotificationMatrixChannel> notificationChannelList = new ArrayList<NotificationMatrixChannel>();
        matrix1.setNotificationMatrixChannel(notificationChannelList);
        matrix1.setStatus("Error");

        when(this.personDAO.getPerson(bpkenn)).thenReturn(this.person);

        when(this.notificationRuleBook.checkDecisionLevel(bpkenn, branch, agreementID, false)).thenReturn(matrix1);
        
        when(this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG)).thenReturn("FA- No available e-mail address and no activated push configuration");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN008_AgreementNotification_MissingConfig() throws Exception {

        String bpkenn = "BPKENNTEST";
        String agreementID = "VEREINBARUNG1";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();
        response.setNotification(notificationList);
        response.setStatus("FA- No available e-mail address and no activated push configuration");

        NotificationMatrixResponse matrix1 = new NotificationMatrixResponse();
        List<NotificationMatrixChannel> notificationChannelList = new ArrayList<NotificationMatrixChannel>();
        matrix1.setNotificationMatrixChannel(notificationChannelList);
        matrix1.setStatus("Error");

        when(this.personDAO.getPerson(bpkenn)).thenReturn(this.person);

        when(this.notificationRuleBook.checkDecisionLevel(bpkenn, branch, agreementID, true)).thenReturn(matrix1);
        
        when(this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG)).thenReturn("FA- No available e-mail address and no activated push configuration");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN009_PersonNotification_STDText() throws Exception {

        NotificationMatrixResponse matrix1 = new NotificationMatrixResponse();
        List<NotificationMatrixChannel> notificationChannelList1 = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationChannel1_1 = new NotificationMatrixChannel();
        notificationChannel1_1.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationChannel1_1.setNotificationPath("PUSH DEVICE1");
        notificationChannelList1.add(notificationChannel1_1);
        matrix1.setNotificationMatrixChannel(notificationChannelList1);
        matrix1.setStatus("SUCCESSFUL");
        
        String bpkenn = "BPKENNTEST";
        String agreementID = null;
        Integer branch = null;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();

        Notifications notification4 = new Notifications();
        notification4.setNotificationType(InformationChannelTypeE.PUSH.toString());
        notification4.setNotificationPath("PUSH DEVICE1");
        notification4.setNotificationText("BASE64ENCODEDSTD");
        notification4.setNotificationSubject("New Document");
        notificationList.add(notification4);
        String successMessage = "OK- Successful";
        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        response.setNotification(notificationList);
        response.setStatus(successMessage);

        when(this.personDAO.getPerson(bpkenn)).thenReturn(this.person);

        when(this.notificationRuleBook.checkDecisionLevel(bpkenn, branch, agreementID, false)).thenReturn(matrix1);

        when(this.environment.getProperty("VERLASSUNGS_TYPE_PER")).thenReturn("PER");

        when(this.notificationConfigPersonDAO.findByPersonUID(1L)).thenReturn(this.notifConfigPerson1);

        when(this.notificationConfigPersonDAO.findByPersonUID(2L)).thenReturn(this.notifConfigPerson2);

        when(this.notificationConfigPersonDAO.findByPersonUID(3L)).thenReturn(this.notifConfigPerson3);

        when(this.notificationTextDAO.findOne(1L)).thenReturn(this.notificationText);

        when(this.notificationTextDAO.findOne(2L)).thenReturn(this.notificationText);

        when(this.notificationTextDAO.findOne(3L)).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText")).thenReturn("This is standard text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText")).thenReturn("This is standard text in EN");

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODEDSTD");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN010_PersonNotification_FREEText() throws Exception {

        NotificationMatrixResponse matrix2 = new NotificationMatrixResponse();
        List<NotificationMatrixChannel> notificationChannelList2 = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationChannel2_1 = new NotificationMatrixChannel();
        notificationChannel2_1.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationChannel2_1.setNotificationPath("PUSH DEVICE1");
        notificationChannelList2.add(notificationChannel2_1);
        matrix2.setNotificationMatrixChannel(notificationChannelList2);
        matrix2.setStatus("SUCCESSFUL");
        
        String bpkenn = "BPKENNTEST";
        String agreementID = null;
        Integer branch = null;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();

        Notifications notification4 = new Notifications();
        notification4.setNotificationType(InformationChannelTypeE.PUSH.toString());
        notification4.setNotificationPath("PUSH DEVICE1");
        notification4.setNotificationText("BASE64ENCODED");
        notification4.setNotificationSubject("New Document");
        notificationList.add(notification4);
        String successMessage = "OK- Successful";
        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        response.setNotification(notificationList);
        response.setStatus(successMessage);

        when(this.personDAO.getPerson(bpkenn)).thenReturn(this.person);

        when(this.notificationRuleBook.checkDecisionLevel(bpkenn, branch, agreementID, false))
                .thenReturn(matrix2);

        when(this.environment.getProperty("VERLASSUNGS_TYPE_PER")).thenReturn("PER");

        when(this.notificationConfigPersonDAO.findByPersonUID(1L)).thenReturn(this.notifConfigPerson1);

        when(this.notificationConfigPersonDAO.findByPersonUID(2L)).thenReturn(this.notifConfigPerson2);

        when(this.notificationConfigPersonDAO.findByPersonUID(3L)).thenReturn(this.notifConfigPerson3);

        this.notificationText.setNotificationTextType("FREE");
        this.notificationText.setText("This is a FREE Text");

        when(this.notificationTextDAO.findOne(1L)).thenReturn(this.notificationText);

        when(this.notificationTextDAO.findOne(2L)).thenReturn(this.notificationText);

        when(this.notificationTextDAO.findOne(3L)).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODED");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

    @Test
    public void SCN011_AgreementNotification_STDText() throws Exception {
        
        
        NotificationMatrixResponse matrix3 = new NotificationMatrixResponse();
        List<NotificationMatrixChannel> notificationChannelList3 = new ArrayList<NotificationMatrixChannel>();
        NotificationMatrixChannel notificationChannel3_1 = new NotificationMatrixChannel();
        notificationChannel3_1.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationChannel3_1.setNotificationPath("Email@Address.com");
        notificationChannelList3.add(notificationChannel3_1);
        NotificationMatrixChannel notificationChannel3_2 = new NotificationMatrixChannel();
        notificationChannel3_2.setInformationChannelType(InformationChannelTypeE.PUSH);
        notificationChannel3_2.setNotificationPath("PUSH DEVICE1");
        notificationChannelList3.add(notificationChannel3_2);
        matrix3.setNotificationMatrixChannel(notificationChannelList3);
        matrix3.setStatus("SUCCESSFUL");
        
        String bpkenn = "BPKENNTEST";
        String agreementID = "VEREINBARUNG1";
        Integer branch = 100;

        NotificationRequest request = new NotificationRequest();
        NotificationResponse response = new NotificationResponse();

        request.setBpkenn(bpkenn);
        request.setVereinbarungskennung(agreementID);
        request.setSparte(branch);

        response.setBPKENN(bpkenn);
        List<Notifications> notificationList = new ArrayList<Notifications>();

        Notifications notification3 = new Notifications();
        notification3.setNotificationType(InformationChannelTypeE.EMAIL.toString());
        notification3.setNotificationPath("Email@Address.com");
        notification3.setNotificationText("BASE64ENCODEDSTD");
        notification3.setNotificationSubject("New Document");
        notificationList.add(notification3);

        Notifications notification4 = new Notifications();
        notification4.setNotificationType(InformationChannelTypeE.PUSH.toString());
        notification4.setNotificationPath("PUSH DEVICE1");
        notification4.setNotificationText("BASE64ENCODEDSTD");
        notification4.setNotificationSubject("New Document");
        notificationList.add(notification4);
        String successMessage = "OK- Successful";
        when(this.environment.getProperty(STATUS_OK)).thenReturn(successMessage);

        response.setNotification(notificationList);
        response.setStatus(successMessage);

        when(this.personDAO.getPerson(bpkenn)).thenReturn(this.person);

        when(this.notificationRuleBook.checkDecisionLevel(bpkenn, branch, agreementID, true))
                .thenReturn(matrix3);

        when(this.environment.getProperty("VERLASSUNGS_TYPE_PER")).thenReturn("PER");

        when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(1L, agreementID, branch))
                .thenReturn(this.agreement1);

        when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(2L, agreementID, branch))
                .thenReturn(this.agreement1);

        when(this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(3L, agreementID, branch))
                .thenReturn(this.agreement1);

        when(this.notificationConfigAgreementDAO.findByAgreementUID(1L, branch, agreementID))
                .thenReturn(this.notifConfigAgreement1);

        when(this.notificationConfigAgreementDAO.findByAgreementUID(2L, branch, agreementID))
                .thenReturn(this.notifConfigAgreement2);

        when(this.notificationConfigAgreementDAO.findByAgreementUID(3L, branch, agreementID))
                .thenReturn(this.notifConfigAgreement3);

        when(this.notificationTextDAO.findOne(1L)).thenReturn(this.notificationText);

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText")).thenReturn("This is standard text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText")).thenReturn("This is standard text in EN");

        when(this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in DE");

        when(this.settings.getLocaleField("EN", "subTextArea_DefaultText_Push"))
                .thenReturn("This is standard PUSH text in EN");

        final Configuration configuration = new Configuration(Configuration.VERSION_2_3_25);
        configuration.setDirectoryForTemplateLoading(new File("src/main/resources/templates"));
        Template t = configuration.getTemplate("NotificationEmailTemplate.ftl");

        when(this.freemarkerConfig.getTemplate("NotificationEmailTemplate.ftl")).thenReturn(t);

        when(this.tools.base64Encode(any(String.class))).thenReturn("BASE64ENCODEDSTD");

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.EMAIL.toString())).thenReturn(1L);

        when(this.infoChannelDAO.getInformationChannelUID(InformationChannelTypeE.PUSH.toString())).thenReturn(2L);

        when(this.environment.getProperty("EMAIL_SUBJECT")).thenReturn("New Document");
        
        when(this.KeyService.getShortTextValue(anyString(), anyString(), anyString())).thenReturn("Herrn");

        NotificationResponse requestNotification = this.notificationServiceImpl.sendNotification(request);
        assertEquals(requestNotification.toString(), response.toString());

    }

}
