package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AuditLogService;

/**
 * JUnit test class for AuditLogController
 * 
 * @since 20/11/2017
 * @author ZE2MACL
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2MACL    Initial Version
 * 29/11/2017      1.01      ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class AuditLogControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private AuditLogService auditLogServiceMock;

	@InjectMocks
	private AuditLogController auditLogController;

	private MockMvc mockMvc;

	private AuditLog auditLog = new AuditLog();

	private Tokenizer token = new Tokenizer();

	private ResponseBuilder<AuditLog> builder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(AuditLogController.class);

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(auditLogController).build();

		token.setUserId("test");
		token.setProcessRunID("123test");
		token.setError(false);

		auditLog.setEventType("1001");

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<AuditLog>(logger, token, globalRWrapper);
	}

	@Test
	public void saveAuditLog_JSONResponseCode_Test() throws Exception {

		when(auditLogServiceMock.save(any(Tokenizer.class), any(AuditLog.class))).thenReturn(builder.OK(auditLog));

		mockMvc.perform(post("/api/auditLogs").contentType(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(auditLog)).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());
	}

	@Test
	public void saveAuditLog_JSON_Test() throws Exception {

		when(auditLogServiceMock.save(any(Tokenizer.class), any(AuditLog.class))).thenReturn(builder.OK(auditLog));

		mockMvc.perform(post("/api/auditLogs").contentType(MediaType.APPLICATION_JSON)
				.content(Parser.asJsonString(auditLog)).accept(MediaType.APPLICATION_JSON))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

}
