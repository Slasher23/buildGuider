package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchResponse;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;

/**
 * JUnit test class for Change Email Address Batch Service Impl
 * 
 * @since 28/11/2017
 * @author ZE2BUEN
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 28/11/2017      1.00      ZE2BUEN    Initial Version
 * </pre>
 */

@RunWith(MockitoJUnitRunner.class)
public class ChangeEmailAddressBatchServiceImplTest {

	@Mock
	private ChangeEmailAddressBatchServiceImpl changeEmailAddressBatchServiceImpl;

	@Mock
	private ChangeEmailAddressServiceImpl changeEmailAddressServiceImpl;

	private ChangeEmailAddressBatchRequest request;

	private ChangeEmailAddressRequest changeEmailAddressRequest1;

	private ChangeEmailAddressRequest changeEmailAddressRequest2;

	private List<ChangeEmailAddressRequest> changeEmailAddressRequestList;

	private ChangeEmailAddressBatchResponse response;

	private ChangeEmailAddressResponse changeEmailAddressResponse1;

	private ChangeEmailAddressResponse changeEmailAddressResponse2;

	private List<ChangeEmailAddressResponse> changeEmailAddressResponseWithoutErrors;

	private List<ChangeEmailAddressResponse> changeEmailAddressResponseWithErrors;

	private final String STATUS_OK = "OK- Successful";

	private final String STATUS_FA_INVALID_REQUEST = "FA- Invalid Request";

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		changeEmailAddressRequest1 = new ChangeEmailAddressRequest();
		changeEmailAddressRequest1.setAddressId(1L);
		changeEmailAddressRequest1.setBpkenn("BPKENNTEST");
		changeEmailAddressRequest1.setChangeEventType("CreateAddressEvent");
		changeEmailAddressRequest1.setEmailAddress("new_email@coba.com");

		changeEmailAddressRequest2 = new ChangeEmailAddressRequest();
		changeEmailAddressRequest2.setAddressId(2L);
		changeEmailAddressRequest2.setBpkenn("BPKENNTEST1");
		changeEmailAddressRequest2.setChangeEventType("InvalidEventType");
		changeEmailAddressRequest2.setEmailAddress("new_email@coba.com");

		changeEmailAddressRequestList = new ArrayList<>();
		changeEmailAddressRequestList.add(changeEmailAddressRequest1);
		changeEmailAddressRequestList.add(changeEmailAddressRequest2);

	}

	@Test
	public void requestForBatchChangeEmailAddress_Test() throws Exception {

		changeEmailAddressResponse1 = new ChangeEmailAddressResponse();
		changeEmailAddressResponse1.setAddressId(1L);
		changeEmailAddressResponse1.setBpkenn("BPKENNTEST");
		changeEmailAddressResponse1.setStatus(STATUS_OK);

		changeEmailAddressResponse2 = new ChangeEmailAddressResponse();
		changeEmailAddressResponse2.setAddressId(2L);
		changeEmailAddressResponse2.setBpkenn("BPKENNTEST1");
		changeEmailAddressResponse2.setStatus(STATUS_FA_INVALID_REQUEST);
		
		response = new ChangeEmailAddressBatchResponse();
		changeEmailAddressResponseWithoutErrors = new ArrayList<>();
		changeEmailAddressResponseWithErrors = new ArrayList<>();

		when(this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(any(ChangeEmailAddressRequest.class)))
				.thenReturn(changeEmailAddressResponse1);
		changeEmailAddressResponseWithoutErrors.add(changeEmailAddressResponse1);
		
		when(this.changeEmailAddressServiceImpl.requestForChangeEmailAddress(any(ChangeEmailAddressRequest.class)))
				.thenReturn(changeEmailAddressResponse2);
		changeEmailAddressResponseWithErrors.add(changeEmailAddressResponse2);

		response.setChangeEmailAddressResponse(changeEmailAddressResponseWithoutErrors);
		response.setChangeEmailAddressResponseWithErrors(changeEmailAddressResponseWithErrors);

		when(this.changeEmailAddressBatchServiceImpl
				.requestForBatchChangeEmailAddress(any(ChangeEmailAddressBatchRequest.class))).thenReturn(response);

		assertEquals(response.toString(),
				this.changeEmailAddressBatchServiceImpl.requestForBatchChangeEmailAddress(request).toString());

	}

}
