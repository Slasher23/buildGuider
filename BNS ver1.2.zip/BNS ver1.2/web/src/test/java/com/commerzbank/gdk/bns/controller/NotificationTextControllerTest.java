package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.NotificationTextService;

/**
 * JUnit test for NotificationText controller
 * 
 * @author ZE2MACL
 * @since 14/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 29/11/2017        1.01       ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class NotificationTextControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

    @Mock
    private NotificationTextService notificationTextService;

    @InjectMocks
    private NotificationTextController notificationTextController;

    private MockMvc mockMvc;

    private Parameter parameter;

    private NotificationText notificationText;

    private ResponseBuilder<NotificationText> builder;

    private Tokenizer token;
    
    private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(NotificationTextController.class);

    @Before
    public void initTest() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(notificationTextController).build();

        parameter = new Parameter();
        parameter.setEventId(1L);
        parameter.setEventType("test");

        notificationText = new NotificationText();
        notificationText.setEventID(1L);
        notificationText.setEventType("test");
        notificationText.setNotificationTextType("test");
        notificationText.setNotificationTextUID(1L);
        notificationText.setText("Test text");

        token = new Tokenizer();
        token.setUserId("test");
        token.setProcessRunID("test123");
        token.setError(false);

        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<NotificationText>(logger, token, globalRWrapper);
    }

    @Test
    public void getNotificationText_JSONResponseCode_Test() throws Exception {

        when(notificationTextService.getNotifText(any(Tokenizer.class), anyString(), anyLong()))
                .thenReturn(builder.OK(notificationText));

        mockMvc.perform(post("/api/notifText").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());

    }

    @Test
    public void getNotificationText_JSON_Test() throws Exception {

        when(notificationTextService.getNotifText(any(Tokenizer.class), anyString(), anyLong()))
                .thenReturn(builder.OK(notificationText));

        mockMvc.perform(post("/api/notifText").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isOk());
    }

}
