package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.BatchUpdatePersonResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePerson;
import com.commerzbank.gdk.bns.model.RequestForUpdatePersonRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePersonService;

/**
 * JUnit test class for RequestForUpdatePersonController
 * 
 * @since 27/11/2017
 * @author ZE2MENY
 * @version 1.02
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 27/11/2017      1.00      ZE2MENY    Initial Version
 * 29/11/2017      1.01      ZE2MENY    Added method for batch processing
 * 4/12/2017       1.02      ZE2MENY    Refactor to use BatchUpdatePersonResponse
 *          </pre>
 */

@EnableWebMvc
public class RequestForUpdatePersonControllerTest {

    private MockMvc mockMvc;

    private Person person = new Person();

    @Mock
    private RequestForUpdatePersonService requestForUpdatePersonServiceMock;

    @InjectMocks
    private RequestForUpdatePersonController requestForUpdatePersonControllerMock;

    RequestForUpdatePersonRequest request = new RequestForUpdatePersonRequest();

    BatchUpdatePersonResponse              response = new BatchUpdatePersonResponse();
    List<RequestForUpdatePersonRequest> requestList;

    ZslUpdateResponse updatePersonresponse = new ZslUpdateResponse();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(requestForUpdatePersonControllerMock).build();

        request.setBpkenn("BPKENNTEST");
        request.setFirstName("test");
        request.setLastName("testa");

        Person person = new Person();
        person.setBPKENN("BPKENNTEST");
        person.setGivenName("Arianne");
        person.setLastName("Mendoza");

        requestList = new ArrayList<RequestForUpdatePersonRequest>();
        requestList.add(request);

    }

    @Test
    public void requestForUpdatePerson_Json_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForUpdatePerson").contentType(MediaType.APPLICATION_JSON)
                .content(Parser.asJsonString(person))).andExpect(status().isOk());

    }

    @Test
    public void requestForUpdatePerson_Xml_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForUpdatePerson").contentType(MediaType.APPLICATION_XML)
                .content(Parser.jaxbObjectToXML(person, Person.class))).andExpect(status().isOk());

    }

    @Test
    public void requestForBatchUpdatePerson_JSON_Test() throws Exception {

        RequestForBatchUpdatePerson batchRequest = new RequestForBatchUpdatePerson();
        batchRequest.setUpdatePersonRequest(requestList);
        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdatePerson").content(Parser.asJsonString(batchRequest))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
        
    }

    @Test
    public void requestForBatchUpdatePerson_XML_Test() throws Exception {

        RequestForBatchUpdatePerson batchRequest = new RequestForBatchUpdatePerson();
        batchRequest.setUpdatePersonRequest(requestList);
        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdatePerson").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(batchRequest))).andExpect(status().isOk());

    }

}
