package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit test class for AgreementConfigServiceImpl
 * 
 * @since 23/10/2017
 * @author ZE2CRUH
 * @version 1.02
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 23/10/2017      1.00      ZE2CRUH    Initial Version
 * 15/11/2017      1.01      ZE2MACl    Updated method to used response builder and added token parameter
 * 27/11/2017      1.02      ZE2MORA   	Updated for Status Code Implementation
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class AgreementConfigServiceImplTest {
	

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Mock
	private Environment environment;

	@Mock
	private NotificationTextDAO notificationTextDAO;

	@InjectMocks
	private AgreementConfigServiceImpl agreementConfigServiceImpl;

	private AgreementConfig agreementConfig;
	
	private NotificationConfigAgreement notificationConfigAgreement;
	
	private List<NotificationConfigAgreement> notificationConfigAgreementList;
	
	private Tokenizer token;
	
	private ResponseBuilder<AgreementConfig> agreementBuilder;
	
	private ResponseBuilder<NotificationConfigAgreement> notifConfigAgreementBuilder;
	
	private ResponseBuilder<List<NotificationConfigAgreement>> notifConfigAgreementBuilderList;
	
	private Map<Integer, String> statusCodesMap;
	
	private static final Logger logger = LoggerFactory.getLogger(AgreementConfigServiceImpl.class);

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		notificationConfigAgreement = new NotificationConfigAgreement();
		notificationConfigAgreement.setActive(true);
		notificationConfigAgreement.setAgreementUID(1L);
		notificationConfigAgreement.setEmailUID(1L);
		notificationConfigAgreement.setInformationChannelUID(1L);
		notificationConfigAgreement.setNotifConfigAgreementUID(1L);
		notificationConfigAgreement.setNotificationTextUID(1L);
		notificationConfigAgreementList = new ArrayList<NotificationConfigAgreement>();
		notificationConfigAgreementList.add(notificationConfigAgreement);
		agreementConfig = new AgreementConfig();
		agreementConfig.setNotificationConfigAgreement(notificationConfigAgreementList);
		token = new Tokenizer();
		token.setUserId("123");

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		// agreementBuilder.OK(agreementConfig);

	}

	@Test
	public void postCustomer_Success_Test() throws Exception {
		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.OK(notificationConfigAgreement);

		when(this.notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class)))
				.thenReturn(notificationConfigAgreement);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.postCustomer(token, notificationConfigAgreement).toString());
	}

	@Test
	public void postCustomer_DataAccessException_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(this.notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class)))
				.thenThrow(new DataAccessException("DataAccessException") {
					private static final long serialVersionUID = 1L;
				});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.postCustomer(token, notificationConfigAgreement).toString());
	}

	@Test
	public void postCustomer_NullPointerException_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(this.notificationConfigAgreementDAO.save(any(NotificationConfigAgreement.class)))
				.thenThrow(new NullPointerException("NullPointerException") {
					private static final long serialVersionUID = 1L;
				});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.postCustomer(token, notificationConfigAgreement).toString());
	}

	@Test
	public void getNotifConfigAgreementById_SuccessFoundData_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.OK(notificationConfigAgreement);

		when(this.notificationConfigAgreementDAO.findOne(1L)).thenReturn(notificationConfigAgreement);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementById(token, 1L).toString());
	}

	@Test
	public void getNotifConfigAgreementById_SuccessNotFoundData_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(this.notificationConfigAgreementDAO.findOne(1L)).thenReturn(null);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementById(token, 1L).toString());
	}

	@Test
	public void getNotifConfigAgreementById_DataAccessException_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findOne(1L)).thenThrow(new DataAccessException("DataAccessException") {
			private static final long serialVersionUID = 1L;
		});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementById(token, 1L).toString());
	}

	@Test
	public void getNotifConfigAgreementById_NullPointerException_Test() throws Exception {

		notifConfigAgreementBuilder = new ResponseBuilder<NotificationConfigAgreement>(logger, token, globalRWrapper);

		notifConfigAgreementBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findOne(1L))
				.thenThrow(new NullPointerException("NullPointerException") {
					private static final long serialVersionUID = 1L;
				});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementById(token, 1L).toString());
	}

	@Test
	public void getNotifConfigAgreementList_SuccessFoundData_Test() throws Exception {

		notifConfigAgreementBuilderList = new ResponseBuilder<List<NotificationConfigAgreement>>(logger, token,
				globalRWrapper);

		notifConfigAgreementBuilderList.OK(notificationConfigAgreementList);

		when(this.notificationConfigAgreementDAO.findAll()).thenReturn(notificationConfigAgreementList);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilderList.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementList_SuccessNotFoundData_Test() throws Exception {

		notifConfigAgreementBuilderList = new ResponseBuilder<List<NotificationConfigAgreement>>(logger, token,
				globalRWrapper);

		notifConfigAgreementBuilderList.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);

		when(this.notificationConfigAgreementDAO.findAll()).thenReturn(null);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilderList.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementList_DataAccessException_Test() throws Exception {

		notifConfigAgreementBuilderList = new ResponseBuilder<List<NotificationConfigAgreement>>(logger, token,
				globalRWrapper);

		notifConfigAgreementBuilderList.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findAll()).thenThrow(new DataAccessException("DataAccessException") {
			private static final long serialVersionUID = 1L;
		});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilderList.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementList_NullPointerException_Test() throws Exception {

		notifConfigAgreementBuilderList = new ResponseBuilder<List<NotificationConfigAgreement>>(logger, token,
				globalRWrapper);

		notifConfigAgreementBuilderList.notOK(Response.NULL_POINTER_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findAll()).thenThrow(new NullPointerException("NullPointerException") {
			private static final long serialVersionUID = 1L;
		});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(notifConfigAgreementBuilderList.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementsList_SuccessFoundData_Test() throws Exception {

		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalRWrapper);

		agreementBuilder.OK(agreementConfig);

		when(this.notificationConfigAgreementDAO.findAll()).thenReturn(notificationConfigAgreementList);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(agreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementsList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementsList_SuccessNotFoundData_Test() throws Exception {

		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalRWrapper);

		AgreementConfig result = new AgreementConfig();
		result.setNotificationConfigAgreement(null);
		agreementBuilder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);

		when(this.notificationConfigAgreementDAO.findAll()).thenReturn(null);
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(agreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementsList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementsList_DataAccessException_Test() throws Exception {

		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalRWrapper);

		agreementBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findAll()).thenThrow(new DataAccessException("DataAccessException") {
			private static final long serialVersionUID = 1L;
		});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(agreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementsList(token).toString());
	}

	@Test
	public void getNotifConfigAgreementsList_NullPointerException_Test() throws Exception {

		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalRWrapper);

		agreementBuilder.notOK(Response.NULL_POINTER_EXCEPTION);

		when(this.notificationConfigAgreementDAO.findAll()).thenThrow(new NullPointerException("NullPointerException") {
			private static final long serialVersionUID = 1L;
		});
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);

		assertEquals(agreementBuilder.toString(),
				this.agreementConfigServiceImpl.getNotifConfigAgreementsList(token).toString());
	}

	@Test
	public void postNotifConfigAgreement_SuccessfulNonNullZeroNotifTextUID_Test() throws Exception {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(1L);
		notifText.setEventType("VER");
		notifText.setNotificationTextType("STD");

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("VER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);
		List<NotificationConfigAgreement> notificationConfigAgreementListBefore = new ArrayList<NotificationConfigAgreement>();
		NotificationConfigAgreement notificationConfigAgreementBefore = new NotificationConfigAgreement();
		notificationConfigAgreementBefore.setAgreementUID(1L);
		notificationConfigAgreementBefore.setActive(true);
		notificationConfigAgreementBefore.setEmailUID(1L);
		notificationConfigAgreementBefore.setInformationChannelUID(1L);
		notificationConfigAgreementBefore.setNotifConfigAgreementUID(1L);
		notificationConfigAgreementBefore.setNotificationTextUID(1L);
		notificationConfigAgreementListBefore.add(notificationConfigAgreementBefore);
		AgreementConfig beforeSaving = new AgreementConfig();
		beforeSaving.setNotificationConfigAgreement(notificationConfigAgreementListBefore);
		token = new Tokenizer();
		token.setUserId("123");

		notificationConfigAgreement.setNotificationTextUID(1L);
		notificationConfigAgreementList = new ArrayList<NotificationConfigAgreement>();
		notificationConfigAgreementList.add(notificationConfigAgreement);
		agreementConfig = new AgreementConfig();
		agreementConfig.setNotificationConfigAgreement(notificationConfigAgreementList);


		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalResponseWrapper);
		agreementBuilder.OK(agreementConfig);

		when(environment.getProperty("VERLASSUNGS_TYPE_VER")).thenReturn("VER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigAgreementDAO.save(notificationConfigAgreementListBefore))
				.thenReturn(notificationConfigAgreementList);

		assertEquals(agreementBuilder.toString(),
				agreementConfigServiceImpl.postNotifConfigAgreement(token, beforeSaving).toString());

	}

	
	@Test
	public void postNotifConfigAgreement_SuccessfulNullNotifTextUID_Test() throws Exception {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(1L);
		notifText.setEventType("VER");
		notifText.setNotificationTextType("STD");

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("VER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(null);
		List<NotificationConfigAgreement> notificationConfigAgreementListBefore = new ArrayList<NotificationConfigAgreement>();
		NotificationConfigAgreement notificationConfigAgreementBefore = new NotificationConfigAgreement();
		notificationConfigAgreementBefore.setAgreementUID(1L);
		notificationConfigAgreementBefore.setActive(true);
		notificationConfigAgreementBefore.setEmailUID(1L);
		notificationConfigAgreementBefore.setInformationChannelUID(1L);
		notificationConfigAgreementBefore.setNotifConfigAgreementUID(1L);
		notificationConfigAgreementBefore.setNotificationTextUID(null);
		notificationConfigAgreementListBefore.add(notificationConfigAgreementBefore);
		AgreementConfig beforeSaving = new AgreementConfig();
		beforeSaving.setNotificationConfigAgreement(notificationConfigAgreementListBefore);
		token = new Tokenizer();
		token.setUserId("123");

		notificationConfigAgreement.setNotificationTextUID(null);
		notificationConfigAgreementList = new ArrayList<NotificationConfigAgreement>();
		notificationConfigAgreementList.add(notificationConfigAgreement);
		agreementConfig = new AgreementConfig();
		agreementConfig.setNotificationConfigAgreement(notificationConfigAgreementList);


		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalResponseWrapper);
		agreementBuilder.OK(agreementConfig);

		when(environment.getProperty("VERLASSUNGS_TYPE_VER")).thenReturn("VER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigAgreementDAO.save(notificationConfigAgreementListBefore))
				.thenReturn(notificationConfigAgreementList);
		
		assertEquals(agreementBuilder.toString(),
				agreementConfigServiceImpl.postNotifConfigAgreement(token, beforeSaving).toString());

	}

	@Test
	public void postNotifConfigAgreement_SuccessfulZeroNotifTextUID_Test() throws Exception {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(1L);
		notifText.setEventType("VER");
		notifText.setNotificationTextType("STD");

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("VER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(0L);
		List<NotificationConfigAgreement> notificationConfigAgreementListBefore = new ArrayList<NotificationConfigAgreement>();
		NotificationConfigAgreement notificationConfigAgreementBefore = new NotificationConfigAgreement();
		notificationConfigAgreementBefore.setAgreementUID(1L);
		notificationConfigAgreementBefore.setActive(true);
		notificationConfigAgreementBefore.setEmailUID(1L);
		notificationConfigAgreementBefore.setInformationChannelUID(1L);
		notificationConfigAgreementBefore.setNotifConfigAgreementUID(1L);
		notificationConfigAgreementBefore.setNotificationTextUID(0L);
		notificationConfigAgreementListBefore.add(notificationConfigAgreementBefore);
		AgreementConfig beforeSaving = new AgreementConfig();
		beforeSaving.setNotificationConfigAgreement(notificationConfigAgreementListBefore);
		token = new Tokenizer();
		token.setUserId("123");

		notificationConfigAgreement.setNotificationTextUID(0L);
		notificationConfigAgreementList = new ArrayList<NotificationConfigAgreement>();
		notificationConfigAgreementList.add(notificationConfigAgreement);
		agreementConfig = new AgreementConfig();
		agreementConfig.setNotificationConfigAgreement(notificationConfigAgreementList);


		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalResponseWrapper);
		agreementBuilder.OK(agreementConfig);

		when(environment.getProperty("VERLASSUNGS_TYPE_VER")).thenReturn("VER");
		when(notificationTextDAO.save(any(NotificationText.class))).thenReturn(notifTextSaved);
		when(notificationConfigAgreementDAO.save(notificationConfigAgreementListBefore))
				.thenReturn(notificationConfigAgreementList);
		
		assertEquals(agreementBuilder.toString(),
				agreementConfigServiceImpl.postNotifConfigAgreement(token, beforeSaving).toString());

	}

	@Test
	public void postNotifConfigAgreement_NPException_Test() throws Exception {

		token = new Tokenizer();
		token.setUserId("123");

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalResponseWrapper);
		agreementBuilder.notOK(Response.NULL_POINTER_EXCEPTION);
		
		agreementConfig.setNotificationConfigAgreement(null);

		assertEquals(agreementBuilder.toString(),
				agreementConfigServiceImpl.postNotifConfigAgreement(token, agreementConfig).toString());
	}

	@Test
	public void postNotifConfigAgreement_DTException_Test() throws Exception {

		NotificationText notifText = new NotificationText();
		notifText.setEventID(1L);
		notifText.setEventType("VER");
		notifText.setNotificationTextType("STD");

		NotificationText notifTextSaved = new NotificationText();
		notifTextSaved.setEventID(1L);
		notifTextSaved.setEventType("VER");
		notifTextSaved.setNotificationTextType("STD");
		notifTextSaved.setNotificationTextUID(1L);
		List<NotificationConfigAgreement> notificationConfigAgreementListBefore = new ArrayList<NotificationConfigAgreement>();
		NotificationConfigAgreement notificationConfigAgreementBefore = new NotificationConfigAgreement();
		notificationConfigAgreementBefore.setAgreementUID(1L);
		notificationConfigAgreementBefore.setActive(true);
		notificationConfigAgreementBefore.setEmailUID(1L);
		notificationConfigAgreementBefore.setInformationChannelUID(1L);
		notificationConfigAgreementBefore.setNotifConfigAgreementUID(1L);
		notificationConfigAgreementBefore.setNotificationTextUID(1L);
		notificationConfigAgreementListBefore.add(notificationConfigAgreementBefore);
		AgreementConfig beforeSaving = new AgreementConfig();
		beforeSaving.setNotificationConfigAgreement(notificationConfigAgreementListBefore);
		token = new Tokenizer();
		token.setUserId("123");

		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		agreementBuilder = new ResponseBuilder<AgreementConfig>(logger, token, globalResponseWrapper);
		agreementBuilder.notOK(Response.DATA_ACCESS_EXCEPTION);

		when(environment.getProperty("VERLASSUNGS_TYPE_VER")).thenReturn("VER");
		when(notificationTextDAO.save(any(NotificationText.class)))
				.thenThrow(new DataAccessException("DataAccessException") {
					private static final long serialVersionUID = 1L;
				});
		when(notificationConfigAgreementDAO.save(notificationConfigAgreementBefore))
				.thenThrow(new DataAccessException("DataAccessException") {
					private static final long serialVersionUID = 1L;
				});

		assertEquals(agreementBuilder.toString(),
				agreementConfigServiceImpl.postNotifConfigAgreement(token, beforeSaving).toString());

	}
}
