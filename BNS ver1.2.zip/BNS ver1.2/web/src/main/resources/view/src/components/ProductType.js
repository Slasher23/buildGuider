import React, { Component } from 'react';
import ToggleConfig from './ToggleConfig';
import NotifStore from './../stores/NotifStore.js';
import { HelperService } from '../services';

class ProductType extends Component {
    constructor(props) {
        super(props);
        this.setProductTypeText = this.setProductTypeText.bind(this);
        this.setAgreementToggleText = this.setAgreementToggleText.bind(this);
        this.concatCustomerNames = this.concatCustomerNames.bind(this);

        this.agreementInfoTextTemplate = NotifStore.getAgreementInfoText();
    }

    setProductTypeText() {
        let productType = this.props.productType.agreementType;
        let productTypeText = null;

        switch (productType) {
            case 'KTO':
                productTypeText = this.props.staticTexts.mainHeading_categAccount;
                break;

            case 'KAR':
                productTypeText = this.props.staticTexts.mainHeading_categCards;
                break;

            case 'WP':
                productTypeText = this.props.staticTexts.mainHeading_categSecurities;
                break;

            case 'KRE':
                productTypeText = this.props.staticTexts.mainHeading_categLoans;
                break;

            case 'VOR':
                productTypeText = this.props.staticTexts.mainHeading_categProvision;
                break;

            case 'PER':
                productTypeText = this.props.staticTexts.mainHeading_categPerson;

                break;

            default:
                productTypeText = this.props.staticTexts.mainHeading_categOther;
        }

        return productTypeText;
    }

    setAgreementToggleText(agreement) {
        let agreementInfoText = null;
        let nonPersonAgreementTextTemplate = "";

        const agreementInfoValues = {
            type: agreement.type === null ? "" : agreement.type,
            customerNames: agreement.agreementCustomerNames === null ? "" : this.concatCustomerNames(agreement.agreementCustomerNames),
            number: agreement.agreement
        };

        if (agreementInfoValues.type !== "") {
            nonPersonAgreementTextTemplate = "{type} | ";
        }

        if (agreementInfoValues.customerNames !== "") {
            nonPersonAgreementTextTemplate = nonPersonAgreementTextTemplate + "{customerNames} | ";
        }

        if (agreementInfoValues.number !== "") {
            nonPersonAgreementTextTemplate = nonPersonAgreementTextTemplate + "{number}";
        }

        agreementInfoText = HelperService.parseStr(nonPersonAgreementTextTemplate, agreementInfoValues);

        return agreementInfoText;
    }

    /**
     * Add And/Und if the customernames is below 500
     * Add a suffix if the customernames count is above 500
     * Just return if the customernames is just 1
     * 
     * The checker if string is above 500 is the "," at the end of the customerNames string
     * 
     * @return String customerNames
     */
    concatCustomerNames(customerNames) {

        let conjunction = this.props.staticTexts.conjuction_CustomerNames;
        let suffix = this.props.staticTexts.suffix_CustomerNames;

        if (customerNames.indexOf(",", (customerNames.length - 1)) !== -1) {
            customerNames += " " + suffix;
        } else {
            let customerArray = customerNames.split(",");

            if (customerArray.length === 1) {
                return customerNames.toUpperCase();
            }

            customerArray[customerArray.length - 1] = " " + conjunction + " " + customerArray[customerArray.length - 1];
            customerNames = customerArray.join();
            customerNames = customerNames.replace(", " + conjunction, " " + conjunction);
        }

        return customerNames.toUpperCase();
    }

    render() {
        const products = [];
        let lastIndex = 0;
        if (this.props.productType) {

            if (this.props.productType.agreements) {
                this.props.productType.agreements.map((agreement, index) => {
                    lastIndex = index;
                    let toggleText = this.setAgreementToggleText(agreement);
                    let configObj = {
                        agreementTypeIndex: this.props.index,
                        agreementIndex: index,
                        personFlag: false
                    };

                    let isCustomObj = {
                        textType: agreement.textType
                    };
                    return products.push(
                        <ToggleConfig
                            id={"toggleAgreement" + this.props.index + index}
                            key={index}
                            configObj={configObj}
                            toggleStatus={agreement.notificationConfigAgreement.active}
                            toggleText={toggleText}
                            expandConfig={agreement.expandConfig}
                            config={agreement.notificationConfigAgreement}
                            notificationText={agreement.notificationText}
                            emailList={this.props.emailList}
                            informationChannelList={this.props.informationChannels}
                            staticTexts={this.props.staticTexts}
                            permissions={this.props.permissions}
                            isCustomObj={isCustomObj}
                            hidden={false}/>

                    );
                });
            }

            if (this.props.productType.personConfig) {
                let index = lastIndex + 1;
                let toggleText = HelperService.parseStr(this.agreementInfoTextTemplate.personText, this.props.staticTexts.subHeading_agreementPerson);
                let isCustomObj = {
                    textType: this.props.productType.personConfig.textType
                };
                let configObj = {
                    agreementTypeIndex: 0,
                    agreementIndex: 0,
                    personFlag: true
                };

                products.push(
                    <ToggleConfig
                        id="togglePerson"
                        key={index}
                        configObj={configObj}
                        toggleStatus={this.props.productType.personConfig.notificationConfigPerson.active}
                        toggleText={toggleText}
                        expandConfig={this.props.productType.personConfig.expandConfig}
                        config={this.props.productType.personConfig.notificationConfigPerson}
                        notificationText={this.props.productType.personConfig.notificationText}
                        emailList={this.props.emailList}
                        informationChannelList={this.props.informationChannels}
                        staticTexts={this.props.staticTexts}
                        permissions={this.props.permissions}
                        isCustomObj={isCustomObj}
                        hidden={false}/>
                );

            }

        }

        return (
            <div className="child toggle-div row bns-parent-row">
                <div className="row bns-header-row">
                    <label className="bns-product-type">{this.setProductTypeText() }</label>
                </div>
                {products}
            </div>
        );
    }
}

export default ProductType;
