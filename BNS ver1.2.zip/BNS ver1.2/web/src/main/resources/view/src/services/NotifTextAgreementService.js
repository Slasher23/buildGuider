import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class NotifTextAgreementServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH;
  }

  postNotifTextAgreementConfig(data) {
    return RestService.post(this.url + '/notifText/agreementConfig', data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }

  postNotifTextPersonConfig(data) {
    return RestService.post(this.url + '/notifText/personConfig', data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const NotifTextAgreementService = new NotifTextAgreementServiceClass();

export default NotifTextAgreementService;
