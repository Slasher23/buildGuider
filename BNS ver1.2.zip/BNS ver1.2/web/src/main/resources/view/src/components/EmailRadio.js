import React, { Component } from 'react';

class EmailRadio extends Component {
  constructor(props) {
    super(props);
    this._handleEmailChange = this._handleEmailChange.bind(this);
  }

  _handleEmailChange() {
    this.props.onChange(this.props.email.emailUID);
  }

  render() {

    return (
      <div className="radio bns-radio col">
        <div className="row">
          <div className="col col-lg-radio">
            <label>
              <input
                name={this.props.itemId + '-radio' + this.props.index}
                type="radio"
                value={this.props.email.emailUID}
                onChange={() => this._handleEmailChange() }
                checked={this.props.isChecked}
                disabled={!this.props.isChecked && this.props.disabled}
                />
              <span />
            </label>
          </div>
          <div className="col">
            <p>{this.props.email.emailAddress}</p>
          </div>
        </div>
      </div>
    );
  }
}

export default EmailRadio;
