import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class DataBackpackServiceClass {
    constructor() {
        this.url = ConfigConstants.API_PATH;
    }

    getDatabackpackContents(data) {
        return RestService.post(this.url + '/databackpack', data)
            .then(response => {
                if (RestService.isError(response.code)) {
                    return Promise.reject(response.data);
                } else {
                    return Promise.resolve(response.data);
                }
            })
            .catch(error => Promise.reject(error));
    }

}

const DataBackpackService = new DataBackpackServiceClass();

export default DataBackpackService;
