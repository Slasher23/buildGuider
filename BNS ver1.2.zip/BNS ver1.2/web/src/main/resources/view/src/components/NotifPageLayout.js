import React, { Component } from 'react';
import Modal from './Modal';
import ProductType from './ProductType';
import ToggleConfig from './ToggleConfig';
import { HelperService } from '../services';

class NotifPageLayout extends Component {
    constructor(props) {
        super(props);
        this.hideEncryptionText = this.hideEncryptionText.bind(this);
        this.setProductTypes = this.setProductTypes.bind(this);
        this._cancelClick = this._cancelClick.bind(this);
    }

    componentDidMount() {
        HelperService.initSmoothScrolling();
        this.hideEncryptionText();
    }

    componentDidUpdate() {
        this.hideEncryptionText();
    }

    hideEncryptionText() {
        const hide_encryption_info_text = document.getElementById('encryption-info-text');
        HelperService.addClass(hide_encryption_info_text, 'hidden');
    }

    setProductTypes() {
        let productTypes = [];
        let lastIndex = 0;

        if (this.props.data.agreementInfos.agreementTypes) {
            this.props.data.agreementInfos.agreementTypes.map((agreementType, index) => {
                lastIndex = index;

                return productTypes.push(
                    <ProductType
                        key={index}
                        index={index}
                        productType={agreementType}
                        staticTexts={this.props.data.staticTexts}
                        emailList={this.props.data.agreementInfos.email}
                        informationChannels={this.props.data.agreementInfos.informationChannel}
                        permissions={this.props.data.permissions}
                        />
                );
            });
        }

        if (this.props.data.agreementInfos.personConfigType) {
            productTypes.push(
                <ProductType
                    key={lastIndex + 1}
                    index={lastIndex + 1}
                    productType={this.props.data.agreementInfos.personConfigType}
                    staticTexts={this.props.data.staticTexts}
                    emailList={this.props.data.agreementInfos.email}
                    informationChannels={this.props.data.agreementInfos.informationChannel}
                    permissions={this.props.data.permissions}
                    />
            );
        }

        return productTypes;
    }

    _cancelClick() {
        const redirect_url = HelperService.getParameterByName('redirect_url');
        const hide_encryption_info_text = document.getElementById('encryption-info-text');
        HelperService.addClass(hide_encryption_info_text, 'hidden');

        if (redirect_url) {
            window.location.href = redirect_url;
        } else {
            window.history.back();
        }

    }

    render() {
        let productTypes = this.setProductTypes();

        return (
            <div>
                <div className="col-lg-12">
                    <h1 className="h-01">{this.props.data.staticTexts.title_PageTitle}</h1>
                </div>
                <div className="toggle-div row bns-parent-row">
                    <div className="row bns-header-row">
                        <div className="col col-lg-12">
                            <p>
                                {this.props.data.staticTexts.mainLabel_PageDescription}{' '}
                                <a href="#encryption-info-text" id="encryption-info-link">
                                    {this.props.data.staticTexts.mainLabel_EncryptionInformation}
                                </a>
                            </p>
                        </div>
                    </div>
                    <div className="row bns-middle-row">
                        <div className="col col-lg-12">
                            <div className="bns-noticeText clearfix">
                                <img className="pull-left" src="./assets/images/icon-info.svg" alt="" />
                                <p>
                                    <strong>{this.props.data.staticTexts.mainLabel_Notice}: </strong>{' '}
                                    {this.props.data.staticTexts.mainLabel_NoticeInfo}
                                </p>
                            </div>
                        </div>
                    </div>
                    <ToggleConfig
                        id="allToggleConfig"
                        toggleStatus={this.props.data.agreementInfos.allNotifStatus}
                        toggleText={this.props.data.staticTexts.mainToggle_AllNotifications}
                        expandConfig={this.props.data.agreementInfos.allNotifExpandConfig}
                        config={this.props.data.agreementInfos.allNotificationConfig}
                        emailList={this.props.data.agreementInfos.email}
                        informationChannelList={this.props.data.agreementInfos.informationChannel}
                        staticTexts={this.props.data.staticTexts}
                        permissions={this.props.data.permissions}
                        hidden={this.props.data.agreementInfos.agreementTypes.length > 0 ? false : true}/>
                </div>
                {productTypes}
                <div className="buttons-div row">
                    <div id="encryption-info-text-div" className="col col-lg-10 encryption-info-text f-04">
                        <p id="encryption-info-text" className="hidden">
                            {this.props.data.staticTexts.mainLabel_EncryptionInfoText}
                        </p>
                    </div>
                    <div className="col col-lg-2">
                        <button type="button" className="bns-btn bns-btn-default bns-btn-lg pull-right" onClick={this._cancelClick}>
                            {this.props.data.staticTexts.mainButton_Back}
                        </button>
                    </div>
                </div>

                <button type="button modal-trigger" id="confirmationLayerButton" className="hidden" data-toggle="modal" data-target="#confirmationLayer">Confirmation Modal</button>
                <Modal id="confirmationLayer" type="success" headerText={this.props.data.staticTexts.modalHeading_AppliedSettings} okayText={this.props.data.staticTexts.modalButton_Close} />
            </div>
        );
    }
}

export default NotifPageLayout;
