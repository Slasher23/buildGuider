import AppDispatcher from '../dispatcher/AppDispatcher';
import { NotifConstants } from '../constants/NotifConstants';
import { UrlConstants } from '../constants/UrlConstants';
import { EventEmitter } from 'events';
import { historyPush } from './../services/Router.js';
import {
    AgreementConfigService,
    PersonConfigService,
    AuditLogService,
    NotifTextAgreementService,
    NotifTextService,
    AllNotificationConfigService,
    HelperService
} from '../services';
import _ from 'lodash';

const CHANGE_EVENT = 'change';

const agreementInfoTexts = {
    nonPersonAgreementText: '{type} | {customerNames} |  {number}',
    personText: '{defaultText}',
};

// Define the store with initial data
const data = {
    user: null,
    bpkenn: null,
    isLoading: true,
    agreementInfos: {},
    permissions: {},
    staticTexts: {},
    errorMessage: {
        technicalError: 'Es ist ein technischer Fehler aufgetreten.',
        contactList: {
            contact: {
                contact: '069 / 98 66 00 33',
                contact1: '069 / 50 50 27 86',
                contact2: '069 / 66 57 19 99',
                contact3: '01805 / 021 021*',
            },
        }
    }
};

let bnsCif = {}

const readBNSCif = () => {

    if (typeof window !== 'undefined' && window.bnsCif) {
        bnsCif = window.bnsCif;
        data.staticTexts = bnsCif.translatedTexts;
        data.agreementInfos = bnsCif.agreementList;
        data.user = bnsCif.person;

        if (bnsCif.hasError) {
            handleErrorMessage();
        }

    } else {
        handleErrorMessage();
    }
};

const setPermissions = () => {
    let bnsToken = bnsCif.bnsToken;

    if (bnsToken === null) {
        handleErrorMessage();
    } else {
        let bnsTokenDecoded = Buffer.from(unescape(bnsToken), 'base64').toString();

        try {
            let splitToken = bnsTokenDecoded.split("|");
            bnsCif.role = splitToken[0];
        }
        catch (err) {
            handleErrorMessage();
        }

        let role = bnsCif.role;

        if (role.indexOf('PK-WEB') > -1) {
            data.permissions.enableToggle = true;
            data.permissions.enableEmailChange = true;
            data.permissions.enableSave = true;
            data.permissions.enableTextEdit = true;
        } else if (role.indexOf('FILIALE') > -1) {
            data.permissions.enableToggle = true;
            data.permissions.enableEmailChange = true;
            data.permissions.enableSave = true;
            data.permissions.enableTextEdit = false;
        } else {
            data.permissions.enableToggle = false;
            data.permissions.enableEmailChange = false;
            data.permissions.enableSave = false;
            data.permissions.enableTextEdit = false;
        }

    }

}

const validateEmail = () => {

    if (bnsCif.hasEmail) {
        data.isLoading = false;
        setPermissions();
        setAllNotifStatus();
        initSaveStates();
        NotifStore.emitChange();
    } else {
        HelperService.clickElement('#noEmailErrorButton');
    }

};

const toggleAllNotif = () => {
    const allNotifStatusValue = data.agreementInfos.allNotifStatus;
    data.agreementInfos.allNotifStatus = !allNotifStatusValue;
    let notificationConfigAgreement = [];
    let { agreementTypes } = data.agreementInfos;

    _.forEach(agreementTypes, agreementType => {
        let { agreements } = agreementType;
        _.forEach(agreements, agreement => {
            agreement.notificationConfigAgreement.active = data.agreementInfos.allNotifStatus;

            if (!agreement.active) {
                agreement.expandConfig = false;
            }

            agreement.toggleSaving = true;
            notificationConfigAgreement.push(agreement.notificationConfigAgreement);
        });
    });

    AgreementConfigService.postConfig({ notificationConfigAgreement })
        .then(res => {
            if (res) {
                _.forEach(agreementTypes, agreementType => {
                    let { agreements } = agreementType;
                    _.forEach(agreements, agreement => {
                        agreement.toggleSaving = false;
                        let agreementIndex = _.findIndex(res.notificationConfigAgreement, {
                            agreementUID: agreement.notificationConfigAgreement.agreementUID,
                            informationChannelUID: agreement.notificationConfigAgreement.informationChannelUID,
                        });
                        agreement.notificationConfigAgreement = res.notificationConfigAgreement[agreementIndex];
                    });
                });

                let notificationConfigPerson = data.agreementInfos.personConfigType.personConfig.notificationConfigPerson;
                notificationConfigPerson.active = data.agreementInfos.allNotifStatus;
                let personConfig = data.agreementInfos.personConfigType.personConfig;

                if (!notificationConfigPerson.active) {
                    personConfig.expandConfig = false;
                }
                personConfig.toggleSaving = true;

                PersonConfigService.postConfig({ notificationConfigPerson })
                    .then(res => {
                        if (res) {
                            personConfig.toggleSaving = false;
                            personConfig.notificationConfigPerson = res.notificationConfigPerson;
                            const notifTextLog = {
                                eventType: 1001,
                                oldValue: allNotifStatusValue ? 'true' : 'false',
                                newValue: data.agreementInfos.allNotifStatus ? 'true' : 'false',
                                userID: data.user.personUID,
                                bpkenn: data.bpkenn
                            };
                            AuditLogService.postLog(notifTextLog);
                            NotifStore.emitChange();
                        } else {
                            handleErrorMessage(res);
                        }
                    })
                    .catch(handleErrorMessage);
            } else {
                handleErrorMessage(res);
            }
        })
        .catch(handleErrorMessage);
};

const clickAllConfig = () => {
    data.agreementInfos.allNotifExpandConfig = !data.agreementInfos.allNotifExpandConfig
    NotifStore.emitChange();
};

const cancelAllConfig = () => {
    data.agreementInfos.allNotifExpandConfig = false;
    NotifStore.emitChange();
};

const saveAllConfig = (request) => {
    const initialConfig = _.cloneDeep(data.agreementInfos.allNotificationConfig);
    const newConfig = _.cloneDeep(data.agreementInfos.allNotificationConfig);
    newConfig.emailUID = request.emailUID;
    newConfig.informationChannelUID = request.informationChannelUID;

    AllNotificationConfigService.postAllConfig(newConfig)
        .then(res => {
            if (res) {
                data.agreementInfos = res;
                setAllNotifStatus();
                initSaveStates();
                document.getElementById('confirmationLayerButton').click();
                const oldEmailObj = _.find(data.agreementInfos.email, { emailUID: initialConfig.emailUID });
                const newEmailObj = _.find(data.agreementInfos.email, { emailUID: newConfig.emailUID });
                const emailLog = {
                    eventType: 1007,
                    oldValue: oldEmailObj.emailAddress,
                    newValue: newEmailObj.emailAddress,
                    userID: data.user.personUID,
                    objectID: newConfig.allNotificationConfigUID,
                    bpkenn: data.bpkenn
                };
                AuditLogService.postLog(emailLog);
                NotifStore.emitChange();
            } else {
                handleErrorMessage(res);
            }
        })
        .catch(handleErrorMessage);
};

const toggleAgreementNotif = notifObj => {
    if (notifObj.personFlag === true) {
        const personConfigType = data.agreementInfos.personConfigType;
        const personConfig = personConfigType.personConfig;
        let notificationConfigPerson = data.agreementInfos.personConfigType.personConfig.notificationConfigPerson;
        const personNotifStatus = notificationConfigPerson.active;

        personConfig.notificationConfigPerson.active = !personNotifStatus;

        setAllNotifStatus();
        if (!personConfig.notificationConfigPerson.active) {
            personConfig.expandConfig = false;
        }
        personConfig.toggleSaving = true;

        PersonConfigService.postConfig({ notificationConfigPerson })
            .then(res => {
                if (res) {
                    personConfig.toggleSaving = false;
                    personConfig.notificationConfigPerson = res.notificationConfigPerson;

                    const notifTextLog = {
                        eventType: 1008,
                        oldValue: personNotifStatus ? 'true' : 'false',
                        newValue: personConfig.notificationConfigPerson.active ? 'true' : 'false',
                        userID: data.user.personUID,
                        objectID: personConfig.notificationConfigPerson.personUID,
                        bpkenn: data.bpkenn
                    };
                    AuditLogService.postLog(notifTextLog);

                    NotifStore.emitChange();
                } else {
                    handleErrorMessage(res);
                }
            })
            .catch(handleErrorMessage);
    } else {
        const agreementType = data.agreementInfos.agreementTypes[notifObj.agreementTypeIndex];
        const agreement = agreementType.agreements[notifObj.agreementIndex];

        const agreementNotifStatus = agreement.notificationConfigAgreement.active;
        agreement.notificationConfigAgreement.active = !agreementNotifStatus;

        setAllNotifStatus();
        if (!agreement.notificationConfigAgreement.active) {
            agreement.expandConfig = false;
        }
        agreement.toggleSaving = true;

        let notificationConfigAgreement = [];
        notificationConfigAgreement.push(agreement.notificationConfigAgreement);

        let individualConfig = {
            notificationConfigAgreement,
        };

        AgreementConfigService.postConfig(individualConfig)
            .then(res => {

                if (res) {
                    agreement.toggleSaving = false;
                    agreement.notificationConfigAgreement = res.notificationConfigAgreement[0];

                    const notifTextLog = {
                        eventType: 1002,
                        oldValue: agreementNotifStatus ? 'true' : 'false',
                        newValue: agreement.notificationConfigAgreement.active ? 'true' : 'false',
                        userID: data.user.personUID,
                        objectID: agreement.notificationConfigAgreement.agreementUID,
                        bpkenn: data.bpkenn
                    };
                    AuditLogService.postLog(notifTextLog);
                    NotifStore.emitChange();
                } else {
                    handleErrorMessage(res);
                }
            })
            .catch(handleErrorMessage);
    }
};

const clickAgreementStiff = notifObj => {

    if (notifObj.personFlag === true) {
        const agreement = data.agreementInfos.personConfigType.personConfig;
        agreement.expandConfig = !agreement.expandConfig;

        if (agreement.expandConfig) {

            if (agreement.textType !== 'STD') {
                let eventType = 'PER';
                let eventID = agreement.notificationConfigPerson.personUID;

                NotifTextService.getNotifText(eventType, eventID)
                    .then(res => {

                        if (res) {
                            agreement.notificationText = res;
                            NotifStore.emitChange();
                        } else {
                            handleErrorMessage(res);
                        }

                    })
                    .catch(handleErrorMessage);

            } else {
                NotifStore.emitChange();
            }

        } else {
            NotifStore.emitChange();
        }

    } else {
        const agreementType = data.agreementInfos.agreementTypes[notifObj.agreementTypeIndex];
        const agreement = agreementType.agreements[notifObj.agreementIndex];
        agreement.expandConfig = !agreement.expandConfig;

        if (agreement.expandConfig) {

            if (agreement.textType !== 'STD') {
                let eventType = 'VER';
                let eventID = agreement.notificationConfigAgreement.agreementUID;

                NotifTextService.getNotifText(eventType, eventID)
                    .then(res => {
                        if (res.errorMessage) {
                            data.errorMessage = res.errorMessage;
                            historyPush(UrlConstants.ERROR_PAGE);
                        } else if (res) {
                            agreement.notificationText = res;
                            agreement.expandConfig = true;
                            NotifStore.emitChange();
                        } else {
                            handleErrorMessage(res);
                        }
                    })
                    .catch(handleErrorMessage);

            } else {
                NotifStore.emitChange();
            }

        } else {
            NotifStore.emitChange();
        }

    }
};

const cancelNotifConfig = notifObj => {
    if (notifObj.personFlag === true) {
        data.agreementInfos.personConfigType.personConfig.expandConfig = false;
        NotifStore.emitChange();
    } else {
        data.agreementInfos.agreementTypes[notifObj.agreementTypeIndex].agreements[
            notifObj.agreementIndex
        ].expandConfig = false;
        NotifStore.emitChange();
    }
};

const saveNotifConfig = (notifObj, notifConfig) => {
    if (notifObj.personFlag === true) {
        const agreementType = data.agreementInfos.personConfigType;
        const agreement = agreementType.personConfig;
        const notificationConfigPerson = agreement.notificationConfigPerson;
        const initialConfig = notifConfig.initialConfig;
        const newConfig = notifConfig.newConfig;
        const diff = _.differenceWith([initialConfig], [newConfig], _.isEqual);

        if (diff.length > 0) {
            const oldEmail = initialConfig.emailUID;
            const newEmail = newConfig.emailUID;
            const stdText = data.staticTexts.subTextArea_DefaultText;
            const oldTxt = initialConfig.text;
            const newText = newConfig.text;
            const text = stdText !== newText ? newText : null;
            const configData = {
                personUID: notificationConfigPerson.personUID,
                active: notificationConfigPerson.active,
                informationChannelUID: null,
                emailUID: newEmail,
                text: text,
            };
            NotifTextAgreementService.postNotifTextPersonConfig(configData)
                .then(res => {
                    if (res) {
                        notificationConfigPerson.emailUID = res.notificationConfigPerson.emailUID;
                        notificationConfigPerson.notificationTextUID = res.notificationConfigPerson.notificationTextUID;
                        notificationConfigPerson.active = res.notificationConfigPerson.active;
                        notificationConfigPerson.informationChannelUID = res.notificationConfigPerson.informationChannelUID;
                        agreement.textType = res.notificationText.notificationTextType;
                        document.getElementById('confirmationLayerButton').click();
                        agreement.expandConfig = false;

                        if (oldEmail !== newEmail) {
                            const oldEmailObj = _.find(data.agreementInfos.email, { emailUID: oldEmail });
                            const newEmailObj = _.find(data.agreementInfos.email, { emailUID: newEmail });
                            const emailLog = {
                                eventType: 1010,
                                oldValue: oldEmailObj.emailAddress,
                                newValue: newEmailObj.emailAddress,
                                userID: data.user.personUID,
                                objectID: notificationConfigPerson.notifConfigPersonUID,
                                bpkenn: data.bpkenn
                            };
                            AuditLogService.postLog(emailLog);
                        }

                        if (oldTxt !== newText) {
                            const notifTextLog = {
                                eventType: 1009,
                                oldValue: oldTxt,
                                newValue: newText,
                                userID: data.user.personUID,
                                objectID: notificationConfigPerson.notifConfigPersonUID,
                                bpkenn: data.bpkenn
                            };
                            AuditLogService.postLog(notifTextLog);
                        }

                        NotifStore.emitChange();
                    }
                })
                .catch(handleErrorMessage);
        } else {
            agreement.expandConfig = false;
            NotifStore.emitChange();
        }
    } else {
        const agreementType = data.agreementInfos.agreementTypes[notifObj.agreementTypeIndex];
        const agreement = agreementType.agreements[notifObj.agreementIndex];
        const notificationConfigAgreement = agreement.notificationConfigAgreement;
        const initialConfig = notifConfig.initialConfig;
        const newConfig = notifConfig.newConfig;
        const diff = _.differenceWith([initialConfig], [newConfig], _.isEqual);

        if (diff.length > 0) {
            const oldEmail = initialConfig.emailUID;
            const newEmail = newConfig.emailUID;
            const stdText = data.staticTexts.subTextArea_DefaultText;
            const oldTxt = initialConfig.text;
            const newText = newConfig.text;
            const text = stdText !== newText ? newText : null;
            const configData = {
                agreementUID: notificationConfigAgreement.agreementUID,
                active: notificationConfigAgreement.active,
                informationChannelUID: null,
                emailUID: newEmail,
                text: text,
            };
            NotifTextAgreementService.postNotifTextAgreementConfig(configData)
                .then(res => {
                    if (res) {
                        notificationConfigAgreement.emailUID = res.notificationConfigAgreement.emailUID;
                        notificationConfigAgreement.notificationTextUID = res.notificationConfigAgreement.notificationTextUID;
                        notificationConfigAgreement.active = res.notificationConfigAgreement.active;
                        notificationConfigAgreement.informationChannelUID = res.notificationConfigAgreement.informationChannelUID;
                        agreement.textType = res.notificationText.notificationTextType;
                        document.getElementById('confirmationLayerButton').click();
                        agreement.expandConfig = false;

                        if (oldEmail !== newEmail) {
                            const oldEmailObj = _.find(data.agreementInfos.email, { emailUID: oldEmail });
                            const newEmailObj = _.find(data.agreementInfos.email, { emailUID: newEmail });
                            const emailLog = {
                                eventType: 1003,
                                oldValue: oldEmailObj.emailAddress,
                                newValue: newEmailObj.emailAddress,
                                userID: data.user.personUID,
                                objectID: notificationConfigAgreement.agreementUID,
                                bpkenn: data.bpkenn
                            };
                            AuditLogService.postLog(emailLog);
                        }

                        if (oldTxt !== newText) {
                            const notifTextLog = {
                                eventType: 1004,
                                oldValue: oldTxt,
                                newValue: newText,
                                userID: data.user.personUID,
                                objectID: notificationConfigAgreement.agreementUID,
                                bpkenn: data.bpkenn
                            };
                            AuditLogService.postLog(notifTextLog);
                        }

                        NotifStore.emitChange();
                    }
                })
                .catch(handleErrorMessage);
        } else {
            agreement.expandConfig = false;
            NotifStore.emitChange();
        }
    }
};

const setAllNotifStatus = () => {
    let { agreementTypes } = data.agreementInfos;
    let { personConfigType } = data.agreementInfos;
    let disabledItems = 0;

    if (agreementTypes !== undefined && personConfigType !== undefined) {
        if (!personConfigType.personConfig.notificationConfigPerson.active) {
            disabledItems += 1;
        }
        _.forEach(agreementTypes, agreementType => {
            let { agreements } = agreementType;
            _.forEach(agreements, agreement => {
                if (!agreement.notificationConfigAgreement.active) {
                    disabledItems += 1;
                }
            });
        });
        if (disabledItems > 0) {
            data.agreementInfos.allNotifStatus = 0;
        } else {
            data.agreementInfos.allNotifStatus = 1;
        }
    }
};

const initSaveStates = () => {
    data.agreementInfos.allNotifExpandConfig = false;

    let personConfig = data.agreementInfos.personConfigType.personConfig;

    let { agreementTypes } = data.agreementInfos;

    personConfig.toggleSaving = false;
    personConfig.expandConfig = false;
    personConfig.configSaving = false;

    _.forEach(agreementTypes, agreementType => {
        let { agreements } = agreementType;

        _.forEach(agreements, agreement => {
            agreement.toggleSaving = false;
            agreement.expandConfig = false;
            agreement.configSaving = false;
        });
    });
};

const handleErrorMessage = (err) => {
    data.isLoading = false;
    historyPush(UrlConstants.ERROR_PAGE);
    NotifStore.emitChange();
};

class NotifStoreClass extends EventEmitter {
    emitChange() {
        this.emit(CHANGE_EVENT);
    }

    addChangeListener(callback) {
        this.on(CHANGE_EVENT, callback);
    }

    removeChangeListener(callback) {
        this.removeListener(CHANGE_EVENT, callback);
    }

    getStoreData() {
        return data;
    }

    getBNSCif() {
        return bnsCif;
    }

    getStaticTexts() {
        return data.staticTexts;
    }

    getErrorMessage() {
        return data.errorMessage;
    }

    getAgreementInfoText() {
        return agreementInfoTexts;
    }
}

// Initialize the singleton to register with the
// dispatcher and export for React components
const NotifStore = new NotifStoreClass();

// Register each of the actions with the dispatcher
// by changing the store's data and emitting a
// change
AppDispatcher.register(payload => {
    const action = payload.action;

    switch (action.actionType) {

        case NotifConstants.READ_BNS_CIF:
            readBNSCif();
            break;

        case NotifConstants.VALIDATE_EMAIL:
            validateEmail();
            break;

        case NotifConstants.TOGGLE_ALL_NOTIF:
            toggleAllNotif();
            break;

        case NotifConstants.CLICK_ALL_CONFIG:
            clickAllConfig();
            break;

        case NotifConstants.CANCEL_ALL_CONFIG:
            cancelAllConfig();
            break;

        case NotifConstants.SAVE_ALL_CONFIG:
            saveAllConfig(action.data);
            break;

        case NotifConstants.TOGGLE_AGREEMENT_NOTIF:
            toggleAgreementNotif(action.data);
            break;

        case NotifConstants.CLICK_AGREEMENT_STIFF:
            clickAgreementStiff(action.data);
            break;

        case NotifConstants.CANCEL_NOTIF_CONFIG:
            cancelNotifConfig(action.data);
            break;

        case NotifConstants.SAVE_NOTIF_CONFIG:
            saveNotifConfig(action.notifObj, action.notifConfig);
            break;

        default:
            return true;
    }
});

export default NotifStore;
