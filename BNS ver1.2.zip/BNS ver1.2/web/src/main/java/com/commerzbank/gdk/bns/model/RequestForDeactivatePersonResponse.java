package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * Model Class for Batch deactivate person Update Response
 * 
 * @since 04/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description 
 * 04/12/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "RequestForDeactivatePersonResponse")
public class RequestForDeactivatePersonResponse {

    List<ZslUpdateResponse> deactivatePersonResponse;

    List<ZslUpdateResponse> deactivatePersonResponseWithErrors;

    /**
     * Get Deactivate person Response
     * 
     * @return the deactivatePersonResponse
     */
    public List<ZslUpdateResponse> getDeactivatePersonResponse() {
        return deactivatePersonResponse;
    }

    /**
     * Set Deactivate person Response
     * 
     * @param deactivatePersonResponse the deactivatePersonResponse to set
     */
    public void setDeactivatePersonResponse(List<ZslUpdateResponse> deactivatePersonResponse) {
        this.deactivatePersonResponse = deactivatePersonResponse;
    }

    /**
     * Get Deactivate person Response with errors
     * 
     * @return the deactivatePersonResponseWithErrors
     */
    public List<ZslUpdateResponse> getDeactivatePersonResponseWithErrors() {
        return deactivatePersonResponseWithErrors;
    }

    /**
     * Set Deactivate person Response with errors
     * 
     * @param deactivatePersonResponseWithErrors the deactivatePersonResponseWithErrors to set
     */
    public void setDeactivatePersonResponseWithErrors(List<ZslUpdateResponse> deactivatePersonResponseWithErrors) {
        this.deactivatePersonResponseWithErrors = deactivatePersonResponseWithErrors;
    }

    /* 
     * String for batch deactivate person response.
     * 
     * @return string of request for batch deactivate person response
     */
    @Override
    public String toString() {
        return "RequestForDeactivatePersonResponse [deactivatePersonResponse=" + deactivatePersonResponse
                + ", deactivatePersonResponseWithErrors=" + deactivatePersonResponseWithErrors + "]";
    }
    
}
