package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.NotificationTextService;

/**
 * NotificationTextController Accept request and return the expected record to
 * client.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.09
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 27/09/2017	   1.01		 ZE2SARO    Relationship of agreement and notif text is 1:1
 * 25/09/2017      1.02      ZE2BAUL    Refactoring of GetMapping to PostMapping
 * 28/09/2017      1.03      ZE2BAUL    Applied the logging standards
 * 13/10/2017	   1.04		 ZE2RUBI	Clean Up and Implement JWT
 * 13/11/2017      1.05      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.06      ZE2SARO    Add Validation
 * 09/02/2018      1.07      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.08      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.09      ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */

@RestController
public class NotificationTextController {

    @Autowired
    private NotificationTextService notificationTextService;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationTextController.class);

    /**
     * Accept client request and call the service to retrieve the expected
     * record from database using event type and event id then return also
     * consomes and produces json or xml format.
     * 
     * @param bnsInternal
     *            BNS Internal (Parameter)
     * @return return the notification text.
     * 
     */
    @PostMapping(value = "/api/notifText")
    public ResponseEntity<Response<NotificationText>> getNotificationText(@Valid @RequestBody Parameter data,
            BindingResult result, HttpServletRequest request, Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] getNotificationText({})", token.getUserId(), data.getEventId());

        ResponseBuilder<NotificationText> builder = new ResponseBuilder<NotificationText>(LOGGER, token,
                globalResponseWrapper);

        if (!result.hasErrors() && Tokenizer.validator(token)) {
            builder = this.notificationTextService.getNotifText(token, data.getEventType(), data.getEventId());
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }
}
