package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Informations Kanal(Information Channel) Table
 * 
 * @since 03/07/2017
 * @author ZE2FUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/07/2017        1.01       ZE2FUEN    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * </pre>
 */

@Entity
@Table(name="INFORMATIONS_KANAL")
@XmlRootElement
public class InformationChannel {
	
	@Id
	@Column(name="INFORMATIONS_KANAL_UID")
	@GeneratedValue(generator="INFORMATIONS_KANAL_UID_SEQ")
	@SequenceGenerator(name="INFORMATIONS_KANAL_UID_SEQ", sequenceName="INFORMATIONS_KANAL_SEQ")
	private Long informationChannelUID;
	
	@Size(max = 5)
	@Column(name="INFORMATIONS_KANAL_TYP")
	private String informationChannelType;
	
	/**
	 * Returns the value of Unique Identifier of Information Channel Record
	 * 
	 * @return Long Unique Identifier of Information Channel Record
	 */
	public Long getInformationChannelUID() {
		return informationChannelUID;
	}
	
	/**
	 * Sets the value of Unique Identifier of Information Channel Record
	 * 
	 * @param informationChannelUID Long Unique Identifier of Information Channel Record to set
	 */
	public void setInformationChannelUID(Long informationChannelUID) {
		this.informationChannelUID = informationChannelUID;
	}
	
	/**
	 * Returns the value of Information Channel Type
	 * 
	 * @return String Unique Identifier of Information Channel Record
	 */
	public String getInformationChannelType() {
		return informationChannelType;
	}
	
	/**
	 * Sets the value of Information Channel Type
	 * 
	 * @param informationChannelType String Information Channel Type to set
	 */
	public void setInformationChannelType(String informationChannelType) {
		this.informationChannelType = informationChannelType;
	}
	
	/**
	 * Returns the String representation of Information Channel Model
	 * 
	 * @return String String representation of Information Channel Model
	 */
	@Override
	public String toString() {
		return "InformationChannel [informationChannelUID= " + informationChannelUID + 
			   " , informationChannelType= " + informationChannelType + "]";
	}
	
}
