package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Agreement Configuration
 * This class returns and sets List of Notification Configuration Agreement
 * 
 * @since 03/08/2017
 * @author ZE2MENY
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/08/2017        1.01       ZE2MENY    Initial Version
 * </pre>
 */

@XmlRootElement(name = "notificationConfigAgreement")
public class AgreementConfig {
	
	private List<NotificationConfigAgreement> notificationConfigAgreement;
	
	/**
	 * Returns the List of Notification Configuration Agreement
	 * 
	 * @return List List of Notification Configuration Agreement
	 */
	public List<NotificationConfigAgreement> getNotificationConfigAgreement() {
		return notificationConfigAgreement;
	}
	
	/**
	 * Sets the List of Notification Configuration Agreement
	 * 
	 * @param notificationConfigAgreement List List of Notification Configuration Agreement to set
	 */
	public void setNotificationConfigAgreement(List<NotificationConfigAgreement> notificationConfigAgreement) {
		this.notificationConfigAgreement = notificationConfigAgreement;
	}
	
	/**
	 * Returns the String representation of Agreement Configuration Model
	 * 
	 * @return String String representation of Agreement Configuration Model
	 */
	@Override
	public String toString() {
		return "AgreementConfig [notificationConfigAgreement= " + notificationConfigAgreement + "]";
	}
	
}
