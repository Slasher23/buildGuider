package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.tnv.TnvDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.tnv.Tnv;
import com.commerzbank.gdk.bns.service.StoredProcedureService;

/**
 * Service Implementation Class used to implement the business logic
 * invalidating account.
 * 
 * @since 21/12/2017
 * @author ZE2MENY
 * @version 1.02
 * 
 * <pre>
 * Modified Date    Version     Author      Description
 * 21/12/2017       1.00        ZE2MENY     InitialVersion
 * 27/12/2017       1.01        ZE2MACL     Update method, changed agreement to list and rename variable
 * 05/03/2018       1.02        ZE2BUEN     Update validateAccount method to reflect actual implementation
 * </pre>
 */
@Service
@Transactional
public class StoredProcedureServiceImpl implements StoredProcedureService {

	@Autowired
	private PersonDAO personDAO;

	@Autowired
	private AgreementDAO agreementDAO;

	@Autowired
	private NotificationTextDAO notifTextDAO;

	@Autowired
	private NotificationConfigPersonDAO notifConfigPersonDAO;

	@Autowired
	private NotificationConfigAgreementDAO notifConfigAgreementDAO;

	@Autowired
	private TnvDAO tnvDAO;
	
    @Value("${spring.profiles.active}")
    private String env;

	private static final String OK_CODE_TYPE = "0";
	private static final String OK_CODE_DETAIL = "0000";

	/**
	 * Validate accounts using a given bpkenn, agreementId and sparte.
	 * 
	 * @param bpkenn
	 * @param agreementId
	 * @param sparte
	 * @return String statusId
	 */
	@Override
	public String validateAccount(String bpkenn, String agreementId, Integer sparte) {

		String statusId = BNSConstants.EMPTY_STRING;
		
		Tnv result = new Tnv();

		if (env.equalsIgnoreCase("dev")) {
		    result = this.tnvDAO.callStoredProcedure(bpkenn, agreementId, sparte);
		} else {
		    result.setReturnCodeType(OK_CODE_TYPE);
		    result.setReturnCodeDetail(OK_CODE_DETAIL);
		    result.setStateId("01");
		}

		if (Objects.nonNull(result.getReturnCodeType())) {

			if (result.getReturnCodeType().equalsIgnoreCase(OK_CODE_TYPE)
					&& result.getReturnCodeDetail().equalsIgnoreCase(OK_CODE_DETAIL)) {
				statusId = result.getStateId().trim();
			}

		}

		return statusId;

	}

	/**
	 * Delete person related using a given bpkenn.
	 * 
	 * @param String
	 *            bpkenn
	 * @return String 02
	 */
	@Override
	public void deletePersonRelated(String bpkenn) {

		Person person = this.personDAO.findByBpkennIgnoreCase(bpkenn);

		List<NotificationText> personNotifTextList = this.getPersonRelatedNotifTextList(person.getPersonUID());

		this.personDAO.delete(person.getPersonUID());

		if (!personNotifTextList.isEmpty()) {
			this.notifTextDAO.delete(personNotifTextList);
		}

	}

	/**
	 * Delete agreement related using a given agreementId and sparte.
	 * 
	 * @param String
	 *            agreementId
	 * @param Integer
	 *            sparte
	 * @return String 03
	 */
	@Override
	public void deleteAgreementRelated(String agreementId, Integer sparte) {

		List<Agreement> agreement = this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(agreementId, sparte);

		if (Objects.nonNull(agreement)) {

			List<NotificationText> agreementNotifTextList = this.getAgreementNotifTextList(agreement);

			this.agreementDAO.delete(agreement);

			if (!agreementNotifTextList.isEmpty()) {
				this.notifTextDAO.delete(agreementNotifTextList);
			}
		}

	}

	/**
	 * Retrieve list of Person Related Notification Text
	 * 
	 * @param personUID
	 *            Long Unique Identifier for Person record
	 * @return List<NotificationText> List of Person Related Notification Text
	 */
	private List<NotificationText> getPersonRelatedNotifTextList(Long personUID) {

		List<NotificationText> personRelatedNotifTextList = new ArrayList<>();

		NotificationConfigPerson notificationConfigPerson = this.notifConfigPersonDAO.findByPersonUID(personUID);

		if (Objects.nonNull(notificationConfigPerson)) {

			NotificationText personNotifText = this.notifTextDAO
					.findByNotificationTextUID(notificationConfigPerson.getNotificationTextUID());
			
			if(Objects.nonNull(personNotifText)) {
				personRelatedNotifTextList.add(personNotifText);
			}

		}

		List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);

		List<Long> agreementUIDList = new ArrayList<>();

		for (Agreement agreement : agreementList) {
			agreementUIDList.add(agreement.getAgreementUID());
		}

		if (!agreementUIDList.isEmpty()) {

			List<NotificationConfigAgreement> notificationConfigAgreementList = this.notifConfigAgreementDAO
					.findByAgreementUIDIn(agreementUIDList);

			if (Objects.nonNull(notificationConfigAgreementList)) {

				for (NotificationConfigAgreement notificationConfigAgreement : notificationConfigAgreementList) {
					NotificationText agreementNotifText = this.notifTextDAO
							.findByNotificationTextUID(notificationConfigAgreement.getNotificationTextUID());

					personRelatedNotifTextList.add(agreementNotifText);
				}

			}
		}

		return personRelatedNotifTextList;

	}

	/**
	 * Retrieve list of Agreement Related Notification Text
	 * 
	 * @param agreementList
	 *            List<Agreement> List of Agreement Records
	 * @return List<NotificationText> List of Agreement Related Notification
	 *         Text
	 */
	private List<NotificationText> getAgreementNotifTextList(List<Agreement> agreementList) {

		List<NotificationText> agreementRelatedNotifTextList = new ArrayList<>();

		List<Long> agreementUIDList = new ArrayList<>();

		for (Agreement agreement : agreementList) {
			agreementUIDList.add(agreement.getAgreementUID());
		}

		if (!agreementUIDList.isEmpty()) {

			List<NotificationConfigAgreement> notificationConfigAgreementList = this.notifConfigAgreementDAO
					.findByAgreementUIDIn(agreementUIDList);

			if (Objects.nonNull(notificationConfigAgreementList)) {

				for (NotificationConfigAgreement notificationConfigAgreement : notificationConfigAgreementList) {
					NotificationText agreementNotifText = this.notifTextDAO
							.findByNotificationTextUID(notificationConfigAgreement.getNotificationTextUID());

					agreementRelatedNotifTextList.add(agreementNotifText);
				}

			}
		}

		return agreementRelatedNotifTextList;

	}

}
