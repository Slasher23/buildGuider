package com.commerzbank.gdk.bns.model.db2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Model Class for Key DB2
 * 
 * @since 21/02/2018
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 21/02/2018        1.00       ZE2BUEN    Initial Version
 * 05/03/2018        1.01       ZE2BUEN    Modified data type of count to int
 * </pre>
*/
@Entity
public class KeyDB2 {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long keyDB2UID;

	private String rcd;

	private String sqlCode;

	private String sqlCa;

	private String errorText;

	private int count;

	private String data;

	/**
	 * Returns the value of Unique Identifier of Key DB2 Record
	 * 
	 * @return Long Unique Identifier of Key DB2 Record
	 */
	public Long getKeyDB2UID() {
		return keyDB2UID;
	}

	/**
	 * Sets the value of Unique Identifier of Key DB2 Record
	 * 
	 * @param keyDB2UID
	 *            Long Unique Identifier of Key DB2 Record to set
	 */
	public void setKeyDB2UID(Long keyDB2UID) {
		this.keyDB2UID = keyDB2UID;
	}

	/**
	 * Returns the value of RCD
	 * 
	 * @return String RCD
	 */
	public String getRCD() {
		return rcd;
	}

	/**
	 * Sets the value of RCD
	 * 
	 * @param rcd
	 *            String RCD to set
	 */
	public void setRCD(String rcd) {
		this.rcd = rcd;
	}

	/**
	 * Returns the value of SQL Code
	 * 
	 * @return String SQL Code
	 */
	public String getSqlCode() {
		return sqlCode;
	}

	/**
	 * Sets the value of SQL Code
	 * 
	 * @param sqlCode
	 *            String SQL Code to set
	 */
	public void setSqlCode(String sqlCode) {
		this.sqlCode = sqlCode;
	}

	/**
	 * Returns the value of SQL CA
	 * 
	 * @return String SQL CA
	 */
	public String getSqlCa() {
		return sqlCa;
	}

	/**
	 * Sets the value of SQL CA
	 * 
	 * @param sqlCa
	 *            String SQL CA to set
	 */
	public void setSqlCa(String sqlCa) {
		this.sqlCa = sqlCa;
	}

	/**
	 * Returns the value of Error Text
	 * 
	 * @return String Error Text
	 */
	public String getErrorText() {
		return errorText;
	}

	/**
	 * Sets the value of Error Text
	 * 
	 * @param errorText
	 *            String Error Text to set
	 */
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	/**
	 * Returns the value of Count
	 * 
	 * @return int Count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * Sets the value of Count
	 * 
	 * @param count
	 *            int Count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * Returns the value of Data
	 * 
	 * @return String Data
	 */
	public String getData() {
		return data;
	}

	/**
	 * Sets the value of Data
	 * 
	 * @param data
	 *            String Data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * Returns the String representation of Key DB2 Model
	 * 
	 * @return String String representation of Key DB2 Model
	 */
	@Override
	public String toString() {
		return "KeyDB2 [rcd=" + rcd + ", sqlCode=" + sqlCode + ", sqlCa="
				+ sqlCa + ", errorText=" + errorText + ", count="
				+ count + ", data=" + data + "]";
	}
	
}
