package com.commerzbank.gdk.bns.service;

import java.util.Date;
import java.util.List;

import com.commerzbank.gdk.bns.model.DailyReportLog;

/**
 * Interface used to access the Person
 * 
 * @since 04/01/2017
 * @author ZE2RUBI
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2017        1.00       ZE2RUBI    Initial Version
 *          </pre>
 */
public interface DailyReportLogService {

    DailyReportLog save(DailyReportLog dailyReportLog);

    List<DailyReportLog> getAll();

    void deleteAllByLessThan(Date paramDate);

}
