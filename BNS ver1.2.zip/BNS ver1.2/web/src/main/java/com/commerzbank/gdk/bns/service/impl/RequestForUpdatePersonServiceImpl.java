package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchUpdatePersonResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePerson;
import com.commerzbank.gdk.bns.model.RequestForUpdatePersonRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForUpdatePersonService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement the business logic in
 * RequestForUpdatePerson.
 * 
 * @since 28/11/2017
 * @author ZE2MENY
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00      ZE2MENY    Initial Version
 * 29/11/2017        1.01      ZE2MENY    Added implementation for BatchProcessing
 * 4/12/2017         1.02      ZE2MENY    Refactor to use BatchUpdatePersonResponse
 * 12/12/2017        1.03      ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 12/12/2017        1.04      ZE2BUEN    Refactor/Clean-up of ZSL Status Messages
 * 06/02/2018        1.05      ZE2MACL    Remove throws Exception and add try catch
 * 21/02/2018        1.06      ZE2MACL    Added required field/s validation
 *          </pre>
 */

@Service
@Transactional
public class RequestForUpdatePersonServiceImpl implements RequestForUpdatePersonService {

    private static final Logger LOGGER                         = LoggerFactory
                    .getLogger(RequestForUpdatePersonServiceImpl.class);
    private static final String STATUS_OK                      = "ZSL_STATUS_OK";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS    = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_INVALID_REQUEST      = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_NO_CHANGES_REQ          = "ZSL_STATUS_NO_CHANGES_REQ";
    private static final String STATUS_FA_FAILED_UPDATE_PERSON = "ZSL_STATUS_FA_FAILED_UPDATE_PERSON";
    private static final String EMPTY_STRING                   = "";

    @Autowired
    private Environment environment;

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    /**
     * Updates person record in BNS and returns Update Person response
     * 
     * @param requestForUpdatePersonRequest RequestForUpdatePersonRequest Update
     *            Person Request sent by ZSL.
     * @return ZslUpdateResponse Update Person Response
     */
    @Override
    public ZslUpdateResponse requestForUpdResponse(RequestForUpdatePersonRequest requestForUpdatePersonRequest) {

        final ZslUpdateResponse response = new ZslUpdateResponse();
        String status = EMPTY_STRING;

        try {
            status = isValidRequest(requestForUpdatePersonRequest);
            if (isNullOrEmpty(status)) {

                final Person person = this.personDAO.findByBpkennIgnoreCase(requestForUpdatePersonRequest.getBpkenn());

                if (Objects.nonNull(person)) {
                    if ((Objects.isNull(status) || isNullOrEmpty(status))
                                    && this.isValidRegexRequest(requestForUpdatePersonRequest)) {

                        if (isUpdatable(person, requestForUpdatePersonRequest)) {

                            person.setGivenName(requestForUpdatePersonRequest.getFirstName());
                            person.setLastName(requestForUpdatePersonRequest.getLastName());

                            this.personDAO.save(person);

                            response.setBpkenn(requestForUpdatePersonRequest.getBpkenn());
                            response.setStatus(this.environment.getProperty(STATUS_OK));

                        } else {

                            response.setBpkenn(requestForUpdatePersonRequest.getBpkenn());
                            response.setStatus(this.environment.getProperty(STATUS_NO_CHANGES_REQ));
                        }

                    } else {

                        response.setBpkenn(requestForUpdatePersonRequest.getBpkenn());
                        response.setStatus(status);
                    }

                } else {

                    response.setBpkenn(requestForUpdatePersonRequest.getBpkenn());
                    response.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                }
            } else {

                response.setBpkenn(requestForUpdatePersonRequest.getBpkenn());
                response.setStatus(status);
            }

        } catch (Exception e) {
            response.setStatus(this.environment.getProperty(STATUS_FA_FAILED_UPDATE_PERSON));
            LOGGER.error(e.getMessage(), e);

        }

        return response;
    }

    /**
     * Processes multiple requests to update person records in BNS and returns
     * Batch Update Person response
     * 
     * @param requestForBatchUpdatePersonList RequestForBatchUpdatePerson Batch
     *            Update Person Request sent by ZSL.
     * @return BatchUpdatePersonResponse Batch Update Person Response
     */
    @Override
    public BatchUpdatePersonResponse requestForBatchUpdatePerson(
                    RequestForBatchUpdatePerson requestForBatchUpdatePersonList) {

        final BatchUpdatePersonResponse response = new BatchUpdatePersonResponse();
        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();

        final List<ZslUpdateResponse> updatePersonResponse = new ArrayList<ZslUpdateResponse>();
        final List<ZslUpdateResponse> updatePersonResponseWithErrors = new ArrayList<ZslUpdateResponse>();

        for (RequestForUpdatePersonRequest requestForUpdPersonRequest : requestForBatchUpdatePersonList
                        .getUpdatePersonRequest()) {
            zslUpdateResponse = this.requestForUpdResponse(requestForUpdPersonRequest);

            if (zslUpdateResponse.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))
                            || zslUpdateResponse.getStatus()
                                            .equalsIgnoreCase(this.environment.getProperty(STATUS_NO_CHANGES_REQ))) {
                updatePersonResponse.add(zslUpdateResponse);
            } else {
                updatePersonResponseWithErrors.add(zslUpdateResponse);
            }

        }

        response.setUpdatePersonResponse(updatePersonResponse);
        response.setUpdatePersonResponseWithErrors(updatePersonResponseWithErrors);

        return response;

    }

    /**
     * Method to check the updated firstName and lastName.
     * 
     * @param person Person
     * @param requestForUpdatePersonRequest UpdatePersonRequest
     * @return boolean
     */
    private boolean isUpdatable(Person person, RequestForUpdatePersonRequest requestForUpdatePersonRequest) {
        boolean isUpdatable = true;
        if (person.getGivenName().equals(requestForUpdatePersonRequest.getFirstName())
                        && person.getLastName().equals(requestForUpdatePersonRequest.getLastName())) {
            isUpdatable = false;

        }
        return isUpdatable;
    }

    /**
     * Method to check if string is null or empty.
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
    }

    /**
     * Method to validate data in UpdatePersonRequest.
     * 
     * @param requestForUpdatePersonRequest UpdatePersonREquest
     * @return String
     */
    private String isValidRequest(RequestForUpdatePersonRequest requestForUpdatePersonRequest) {

        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        final boolean nullFirstName = this.isNullOrEmpty(requestForUpdatePersonRequest.getFirstName());
        final boolean nullLastName = this.isNullOrEmpty(requestForUpdatePersonRequest.getLastName());

        if (nullFirstName) {
            invalidFields.add("firstName");
        }

        if (nullLastName) {
            invalidFields.add("lastName");
        }

        if (isNullOrEmpty(requestForUpdatePersonRequest.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;

    }

    /**
     * Method to validate data in UpdatePersonRequest.
     * 
     * @param requestForUpdatePersonRequest UpdatePersonREquest
     * @return boolean
     */
    private boolean isValidRegexRequest(RequestForUpdatePersonRequest requestForUpdatePersonRequest) {

        String firstName = requestForUpdatePersonRequest.getFirstName();
        String lastName = requestForUpdatePersonRequest.getLastName();

        return (firstName.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df\\u0020]*$")
                        && lastName.matches("^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df\\u0020]*$"));

    }

}
