package com.commerzbank.gdk.bns.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.conf.CryptoServiceConfig;
import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.CustomerDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.DatabackpackLog;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.impl.DatabackpackDeserializer;
import com.commerzbank.gdk.bns.service.DatabackpackService;

/**
 * Service Implementation Class used to implement the business logic in converting String Databackpack from CIF to BNS
 * Object
 * 
 * @since 21/12/2017
 * @author ZE2BUEN
 * @version 1.07
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 21/12/2017		1.00		ZE2BUEN 	Initial Version
 * 30/01/2018       1.01        ZE2FARI     Updated code to include parsing of customer names
 * 01/02/2018       1.02        ZE2BUEN     Updated databackpack deserializer implementation
 * 09/02/2018       1.03        ZE2MACL     Removed throws Exception
 * 23/02/2018       1.04        ZE2FARI     Adjust regex pattern for the customername
 * 26/02/2018       1.05        ZE2BUEN     Removed databackpackDeserializer method.
 * 01/03/2018       1.06        ZE2FUEN     Fixed logging of null databackpack.
 * 02/03/2018       1.07        ZE2BUEN     Handling of umlauts on databackpack.
 * </pre>
 */

@Service
public class DatabackpackServiceImpl implements DatabackpackService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DatabackpackServiceImpl.class);

    private static final String PERSON_ADDED = "2000";
    private static final String PERSON_UPDATED = "2001";
    private static final String NOTIF_CONFIG_PERSON_UPDATED = "2002";
    private static final String NOTIF_CONFIG_PERSON_ADDED = "2003";
    private static final String EMAIL_UPDATED = "2004";
    private static final String EMAIL_ADDED = "2005";
    private static final String EMAIL_DELETED = "2006";
    private static final String AGREEMENT_UPDATED = "2007";
    private static final String AGREEMENT_ADDED = "2008";
    private static final String CUSTOMER_NUMBER_ADDED = "2009";
    private static final String CUSTOMER_NUMBER_DELETED = "2010";
    
    private static final String UTF_8 = "UTF-8";
    
    @Value("${CONFIG_EVENT01}")
    private String eventType;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private CustomerDAO customerDAO;

    @Autowired
    private EmailDAO emailDAO;

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Autowired
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    @Autowired
    public CryptoServiceConfig cryptoServiceConfig;

    @Autowired
    private InformationChannelDAO informationChannelDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private NotificationTextDAO notificationTextDAO;

    @Autowired
    private GlobalEventTypeWrapper globalEventType;
    
    @Autowired
    private DatabackpackDeserializer databackpackDeserializer;

    /**
     * Converts String Databackpack from CIF to BNS Object
     * 
     * @param token Tokenizer
     * @param encryptedDatabackpack String
     * @return ResponseBuilder Databackpack BNS Object
     */
    @Override
    public ResponseBuilder<Databackpack> databackpackProcessor(Tokenizer token) {

        ResponseBuilder<Databackpack> builder = new ResponseBuilder<Databackpack>(LOGGER, token, globalResponseWrapper);

        String encryptedDatabackpack = token.getDatabackpack();

        try {

            if (!encryptedDatabackpack.isEmpty()) {

                Databackpack databackpack = this.databackpackDecryptor(encryptedDatabackpack);

                if (Objects.nonNull(databackpack) && Objects.nonNull(databackpack.getEmailList())) {

                    if (databackpack.getIsValid()) {

                        Person person = personDAO.findByBpkennIgnoreCase(token.getBpkenn());

                        if (Objects.nonNull(databackpack.getPerson())) {

                            DatabackpackLog dbpLog = new DatabackpackLog();

                            if (Objects.nonNull(person)) {

                                databackpack.getPerson().setPersonUID(person.getPersonUID());
                                databackpack.getPerson().setBPKENN(person.getBPKENN());

                                if (!person.toString().equals(databackpack.getPerson().toString())) {
                                    dbpLog.setEventType(PERSON_UPDATED);
                                    dbpLog.setBpkenn(token.getBpkenn());
                                    dbpLog.setUser(token.getUserId());
                                    dbpLog.setOldValue(person.toString());
                                    dbpLog.setNewValue(databackpack.getPerson().toString());

                                    this.databackpackLog(dbpLog);

                                    this.personDAO.save(databackpack.getPerson());
                                }

                            } else {

                                databackpack.getPerson().setBPKENN(token.getBpkenn());
                                this.personDAO.save(databackpack.getPerson());

                                dbpLog.setEventType(PERSON_ADDED);
                                dbpLog.setBpkenn(token.getBpkenn());
                                dbpLog.setUser(token.getUserId());
                                dbpLog.setNewValue(databackpack.getPerson().toString());

                                this.databackpackLog(dbpLog);
                            }

                            List<Agreement> agreementFromDB = this.agreementDAO
                                    .getAgreementList(databackpack.getPerson().getPersonUID());
                            List<Agreement> insertableAgreements = this.agreementFilter(token, databackpack,
                                    agreementFromDB, databackpack.getPerson().getPersonUID());

                            if (!insertableAgreements.isEmpty()) {

                                List<Long> updateAgreementUIDs = this.agreementFilterForUpdate(insertableAgreements);

                                this.agreementDAO.save(insertableAgreements);

                                this.newAgreementsDatabackpackLog(token, updateAgreementUIDs, insertableAgreements);

                            }

                            List<Customer> customerFromDB = this.customerDAO
                                    .findByPersonUID(databackpack.getPerson().getPersonUID());
                            List<Customer> insertableCustomers = this.customerFilter(token, databackpack,
                                    customerFromDB, databackpack.getPerson().getPersonUID());

                            if (!insertableCustomers.isEmpty()) {

                                List<Long> updateCustomerUIDs = this.customerFilterForUpdate(insertableCustomers);

                                this.customerDAO.save(insertableCustomers);

                                this.newCustomersDatabackpackLog(token, updateCustomerUIDs, insertableCustomers);

                            }

                            List<Customer> customerForDeletion = this.customerFilterForDeletion(databackpack,
                                    customerFromDB, databackpack.getPerson().getPersonUID());

                            if (!customerForDeletion.isEmpty()) {
                                this.deleteCustomerRecords(token, customerForDeletion);
                            }

                            List<Email> emailFromDB = this.emailDAO
                                    .findByPersonUID(databackpack.getPerson().getPersonUID());
                            List<Email> insertableEmails = this.emailFilter(token, databackpack, emailFromDB,
                                    databackpack.getPerson().getPersonUID());

                            if (!insertableEmails.isEmpty()) {

                                List<Long> updateEmailUIDs = this.emailFilterForUpdate(insertableEmails);

                                this.emailDAO.save(insertableEmails);

                                this.newEmailsDatabackpackLog(token, updateEmailUIDs, insertableEmails);

                            }

                            List<Email> emailsForDeletion = this.emailFilterForDeletion(databackpack, emailFromDB,
                                    databackpack.getPerson().getPersonUID());

                            if (!emailsForDeletion.isEmpty()) {
                                this.deleteEmailRelatedRecords(token, emailsForDeletion);
                            }

                            if (Objects.nonNull(databackpack.getNotificationConfigPerson())) {
                                notifConfigPersonInit(token,
                                        this.emailDAO.getEmailList(databackpack.getPerson().getPersonUID()),
                                        databackpack.getPerson().getPersonUID(),
                                        databackpack.getNotificationConfigPerson().getActive());
                            }

                            builder.OK(databackpack);

                        } else {
                            builder.notOK(Response.DATA_ACCESS_EXCEPTION,
                                    new Exception("Cannot find required Person in the request!"));

                        }

                    } else {
                        builder.notOK(Response.DATA_ACCESS_EXCEPTION,
                                new Exception("Invalid Databackpack in the request!"));
                    }

                } else {
                    DailyReportLog dailyReportLog = new DailyReportLog();
                    dailyReportLog.setEventType(eventType);
                    dailyReportLog.setTimestamp(new Date());
                    this.dailyReportLogDAO.save(dailyReportLog);

                    builder.notOK(Response.MISSING_EMAIL_EXCEPTION,
                            new Exception("Cannot find required Email address in the request!"));
                }

                LOGGER.info("<<= User [{}] databackpackDeserializer({}) request was successfully processed.",
                        token.getUserId(), encryptedDatabackpack);

            } else {
                builder.notOK(Response.DATA_ACCESS_EXCEPTION,
                        new Exception("Cannot find required Databackpack in the request!"));
            }

        } catch (DataAccessException e) {
            LOGGER.info(e.toString());
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        } catch (NullPointerException e) {
            LOGGER.info(e.toString());
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
            LOGGER.info(e.toString());
            builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        return builder;

    }

    /**
     * Decrypts Databackpack String
     * 
     * @param encryptedDatabackpack AES Encoded Databackpack
     * @return String Databackpack String
     */
    @Override
    public Databackpack databackpackDecryptor(String encryptedDatabackpack) {

        String databackpackRaw = this.cryptoServiceConfig.decrypt(encryptedDatabackpack);

		Databackpack databackpack = null;
		
		try {
			databackpack = this.databackpackDeserializer.databackpackDeserializer(new String(databackpackRaw.getBytes(), UTF_8));
		} catch (UnsupportedEncodingException e) {
			LOGGER.error(e.getMessage());
		}

        return databackpack;

    }

    /**
     * Filters Agreement if it is existing in database if not it will be inserted
     * 
     * @param token Tokenizer
     * @param databackpack Decoded Databackpack
     * @param agreements List of agreements from database
     * @param personUID uid of the owner of the agreeement
     * @return List<Agreement> filtered agreeement
     */
    private List<Agreement> agreementFilter(Tokenizer token, Databackpack databackpack, List<Agreement> agreements,
            long personUID) {

        List<Agreement> insertableAgreement = new ArrayList<>();

        if (Objects.isNull(databackpack.getAgreementList())) {
            return insertableAgreement;
        }

        for (Agreement agreementDBP : databackpack.getAgreementList()) {

            DatabackpackLog dbpLog = new DatabackpackLog();

            if (Objects.nonNull(agreements)) {
                for (Agreement agreement : agreements) {
                    if (agreement.getAgreementID().equals(agreementDBP.getAgreementID())) {
                        agreementDBP.setAgreementUID(agreement.getAgreementUID());

                        dbpLog.setOldValue(agreement.toString());

                        break;
                    }
                }
            }

            agreementDBP.setPersonUID(personUID);
            insertableAgreement.add(agreementDBP);

            if (Objects.nonNull(agreementDBP.getAgreementUID())) {
                if (!dbpLog.getOldValue().equals(agreementDBP.toString())) {
                    dbpLog.setEventType(AGREEMENT_UPDATED);
                    dbpLog.setBpkenn(token.getBpkenn());
                    dbpLog.setUser(token.getUserId());
                    dbpLog.setNewValue(agreementDBP.toString());

                    this.databackpackLog(dbpLog);
                }
            }

        }

        return insertableAgreement;
    }

    /**
     * Filters Agreement based on databackpack. Only agreements available in databackpack will be return to UI.
     * 
     * @param databackpack Decoded Databackpack
     * @param agreements List of agreements from database
     * @param personUID uid of the owner of the agreeement
     * @return List<Agreement> filtered agreeement
     */
    public List<Agreement> agreementFilterByDatabackpack(Databackpack databackpack, List<Agreement> agreements,
            long personUID) {

        List<Agreement> finalAgreement = new ArrayList<>();

        if (Objects.isNull(agreements)) {
            return finalAgreement;
        }

        for (Agreement agreement : agreements) {

            boolean isExist = false;
            if (Objects.nonNull(databackpack.getAgreementList())) {
                for (Agreement agreementDBP : databackpack.getAgreementList()) {
                    if (agreement.getAgreementID().equals(agreementDBP.getAgreementID())) {
                        isExist = true;
                    }
                }

                if (isExist) {

                    finalAgreement.add(agreement);
                }
            } else {
                break;
            }

        }

        return finalAgreement;
    }

    /**
     * Filters Agreement UIDs for Update
     * 
     * @param agreements List of insertable agreements
     * @return List<Long> Filtered agreement UIDs
     */
    private List<Long> agreementFilterForUpdate(List<Agreement> agreements) {

        List<Long> updateAgreementUIDs = new ArrayList<>();

        for (Agreement agreement : agreements) {
            if (Objects.nonNull(agreement.getAgreementUID())) {
                updateAgreementUIDs.add(agreement.getAgreementUID());
            }
        }

        return updateAgreementUIDs;

    }

    /**
     * Filters Customer if it is existing in database if not it will be inserted
     * 
     * @param token Tokenizer
     * @param databackpack Decoded Databackpack
     * @param customers List of customer from database
     * @param personUID uid of the owner of the customer
     * @return List<Customer> filtered Customer
     */
    private List<Customer> customerFilter(Tokenizer token, Databackpack databackpack, List<Customer> customers,
            long personUID) {

        List<Customer> insertableCustomer = new ArrayList<>();

        if (Objects.isNull(databackpack.getCustomerList())) {
            return insertableCustomer;
        }

        for (Customer customerDBP : databackpack.getCustomerList()) {

            if (Objects.nonNull(customers)) {
                for (Customer customer : customers) {
                    if (customer.getCustomerNumber().trim().equals(customerDBP.getCustomerNumber().trim())) {
                        customerDBP.setCustomerUID(customer.getCustomerUID());
                        break;
                    }
                }
            }

            customerDBP.setPersonUID(personUID);
            insertableCustomer.add(customerDBP);

        }

        return insertableCustomer;
    }

    /**
     * Filters Customer from DB for deletion
     * 
     * @param databackpack Decoded Databackpack
     * @param customers List of customers from database
     * @param personUID UID of the BPKENN related to the customer number
     * @return List<Customer> Filtered customer
     */
    private List<Customer> customerFilterForDeletion(Databackpack databackpack, List<Customer> customers,
            long personUID) {

        List<Customer> deletableCustomers = new ArrayList<>();

        if (Objects.nonNull(customers)) {
            for (Customer customer : customers) {
                boolean isExisting = false;

                if (Objects.nonNull(databackpack.getCustomerList())) {
                    for (Customer customerDBP : databackpack.getCustomerList()) {
                        if (customerDBP.getCustomerNumber().equals(customer.getCustomerNumber())) {
                            isExisting = true;
                            break;
                        }
                    }
                }

                if (!isExisting) {
                    deletableCustomers.add(customer);
                }
            }

        }

        return deletableCustomers;

    }

    /**
     * Filters Customer UIDs for Update
     * 
     * @param customers List of insertable customers
     * @return List<Long> Filtered customer UIDs
     */
    private List<Long> customerFilterForUpdate(List<Customer> customers) {

        List<Long> updateCustomerUIDs = new ArrayList<>();

        for (Customer customer : customers) {
            if (Objects.nonNull(customer.getCustomerUID())) {
                updateCustomerUIDs.add(customer.getCustomerUID());
            }
        }

        return updateCustomerUIDs;

    }

    /**
     * Filters Email if it is existing in database and get the current UID and updated the details
     * 
     * @param token Tokenizer
     * @param databackpack Decoded Databackpack
     * @param emails List of emails from database
     * @param personUID uid of the owner of the emails
     * @return List<Email> filtered emails
     */
    private List<Email> emailFilter(Tokenizer token, Databackpack databackpack, List<Email> emails, long personUID) {

        List<Email> insertableEmail = new ArrayList<>();

        if (Objects.isNull(databackpack.getEmailList())) {
            return insertableEmail;
        }

        DatabackpackLog dbpLog = new DatabackpackLog();

        for (Email emailDBP : databackpack.getEmailList()) {

            if (Objects.nonNull(emails)) {
                for (Email email : emails) {
                    if (email.getAddressId().equals(emailDBP.getAddressId())) {
                        emailDBP.setEmailUID(email.getEmailUID());

                        dbpLog.setOldValue(email.toString());

                        break;
                    }
                }
            }

            emailDBP.setPersonUID(personUID);
            insertableEmail.add(emailDBP);

            if (Objects.nonNull(emailDBP.getEmailUID())) {
                if (!dbpLog.getOldValue().equals(emailDBP.toString())) {
                    dbpLog.setEventType(EMAIL_UPDATED);
                    dbpLog.setBpkenn(token.getBpkenn());
                    dbpLog.setUser(token.getUserId());
                    dbpLog.setNewValue(emailDBP.toString());

                    this.databackpackLog(dbpLog);
                }
            }

        }

        return insertableEmail;
    }

    /**
     * Filters Emails from DB for deletion
     * 
     * @param databackpack Decoded Databackpack
     * @param emails List of emails from database
     * @param personUID uid of the owner of the emails
     * @return List<Email> filtered emails
     */
    private List<Email> emailFilterForDeletion(Databackpack databackpack, List<Email> emails, long personUID) {

        List<Email> deletetableEmail = new ArrayList<>();

        if (Objects.nonNull(emails)) {
            for (Email email : emails) {
                boolean isExistng = false;

                if (Objects.nonNull(databackpack.getEmailList())) {
                    for (Email emailDBP : databackpack.getEmailList()) {
                        if (email.getAddressId().equals(emailDBP.getAddressId())) {
                            isExistng = true;
                            break;
                        }
                    }
                }

                if (!isExistng) {
                    deletetableEmail.add(email);
                }
            }

        }

        return deletetableEmail;
    }

    /**
     * Filters Email UIDs for Update
     * 
     * @param emails List of insertable emails
     * @return List<Long> Filtered email UIDs
     */
    private List<Long> emailFilterForUpdate(List<Email> emails) {

        List<Long> updateEmailUIDs = new ArrayList<>();

        for (Email email : emails) {
            if (Objects.nonNull(email.getEmailUID())) {
                updateEmailUIDs.add(email.getEmailUID());
            }
        }

        return updateEmailUIDs;

    }
    
    /**
     * Initialise notifConfigPerson details
     * 
     * @param token Tokenizer
     * @param emailList List of Emails
     * @param personUID person identifier
     * @return Databackpack Databackpack BNS Object
     */
    private void notifConfigPersonInit(Tokenizer token, List<Email> emailList, Long personUID, boolean value) {

        NotificationConfigPerson initialPersonConfig = new NotificationConfigPerson();

        DatabackpackLog dbpLog = new DatabackpackLog();

        if (Objects.isNull(this.notificationConfigPersonDAO.findByPersonUID(personUID))) {

            List<InformationChannel> informationChannelList = this.informationChannelDAO.getInformationChannelList();
            // set initial values
            initialPersonConfig.setActive(value);
            initialPersonConfig.setEmailUID(emailList.get(0).getEmailUID());
            initialPersonConfig.setInformationChannelUID(getInitialInfoChannelUID(token, informationChannelList));
            initialPersonConfig.setPersonUID(personUID);

            // check if notiftext has value even there's notifconfig
            NotificationText notifText = notificationTextDAO
                    .getNotifText(environment.getProperty(BNSConstants.PERSON_TYPE_KEY), personUID);

            if (Objects.nonNull(notifText)) {
                initialPersonConfig.setNotificationTextUID(notifText.getNotificationTextUID());

            } else {
                NotificationText newNotifText = new NotificationText();
                newNotifText.setNotificationTextUID(Long.valueOf(0));
                newNotifText.setNotificationTextType(BNSConstants.TEXT_TYPE_STD);
                newNotifText.setEventType("PER");
                newNotifText.setEventID(personUID);

                newNotifText = this.notificationTextDAO.save(newNotifText);

                initialPersonConfig.setNotificationTextUID(newNotifText.getNotificationTextUID());

            }

        } else {

            initialPersonConfig = this.notificationConfigPersonDAO.findByPersonUID(personUID);
            dbpLog.setOldValue(initialPersonConfig.toString());

            initialPersonConfig.setActive(value);
        }

        Boolean isExisting = false;

        if (Objects.nonNull(initialPersonConfig.getNotifConfigPersonUID())) {

            isExisting = true;

            if (!dbpLog.getOldValue().equals(initialPersonConfig.toString())) {
                dbpLog.setEventType(NOTIF_CONFIG_PERSON_UPDATED);
                dbpLog.setBpkenn(token.getBpkenn());
                dbpLog.setUser(token.getUserId());
                dbpLog.setNewValue(initialPersonConfig.toString());

                this.databackpackLog(dbpLog);
            }
        }

        this.notificationConfigPersonDAO.save(initialPersonConfig);

        if (!isExisting) {

            dbpLog.setEventType(NOTIF_CONFIG_PERSON_ADDED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setNewValue(initialPersonConfig.toString());

            this.databackpackLog(dbpLog);

        }

    }

    /**
     * Retrieves the value of Information Channel using a given Unique Identifier.
     * 
     * @param token identifier for the request's user
     * @param informationChannelList list of the InformationChannel
     * @return InfoChannelUID List of Information Channel
     */
    private Long getInitialInfoChannelUID(Tokenizer token, List<InformationChannel> informationChannelList) {

        Long infoChannelUID = null;

        for (InformationChannel informationChannel : informationChannelList) {
            if (informationChannel.getInformationChannelType()
                    .equalsIgnoreCase(environment.getProperty(BNSConstants.INFO_CHANNEL_KEY))) {
                infoChannelUID = informationChannel.getInformationChannelUID();
                break;
            }
        }

        LOGGER.info("<<= User [{}] getInitialInfoChannelUID({}) request was successfully processed.", token.getUserId(),
                informationChannelList.toString());

        return infoChannelUID;

    }

    /**
     * Delete all Email Related Records (Person and Agreement Notification Configuration, Notification Text and Email
     * records)
     * 
     * @param token Tokenizer
     * @param emailsForDeletion List of Emails for Deletion
     */
    private void deleteEmailRelatedRecords(Tokenizer token, List<Email> emailsForDeletion) {

        for (Email email : emailsForDeletion) {

            // delete notif config person
            List<NotificationConfigPerson> personConfigList = notificationConfigPersonDAO
                    .findByEmailUID(email.getEmailUID());

            if (Objects.nonNull(personConfigList)) {
                for (NotificationConfigPerson notificationConfigPerson : personConfigList) {

                    NotificationText personNotifText = notificationTextDAO
                            .findByNotificationTextUID(notificationConfigPerson.getNotificationTextUID());

                    // delete notif text
                    if (Objects.nonNull(personNotifText)) {
                        this.notificationTextDAO.delete(personNotifText.getNotificationTextUID());
                    }

                    this.notificationConfigPersonDAO.delete(notificationConfigPerson.getNotifConfigPersonUID());

                }
            }

            // delete notif config agreement
            List<NotificationConfigAgreement> agreementConfigList = notificationConfigAgreementDAO
                    .findByEmailUID(email.getEmailUID());

            if (Objects.nonNull(agreementConfigList)) {
                for (NotificationConfigAgreement notificationConfigAgreement : agreementConfigList) {

                    NotificationText agreementNotifText = notificationTextDAO
                            .findByNotificationTextUID(notificationConfigAgreement.getNotificationTextUID());

                    // delete notif text
                    if (Objects.nonNull(agreementNotifText)) {
                        this.notificationTextDAO.delete(agreementNotifText.getNotificationTextUID());
                    }

                    this.notificationConfigAgreementDAO
                            .delete(notificationConfigAgreement.getNotifConfigAgreementUID());

                }
            }

            DatabackpackLog dbpLog = new DatabackpackLog();

            dbpLog.setEventType(EMAIL_DELETED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setOldValue(email.toString());

            this.databackpackLog(dbpLog);

            // delete email
            this.emailDAO.delete(email.getEmailUID());

        }

    }

    /**
     * Delete Customer Records
     * 
     * @param token Tokenizer
     * @param customersForDeletion List of Customers for Deletion
     */
    private void deleteCustomerRecords(Tokenizer token, List<Customer> customersForDeletion) {

        for (Customer customer : customersForDeletion) {

            DatabackpackLog dbpLog = new DatabackpackLog();

            dbpLog.setEventType(CUSTOMER_NUMBER_DELETED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setOldValue(customer.toString());

            this.databackpackLog(dbpLog);

            this.customerDAO.delete(customer.getCustomerUID());

        }

    }

    /**
     * Logging of Databackpack Details
     * 
     * @param databackpackLog Databackpack Log
     */
    private void databackpackLog(DatabackpackLog databackpackLog) {

        EventType event = globalEventType.get(databackpackLog.getEventType());

        databackpackLog.setDescription(event.getDescription());

        LOGGER.info("=>> DATABACKPACK LOG: [{}]", databackpackLog.toString());

    }

    /**
     * Logging of New Agreement Details
     * 
     * @param token Tokenizer
     * @param updateAgreementUIDs List of Agreement UIDs for Update
     * @param agreements List of Insertable Agreements
     * 
     */
    private void newAgreementsDatabackpackLog(Tokenizer token, List<Long> updateAgreementUIDs,
            List<Agreement> agreements) {

        List<Agreement> newAgreements = new ArrayList<>();

        for (Agreement agreement : agreements) {

            if (!updateAgreementUIDs.contains(agreement.getAgreementUID())) {
                newAgreements.add(agreement);
            }

        }

        for (Agreement newAgreement : newAgreements) {

            DatabackpackLog dbpLog = new DatabackpackLog();

            dbpLog.setEventType(AGREEMENT_ADDED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setNewValue(newAgreement.toString());

            this.databackpackLog(dbpLog);

        }

    }

    /**
     * Logging of New Customer Details
     * 
     * @param token Tokenizer
     * @param updateCustomerUIDs List of Customer UIDs for Update
     * @param customers List of Insertable Customers
     * 
     */
    private void newCustomersDatabackpackLog(Tokenizer token, List<Long> updateCustomerUIDs, List<Customer> customers) {

        List<Customer> newCustomers = new ArrayList<>();

        for (Customer customer : customers) {

            if (!updateCustomerUIDs.contains(customer.getCustomerUID())) {
                newCustomers.add(customer);
            }

        }

        for (Customer newCustomer : newCustomers) {

            DatabackpackLog dbpLog = new DatabackpackLog();

            dbpLog.setEventType(CUSTOMER_NUMBER_ADDED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setNewValue(newCustomer.toString());

            this.databackpackLog(dbpLog);

        }

    }

    /**
     * Logging of New Email Details
     * 
     * @param token Tokenizer
     * @param updateEmailUIDs List of Email UIDs for Update
     * @param emails List of Insertable Emails
     * 
     */
    private void newEmailsDatabackpackLog(Tokenizer token, List<Long> updateEmailUIDs, List<Email> emails) {

        List<Email> newEmails = new ArrayList<>();

        for (Email email : emails) {

            if (!updateEmailUIDs.contains(email.getEmailUID())) {
                newEmails.add(email);
            }

        }

        for (Email newEmail : newEmails) {

            DatabackpackLog dbpLog = new DatabackpackLog();

            dbpLog.setEventType(EMAIL_ADDED);
            dbpLog.setBpkenn(token.getBpkenn());
            dbpLog.setUser(token.getUserId());
            dbpLog.setNewValue(newEmail.toString());

            this.databackpackLog(dbpLog);

        }

    }

}
