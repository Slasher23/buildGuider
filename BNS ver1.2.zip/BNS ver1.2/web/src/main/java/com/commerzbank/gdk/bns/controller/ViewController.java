package com.commerzbank.gdk.bns.controller;

import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.commerzbank.gdk.bns.model.BNSCif;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementTypesWrapperService;
import com.commerzbank.gdk.bns.service.DatabackpackService;
import com.commerzbank.gdk.bns.service.PersonService;
import com.commerzbank.gdk.bns.service.TranslationService;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * This class handles the controller service that will handle the redirection to
 * index.html upon successful registration of the databackpack
 * 
 * @author ZE2RUBI
 * @since 10/01/2018
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/01/2018        1.00       ZE2RUBI    Initial Version
 * 20/02/2018        1.01       ZE2FUEN    Updated implementation to CIF-Integration
 * 28/02/2018        1.02       ZE2FUEN    Implemented BNStoken builder
 *          </pre>
 */
@Controller
public class ViewController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ViewController.class);

    @Autowired
    public DatabackpackService databackpackService;

    @Autowired
    private AgreementTypesWrapperService agreementTypesWrapperService;

    @Autowired
    private PersonService personService;

    @Autowired
    private TranslationService translationService;

    @Autowired
    public Tools tools;

    @RequestMapping(value = { "/", "register" }, method = RequestMethod.POST, produces = MediaType.TEXT_HTML_VALUE)
    public String register(HttpServletRequest request, HttpServletResponse response, Parameter parameter, Model model,
            Authentication auth) {

        LOGGER.info("Request URL: " + request.getRequestURL().toString());

        List<String> requestParameterNames = Collections.list((Enumeration<String>) request.getParameterNames());
        LOGGER.info("Parameter number: " + requestParameterNames.size());

        for (String parameterName : requestParameterNames) {
            LOGGER.info(
                    "Parameter name: " + parameterName + " - Parameter value: " + request.getParameter(parameterName));
        }

        List<String> requestHeaderNames = Collections.list((Enumeration<String>) request.getHeaderNames());
        LOGGER.info("headerName number: " + requestHeaderNames.size());

        for (String headerName : requestHeaderNames) {
            LOGGER.info("headerName name: " + headerName + " - headerName value: " + request.getHeader(headerName));
        }

        Tokenizer token = Tokenizer.getUserToken(auth);

        BNSCif bnsCif = new BNSCif();
        ResponseBuilder<Map<String, String>> translationResponseBuilder = this.translationService
                .getTranslatedTexts(request, token);

        bnsCif.setBnsToken(null);
        bnsCif.setPerson(null);
        bnsCif.setTranslatedTexts(translationResponseBuilder.getData());
        bnsCif.setAgreementList(null);
        bnsCif.setHasError(true);
        bnsCif.setHasEmail(false);

        if (Objects.nonNull(token) || !token.getError()) {
            String databackpack = parameter.getSignedAndEncryptedDataBackPack();
            token.setDatabackpack(databackpack);
            ResponseBuilder<Databackpack> databackpackResponseBuilder = databackpackService
                    .databackpackProcessor(token);

            if (databackpackResponseBuilder.getCode() == Response.SUCCESS_RESULTS_FOUND) {
                ResponseBuilder<MainAgreementTypeWrapper> agreementsResponseBuilder = this.agreementTypesWrapperService
                        .getMainAgreementTypeWrapperList(token, null);
                ResponseBuilder<Person> personResponseBuilder = this.personService.getPerson(token);

                if (agreementsResponseBuilder.getCode() == Response.SUCCESS_RESULTS_FOUND
                        && personResponseBuilder.getCode() == Response.SUCCESS_RESULTS_FOUND) {

                    MainAgreementTypeWrapper agreementsData = agreementsResponseBuilder.getData();

                    bnsCif.setBnsToken(tools.bnsTokenBuilder(token, agreementsData));
                    bnsCif.setPerson(personResponseBuilder.getData());
                    bnsCif.setAgreementList(agreementsResponseBuilder.getData());
                    bnsCif.setHasError(false);
                    bnsCif.setHasEmail(true);
                }

            } else if (databackpackResponseBuilder.getCode() == Response.MISSING_EMAIL_EXCEPTION) {
                bnsCif.setHasError(false);
                bnsCif.setHasEmail(false);
            }
        }

        model.addAttribute("BNSCif", bnsCif);
        return "index";
    }

}
