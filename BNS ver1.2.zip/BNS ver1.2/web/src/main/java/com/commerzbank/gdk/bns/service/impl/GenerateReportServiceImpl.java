package com.commerzbank.gdk.bns.service.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.supercsv.cellprocessor.FmtDate;
import org.supercsv.cellprocessor.FmtNumber;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.commerzbank.gdk.bns.dao.ReportDAO;
import com.commerzbank.gdk.bns.model.GenerateReportRequest;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.GenerateReportService;

/**
 * Service Implementation Class used to generate CSV report files based on the
 * start date, end date and report type provided.
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2BUEN    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 *          </pre>
 */

@Transactional
@Service
public class GenerateReportServiceImpl implements GenerateReportService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenerateReportServiceImpl.class);

    private static final String RPT001 = "RPT001";
    private static final String RPT002 = "RPT002";
    private static final String RPT003 = "RPT003";
    private static final String RPT004 = "RPT004";
    private static final String RPT005 = "RPT005";
    private static final String RPT006 = "RPT006";
    private static final String RPT007 = "RPT007";

    private static final String HEADER = "_HEADER";

    @Autowired
    Environment environment;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    @Autowired
    private ReportDAO reportDAO;

    private static final String DATE_FORMAT = "dd.MM.yyyy";

    private static final String TIME_FORMAT = "hh:mm";

    private static final String PERCENTAGE_FORMAT = "#.00'%'";

    private static final String COUNT_FORMAT = "#,###";

    private static final CsvPreference PIPE_DELIMITED = new CsvPreference.Builder('"', '|', "\n").build();

    /**
     * Retrieves Report Data
     * 
     * @param token Tokenizer to identify the user
     * @param generateReportRequest GenerateReportRequest Generate Report
     *            Request
     * @return Response Builder
     */
    @Override
    public ResponseBuilder<List<Report>> retrieveReportData(Tokenizer token,
                    GenerateReportRequest generateReportRequest) {

        ResponseBuilder<List<Report>> builder = new ResponseBuilder<List<Report>>(LOGGER, token, globalResponseWrapper);

        try {
            Date startDate = null;
            Date endDate = null;

            String reportType = generateReportRequest.getReportType();

            if (!this.isNullOrEmpty(generateReportRequest.getStartDate())) {
                startDate = this.parseDate(generateReportRequest.getStartDate());
            }

            if (!this.isNullOrEmpty(generateReportRequest.getEndDate())) {
                endDate = this.parseDate(generateReportRequest.getEndDate());
            }

            List<Report> reportList = new ArrayList<>();

            if (this.validateRequest(startDate, endDate, reportType)) {

                reportList = this.reportDAO.getReportList(startDate, endDate, reportType);

            }

            if (!reportList.isEmpty()) {
                builder.OK(reportList);
            } else {
                builder.OK(reportList, Response.SUCCESS_NO_RESULTS_FOUND);
            }

        } catch (DataAccessException dataAccessException) {
            LOGGER.error(dataAccessException.getMessage(), dataAccessException);
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, dataAccessException);
        } catch (NullPointerException nullPointerException) {
            LOGGER.error(nullPointerException.getMessage(), nullPointerException);
            builder.notOK(Response.NULL_POINTER_EXCEPTION, nullPointerException);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        return builder;

    }

    /**
     * Method to validate request
     * 
     * @param startDate Date Start Date
     * @param endDate Date End Date
     * @param reportType String Report Type
     * @return Boolean isValid
     */
    private Boolean validateRequest(Date startDate, Date endDate, String reportType) {

        Boolean isValid = true;
        Boolean validDates = false;

        Boolean nullStartDate = Objects.isNull(startDate);
        Boolean nullEndDate = Objects.isNull(endDate);
        Boolean nullReportType = this.isNullOrEmpty(reportType);

        if (!nullStartDate && !nullEndDate) {
            validDates = this.validateDates(startDate, endDate);
        }

        if (nullStartDate || nullEndDate || nullReportType || !validDates) {
            isValid = false;
        }

        return isValid;

    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return Boolean isNullOrEmpty
     * 
     */
    private Boolean isNullOrEmpty(String stringToCheck) {

        Boolean isNullOrEmpty = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;

        return isNullOrEmpty;

    }

    /**
     * Method to Parse Date
     * 
     * @param dateString String Date in String Format
     * @return Date date
     */
    private Date parseDate(String dateString) {

        Date date = null;

        try {

            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

            date = sdf.parse(dateString);

            if (!dateString.equals(sdf.format(date))) {
                date = null;
            }

        } catch (ParseException ex) {
            LOGGER.error(ex.toString());
        }

        return date;

    }

    /**
     * Method to validate start and end dates
     * 
     * @param startDate Date Start Date
     * @param endDate Date End Date
     * @return Boolean isValid
     */
    private Boolean validateDates(Date startDate, Date endDate) {

        Boolean isValid = false;

        if (startDate.before(endDate) || startDate.equals(endDate)) {
            isValid = true;
        }

        return isValid;

    }

    /**
     * Method to generate CSV File
     * 
     * @param printWriter PrintWriter Print Writer
     * @param reportType String Report Type
     * @param reportList List Report List
     * @param token Tokenizer to identify the user
     * @return ICsvBeanWriter beanWriter
     */
    @Override
    public ICsvBeanWriter generateCSVFile(PrintWriter printWriter, String reportType, List<Report> reportList,
                    Tokenizer token) {

        ICsvBeanWriter beanWriter = null;

        try {
            beanWriter = this.setCSVHeader(printWriter, reportType);

            CellProcessor[] processors = this.getProcessors(reportType);

            for (Report report : reportList) {

                beanWriter.write(report, this.getMappingStrategy(reportType), processors);

            }

            beanWriter.close();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }

        LOGGER.info("<<= User [{}] request was successfully processed.", "Admin");

        return beanWriter;

    }

    /**
     * Method to set CSV Header
     * 
     * @param printWriter PrintWriter Print Writer
     * @param reportType String Report type
     * @return ICsvBeanWriter beanWriter
     */
    private ICsvBeanWriter setCSVHeader(PrintWriter printWriter, String reportType) throws IOException {

        ICsvBeanWriter beanWriter = new CsvBeanWriter(printWriter, PIPE_DELIMITED);
        beanWriter.writeHeader(this.getHeader(reportType));
        beanWriter.writeHeader(this.getColumnHeader(reportType));

        return beanWriter;

    }

    /**
     * Method to get mapping strategy
     * 
     * @param reportType String Report Type
     * @return String[] mappingStrategy
     */
    private String[] getMappingStrategy(String reportType) {

        String[] mappingStrategy = null;

        final String[] mappingStrategy1 = new String[] { "date", "count" };

        final String[] mappingStrategy2 = new String[] { "date", "count", "percentage" };

        final String[] mappingStrategy3 = new String[] { "date", "time", "count" };

        switch (reportType) {

        case RPT001:
            mappingStrategy = mappingStrategy1;
            break;

        case RPT002:
            mappingStrategy = mappingStrategy2;
            break;

        case RPT003:
            mappingStrategy = mappingStrategy2;
            break;

        case RPT004:
            mappingStrategy = mappingStrategy2;
            break;

        case RPT005:
            mappingStrategy = mappingStrategy2;
            break;

        case RPT006:
            mappingStrategy = mappingStrategy3;
            break;

        case RPT007:
            mappingStrategy = mappingStrategy3;
            break;
        }

        return mappingStrategy;

    }

    /**
     * Method to get column header
     * 
     * @param reportType String Report Type
     * @return String[] header
     */
    private String[] getColumnHeader(String reportType) {

        String[] header = null;

        final String[] header1 = new String[] { "Date", "Sum of Users" };

        final String[] header2 = new String[] { "Date", "Sum of Users", "Percent of Total Users" };

        final String[] header3 = new String[] { "Date", "Time", "Sum of Notification" };

        switch (reportType) {

        case RPT001:
            header = header1;
            break;

        case RPT002:
            header = header2;
            break;

        case RPT003:
            header = header2;
            break;

        case RPT004:
            header = header2;
            break;

        case RPT005:
            header = header2;
            break;

        case RPT006:
            header = header3;
            break;

        case RPT007:
            header = header3;
            break;

        }

        return header;

    }

    /**
     * Method to get header
     * 
     * @param reportType String Report Type
     * @return String[] header
     */
    private String getHeader(String reportType) {

        String header = this.environment.getProperty(reportType + HEADER);

        return header;

    }

    /**
     * Method to get cell processor
     * 
     * @param reportType String Report Type
     * @return CellProcessor[] processors
     */
    private CellProcessor[] getProcessors(String reportType) {

        DecimalFormatSymbols decimalSymbols = new DecimalFormatSymbols(Locale.GERMAN);
        decimalSymbols.setDecimalSeparator(',');
        decimalSymbols.setGroupingSeparator('.');

        CellProcessor[] processors = null;

        final CellProcessor[] processor1 = new CellProcessor[] { new FmtDate(DATE_FORMAT),
                new FmtNumber(new DecimalFormat(COUNT_FORMAT, decimalSymbols)) };

        final CellProcessor[] processor2 = new CellProcessor[] { new FmtDate(DATE_FORMAT),
                new FmtNumber(new DecimalFormat(COUNT_FORMAT, decimalSymbols)),
                new FmtNumber(new DecimalFormat(PERCENTAGE_FORMAT, decimalSymbols)) };

        final CellProcessor[] processor3 = new CellProcessor[] { new FmtDate(DATE_FORMAT), new FmtDate(TIME_FORMAT),
                new FmtNumber(new DecimalFormat(COUNT_FORMAT, decimalSymbols)) };

        switch (reportType) {

        case RPT001:
            processors = processor1;
            break;

        case RPT002:
            processors = processor2;
            break;

        case RPT003:
            processors = processor2;
            break;

        case RPT004:
            processors = processor2;
            break;

        case RPT005:
            processors = processor2;
            break;

        case RPT006:
            processors = processor3;
            break;

        case RPT007:
            processors = processor3;
            break;

        }

        return processors;

    }

}
