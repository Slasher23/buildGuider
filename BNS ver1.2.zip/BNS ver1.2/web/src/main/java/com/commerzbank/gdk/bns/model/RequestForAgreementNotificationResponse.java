package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for RequestForAgreementNotificationResponse
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 11/12/2017        1.00       ZE2GOME    Initial Version
 * 14/12/2017        1.01       ZE2MENY    Change customerNotification into agreeementNotifications
 *          </pre>
 */
public class RequestForAgreementNotificationResponse {

    private String vereinbarungskennung;

    private Integer sparte;

    private List<NotificationResponse> agreementNotifications;

    private String status;

    /**
     * @return the vereinbarungskennung
     */
    public String getVereinbarungskennung() {
        return vereinbarungskennung;
    }

    /**
     * @param vereinbarungskennung the vereinbarungskennung to set
     */
    public void setVereinbarungskennung(String vereinbarungskennung) {
        this.vereinbarungskennung = vereinbarungskennung;
    }

    /**
     * @return the sparte
     */
    public Integer getSparte() {
        return sparte;
    }

    /**
     * @param sparte the sparte to set
     */
    public void setSparte(Integer sparte) {
        this.sparte = sparte;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the agreementNotifications
     */
    public List<NotificationResponse> getAgreementNotifications() {
        return agreementNotifications;
    }

    /**
     * @param agreementNotifications the agreementNotifications to set
     */
    public void setAgreementNotifications(List<NotificationResponse> agreementNotifications) {
        this.agreementNotifications = agreementNotifications;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RequestForAgreementNotificationResponse [vereinbarungskennung=" + vereinbarungskennung + ", sparte="
                + sparte + ", agreementNotifications=" + agreementNotifications + ", status=" + status + "]";
    }

}
