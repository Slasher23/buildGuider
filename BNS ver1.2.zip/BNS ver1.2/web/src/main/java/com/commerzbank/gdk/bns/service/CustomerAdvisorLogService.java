package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.CustomerAdvisorLog;
import com.commerzbank.gdk.bns.model.Tokenizer;
/**
 * Interface used to access logging events service
 * 
 * @author ZE2MACL
 * @version 1.00
 * @since 05/01/2017
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 05/01/2017        1.00       ZE2MACL   Initial Version
 * </pre>
 */
public interface CustomerAdvisorLogService {
	
	CustomerAdvisorLog saveLog(Tokenizer token, AuditLog auditLog);
	
	
}
