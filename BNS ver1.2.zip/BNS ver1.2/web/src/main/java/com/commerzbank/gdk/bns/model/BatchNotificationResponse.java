package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * Model Class for Batch notification response
 * 
 * @since 13/11/2017
 * @author ZE2GOME
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description 
 * 13/11/2017        1.00       ZE2GOME    Initial Version
 * 04/12/2017        1.01       ZE2GOME    Added ToString and XML root element
 * </pre>
 */
@XmlRootElement(name = "BatchNotificationResponse")
public class BatchNotificationResponse {
    
    List<NotificationResponse> notificationResponse;
    
    List<NotificationResponse> notificationResponseWithErrors;

    /**
     * Get notification response.
     * 
     * @return the notificationResponse
     */
    public List<NotificationResponse> getNotificationResponse() {
        return notificationResponse;
    }

    /**
     * Set notification response
     * 
     * @param notificationResponse the notificationResponse to set
     */
    public void setNotificationResponse(List<NotificationResponse> notificationResponse) {
        this.notificationResponse = notificationResponse;
    }

    /**
     * Get notification response with errors
     * 
     * @return the notificationResponseWithErrors
     */
    public List<NotificationResponse> getNotificationResponseWithErrors() {
        return notificationResponseWithErrors;
    }

    /**
     * Set notification response with errors
     * 
     * @param notificationResponseWithErrors the notificationResponseWithErrors to set
     */
    public void setNotificationResponseWithErrors(List<NotificationResponse> notificationResponseWithErrors) {
        this.notificationResponseWithErrors = notificationResponseWithErrors;
    }

    /* 
     * Convert batch notification response to string
     * 
     * @return String of batch notification response
     */
    @Override
    public String toString() {
        return "BatchNotificationResponse [notificationResponse=" + notificationResponse
                + ", notificationResponseWithErrors=" + notificationResponseWithErrors + "]";
    }

}
