package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Email(Email) Table
 * 
 * @since 30/06/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 30/06/2017        1.01       ZE2BUEN    Initial Version
 * 14/08/2017        1.02       ZE2BUEN    Modified data type of Primary from int to boolean
 * 23/11/2017        1.03       ZE2BUEN    Added new column for Address ID. Removed email type and primary column.
 * </pre>
 */

@Entity
@Table(name = "EMAIL")
@XmlRootElement
public class Email {

	@Id
	@Column(name = "EMAIL_UID")
	@GeneratedValue(generator = "EMAIL_ID_SEQ")
	@SequenceGenerator(name = "EMAIL_ID_SEQ", sequenceName = "EMAIL_SEQ")
	private Long emailUID;

	@NotNull
	@Max(value = 99999999999L)
	@Column(name = "PERSON_UID")
	private Long personUID;

	@NotNull
	@Size(max = 50)
	@Column(name = "EMAIL_ADRESSE")
	private String emailAddress;

	@NotNull
	@Max(value = 99999999999L)
	@Column(name = "ADRESSE_ID")
	private Long addressId;

	/**
	 * Returns the value of Unique Identifier of Email Record
	 * 
	 * @return Long Unique Identifier of Email Record
	 */
	public Long getEmailUID() {
		return emailUID;
	}

	/**
	 * Sets the value of Unique Identifier of Email Record
	 * 
	 * @param emailUID
	 *            Long Unique Identifier of Email Record to set
	 */
	public void setEmailUID(Long emailUID) {
		this.emailUID = emailUID;
	}

	/**
	 * Returns the value of Unique Identifier of Person Record
	 * 
	 * @return Long Unique Identifier of Person Record
	 */
	public Long getPersonUID() {
		return personUID;
	}

	/**
	 * Sets the value of Unique Identifier of Person Record
	 * 
	 * @param personUID
	 *            Long Unique Identifier of Person Record to set
	 */
	public void setPersonUID(Long personUID) {
		this.personUID = personUID;
	}

	/**
	 * Returns the value of Email Address
	 * 
	 * @return String Email Address
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * Sets the value of Email Address
	 * 
	 * @param emailAddress
	 *            String Email Address to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * Returns the value of Address ID
	 * 
	 * @return Long Address ID
	 */
	public Long getAddressId() {
		return addressId;
	}

	/**
	 * Sets the value of Address ID
	 * 
	 * @param addressId
	 *            Long Address ID to set
	 */
	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	/**
	 * Returns the String representation of Email Model
	 * 
	 * @return String String representation of Email Model
	 */
	@Override
	public String toString() {
		return "Email [emailUID=" + emailUID + ", personUID=" + personUID + ", emailAddress=" + emailAddress
				+ ", addressId=" + addressId + "]";
	}

}
