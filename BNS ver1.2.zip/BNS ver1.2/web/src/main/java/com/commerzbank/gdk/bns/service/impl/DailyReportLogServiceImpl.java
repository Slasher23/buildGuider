/**
 * 
 */
package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.service.DailyReportLogService;

/**
 * Service Implementation Class used to implement the business logic in managing
 * the Daily Report Log
 *
 * @since 04/01/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 * <pre>
 * Modified Date    Version     Author      Description 
 * 04/01/2018       1.00        ZE2RUBI     InitialVersion
 * </pre>
 */
@Service
@Transactional
public class DailyReportLogServiceImpl implements DailyReportLogService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DailyReportLogServiceImpl.class);

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    @Override
    public DailyReportLog save(DailyReportLog dailyReportLog) {

        try {

            dailyReportLogDAO.save(dailyReportLog);

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return dailyReportLog;
    }

    @Override
    public List<DailyReportLog> getAll() {

        List<DailyReportLog> list = new ArrayList<>();
        try {

          list = Lists.newArrayList(dailyReportLogDAO.findAll());

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return list;
    }

    @Override
    public void deleteAllByLessThan(Date paramDate) {

        try {

            dailyReportLogDAO.deleteByTimestampLessThan(paramDate);;

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

}