package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Wrapper class for Request For Required Batch Notification
 * 
 * @author ZE2BAUL
 * @since 10/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017	     1.00       ZE2BAUL    Initial Version
 * 23/11/2017        1.01       ZE2GOME    Change RequiredNotificationResponse to NotificationResponse
 *          </pre>
 */
public class RequiredBatchNotificationResponseWrapper {

	private List<NotificationResponse> requiredNotificationResponse;
	private List<RequiredNotificationResponseWithErrors> requiredNotificationResponseWithErrors;

	/**
	 * Gets the list of RequiredNotificationResponse
	 *
	 * @return the requiredNotificationResponse
	 */
	public List<NotificationResponse> getRequiredNotificationResponse() {
		return requiredNotificationResponse;
	}

	/**
	 * Sets the list of RequiredNotificationResponse
	 *
	 * @param requiredNotificationResponse
	 *            the requiredNotifResponse to set
	 */
	public void setRequiredNotificationResponse(List<NotificationResponse> requiredNotificationResponse) {
		this.requiredNotificationResponse = requiredNotificationResponse;
	}

	/**
	 * Gets the list of RequiredNotificationResponseWithErrors
	 *
	 * @return the requiredNotificationResponseWithErrors
	 */
	public List<RequiredNotificationResponseWithErrors> getRequiredNotificationResponseWithErrors() {
		return requiredNotificationResponseWithErrors;
	}

	/**
	 * Sets the list of RequiredNotificationResponseWithErrors
	 *
	 * @param requiredNotificationResponseWithErrors
	 *            the requiredNotificationResponseWithErrors to set
	 */
	public void setRequiredNotificationResponseWithErrors(
			List<RequiredNotificationResponseWithErrors> requiredNotificationResponseWithErrors) {
		this.requiredNotificationResponseWithErrors = requiredNotificationResponseWithErrors;
	}

	/**
	 * Returns the String representation of
	 * RequiredBatchNotificationResponse Wrapper
	 * 
	 * @return String String representation of
	 *         RequiredBatchNotificationResponse Wrapper
	 */
	@Override
	public String toString() {
		return "RequiredBatchNotificationResponseWrapper [requiredNotificationResponse=" + requiredNotificationResponse
				+ ", requiredNotificationResponseWithErrors=" + requiredNotificationResponseWithErrors + "]";
	}

}
