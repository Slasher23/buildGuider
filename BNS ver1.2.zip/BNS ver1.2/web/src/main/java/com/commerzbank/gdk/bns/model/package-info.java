
/**
 * This package contains POJO Models
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.model;