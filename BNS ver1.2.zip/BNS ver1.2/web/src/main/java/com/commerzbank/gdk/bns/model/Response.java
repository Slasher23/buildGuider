package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Response class for generic response
 * 
 * @since 02/10/2017
 * @author ZE2SARO
 * @version 1.05
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 02/10/2017        1.00       ZE2SARO    Initial Version
 * 05/10/2017        1.01       ZE2MACK    Added constructor for the mapping of Response Message in configuration file
 * 24/10/2017        1.02       ZE2RUBI    Remove status, success fields and make data generic type
 * 23/11/2017        1.03       ZE2MORA    Added Status Codes Map Class
 * 24/11/2017        1.04       ZE2BAUL    Added static variables for status codes
 * 09/02/2018        1.05       ZE2MACL    Added static variables for bad request
 * 20/02/2018        1.06       ZE2FUEN    Added Missing email and invalid authorization
 *          </pre>
 */

@XmlRootElement(name = "Response")
public class Response<T> {

    private T       data;
    private Integer code;
    private String  message;
    
    public static final int SUCCESS_RESULTS_FOUND = 1001;
    public static final int SUCCESS_NO_RESULTS_FOUND = 1002;
    public static final int SUCCESS_NO_PERSON_FOUND = 1003;
    public static final int SUCCESS_NO_ALLNOTIFCONFIG_FOUND = 1004;
    public static final int GENERAL_FUNCTION_ERROR = 2001;
    public static final int DATA_ACCESS_EXCEPTION = 2002;
    public static final int NULL_POINTER_EXCEPTION = 2003;
    public static final int MISSING_EMAIL_EXCEPTION = 2004;
    public static final int INVALID_AUTHORIZATION_EXCEPTION = 2005;
    public static final int INTERNAL_SERVER_HTTP_ERROR = 3001;
    public static final int BAD_REQUEST = 400;
 
    /**
     * Default Constructor
     */
    public Response() {
    }

    /**
     * Constructor method to be used in the configuration file to initialise or set the Response Message Mapped
     * 
     * @param status int Status Code to set
     * @param success boolean Success Flag to set
     * @param message String Status Message to set
     * @param data Object Data Object to set
     */
    public Response(T data, Integer code, String message) {
        super();
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * Returns value of message code
     * 
     * @return String message code
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets value message code
     * 
     * @param message String to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Returns value of Object
     * 
     * @return Object data
     */
    public T getData() {
        return data;
    }

    /**
     * Sets value Object
     * 
     * @param message Object to set
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     * 
     * Returns value of Object
     *
     * @return Object code
     */
    public Integer getCode() {
        return code;
    }

    /**
     * 
     * Sets value Object
     *
     * @param code int to set
     */
    public void setCode(Integer code) {
        this.code = code;
    }

    /**
	 * Returns the String representation of Response Model class Response
	 * 
	 * @return String String representation of Response Model class Response
	 */
    @Override
    public String toString() {
        return "Response [data=" + data + ", code=" + code + ", message=" + message + "]";
    }

}
