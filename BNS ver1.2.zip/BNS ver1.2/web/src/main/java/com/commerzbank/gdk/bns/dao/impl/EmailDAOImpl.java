package com.commerzbank.gdk.bns.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.EmailCustomDAO;
import com.commerzbank.gdk.bns.model.Email;

/**
 * DAO Implementation Class to get the Email List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.03
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 13/11/2017       1.01        ZE2BUEN	    Modified getEmailList method to add order by Primary column.
 * 23/11/2017       1.02        ZE2BUEN     Modified getEmailList method to replace order by Primary column to order by Address Id column.
 *  09/02/2018      1.03        ZE2MACL     Removed throws Exception
 *          </pre>
 */

@Repository
public class EmailDAOImpl implements EmailCustomDAO {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Retrieves the List of Email records using a given Unique Identifier of
     * Person record
     * 
     * @param personUID Long Unique Identifier of Person Record to set
     * @return List List of Email
     */
    @Override
    public List<Email> getEmailList(Long personUID) {

        List<Email> emailList = this.entityManager
                        .createQuery("FROM Email WHERE personUID = :personUID ORDER BY addressId ASC", Email.class)
                        .setParameter("personUID", personUID).getResultList();

        return emailList;

    }

}
