package com.commerzbank.gdk.bns.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.service.StoredProcedureService;

/**
 * Service Implementation Class used to implement business logic service in
 * DispatchRuleBook
 * 
 * @since 26/10/2017
 * @author ZE2GOME
 * @version 1.08
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2GOME    Initial Version
 * 23/11/2017        1.01       ZE2SARO    Remove Participant
 * 01/12/2017        1.02       ZE2GOME    Add condition for push configuration in decision one
 * 07/12/2017        1.03       ZE2GOME    Remove global variables
 * 12/12/2017        1.04       ZE2BUEN    Refactor/clean up for status messages
 * 04/01/2018        1.05       ZE2MACL    Added decision level two Implementation and call stored procedure
 * 01/02/2018        1.06       ZE2MACL    Remove general exception(throws exception)
 * 20/02/2018        1.07       ZE2MACL    Added error message status
 * 05/03/2018        1.08       ZE2BUEN    Updated validateDecisionTwo method
 * </pre>
 */
@Service
public class NotificationRuleBookImpl implements NotificationRuleBook {

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDao;

    @Autowired
    private NotificationConfigAgreementDAO notificationAgreementDao;

    @Autowired
    private EmailDAO emailDao;

    @Autowired
    private PersonDAO personDao;

    @Autowired
    private PushConfigurationDAO pushConfigDao;

    @Autowired
    private StoredProcedureService storedProcedureService;

    private static final String STATUS_FA_BPKENN_NOT_EXISTS                     = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING              = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING";
    private static final String STATUS_FA_NOT_SENT                              = "ZSL_STATUS_FA_NOT_SENT";
    private static final String STATUS_FA_NO_AVAIL_NOTIF_CONFIG                 = "ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG";
    private static final String STATUS_FA_NO_AVAIL_EMAIL                        = "ZSL_STATUS_FA_NO_AVAIL_EMAIL";
    private static final String STATUS_FA_NO_ACTIVATED_CONFIG                   = "ZSL_STATUS_FA_NO_ACTIVATED_CONFIG";
    private static final String STATUS_FA_TNV_NOTIFICATION_REJECTED             = "ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED";
    private static final String STATUS_FA_TNV_CANT_PROCESS_REQUEST              = "ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST";

    /**
     * Check decision level of notification
     * 
     * @param bpkenn String
     * @param branch Integer
     * @param agreementID String
     * @param isAgreementRelated boolean
     * 
     * @return responseMatrix NotificationMatrixResponse
     * 
     */
    @Override
    public NotificationMatrixResponse checkDecisionLevel(String bpkenn, Integer branch, String agreementID,
                    boolean isAgreementRelated) {

        NotificationMatrixResponse responseMatrix = new NotificationMatrixResponse();
        Person person = this.personDao.findByBpkennIgnoreCase(bpkenn);

        if (Objects.nonNull(person)) {
            responseMatrix = this.validateDecision(person.getPersonUID(), bpkenn, isAgreementRelated, branch,
                            agreementID);
        }

        return responseMatrix;
    }

    /**
     * validate decision level.
     * 
     * @param personUID Long
     * 
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse validateDecision(Long personUID, String bpkenn, boolean isAgreementRelated,
                    Integer branch, String agreementId) {

        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

        boolean decisionOne = this.decisionLevelOne(personUID, isAgreementRelated, branch, agreementId);

        if (decisionOne) {
            notificationResponse = this.validateDecisionTwo(personUID, bpkenn, isAgreementRelated, branch, agreementId);
        } else {
            List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();
            notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList,
                            STATUS_FA_NO_AVAIL_NOTIF_CONFIG);
        }

        return notificationResponse;
    }

    /**
     * validate decision level two
     * 
     * @param personUID Long
     * @param bpkenn String
     * @param isAgreementRelated Boolean
     * @param branch Integer
     * @param agreementId String
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse validateDecisionTwo(Long personUID, String bpkenn, boolean isAgreementRelated,
                    Integer branch, String agreementId) {

        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

        String decisionTwo = this.decisionLevelTwo(bpkenn, agreementId, branch);

        if (decisionTwo.equalsIgnoreCase("01")) {
            notificationResponse = this.validateDecisionThree(personUID, bpkenn, isAgreementRelated, branch,
                            agreementId);
        } else if (decisionTwo.equalsIgnoreCase("02")) {
            storedProcedureService.deletePersonRelated(bpkenn);
            notificationResponse.setStatus(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        } else if (decisionTwo.equalsIgnoreCase("03")) {
            storedProcedureService.deleteAgreementRelated(agreementId, branch);
            notificationResponse.setStatus(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        } else if (decisionTwo.equalsIgnoreCase("04")) {
            notificationResponse.setStatus(STATUS_FA_TNV_NOTIFICATION_REJECTED);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        } else {
        	notificationResponse.setStatus(STATUS_FA_TNV_CANT_PROCESS_REQUEST);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        }

        return notificationResponse;
    }

    /**
     * check decision level two. Call stored procedure service for validation of
     * return String.
     * 
     * @return String
     */
    private String decisionLevelTwo(String bpkenn, String agreementId, Integer branch) {
        String result = storedProcedureService.validateAccount(bpkenn, agreementId, branch);

        return result;
    }

    /**
     * validate decision level three.
     * 
     * @param personUID Long
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse validateDecisionThree(Long personUID, String bpkenn, boolean isAgreementRelated,
                    Integer branch, String agreementId) {

        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();
        boolean decisionThree = this.decisionLevelThree(bpkenn);

        if (decisionThree) {
            notificationResponse = this.validateDecisionFour(personUID, isAgreementRelated, branch, agreementId);
        } else {

            List<PushConfiguration> desionFourSecond = this.pushConfigStatusChecking(personUID);

            if (!decisionThree) {
                notificationResponse.setStatus(STATUS_FA_NO_AVAIL_EMAIL);
                notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
            } else if (!desionFourSecond.isEmpty()) {

                if (!desionFourSecond.isEmpty()) {
                    List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<NotificationMatrixChannel>();

                    for (PushConfiguration pushConfiguration : desionFourSecond) {
                        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
                        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
                        notificationMatrixChannel.setNotificationPath(pushConfiguration.getDeviceID());
                        notificationMatrixChannelList.add(notificationMatrixChannel);
                    }

                    notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");
                } else {
                    notificationResponse.setStatus(STATUS_FA_NO_AVAIL_NOTIF_CONFIG);
                    notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
                }

            }

        }

        return notificationResponse;
    }

    /**
     * validate decision level four.
     * 
     * @param personUID Long
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse validateDecisionFour(Long personUID, boolean isAgreementRelated, Integer branch,
                    String agreementId) {

        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();
        notificationResponse = this.decisionLevelFour(personUID, isAgreementRelated, branch, agreementId);

        return notificationResponse;
    }

    /**
     * Check participant in decision level one.
     * 
     * @param personUID Long
     * 
     * @return decision boolean
     */
    private boolean decisionLevelOne(Long personUID, boolean isAgreementRelated, Integer branch, String agreementID) {

        boolean decision = false;

        List<PushConfiguration> pushConfiguration = this.pushConfigDao.getPushConfiguration(personUID);

        if (isAgreementRelated) {
            NotificationConfigAgreement notificationConfigAgreement = this.notificationAgreementDao
                            .findByAgreementUID(personUID, branch, agreementID);
            decision = (Objects.nonNull(notificationConfigAgreement) || Objects.nonNull(pushConfiguration)) ? true
                            : false;
        } else {
            NotificationConfigPerson notificationConfigPerson = this.notificationConfigPersonDao
                            .findByPersonUID(personUID);
            decision = (Objects.nonNull(notificationConfigPerson) || Objects.nonNull(pushConfiguration)) ? true : false;
        }

        return decision;
    }

    /**
     * Check decision level three.
     * 
     * @param bpkenn String
     * 
     * @return decision boolean
     */
    private boolean decisionLevelThree(String bpkenn) {

        Person person = this.personDao.findByBpkennIgnoreCase(bpkenn);

        List<Email> email = this.emailDao.findByPersonUID(person.getPersonUID());

        boolean decision = email.size() != 0 ? true : false;

        return decision;
    }

    /**
     * Check decision level four
     * 
     * @param personUID Long
     * @return decision boolean
     */
    private NotificationMatrixResponse decisionLevelFour(Long personUID, boolean isAgreementRelated, Integer branch,
                    String agreementId) {
        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();

        if (isAgreementRelated) {

            NotificationConfigAgreement notificationConfigAgreement = this.notificationAgreementDao
                            .findByAgreementUID(personUID, branch, agreementId);

            if (Objects.isNull(notificationConfigAgreement)) {
                notificationResponse = this.validatePushAndEmailConfig(null, personUID, false);
            } else {
                notificationResponse = this.validatePushAndEmailConfig(notificationConfigAgreement.getEmailUID(),
                                personUID, notificationConfigAgreement.getActive());
            }

        } else {

            NotificationConfigPerson notificationConfigPerson = this.notificationConfigPersonDao
                            .findByPersonUID(personUID);

            if (Objects.isNull(notificationConfigPerson)) {
                notificationResponse = this.validatePushAndEmailConfig(null, personUID, false);
            } else {
                notificationResponse = this.validatePushAndEmailConfig(notificationConfigPerson.getEmailUID(),
                                personUID, notificationConfigPerson.getActive());
            }

        }

        return notificationResponse;
    }

    /**
     * Validate push and email configuration
     * 
     * @param emailUID
     * @param personUID
     * @param active
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse validatePushAndEmailConfig(Long emailUID, Long personUID, boolean active) {

        NotificationMatrixResponse notificationResponse = new NotificationMatrixResponse();
        Email mail = this.emailDao.findByEmailUID(emailUID);

        List<PushConfiguration> pushConfigActive = this.pushConfigStatusChecking(personUID);

        if (!pushConfigActive.isEmpty() && active) {
            notificationResponse = this.setEmailAndPushConfig(notificationResponse, mail.getEmailAddress(),
                            pushConfigActive);
        } else if (active) {
            notificationResponse = this.setEmailConfig(notificationResponse, mail.getEmailAddress());
        } else if (!pushConfigActive.isEmpty()) {
            notificationResponse = this.setPushConfig(notificationResponse, pushConfigActive);
        } else  if(!active){
            notificationResponse.setStatus(STATUS_FA_NO_ACTIVATED_CONFIG);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        } else {    
            notificationResponse.setStatus(STATUS_FA_NO_AVAIL_NOTIF_CONFIG);
            notificationResponse.setNotificationMatrixChannel(new ArrayList<NotificationMatrixChannel>());
        }

        return notificationResponse;
    }

    /**
     * Set email configuration
     * 
     * @param notificationResponse
     * @param emailAddress
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse setEmailConfig(NotificationMatrixResponse notificationResponse,
                    String emailAddress) {

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannel.setNotificationPath(emailAddress);
        notificationMatrixChannelList.add(notificationMatrixChannel);
        notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

        return notificationResponse;
    }

    /**
     * Set push configuration.
     * 
     * @param notificationResponse
     * @param pushConfigActive
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse setPushConfig(NotificationMatrixResponse notificationResponse,
                    List<PushConfiguration> pushConfigActive) {

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();

        for (PushConfiguration push : pushConfigActive) {
            NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
            notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.PUSH);
            notificationMatrixChannel.setNotificationPath(push.getDeviceID());
            notificationMatrixChannelList.add(notificationMatrixChannel);
        }

        notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

        return notificationResponse;
    }

    /**
     * Set email and push configuration
     * 
     * @param notificationResponse
     * @param path
     * @param pushConfigActive
     * @return notificationResponse NotificationMatrixResponse
     */
    private NotificationMatrixResponse setEmailAndPushConfig(NotificationMatrixResponse notificationResponse,
                    String path, List<PushConfiguration> pushConfigActive) {

        List<NotificationMatrixChannel> notificationMatrixChannelList = new ArrayList<>();
        NotificationMatrixChannel notificationMatrixChannel = new NotificationMatrixChannel();
        notificationMatrixChannel.setInformationChannelType(InformationChannelTypeE.EMAIL);
        notificationMatrixChannel.setNotificationPath(path);
        notificationMatrixChannelList.add(notificationMatrixChannel);

        for (PushConfiguration push : pushConfigActive) {
            NotificationMatrixChannel notificationForPush = new NotificationMatrixChannel();
            notificationForPush.setInformationChannelType(InformationChannelTypeE.PUSH);
            notificationForPush.setNotificationPath(push.getDeviceID());
            notificationMatrixChannelList.add(notificationForPush);
        }

        notificationResponse = this.setNotificationMatrix(notificationMatrixChannelList, "SUCCESSFUL");

        return notificationResponse;
    }

    /**
     * check if push configuration is active.
     * 
     * @param personUID
     * @return boolean status of push configuration
     */
    private List<PushConfiguration> pushConfigStatusChecking(Long personUID) {

        List<PushConfiguration> pushConfiguration = this.pushConfigDao.getPushConfiguration(personUID);
        List<PushConfiguration> pushConfigurationActiveList = new ArrayList<>();
        if (Objects.nonNull(pushConfiguration)) {
            for (PushConfiguration pc : pushConfiguration) {
                if (pc.getActive()) {
                    pushConfigurationActiveList.add(pc);
                }
            }
        }
        return pushConfigurationActiveList;
    }

    /**
     * 
     * Return Dispatch matrix response
     * 
     * @param List<DispatchChannelTypeE> dispatchChannelTypeList
     * @param status String
     * @return dispatchMatrixResponse DispatchMatrixResponse
     * 
     */
    private NotificationMatrixResponse setNotificationMatrix(List<NotificationMatrixChannel> notificationMatrixChannel,
                    String status) {

        NotificationMatrixResponse notificationMatrixResponse = new NotificationMatrixResponse();
        notificationMatrixResponse.setNotificationMatrixChannel(notificationMatrixChannel);
        notificationMatrixResponse.setStatus(status);

        return notificationMatrixResponse;
    }

}
