package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class used to access the Agreement List
 * 
 * @since 07/08/2017 
 * @author ZE2SARO
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 07/08/2017        1.00       ZE2SARO    Initial Version
 * 22/09/2017        1.01       ZE2SARO    Change parameter bpkenn to Parameter Model.
 * 10/11/2017        1.02       ZE2MACL    Updated method to used response builder and added token parameter
 * </pre>
 */
public interface AgreementService {

	ResponseBuilder<List<Agreement>> getAgreementList(Tokenizer token, Parameter parameter);

}
