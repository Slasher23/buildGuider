package com.commerzbank.gdk.bns.conf;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.commerzbank.gdk.bns.conf.security.CifAuthorizationProvider;
import com.commerzbank.gdk.bns.conf.security.CifAuthorizationTokenFilter;

/**
 * Application Entry point
 * 
 * @author ZE2RUBI
 * @since 03/10/2017
 * @version 1.03
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017	     1.01       ZE2RUBI    Initial Version
 * 23/10/2017	     1.02       ZE2CRUH    Updated API for security roles.
 * 22/02/2018        1.03       ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@Configuration
@EnableWebSecurity
public class SecurityJavaConfig extends WebSecurityConfigurerAdapter {

    @Value("${USER_ROLE}")
    private String userRole;

    @Value("${CBE_ROLE}")
    private String cbeRole;

    @Value("${CDS_ROLE}")
    private String cdsRole;

    @Autowired
    private CifAuthorizationProvider authenticationProvider;

    @Bean
    @Override
    public AuthenticationManager authenticationManager() throws Exception {
        AuthenticationProvider auth = authenticationProvider;
        return new ProviderManager(Arrays.asList(auth));
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        http.authorizeRequests().antMatchers("/register.html").permitAll();
        http.authorizeRequests().antMatchers("/assets/**", "/static/**").permitAll();
        http.authorizeRequests().antMatchers("/api/zsl/**").permitAll();
        http.authorizeRequests().antMatchers("/api/agreementConfig", "/api/personConfig",
                "/api/notifText/agreementConfig", "/api/notifText/personConfig").hasAnyRole(userRole, cbeRole);
        http.authorizeRequests().antMatchers("/register", "/api/**").hasAnyRole(userRole, cbeRole, cdsRole);
        http.addFilterBefore(new CifAuthorizationTokenFilter(), BasicAuthenticationFilter.class);
    }

}