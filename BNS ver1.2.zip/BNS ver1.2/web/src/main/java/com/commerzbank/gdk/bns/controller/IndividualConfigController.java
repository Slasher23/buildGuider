package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.IndividualConfigService;

/**
 * SaveIndividualConfigController Accept client request and process then return.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.08
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 28/09/2017	   1.01		 ZE2BAUL	Applied the logging standards
 * 03/10/2017	   1.02		 ZE2BAUL	Added postMethod for PersonConfig 
 * 13/10/2017	   1.03		 ZE2RUBI	Clean Up and Implement JWT
 * 13/11/2017      1.04      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.05      ZE2SARO    Add Validation
 * 09/02/2018      1.06      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.07      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.08      ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@RestController
public class IndividualConfigController {

    @Autowired
    private IndividualConfigService saveConfig;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(IndividualConfigController.class);

    /**
     * Accept client request and call the service to save the record send by
     * client and return the notification text and agreement config values also
     * consumes and produce json or xml format.
     * 
     * @param customNotifConfig
     *            CustomNotifConfig
     * @return return the notification text and agreement config.
     * 
     */
    @PostMapping(value = "/api/notifText/agreementConfig")
    public ResponseEntity<Response<NotifTextAgreementConfigWrapper>> saveNotifTextAndAgreementConfig(
            @Valid @RequestBody CustomNotifConfig notifConfig, BindingResult result, HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] saveNotifTextAndAgreementConfig({})", token.getUserId(), notifConfig.toString());

        ResponseBuilder<NotifTextAgreementConfigWrapper> builder = new ResponseBuilder<NotifTextAgreementConfigWrapper>(
                LOGGER, token, globalResponseWrapper);

        if (!result.hasErrors() && Tokenizer.validator(token)) {
            builder = this.saveConfig.saveNotifTextAndAgreementConfig(token, notifConfig);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }

    /**
     * Accept client request and call the service to save the record send by
     * client and return the notification text and person config values also
     * consumes and produce json or xml format.
     * 
     * @param customNotifConfig
     *            CustomNotifConfig
     * @return return the notification text and person config.
     * 
     */
    @PostMapping(value = "/api/notifText/personConfig")
    public ResponseEntity<Response<NotifTextPersonConfigWrapper>> saveNotifTextAndPersonConfig(
            @Valid @RequestBody CustomNotifConfig customNotifConfig, BindingResult result, HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] saveNotifTextAndPersonConfig({})", token.getUserId(), customNotifConfig.toString());

        ResponseBuilder<NotifTextPersonConfigWrapper> builder = new ResponseBuilder<NotifTextPersonConfigWrapper>(
                LOGGER, token, globalResponseWrapper);

        if (!result.hasErrors() && Tokenizer.validator(token)) {
            builder = this.saveConfig.saveNotifTextAndPersonConfig(token, customNotifConfig);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }

}
