package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.Key;

/**
 * Key DAO Interface
 * 
 * @since 12/12/2017
 * @author ZE2MACL
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 12/12/2017		1.00		ZE2MACL 	Initial Version
 * 21/12/2017		1.01		ZE2MACL		Added method to find key and return key code.
 * </pre>
 */

public interface KeyDAO extends CrudRepository<Key, Long>, KeyCustomDAO {

	Key findByKeyTypIgnoreCaseAndKeyCodeIgnoreCaseAndLanguage(String keyTyp, String keyCode, String language);

	List<Key> findByKeyTypIgnoreCaseAndKeyShortText(String keyTyp, String shortText);

	List<Key> findByKeyTypIgnoreCaseAndKeyLongText(String keyTyp, String longText);

}
