package com.commerzbank.gdk.bns.service.impl;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.naming.InitialContext;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.ScheduleLockerDAO;
import com.commerzbank.gdk.bns.model.ScheduleLocker;
import com.commerzbank.gdk.bns.service.ScheduleLockerService;

/**
 * Service Implementation Class used to implement the business logic in locking
 * schedule task
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.01
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 15/02/2018       1.00        ZE2RUBI     Initial Version
 * 07/08/2018       1.01        ZE2RUBI     Additional Validation to address OptimisticException
 *          </pre>
 */
@Service
@Transactional
public class ScheduleLockerServiceImpl implements ScheduleLockerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleLockerServiceImpl.class);

    @Autowired
    private ScheduleLockerDAO scheduleLockerDAO;

    public ScheduleLockerServiceImpl() {
        lastExecutionTime = LocalDateTime.now();
    }

    private static LocalDateTime lastExecutionTime;

    /**
     * Initialise Schedule Locker by cleaning old data and inserting new data on
     * the database
     * 
     */
    private void initLocker() {

        if (Objects.isNull(lastExecutionTime)) {
            lastExecutionTime = LocalDateTime.now();
        }

        LocalDateTime currentTime = LocalDateTime.now();
        currentTime = currentTime.minusSeconds(5);

        if (lastExecutionTime.isBefore(currentTime)) {

            final ZoneId defaultZoneId = ZoneId.systemDefault();

            LocalDateTime current = LocalDateTime.now(defaultZoneId);

            Date schedDate = Date.from(current.atZone(ZoneId.systemDefault()).toInstant());

            String node = nodeName();

            SecureRandom secRan = new SecureRandom();
            ScheduleLocker locker = scheduleLockerDAO.findByNodeName(node);

            if (Objects.isNull(locker)) {

                this.scheduleLockerDAO
                        .save(new ScheduleLocker(Long.valueOf(0), node, secRan.nextInt(100000), schedDate));
            } else {

                locker.setRandom(secRan.nextInt(100000));
                locker.setUpdated_at(schedDate);

                this.scheduleLockerDAO.save(locker);
            }

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                LOGGER.error(e.getMessage(), e);
            }

            lastExecutionTime = LocalDateTime.now();

        }

    }

    /**
     * Check if the node is active by identifying if it has the minimum random
     * number
     * 
     * @return Boolean true if it is an active node
     */
    @Override
    public boolean isNodeActive() {

        this.initLocker();

        String nodeName = this.nodeName();

        if (this.scheduleLockerDAO.getActiveScheduleLocker(nodeName)) {

            LOGGER.info("Scheduled Job's will be executed by node: " + nodeName);

            return true;
        }

        return false;

    }

    /**
     * Method for Cleaning data on Schedules Nodes table
     * 
     */
    @Override
    public void cleanScheduleNodes() {

        final ZoneId defaultZoneId = ZoneId.systemDefault();

        LocalDateTime current = LocalDateTime.now(defaultZoneId);

        this.cleanScheduleNodes(current, defaultZoneId);

        lastExecutionTime = LocalDateTime.now();

    }

    /**
     * Cleans or delete existing Schedule Nodes data in the database. All data
     * later than the current time subtracted by 5 Minutes will be deleted in
     * the database.
     * 
     * @param current LcoalDateTime
     * @param defaultZoneId ZoneId
     **/
    private void cleanScheduleNodes(LocalDateTime current, ZoneId defaultZoneId) {

        List<Long> uid = new ArrayList<Long>();

        scheduleLockerDAO.findAll().forEach(item -> {

            current.minusMinutes(5);

            Instant instant = item.getUpdated_at().toInstant();

            LocalDateTime dbData = instant.atZone(defaultZoneId).toLocalDateTime();

            if (current.isAfter(dbData)) {
                uid.add(item.getUid());
            }

        });

        uid.forEach(i -> {
            scheduleLockerDAO.delete(i);
        });

    }

    /**
     * Retrieve the server name and node name of the host. Variable serverName
     * was initialised with "server" and node with "node" for local development
     * testing only to prevent null pointer in deploying in Tomcat.
     * 
     * @return String server name concatenated by node name
     */
    private String nodeName() {

        String serverName = "server";
        String node = "node";

        try {

            InitialContext ic = new javax.naming.InitialContext();

            serverName = ic.lookup("servername").toString();

            node = ic.lookup("thisNode/nodename").toString();

            ic.close();

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return serverName.concat("_").concat(node);

    }

    /**
     * Retrieve the server name and node name of the host via API interface
     * 
     * @return String server name concatenated by node name
     */
    @Override
    public String getNodeName() {
        return this.nodeName();
    }

}
