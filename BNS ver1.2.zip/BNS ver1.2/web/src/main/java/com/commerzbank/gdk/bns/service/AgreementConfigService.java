package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class used to access the AgreementConfig
 * 
 * @since 03/08/2017
 * @author ZE2MENY
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/08/2017        1.00       ZE2MENY    Initial Version
 * 14/11/2017        1.01       ZE2MACL    Updated method to used response builder and added token parameter
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface AgreementConfigService {
    
    @Deprecated
	ResponseBuilder<NotificationConfigAgreement> getNotifConfigAgreementById(Tokenizer token, Long UID);
	
    @Deprecated
	ResponseBuilder<NotificationConfigAgreement> postCustomer(Tokenizer token, NotificationConfigAgreement notificationConfigAgreement);
	
    @Deprecated
	ResponseBuilder<List<NotificationConfigAgreement>> getNotifConfigAgreementList(Tokenizer token);

	ResponseBuilder<AgreementConfig> getNotifConfigAgreementsList(Tokenizer token);

	ResponseBuilder<AgreementConfig> postNotifConfigAgreement(Tokenizer token, AgreementConfig savingNotifConfigAgreement);

}
