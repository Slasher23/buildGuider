package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.DailyReportLogService;
import com.commerzbank.gdk.bns.service.ExtractReportDataService;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.service.ReportService;
import com.commerzbank.gdk.bns.service.ScheduleLockerService;
import com.commerzbank.gdk.bns.service.db2.KeyDB2Service;

/**
 * Service Implementation Class used to execute cron jobs for the extraction of
 * report
 * 
 * @since 15/01/2018
 * @author ZE2RUBI
 * @version 1.04
 * 
 * <pre>
 * Modified Date        Version     Author      Description 
 * 15/01/2018           1.00        ZE2RUBI     Initial Version  
 * 25/01/2018           1.01        ZE2RUBI     Update Delete all by specified date
 * 15/02/2018           1.02        ZE2RUBI     Add Schedule Locker 
 * 21/02/2018           1.03        ZE2BUEN     Added deletion, extract and saving of Key Database records
 * 07/03/2018           1.04        ZE2RUBI     Update Schedule Locker
 * </pre>
 */
@Service
@EnableScheduling
public class ReportScheduler {

    @Autowired
    private ExtractReportDataService extractReportDataService;

    @Autowired
    private DailyReportLogService dailyReportLogService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private ScheduleLockerService lockerService;
    
	@Autowired
	private KeyDB2Service keyDB2Service;

	@Autowired
	private KeyService keyService;

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportScheduler.class);

    @Scheduled(cron = "${cron.expression.set1}")
    public void daily() {

        if (lockerService.isNodeActive()) {

            Tokenizer token = new Tokenizer();
            token.setUserId("BNS-Report Generation");

            Date date = new Date();

            date = DateUtils.addDays(date, -1);

            Report report = new Report();

            try {

                report = extractReportDataService.extractActiveNotificationReport(token, date);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {
                report = extractReportDataService.extractAllUsersWithAllActiveProducts(token, date);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {
                report = extractReportDataService.extractAllUsersWithOneProdSelected(token, date);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {
                report = extractReportDataService.extractOneIndividualConfiguredNotificationReport(token, date);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {
                report = extractReportDataService.extractAllUsersWhoReceivedRequiredNotificationReport(token, date);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {

                date = new Date();
                date = DateUtils.setHours(date, 0);
                date = DateUtils.setMinutes(date, 0);
                date = DateUtils.setSeconds(date, 0);

                dailyReportLogService.deleteAllByLessThan(date);

                LOGGER.info("BNS REPORT: Deleting Daily Report Log Successful in Node [{}] " ,lockerService.getNodeName());

            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            LOGGER.info("BNS REPORT: Extraction Completed in Node [{}] " , lockerService.getNodeName());
            
            this.updateBNSKeyTable();
            
            //This is needed after execution to refresh the tables
            lockerService.cleanScheduleNodes();
        }

    }

    @Scheduled(cron = "${cron.expression.set2}")
    public void thirty() {

        if (lockerService.isNodeActive()) {

            Tokenizer token = new Tokenizer();
            token.setUserId("BNS-Report Generation");

            Report report = new Report();

            Date currentDate = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            int unroundedMinutes = calendar.get(Calendar.MINUTE);
            int mod = (unroundedMinutes % 30);
            calendar.add(Calendar.MINUTE, mod < 30 ? -mod : (30 - mod));
            calendar.add(Calendar.MINUTE, -30);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            Date startDateTimestamp = calendar.getTime();
            calendar.add(Calendar.MINUTE, 29);
            calendar.add(Calendar.SECOND, 59);
            calendar.add(Calendar.MILLISECOND, 999);
            Date endDateTimestamp = calendar.getTime();

            try {
                report = extractReportDataService.extractAllNotificationServiceCalls(token, startDateTimestamp,
                        endDateTimestamp);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            try {
                report = extractReportDataService.extractAllUsersAccessingNotificationWithoutEmail(token,
                        startDateTimestamp, endDateTimestamp);
                reportService.saveReport(report, token);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            LOGGER.info("BNS REPORT: Extraction Completed in Node [{}] " ,lockerService.getNodeName());
            

            //This is needed after execution to refresh the tables
            lockerService.cleanScheduleNodes();
        }
    }
    
    /**
	 * Extracts, Delete and Save Key Database records
	 * 
	 */
	private void updateBNSKeyTable() {
		
		// Key DB2
		Tokenizer token = new Tokenizer();
		token.setUserId("BNS-KEY DB2");

		List<Key> keyList = new ArrayList<>();

		// Salutation Key Records
		try {
			// Extract Salutation Key Records from DB2
			keyList = keyDB2Service.extractKeyDB2Records("PAKTL", token);

			if (!keyList.isEmpty()) {

				// Delete Salutation Key Records
				keyService.deleteKeyRecords("PAKTL", token);
			}

			LOGGER.info("BNS KEY DB2: Deleting Salutation Key Records Successful in Node [{}] " ,lockerService.getNodeName());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		try {

			if (!keyList.isEmpty()) {

				// Save Salutation Key Records from DB2
				keyService.savingKeyRecords(keyList, token);
			}

			LOGGER.info("BNS KEY DB2: Saving Salutation Key Records Successful in Node [{}] " ,lockerService.getNodeName());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		// Title Key Records
		keyList = new ArrayList<>();
		
		try {

			// Extract Title Key Records from DB2
			keyList = keyDB2Service.extractKeyDB2Records("BBANR", token);

			if (!keyList.isEmpty()) {

				// Delete Title Key Records
				keyService.deleteKeyRecords("BBANR", token);
			}

			LOGGER.info("BNS KEY DB2: Deleting Title Key Records Successful in Node [{}] " ,lockerService.getNodeName());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		try {

			if (!keyList.isEmpty()) {

				// Save Title Key Records from DB2
				keyService.savingKeyRecords(keyList, token);
			}

			LOGGER.info("BNS KEY DB2: Saving Title Key Records Successful in Node [{}] " ,lockerService.getNodeName());

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

	}

}
