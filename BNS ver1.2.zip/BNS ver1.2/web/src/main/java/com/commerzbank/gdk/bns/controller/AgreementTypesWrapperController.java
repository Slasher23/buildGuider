package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementTypesWrapperService;

/**
 * AgreementTypesWrapperController Accept request and return the expected record
 * to client.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.08
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 22/09/2017      1.01      ZE2SARO    Update request to postmapping and change the parameter request
 * 02/10/2017	   1.02		 ZE2BAUL	Changed the AgreementEmailChannelWrapper to MainAgreementTypeWrapper
 * 13/10/2017	   1.03		 ZE2RUBI	Clean Up and Implement JWT
 * 10/11/2017      1.04      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.05      ZE2SARO    Add Validation
 * 09/02/2018      1.06      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.07      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.08      ZE2FUEN    Updated implementation to CIF-Integration
 * 28/02/2018      1.02      ZE2FUEN    Implemented BNStoken builder
 *          </pre>
 */

@RestController
public class AgreementTypesWrapperController {

    @Autowired
    private AgreementTypesWrapperService agreementTypesWrapperService;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(AgreementTypesWrapperController.class);

    /**
     * Accept client request and call service to get the agreements, agreement
     * config, email list and info channel list from database using participant
     * number then return also consumes and produces json or xml format.
     * 
     * @param bnsInternal
     *            BNS Internal (Parameter)
     * @return return the Agreements, agreement config, email list and info
     * 
     */
    @PostMapping(value = "/api/agreementInfos")
    public ResponseEntity<Response<MainAgreementTypeWrapper>> getAgreementTypes(HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] getAgreementTypes({})", token.getUserId(), token.getBpkenn());

        ResponseBuilder<MainAgreementTypeWrapper> builder = new ResponseBuilder<MainAgreementTypeWrapper>(LOGGER, token,
                globalResponseWrapper);

        if (Tokenizer.validator(token)) {
            builder = this.agreementTypesWrapperService.getMainAgreementTypeWrapperList(token, null);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }

}
