package com.commerzbank.gdk.bns.dao;

import java.util.List;

import com.commerzbank.gdk.bns.model.InformationChannel;

/**
 * InformationChannelCustomDAO Interface
 * 
 * @since 30/06/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date    Version     Author      Description
 * 30/06/2017       1.00        ZE2BUEN     Initial Version
 * </pre>
 */
public interface InformationChannelCustomDAO {
	
	List<InformationChannel> getInformationChannelList();

	Long getInformationChannelUID(String type);
	
}
