package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;

/**
 * Interface used to get CustomerNotificationService
 * 
 * @since 09/11/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 09/11/2017        1.00       ZE2SARO   Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface CustomerNotificationService {

    CustomerNotificationsResponse getResponse(CustomerNotificationRequest request);

}
