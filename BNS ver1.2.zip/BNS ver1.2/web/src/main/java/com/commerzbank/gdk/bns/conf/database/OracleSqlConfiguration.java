package com.commerzbank.gdk.bns.conf.database;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Configuration Class for Oracle Data Source
 * 
 * @since 21/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 21/02/2018		1.00	    ZE2BUEN 	Initial Version
 *          </pre>
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {
        "com.commerzbank.gdk.bns.dao" }, entityManagerFactoryRef = "oraclesqlEntityManager", transactionManagerRef = "oraclesqlTransactionManager")
public class OracleSqlConfiguration {

    @Autowired
    private Environment env;

    @Value("${spring.datasource.name}")
    private String datasourceName;

    private JndiDataSourceLookup lookup = new JndiDataSourceLookup();

    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean oraclesqlEntityManager() {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();

        em.setDataSource(oraclesqlDatasource());
        em.setPackagesToScan("com.commerzbank.gdk.bns.model");
        em.setPersistenceUnitName("oraclesqlEntityManager");

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
        properties.put("hibernate.current_session_context_class",
                        env.getProperty("spring.jpa.properties.hibernate.current_session_context_class"));
        properties.put("hibernate.id.new_generator_mapping",
                        env.getProperty("spring.jpa.properties.hibernate.id.new_generator_mapping"));
        properties.put("hibernate.format_sql", env.getProperty("spring.jpa.properties.hibernate.format_sql"));
        properties.put("hibernate.temp.use_jdbc_metadata_defaults",
                        env.getProperty("spring.jpa.properties.hibernate.temp.use_jdbc_metadata_defaults"));

        em.setJpaPropertyMap(properties);
        return em;
    }

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource oraclesqlDatasource() {

        DataSource dataSource = null;

        if (datasourceName.equalsIgnoreCase("CB_DEV")) {
            dataSource = DataSourceBuilder.create().build();
        } else {
            String jndiName = env.getProperty("spring.datasource.jndi-name");
            dataSource = lookup.getDataSource(jndiName);
        }

        return dataSource;

    }

    @Primary
    @Bean
    public PlatformTransactionManager oraclesqlTransactionManager() {

        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(oraclesqlEntityManager().getObject());
        return transactionManager;
    }

}