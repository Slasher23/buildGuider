package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for Batch ZSL Update Response
 * 
 * @since 29/11/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description 
 * 29/11/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
public class BatchZslUpdateResponse {

    List<ZslUpdateResponse> zslUpdateResponseNoError;

    List<ZslUpdateResponse> zslUpdateResponseWithError;

    /**
     * Get list of ZSL update response without error.
     * 
     * @return the zslUpdateResponseNoError
     */
    public List<ZslUpdateResponse> getZslUpdateResponseNoError() {
        return zslUpdateResponseNoError;
    }

    /**
     * Set list of ZSL update response without error.
     * 
     * @param zslUpdateResponseNoError the zslUpdateResponseNoError to set
     */
    public void setZslUpdateResponseNoError(List<ZslUpdateResponse> zslUpdateResponseNoError) {
        this.zslUpdateResponseNoError = zslUpdateResponseNoError;
    }

    /**
     * Get list of ZSL update response with error.
     * 
     * @return the zslUpdateResponseWithError
     */
    public List<ZslUpdateResponse> getZslUpdateResponseWithError() {
        return zslUpdateResponseWithError;
    }

    /**
     * Set list of ZSL update response with error.
     * 
     * @param zslUpdateResponseWithError the zslUpdateResponseWithError to set
     */
    public void setZslUpdateResponseWithError(List<ZslUpdateResponse> zslUpdateResponseWithError) {
        this.zslUpdateResponseWithError = zslUpdateResponseWithError;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "BatchZslUpdateResponse [zslUpdateResponseNoError=" + zslUpdateResponseNoError
                + ", zslUpdateResponseWithError=" + zslUpdateResponseWithError + "]";
    }

}
