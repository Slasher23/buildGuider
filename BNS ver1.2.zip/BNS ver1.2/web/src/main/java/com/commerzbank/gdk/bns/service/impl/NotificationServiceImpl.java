package com.commerzbank.gdk.bns.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.Notification;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Trigger;
import com.commerzbank.gdk.bns.rules.NotificationRuleBook;
import com.commerzbank.gdk.bns.service.EmailTemplateService;
import com.commerzbank.gdk.bns.service.NotificationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * Service Implementation Class used to send Standard and Individual
 * Notifications
 * 
 * @since 20/09/2017
 * @author ZE2BUEN
 * @version 1.14
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 20/09/2017        1.00       ZE2BUEN    Initial Version
 * 25/09/2017        1.01       ZE2SARO    Change method to get participant record.
 * 02/11/2017		 1.02		ZE2FUEN	   Change business logic to add person related agreement and to call rulebook
 * 03/11/2017		 1.03		ZE2BAUL	   Standardised ZSL logging
 * 23/11/2017        1.04       ZE2GOME    Rename the notifications to notifications
 * 23/11/2017        1.05       ZE2SARO    Remove participant
 * 07/12/2017        1.06       ZE2BUEN    Refactor Notification service to save details on log file 
 * 12/12/2017        1.07       ZE2BUEN    Refactor/ clean up for ZSL status messages
 * 11/01/2018        1.08       ZE2FUEN    Added Daily Logging
 * 23/01/2018        1.09       ZE2MACL    Update setting of status using the matrix result
 * 02/02/2018        1.10       ZE2FARI    Removed the email generation
 * 06/02/2018        1.11       ZE2MACL    Remove throws Exception and replace it with try catch block
 * 20/02/2018        1.12       ZE2MACL    Added error message status 
 * 21/02/2018        1.13       ZE2MACL    Added required field/s validation
 * 08/03/2018        1.14       ZE2BUEN    Added new error messages for TNV stored procedure validation
 * </pre>
 */
@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private InformationChannelDAO infoChannelDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private NotificationRuleBook notificationRuleBook;

    @Autowired
    private Settings settings;

    @Autowired
    private Tools tools;

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    @Autowired
    private EmailTemplateService emailTemplateService;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    @Value("${NOTIF_EVENT01}")
    private String eventType;

    private static final Logger LOGGER                                          = LoggerFactory
                    .getLogger(NotificationServiceImpl.class);
    private static final String VERANLASSUNGS_TYPE_VER                          = "VERLASSUNGS_TYPE_VER";
    private static final String VERANLASSUNGS_TYPE_PER                          = "VERLASSUNGS_TYPE_PER";
    private static final String TRIGGER_TYPE_KEY                                = "TRIGGER_TYPE_DOC";
    private static final String EMAIL_SUBJECT_KEY                               = "EMAIL_SUBJECT";
    private static final String STATUS_OK                                       = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST                       = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS                     = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_NO_AVAIL_NOTIF_CONFIG                 = "ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING              = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING";
    private static final String STATUS_FA_NOT_SENT                              = "ZSL_STATUS_FA_NOT_SENT";
    private static final String STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST           = "ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST";
    private static final String STATUS_FA_FAILED_NOTIFICATION                   = "ZSL_STATUS_FA_FAILED_NOTIFICATION";
	private static final String STATUS_FA_NO_AVAIL_EMAIL                        = "ZSL_STATUS_FA_NO_AVAIL_EMAIL";
    private static final String STATUS_FA_NO_ACTIVATED_CONFIG                   = "ZSL_STATUS_FA_NO_ACTIVATED_CONFIG";
    private static final String STATUS_FA_TNV_NOTIFICATION_REJECTED             = "ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED";
    private static final String STATUS_FA_TNV_CANT_PROCESS_REQUEST              = "ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST";
    private static final String EMPTY_STRING                                    = "";
    
    /**
     * Save trigger and notification record, generate email template then return
     * Notification Response
     * 
     * @param notifRequest NotificationRequest Notification request sent by ZSL.
     * @return NotificationResponse Notification Response
     */
    @Override
    public NotificationResponse sendNotification(NotificationRequest notifRequest) {
        String status = EMPTY_STRING;

        NotificationResponse notificationResponse = new NotificationResponse();
        List<Notifications> notificationList = new ArrayList<Notifications>();

        String bpkenn = notifRequest.getBpkenn();
        Integer branch = notifRequest.getSparte();
        String agreementID = notifRequest.getVereinbarungskennung();

        notificationResponse.setBPKENN(bpkenn);

        DailyReportLog dailyReportLog = new DailyReportLog();
        dailyReportLog.setBpkenn(bpkenn);
        dailyReportLog.setEventType(eventType);
        dailyReportLog.setTimestamp(new Date());
        this.dailyReportLogDAO.save(dailyReportLog);

        try {
            status = validateRequest(notifRequest);
            if (isNullOrEmpty(status)) {
                boolean isAgreementRelated = this.isNullOrEmpty(agreementID) ? false : true;

                Person person = this.personDAO.getPerson(bpkenn);

                if (Objects.nonNull(person)) {

                    Agreement agreement = this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(
                                    person.getPersonUID(), agreementID, branch);

                    if (Objects.isNull(agreement) && isAgreementRelated) {
                        notificationResponse
                                        .setStatus(this.environment.getProperty(STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST));
                    } else {

                        NotificationMatrixResponse matrixResponse = this.notificationRuleBook.checkDecisionLevel(bpkenn,
                                        branch, agreementID, isAgreementRelated);
                        int successCount = 0;

                        if (Objects.nonNull(matrixResponse)) {

                            if (matrixResponse.getNotificationMatrixChannel().size() > 0) {
                                successCount++;

                                this.sendTrigger(person, agreementID, branch, isAgreementRelated);

                                for (NotificationMatrixChannel channel : matrixResponse
                                                .getNotificationMatrixChannel()) {
                                    Notifications notifications = this.createNotificationChannel(person, agreementID,
                                                    branch, channel, isAgreementRelated);
                                    notificationList.add(notifications);
                                }

                            }

                        }

                        if (successCount > 0) {
                            notificationResponse.setStatus(this.environment.getProperty(STATUS_OK));
                        } else {

                            notificationResponse
                                            .setStatus(this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG));

                            if (matrixResponse.getStatus()
                                            .equalsIgnoreCase("ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID")) {
                                notificationResponse.setStatus(this.environment
                                                .getProperty(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID));
                            } else if (matrixResponse.getStatus()
                                            .equalsIgnoreCase("ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING")) {
                                notificationResponse.setStatus(
                                                this.environment.getProperty(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING));
                            } else if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_NOT_SENT")) {
                                notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_NOT_SENT));
                            } else if (matrixResponse.getStatus()
                                            .equalsIgnoreCase("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG")) {
                                notificationResponse.setStatus(
                                                this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG));
                            } else if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_BPKENN_NOT_EXISTS")) {
                                notificationResponse
                                                .setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                            } else if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_NO_AVAIL_EMAIL")) {
                                notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_NO_AVAIL_EMAIL));
                            } else
                                if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_NO_ACTIVATED_CONFIG")) {
                                notificationResponse
                                                .setStatus(this.environment.getProperty(STATUS_FA_NO_ACTIVATED_CONFIG));
							} else if (matrixResponse.getStatus()
									.equalsIgnoreCase("ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED")) {
								notificationResponse
										.setStatus(this.environment.getProperty(STATUS_FA_TNV_NOTIFICATION_REJECTED));
							} else if (matrixResponse.getStatus()
									.equalsIgnoreCase("ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST")) {
								notificationResponse
										.setStatus(this.environment.getProperty(STATUS_FA_TNV_CANT_PROCESS_REQUEST));
							}
                        }
                    }
                } else {
                    notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                }

            } else {
                notificationResponse.setStatus(status);
            }

        } catch (Exception e) {
            notificationResponse.setStatus(this.environment.getProperty(STATUS_FA_FAILED_NOTIFICATION));
            LOGGER.error(e.getMessage(), e);
        }

        notificationResponse.setNotification(notificationList);

        return notificationResponse;
    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return boolean
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        Boolean isValidString = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;
        return isValidString;

    }

    /**
     * Method to validate data in NotificationRequest
     * 
     * @param notificationRequest NotificationRequest
     * @return String
     */
    private String validateRequest(NotificationRequest notificationRequest) {

        HashSet<String> invalidFields = new HashSet<String>();
        String invalidMsg;

        boolean nullBpkenn = this.isNullOrEmpty(notificationRequest.getBpkenn());
        boolean nullAgreementID = this.isNullOrEmpty(notificationRequest.getVereinbarungskennung());
        boolean nullBranch = Objects.isNull(notificationRequest.getSparte());

        if (nullBpkenn) {
            invalidFields.add("bpkenn");
        }

        if ((nullAgreementID && !nullBranch) || (!nullAgreementID && nullBranch)) {

            if (nullBranch) {
                invalidFields.add("sparte");
            }

            if (nullAgreementID) {
                invalidFields.add("vereinbarungskennung");
            }
        }

        invalidMsg = requiredFieldValidation.requiredField(invalidFields);

        return invalidMsg;
    }

    /**
     * Method to create trigger and notify in the correct channel
     * 
     * @param person Person person object
     * @param agreementID String ID of the agreement
     * @param branch Integer branch number
     * @param isAgreementRelated boolean determines if notification is
     *            agreementRelated
     */
    private void sendTrigger(Person person, String agreementID, Integer branch, boolean isAgreementRelated) {
        String eventType = null;
        Long eventID = null;

        if (isAgreementRelated) {
            eventType = this.environment.getProperty(VERANLASSUNGS_TYPE_VER);
            eventID = this.agreementDAO.findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(person.getPersonUID(),
                            agreementID, branch).getAgreementUID();
        } else {
            eventType = this.environment.getProperty(VERANLASSUNGS_TYPE_PER);
            eventID = person.getPersonUID();
        }

        Trigger trigger = this.saveTrigger(new Date(System.currentTimeMillis()),
                        this.environment.getProperty(TRIGGER_TYPE_KEY), eventID, eventType, person.getBPKENN());

    }

    /**
     * Method to create trigger and notify in the correct channel
     * 
     * @param person Person person object
     * @param agreementID String ID of the agreement
     * @param branch Integer branch number
     * @param channel NotificationMatrixChannel channel to notify
     * @param isAgreementRelated boolean determines if notification is
     *            agreementRelated
     * @return notifications Notifications notifications object
     * @throws UnsupportedEncodingException
     */
    private Notifications createNotificationChannel(Person person, String agreementID, Integer branch,
                    NotificationMatrixChannel channel, boolean isAgreementRelated) throws UnsupportedEncodingException {

        InformationChannelTypeE informationChannel = channel.getInformationChannelType();
        String notificationPath = channel.getNotificationPath();
        Notifications notifications = null;

        switch (informationChannel) {
        case EMAIL:
            notifications = this.emailTemplateService.createEmailNotification(person, agreementID, branch,
                            notificationPath, isAgreementRelated);
            break;
        case PUSH:
            notifications = this.createPushNotification(person, notificationPath);
            break;
        }

        return notifications;
    }

    /**
     * Method to notify in PUSH channel
     * 
     * @param person Person person object
     * @param notificationPath String Path to send the notification
     * @return notifications Notifications notifications object
     * @throws UnsupportedEncodingException
     */
    private Notifications createPushNotification(Person person, String notificationPath)
                    throws UnsupportedEncodingException {

        String informationChannel = InformationChannelTypeE.PUSH.toString();
        String notifTextDE = this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push");
        // String notifTextEN = this.settings.getLocaleField("EN",
        // "subTextArea_DefaultText_Push");
        Notifications notifications = new Notifications();

        Long infoChannelUID = this.infoChannelDAO.getInformationChannelUID(informationChannel);

        this.saveNotification("STD", infoChannelUID, "OK", new Date(System.currentTimeMillis()));

        notifications.setNotificationPath(notificationPath);
        notifications.setNotificationSubject(this.environment.getProperty(EMAIL_SUBJECT_KEY));
        notifications.setNotificationType(informationChannel);
        notifications.setNotificationText(this.tools.base64Encode(notifTextDE));

        return notifications;
    }

    /**
     * Save Trigger Record
     * 
     * @param timestampTrigger Date Timestamp Trigger
     * @param triggerType String Trigger Type
     * @param eventID Long Event ID
     * @param eventType String Event Type
     * @param bpkenn String
     * @return Trigger Trigger Record
     */
    private Trigger saveTrigger(Date timestampTrigger, String triggerType, Long eventID, String eventType,
                    String bpkenn) {

        Trigger trigger = new Trigger();
        trigger.setTimestampTrigger(timestampTrigger);
        trigger.setTriggerType(triggerType);
        trigger.setEventID(eventID);
        trigger.setEventType(eventType);
        trigger.setBpkenn(bpkenn);

        LOGGER.info("=>> TRIGGER: [{}]", trigger.toString());

        return trigger;
    }

    /**
     * Save Notification Record to log file
     * 
     * @param notificationTextType String Type of Notification Text
     * @param informationChannelUID Long Information Channel UID
     * @param statusShipping String Shipping Status
     * @param timestampShipping Date Timestamp Shipping
     */
    private void saveNotification(String notificationTextType, Long informationChannelUID, String statusShipping,
                    Date timestampShipping) {

        Notification notification = new Notification();
        notification.setNotificationTextType(notificationTextType);
        notification.setInformationChannelUID(informationChannelUID);
        notification.setStatusShipping(statusShipping);
        notification.setTimestampShipping(timestampShipping);

        LOGGER.info("=>> NOTIFICATION: [{}]", notification.toString());

    }

}
