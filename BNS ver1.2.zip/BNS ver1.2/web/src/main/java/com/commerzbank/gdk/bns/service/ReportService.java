package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to access the Report
 * 
 * @since 11/01/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 11/01/2018        1.00       ZE2RUBI    Initial Version
 * </pre>
 */
public interface ReportService {

    Report saveReport(Report report,Tokenizer token);
    List<Report> saveReports(List<Report> reports,Tokenizer token);

}
