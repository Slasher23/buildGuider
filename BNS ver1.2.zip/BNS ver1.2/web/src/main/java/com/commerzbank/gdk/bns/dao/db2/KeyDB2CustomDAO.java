package com.commerzbank.gdk.bns.dao.db2;

import com.commerzbank.gdk.bns.model.db2.KeyDB2;

/**
 * Custom Key DB2 DAO Interface
 * 
 * @since 21/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 21/02/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
public interface KeyDB2CustomDAO {

	KeyDB2 callStoredProcedure(String keyType);

}
