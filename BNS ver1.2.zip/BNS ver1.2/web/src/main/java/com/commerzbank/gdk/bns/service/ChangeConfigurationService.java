package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeConfigurationResponse;

/**
 * Service Class for RequestForChangeConfiguration.
 * 
 * @author ZE2BAUL
 * @since 21/12/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2BAUL    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface ChangeConfigurationService {

    /**
     * 
     * Method for requesting change configuration.
     *
     * @param request RequestForChangeConfiguration sent by ZSL
     * @return RequestForChangeConfigurationResponse change configuration response
     */
    ChangeConfigurationResponse requestForChangeConfiguration(ChangeConfigurationRequest request);

}
