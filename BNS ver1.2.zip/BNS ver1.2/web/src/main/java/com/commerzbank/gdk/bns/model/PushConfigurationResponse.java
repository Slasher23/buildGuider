package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Response for Push Configuration
 * 
 * @since 27/10/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/10/2017        1.01       ZE2BUEN    Initial Version
 * </pre>
 */

@XmlRootElement
public class PushConfigurationResponse {

	@NotNull
	@Size(max = 255)
	private String status;
	
	/**
	 * Returns the value of Status
	 * 
	 * @return String Status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the value of Status
	 * 
	 * @param status String Status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Returns the String representation of Push Configuration Response Model
	 * 
	 * @return String String representation of Push Configuration Response Model
	 * 
	 */
	@Override
	public String toString() {
		return "PushConfigurationResponse [status=" + status + "]";
	}
	
}
