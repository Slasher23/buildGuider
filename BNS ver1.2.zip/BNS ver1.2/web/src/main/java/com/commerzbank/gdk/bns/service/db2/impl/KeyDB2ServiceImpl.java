package com.commerzbank.gdk.bns.service.db2.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.db2.KeyDB2DAO;
import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.model.db2.KeyDB2;
import com.commerzbank.gdk.bns.service.db2.KeyDB2Service;

/**
 * Service Implementation Class to get the result of key database stored procedure
 * 
 * @since 21/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 21/02/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
@Transactional
@Service
public class KeyDB2ServiceImpl implements KeyDB2Service {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(KeyDB2ServiceImpl.class);

	/**
	 * Key DB2 DAO
	 */
	@Autowired
	@Qualifier("keyDB2DAO")
	private KeyDB2DAO keyDB2DAO;

	/**
	 * Extracts Key DB2 Records base on Key Type
	 * 
	 * @param keyType
	 *            String Key Type
	 * @param token
	 *            Tokenizer user identity model
	 * @return keyList List<Key> Key Records
	 */
	@Override
	public List<Key> extractKeyDB2Records(String keyType, Tokenizer token) {

		List<Key> keyList = new ArrayList<>();

		KeyDB2 result = this.keyDB2DAO.callStoredProcedure(keyType);

		if (Objects.nonNull(result)) {
			keyList = this.parseData(result);
		}
		
		LOGGER.info("<<= User [{}] extractKeyDB2Records() request was successfully processed.", token.getUserId());

		return keyList;

	}

	/**
	 * Parse string data as Key Records
	 * 
	 * @param result
	 *            KeyDB2 Key DB2 stored procedure result
	 * @return keyList List<Key> Key Records
	 */
	private List<Key> parseData(KeyDB2 result) {

		List<Key> keyList = new ArrayList<>();
		int charCount = 283;
		int dataCount = result.getCount();

		if (dataCount > 0) {

			String data = result.getData();

			if (Objects.nonNull(data)) {

				String[] records = data.split("(?<=\\G.{" + charCount + "})");

				for (String record : records) {

					Key key = new Key();

					String keyType = record.substring(0, 5);
					String keyCode = record.substring(5, 15);
					String language = record.substring(15, 18);
					String shortText = record.substring(18, 83);
					String longText = record.substring(83, 283);

					key.setKeyTyp(keyType.trim());
					key.setKeyCode(keyCode.trim());
					key.setLanguage(language.trim());
					key.setKeyShortText(shortText.trim());
					key.setKeyLongText(longText.trim());

					keyList.add(key);

				}

			}

		}

		return keyList;

	}

}
