package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to implement the business logic in converting String
 * Databackpack from CIF to BNS Object
 * 
 * @since 21/12/2017
 * @author ZE2BUEN
 * @version 1.04
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2BUEN    Initial Version
 * 01/02/2018        1.01       ZE2BUEN    Updated databackpack deserializer implementation
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * 20/02/2018        1.03       ZE2FUEN    Updated implementation to CIF-Integration
 * 26/02/2018        1.04       ZE2BUEN    Removed databackpackDeserializer and filter methods.
 * </pre>
 */

public interface DatabackpackService {

	public ResponseBuilder<Databackpack> databackpackProcessor(Tokenizer token);
	
	public Databackpack databackpackDecryptor(String token);

	public List<Agreement> agreementFilterByDatabackpack(Databackpack databackpack, List<Agreement> agreements, long personUid);
	
}
