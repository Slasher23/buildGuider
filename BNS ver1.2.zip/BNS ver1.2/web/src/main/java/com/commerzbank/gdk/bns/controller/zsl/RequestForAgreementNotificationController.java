package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.AgreementNotificationRequest;
import com.commerzbank.gdk.bns.model.RequestForAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotification;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotificationResponse;
import com.commerzbank.gdk.bns.service.RequestForAgreementNotificationService;

/**
 * RequestForAgreementNotificationController - Accept agreement notification
 * request and return the update agreement response to ZSL.
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 11/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2JAVO    Added API method for batch
 * 13/12/2017        1.02       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.03       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class RequestForAgreementNotificationController {

    @Autowired
    private RequestForAgreementNotificationService agreementNotificationService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForAgreementNotificationController.class);

    /**
     * Accept client post for agreement notification request then call service
     * to get the agreement notification response then return, also produces XML
     * or JSON format.
     * 
     * @param agreementNotificationRequest
     * @param request
     * @return RequestForAgreementNotificationResponse
     */
    @PostMapping(value = "/api/zsl/requestForAgreementNotification")
    public ResponseEntity<RequestForAgreementNotificationResponse> requestForAgreementNotification(
            @Valid @RequestBody AgreementNotificationRequest agreementNotificationRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForAgreementNotification({})", "ZSL",
                agreementNotificationRequest.toString());

        RequestForAgreementNotificationResponse notifConfigResponse = new RequestForAgreementNotificationResponse();

        if (!result.hasErrors()) {
            notifConfigResponse = this.agreementNotificationService
                    .requestForAgreementNotification(agreementNotificationRequest);

            if (Objects.isNull(notifConfigResponse)) {
                notifConfigResponse = new RequestForAgreementNotificationResponse();
            }

        }

        ResponseEntity<RequestForAgreementNotificationResponse> response = new ResponseEntity<RequestForAgreementNotificationResponse>(
                notifConfigResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", notifConfigResponse.toString());

        return response;
    }

    /**
     * Accept client post for batch agreement notification request then call
     * service to get the agreement notification response then return, also
     * produces XML or JSON format.
     * 
     * @param agreementNotificationRequest
     * @param request
     * @return RequestForAgreementNotificationResponse
     */
    @PostMapping(value = "/api/zsl/requestForBatchAgreementNotification")
    public ResponseEntity<RequestForBatchAgreementNotificationResponse> requestForBatchAgreementNotification(
            @Valid @RequestBody RequestForBatchAgreementNotification requestForBatchAgreementNotification,
            HttpServletRequest request, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForBatchAgreementNotification({})", "ZSL",
                requestForBatchAgreementNotification.toString());

        RequestForBatchAgreementNotificationResponse batchResponse = new RequestForBatchAgreementNotificationResponse();

        if (!result.hasErrors()) {
            batchResponse = this.agreementNotificationService
                    .requestForBatchAgreementNotification(requestForBatchAgreementNotification);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new RequestForBatchAgreementNotificationResponse();
            }

        }

        ResponseEntity<RequestForBatchAgreementNotificationResponse> response = new ResponseEntity<RequestForBatchAgreementNotificationResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;
    }

}
