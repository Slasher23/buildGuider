package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Change Email Address
 * 
 * @since 27/11/2017
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2BUEN    Initial Version
 * </pre>
 */

@XmlRootElement
public class ChangeEmailAddressBatchRequest {

	private List<ChangeEmailAddressRequest> changeEmailAddressRequest;

	/**
	 * Returns the List of Change Email Address Request
	 * 
	 * @return List List of Change Email Address Request
	 */
	public List<ChangeEmailAddressRequest> getChangeEmailAddressRequest() {
		return changeEmailAddressRequest;
	}

	/**
	 * Sets the List of Change Email Address Request
	 * 
	 * @param changeEmailAddressRequest
	 *            String List of Change Email Address Request to set
	 */
	public void setChangeEmailAddressRequest(List<ChangeEmailAddressRequest> changeEmailAddressRequest) {
		this.changeEmailAddressRequest = changeEmailAddressRequest;
	}

	/**
	 * Returns the String representation of Change Email Address Batch Request Model
	 * 
	 * @return String String representation of Change Email Address Batch Request
	 *         Model
	 */
	@Override
	public String toString() {
		return "ChangeEmailAddressBatchRequest [changeEmailAddressRequest=" + changeEmailAddressRequest + "]";
	}

}
