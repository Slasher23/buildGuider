package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class used to access the PersonConfig
 * 
 * @since 03/10/2017
 * @author ZE2BAUL
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017        1.00       ZE2BAUL    Initial Version
 * 10/11/2017        1.01       ZE2MACL    Update method to user Response builder and add tokenizer parameter
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface PersonConfigService {
	
    ResponseBuilder<NotificationConfigPerson> getNotifConfigPersonById(Tokenizer token, Long UID);

    ResponseBuilder<NotificationConfigPerson> postCustomer(Tokenizer token, NotificationConfigPerson notificationConfigPerson);

    ResponseBuilder<List<NotificationConfigPerson>> getNotifConfigPersonList(Tokenizer token);

	ResponseBuilder<PersonConfig> postNotifConfigPerson(Tokenizer token, PersonConfig savingNotifConfigPerson);

}
