package com.commerzbank.gdk.bns.model;

import java.util.Map;

/**
 * Wrapper Class for Global Response
 * 
 * @since 25/07/2017
 * @author ZE2RUBI
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 25/07/2017        1.00       ZE2RUBI    Initial Version
 * 09/11/2017        1.01       ZE2MACL    Update to used Response instead of ResponseMessage
 * 23/11/2017        1.02       ZE2MORA    Added Status Codes Map
 *          </pre>
 */
public class GlobalResponseWrapper {

	private Map<String, Response<String>> responseMessageMap;

	private Map<Integer, String> statusCodesMap;

	/**
	 * Returns the Response Message Map
	 * 
	 * @return Map Response Message Map
	 */
	public Map<String, Response<String>> getResponseMessageMap() {
		return responseMessageMap;
	}

	/**
	 * Sets the Event Type Map
	 * 
	 * @param responseMessageMap
	 *            Map Response Message Map to set
	 */
	public void setResponseMessageMap(Map<String, Response<String>> responseMessageMap) {
		this.responseMessageMap = responseMessageMap;
	}

	/**
	 * Returns the Status Codes Map
	 *
	 * @return Map Status Codes Map
	 */
	public Map<Integer, String> getStatusCodesMap() {
		return statusCodesMap;
	}

	/**
	 * Sets the Status Codes Map
	 *
	 * @param statusCodesMap
	 *            the statusCodesMap to set
	 */
	public void setStatusCodesMap(Map<Integer, String> statusCodesMap) {
		this.statusCodesMap = statusCodesMap;
	}

	/**
	 * Returns specific item on the Response Message Map
	 * 
	 * @param code
	 *            String code
	 * @return ResponseMessage Item on Response Message Map
	 */
	public Response<String> get(String code) {
		return this.responseMessageMap.get(code);
	}

	/**
	 * Returns the String representation of Global Response Wrapper
	 * 
	 * @return String String representation of Global Response Wrapper
	 */
	@Override
	public String toString() {
		return "GlobalResponseWrapper [responseMessageMap= " + responseMessageMap + ", + statusCodesMap= "
				+ statusCodesMap + "]";
	}

}
