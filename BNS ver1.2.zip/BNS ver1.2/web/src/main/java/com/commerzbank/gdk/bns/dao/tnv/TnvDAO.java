package com.commerzbank.gdk.bns.dao.tnv;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.tnv.Tnv;

/**
 * TNV DAO Interface
 * 
 * @since 05/03/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 05/03/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */
public interface TnvDAO extends CrudRepository<Tnv, Long>, TnvCustomDAO {

}
