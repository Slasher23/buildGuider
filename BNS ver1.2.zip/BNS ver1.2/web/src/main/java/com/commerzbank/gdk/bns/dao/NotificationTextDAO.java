package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.NotificationText;

/**
 * Notification Text DAO Interface
 * 
 * @since 30/06/2017
 * @author ZE2MENY
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 30/06/2017		1.00		ZE2MENY 	Initial Version
 * 07/03/2018       1.01        ZE2FUEN     Used list as input for findByNotificationTextUIDIn method
 * </pre>
 */

public interface NotificationTextDAO extends CrudRepository <NotificationText, Long>, NotificationTextCustomDAO{
    
    NotificationText findByNotificationTextUID(Long notificationUID);
    List<NotificationText> findByNotificationTextUIDIn(List<Long> notificationUIDList);

}
