package com.commerzbank.gdk.bns.utils;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.commerzbank.gdk.bns.conf.CryptoServiceConfig;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Tools class for reusable methods
 * 
 * @since 19/09/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 19/09/2017        1.00       ZE2BUEN    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 * 01/03/2018        1.02       ZE2MACL    Added try catch 
 * 01/03/2018        1.03       ZE2FUEN    Implemented BNStoken builder
 *          </pre>
 */
@Component
public class Tools {

    private static final Logger LOGGER = LoggerFactory.getLogger(Tools.class);

    @Autowired
    private CryptoServiceConfig config;

    /**
     * Encode string token to base64 string
     * 
     * @param token
     *            String Token to encode
     * @return String Encoded string token
     */
    public String base64Encode(String token) {
		String encoded = null;
		
        try {
            encoded = DatatypeConverter.printBase64Binary(token.getBytes("utf-8"));
        } catch (UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage(), e);
        }
		
		return encoded;
	}

    /**
     * Decode base64 string token to string
     * 
     * @param token
     *            String Token to decode
     * @return String Decoded string token
     */
    public String base64Decode(String token) {
        String decoded = new String(DatatypeConverter.parseBase64Binary(token));

        return decoded;
    }

    /**
     * // * Convert Object to JSON
     * 
     * @param obj
     *            Object to encode
     * @return String JSON value
     */
    public String jsonify(Object obj) {
        ObjectMapper mapper = new ObjectMapper();

        String jsonInString = null;

        try {
            jsonInString = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return jsonInString;
    }

    /**
     * Method to create a pipe delimited bnsToken
     * 
     * @param token
     *            Tokenizer
     * @param agreementTypeWrapper
     *            MainAgreementTypeWrapper
     * @return String
     * 
     */
    public String bnsTokenBuilder(Tokenizer token, MainAgreementTypeWrapper agreementTypeWrapper) {

        List<String> agreementUIDList = new ArrayList<String>();
        StringBuilder agreementsBuilder = new StringBuilder();
        StringBuilder bnsTokenBuilder = new StringBuilder();

        for (AgreementTypesWrapper agreementType : agreementTypeWrapper.getAgreementTypes()) {

            for (NotificationConfigAgreementWrapper agreementConfig : agreementType.getAgreements()) {
                agreementUIDList.add(agreementConfig.getNotificationConfigAgreement().getAgreementUID().toString());
            }

        }

        for (String agreementUID : agreementUIDList) {
            agreementsBuilder.append(agreementUID).append(",");
        }

        String agreements = agreementsBuilder.toString();

        bnsTokenBuilder.append(token.getRole());
        bnsTokenBuilder.append("|");
        bnsTokenBuilder.append(config.encrypt(agreements));

        return this.base64Encode(bnsTokenBuilder.toString());
    }

    /**
     * Method to decode and split bnsToken
     * 
     * @param bnsToken
     *            String
     * @return List<String>
     * 
     */
    public List<String> bnsTokenDebuilder(String bnsToken) {

        String bnsTokenDecoded = this.base64Decode(bnsToken);
        String[] splitToken = bnsTokenDecoded.split(Pattern.quote("|"));
        List<String> bnsTokenList = Arrays.asList(splitToken);

        if (bnsTokenList.size() > 1) {
            bnsTokenList.set(1, config.decrypt(bnsTokenList.get(1)));
        }

        return bnsTokenList;
    }

}
