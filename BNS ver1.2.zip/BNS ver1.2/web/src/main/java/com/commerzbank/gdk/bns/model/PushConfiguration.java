package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Push Konfig(Push Configuration) Table
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.01       ZE2BUEN    Initial Version
 * 23/11/2017        1.02       ZE2BUEN    Modified TEILNEHMENUMMER_UID to PERSON_UID
 * </pre>
 */

@Entity
@Table(name = "PUSH_KONFIG")
@XmlRootElement
public class PushConfiguration {

	@Id
	@Column(name = "PUSH_KONFIG_UID")
	@GeneratedValue(generator = "PUSH_KONFIG_UID_SEQ")
	@SequenceGenerator(name = "PUSH_KONFIG_UID_SEQ", sequenceName = "PUSH_KONFIG_SEQ")
	private Long pushConfigurationUID;

	@NotNull
	@Max(value = 99999999999L)
	@Column(name = "PERSON_UID")
	private Long personUID;

	@NotNull
	@Size(max = 50)
	@Column(name = "APP_ID")
	private String appID;

	@NotNull
	@Size(max = 50)
	@Column(name = "APP_NAME")
	private String appName;

	@NotNull
	@Size(max = 50)
	@Column(name = "APP_VERSION")
	private String appVersion;

	@NotNull
	@Size(max = 50)
	@Column(name = "DEVICE_ID")
	private String deviceID;

	@NotNull
	@Column(name = "AKTIV")
	private boolean active;

	/**
	 * Returns the value of Unique Identifier of Push Configuration Record
	 * 
	 * @return Long Unique Identifier of Push Configuration Record
	 */
	public Long getPushConfigurationUID() {
		return pushConfigurationUID;
	}

	/**
	 * Sets the value of Unique Identifier of Push Configuration Record
	 * 
	 * @param pushConfigurationUID
	 *            Long Unique Identifier of Push Configuration Record to set
	 */
	public void setPushConfigurationUID(Long pushConfigurationUID) {
		this.pushConfigurationUID = pushConfigurationUID;
	}

	/**
	 * Returns the value of Unique Identifier of Person Record
	 * 
	 * @return Long Unique Identifier of Person Record
	 */
	public Long getPersonUID() {
		return personUID;
	}

	/**
	 * Sets the value of Unique Identifier of Person Record
	 * 
	 * @param personUID
	 *            Long Unique Identifier of Person Record to set
	 */
	public void setPersonUID(Long personUID) {
		this.personUID = personUID;
	}

	/**
	 * Returns the value of Identifier of Mobile Application
	 * 
	 * @return String Identifier of Mobile Application
	 */
	public String getAppID() {
		return appID;
	}

	/**
	 * Sets the value of Identifier of Mobile Application
	 * 
	 * @param appID
	 *            String Identifier of Mobile Application to set
	 */
	public void setAppID(String appID) {
		this.appID = appID;
	}

	/**
	 * Returns the value of Name of Mobile Application
	 * 
	 * @return String Name of Mobile Application
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * Sets the value of Name of Mobile Application
	 * 
	 * @param appName
	 *            String Name of Mobile Application to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * Returns the value of Version of Mobile Application
	 * 
	 * @return String Version of Mobile Application
	 */
	public String getAppVersion() {
		return appVersion;
	}

	/**
	 * Sets the value of Version of Mobile Application
	 * 
	 * @param appVersion
	 *            String Version of Mobile Application to set
	 */
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	/**
	 * Returns the value of Identifier of Device
	 * 
	 * @return String Identifier of Device
	 */
	public String getDeviceID() {
		return deviceID;
	}

	/**
	 * Sets the value of Version of Identifier of Device
	 * 
	 * @param appVersion
	 *            String Version of Identifier of Device to set
	 */
	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	/**
	 * Returns the value of Active Push Configuration Flag
	 * 
	 * @return boolean Active Push Configuration Flag
	 */
	public boolean getActive() {
		return active;
	}

	/**
	 * Sets the value of Active Push Configuration Flag
	 * 
	 * @param active
	 *            boolean Active Push Configuration Flag to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Returns the String representation of Push Configuration Model
	 * 
	 * @return String String representation of Push Configuration Model
	 * 
	 */
	@Override
	public String toString() {
		return "PushConfiguration [pushConfigurationUID= " + pushConfigurationUID + " , personUID= "
				+ personUID + " , appID= " + appID + " , appName= " + appName + " , appVersion= "
				+ appVersion + " , deviceID= " + deviceID + " , active= " + active + "]";
	}

}
