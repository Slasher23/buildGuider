package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.RequestForBatchDeactivatePerson;
import com.commerzbank.gdk.bns.model.RequestForDeactivatePersonResponse;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * Service Class used to access the RequestForDeactivatePersonServiceImpl.
 * 
 * @since 28/11/2017
 * @author ZE2GOME
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2GOME    Initial Version
 * 29/11/2017        1.01       ZE2GOME    Add method for batch request
 * 04/12/2017        1.02       ZE2GOME    Change response of batch request to RequestForDeactivatePersonResponse
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface RequestForDeactivatePersonService {

	/**
	 * This is to request to deactivate a Person entity.
	 *
	 * @param param
	 *            The request.
	 * @return ZslUpdateResponse Response to be.
	 */
	ZslUpdateResponse requestForDeactivatePerson(Parameter param);

	/**
	 * This is to request to deactivate a batch Person entity.
	 *
	 * @param param
	 *            The request
	 * @return RequestForDeactivatePersonResponse Response to be.
	 */
	RequestForDeactivatePersonResponse requestFordeactivatePersonList(RequestForBatchDeactivatePerson param);

}
