package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.Agreement;

/**
 * Agreement DAO Interface
 * 
 * @since 03/07/2017
 * @author ZE2FUEN
 * @version 1.05
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 03/07/2017		1.00		ZE2FUEN 	Initial Version
 * 23/11/2017       1.01        ZE2SARO     Change participantUID to personUID
 * 22/12/2017       1.02        ZE2BAUL     Added a method for finding agreementID
 * 22/12/2017       1.03        ZE2MENY     Added methods for stored proc
 * 27/12/2017       1.04        ZE2JAVO     Added query findByAgreementIDIgnoreCaseAndBranch
 * 05/01/2018       1.05        ZE2BUEN     Added query method findByPersonUID
 * 28/02/2018       1.06        ZE2FUEN     Added query method findByAgreementUIDIn
 *          </pre>
 */

public interface AgreementDAO extends PagingAndSortingRepository<Agreement, Long>, AgreementCustomDAO {

    Agreement findByPersonUIDAndAgreementIDIgnoreCaseAndBranch(Long personUID, String agreementID, Integer branch);

    Agreement findByAgreementID(String agreementID);

    List<Agreement> findByAgreementIDIgnoreCaseAndBranch(String agreementID, Integer branch);

    Agreement findByAgreementUID(Long agreementUID);
    
    List<Agreement> findByAgreementUIDIn(List<Long> agreementUID);

    List<Agreement> findByPersonUID(Long personUID);

}
