package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for CustomerNotificationsBatchRequest
 * 
 * @since 10/11/2017
 * @author ZE2SARO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017        1.00       ZE2SARO    Initial Version
 *          </pre>
 */

@XmlRootElement(name = "CustomerBatchNotificationsRequest")
public class CustomerBatchNotificationsRequest {

    private List<CustomerNotificationRequest> customerNotificationsRequest;

    /**
     * @return the customerNotificationsRequest
     */
    public List<CustomerNotificationRequest> getCustomerNotificationsRequest() {
        return customerNotificationsRequest;
    }

    /**
     * @param customerNotificationsRequest the customerNotificationsRequest to
     *            set
     */
    public void setCustomerNotificationsRequest(List<CustomerNotificationRequest> customerNotificationsRequest) {
        this.customerNotificationsRequest = customerNotificationsRequest;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CustomerNotificationsBatchRequest [customerNotificationsRequest=" + customerNotificationsRequest + "]";
    }

}
