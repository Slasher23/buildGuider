package com.commerzbank.gdk.bns.model;

/**
 * Model Class for Request for Person Exists.
 * 
 * @since 12/12/2017
 * @author ZE2MENY
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2MENY    Initial Version
 *          </pre>
 */
public class PersonExistsRequest {

    private String bpkenn;

    /**
     * Returns the value of bpkenn.
     * 
     * @return String bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * Sets the value of bpkenn.
     * 
     * @param bpkenn String bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Returns the String representation of Person Exists Request Model.
     * 
     * @return String String representation of Person Exists Request Model
     * 
     */
    @Override
    public String toString() {
        return "PersonExistsRequest [bpkenn=" + bpkenn + "]";
    }
}
