package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Change Email Address
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2BUEN    Initial Version
 * 23/11/2017        1.01       ZE2BUEN    Removed first email address and second email address on request.
 *                                         Added address ID, email address and change event type on request.
 * </pre>
 */

@XmlRootElement
public class ChangeEmailAddressRequest {

	private String bpkenn;

	private Long addressId;

	private String emailAddress;

	private String changeEventType;

	/**
	 * Returns the value of BPKENN
	 * 
	 * @return String BPKENN
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * Sets the value of BPKENN
	 * 
	 * @param bpkenn
	 *            String BPKENN to set
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the value of Address ID
	 * 
	 * @return Long Address ID
	 */
	public Long getAddressId() {
		return addressId;
	}

	/**
	 * Sets the value of Address ID
	 * 
	 * @param addressId
	 *            Long Address ID to set
	 */
	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	/**
	 * Returns the value of Email Address
	 * 
	 * @return String Email Address
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * Sets the value of Email Address
	 * 
	 * @param emailAddress
	 *            String Email Address to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * Returns the value of Change Event Type
	 * 
	 * @return String Change Event Type
	 */
	public String getChangeEventType() {
		return changeEventType;
	}

	/**
	 * Sets the value of Change Event Type Address
	 * 
	 * @param changeEventType
	 *            String Change Event Type to set
	 */
	public void setChangeEventType(String changeEventType) {
		this.changeEventType = changeEventType;
	}

	/**
	 * Returns the String representation of Change Email Address Request Model
	 * 
	 * @return String String representation of Change Email Address Request
	 *         Model
	 * 
	 */
	@Override
	public String toString() {
		return "ChangeEmailAddressRequest [bpkenn=" + bpkenn + ", addressId=" + addressId + ", emailAddress="
				+ emailAddress + ", changeEventType=" + changeEventType + "]";
	}

}
