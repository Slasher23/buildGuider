package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.conf.security.AuthenticatedUser;
import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementConfigService;

/**
 * AgreementConfigController Accept request and return the expected record to
 * client.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.07
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 25/09/2017      1.01      ZE2BAUL    Refactoring of GetMapping to PostMapping
 * 28/09/2017	   1.02		 ZE2BAUL    Applied the logging standards
 * 13/10/2017	   1.03		 ZE2RUBI    Clean Up and Implement JWT
 * 14/11/2017      1.04      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.05      ZE2SARO    Add Validation
 * 12/02/2018      1.06      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.07      ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@RestController
public class AgreementConfigController {

    @Autowired
    private AgreementConfigService agreementConfigService;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(AgreementConfigController.class);

    /**
     * Accept client get request then call service to get all the agreement
     * config then return also produces xml or json format.
     * 
     * @param bnsInternal
     *            BNS Internal (Parameter)
     * @return all agreement config.
     * 
     */
    @PostMapping(value = "/api/agreementConfigList")
    public ResponseEntity<Response<AgreementConfig>> getNotifConfigAgreementList(HttpServletRequest request,
            Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] getNotifConfigAgreementList()", token.getUserId());

        ResponseBuilder<AgreementConfig> builder = this.agreementConfigService.getNotifConfigAgreementsList(token);

        return builder.responseEntity();
    }

    /**
     * Accept client post request and call service to save the data send by
     * client and return the saved data also consumes and produces json or xml
     * format.
     * 
     * @param bnsInternal
     *            BNS Internal (Agreement Config)
     * @return all the saved agreement config.
     * 
     */
    @PostMapping(value = "/api/agreementConfig")
    public ResponseEntity<Response<AgreementConfig>> postNotifConfigAgreement(
            @Valid @RequestBody AgreementConfig agreementConfig, BindingResult result, HttpServletRequest request,
            Authentication auth) {

        AuthenticatedUser user = (AuthenticatedUser) auth.getPrincipal();
        Tokenizer token = user.getToken();

        LOGGER.info("=>> User [{}] postNotifConfigAgreement({})", token.getUserId(), agreementConfig.toString());

        ResponseBuilder<AgreementConfig> builder = new ResponseBuilder<AgreementConfig>(LOGGER, token,
                globalResponseWrapper);

        if (!result.hasErrors() && Tokenizer.validator(token)) {
            builder = this.agreementConfigService.postNotifConfigAgreement(token, agreementConfig);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

        return builder.responseEntity();
    }

}
