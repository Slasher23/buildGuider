package com.commerzbank.gdk.bns.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementNotificationRequest;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotification;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.rules.NotificationRuleBook;
import com.commerzbank.gdk.bns.service.EmailTemplateService;
import com.commerzbank.gdk.bns.service.KeyService;
import com.commerzbank.gdk.bns.service.RequestForAgreementNotificationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;
import com.commerzbank.gdk.bns.utils.Tools;

import freemarker.template.Configuration;

/**
 * Service Implementation Class for RequestForAgreementNotificationService.
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.10
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 11/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2JAVO    Added method for batch
 * 21/12/2017        1.02       ZE2JAVO    Added implementations to single and batch response
 * 27/12/2017        1.03       ZE2MACL    Updated method and add new method for complete response
 * 11/01/2018        1.04       ZE2FUEN    Added Daily Logging
 * 22/01/2018        1.05       ZE2MACL    Added method for validation of request
 * 02/02/2018        1.06       ZE2FARI    Removed the generation of email template
 * 07/02/2018        1.07       ZE2MACL    Remove throws Exception and replace it with try catch block
 * 20/02/2018        1.08       ZE2MACL    Added error message status 
 * 21/02/2018        1.09       ZE2MACL    Added required field/s validation
 * 08/03/2018        1.10       ZE2BUEN    Added new error messages for TNV stored procedure validation
 * </pre>
 */
@Service
@Transactional
public class RequestForAgreementNotificationServiceImpl implements RequestForAgreementNotificationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForAgreementNotificationServiceImpl.class);

    @Value("${NOTIF_EVENT02}")
    private String eventType;

    private static final String STATUS_FA_INVALID_REQUEST                       = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST           = "ZSL_STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS                     = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String EMAIL_SUBJECT_KEY                               = "EMAIL_SUBJECT";
    private static final String STATUS_OK                                       = "ZSL_STATUS_OK";
    private static final String STATUS_FA_NO_AVAIL_NOTIF_CONFIG                 = "ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID";
    private static final String STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING              = "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING";
    private static final String STATUS_FA_NOT_SENT                              = "ZSL_STATUS_FA_NOT_SENT";
    private static final String STATUS_FA_FAILED_AGREEMENT_NOTIF                = "ZSL_STATUS_FA_FAILED_AGREEMENT_NOTIFICATION";
    private static final String STATUS_FA_NO_AVAIL_EMAIL                        = "ZSL_STATUS_FA_NO_AVAIL_EMAIL";
    private static final String STATUS_FA_NO_ACTIVATED_CONFIG                   = "ZSL_STATUS_FA_NO_ACTIVATED_CONFIG";
    private static final String STATUS_FA_TNV_NOTIFICATION_REJECTED             = "ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED";
    private static final String STATUS_FA_TNV_CANT_PROCESS_REQUEST              = "ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST";
    private static final String EMPTY_STRING                                    = "";

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private PersonDAO personDao;

    @Autowired
    private Settings settings;

    @Autowired
    private Tools tools;

    @Autowired
    private NotificationRuleBook notificationRuleBook;

    @Autowired
    private DailyReportLogDAO dailyReportLogDAO;

    @Autowired
    private EmailTemplateService emailTemplateService;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    /**
     * Logic for request for agreement notification.
     * 
     * @param agreementNotificationRequest AgreementNotificationRequest
     * @return response RequestForAgreementNotificationResponse
     */
    @Override
    public RequestForAgreementNotificationResponse requestForAgreementNotification(
                    AgreementNotificationRequest agreementNotificationRequest) {
        String status = EMPTY_STRING;

        DailyReportLog dailyReportLog = new DailyReportLog();
        dailyReportLog.setEventType(eventType);
        dailyReportLog.setTimestamp(new Date());
        this.dailyReportLogDAO.save(dailyReportLog);

        RequestForAgreementNotificationResponse response = new RequestForAgreementNotificationResponse();

        try {
            status = validateRequestNull(agreementNotificationRequest);
            if (isNullOrEmpty(status)) {

                List<Agreement> listAgreement = this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(
                                agreementNotificationRequest.getVereinbarungskennung(),
                                agreementNotificationRequest.getSparte());

                if ((!listAgreement.isEmpty())) {

                    List<Notifications> notificationList = new ArrayList<Notifications>();
                    NotificationResponse notifResponse = new NotificationResponse();
                    List<NotificationResponse> notifResponseList = new ArrayList<NotificationResponse>();

                    boolean isAgreementRelated = true;
                    String agreementID = agreementNotificationRequest.getVereinbarungskennung();
                    Integer branch = agreementNotificationRequest.getSparte();

                    for (Agreement agreement : listAgreement) {

                        Person person = this.personDao.findOne(agreement.getPersonUID());

                        if (Objects.nonNull(person)) {
                            NotificationMatrixResponse matrixResponse = this.notificationRuleBook.checkDecisionLevel(
                                            person.getBPKENN(), branch, agreementID, isAgreementRelated);
                            int successCount = 0;

                            if (Objects.nonNull(matrixResponse)) {
                                if (matrixResponse.getNotificationMatrixChannel().size() > 0) {
                                    successCount++;

                                    for (NotificationMatrixChannel channel : matrixResponse
                                                    .getNotificationMatrixChannel()) {
                                        Notifications notifications = this.createNotificationChannel(person,
                                                        agreementID, branch, channel, isAgreementRelated);
                                        notificationList.add(notifications);

                                    }
                                }
                            }

                            if (successCount > 0) {
                                notifResponse.setStatus(this.environment.getProperty(STATUS_OK));
                                notifResponse.setBPKENN(person.getBPKENN());
                                notifResponse.setNotification(notificationList);
                                notifResponseList.add(notifResponse);
                                response.setStatus(this.environment.getProperty(STATUS_OK));
                            } else {
                                if (matrixResponse.getStatus().equalsIgnoreCase(
                                                "ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID")) {
                                    response.setStatus(this.environment
                                                    .getProperty(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING_AGREEMENT_ID));
                                } else if (matrixResponse.getStatus()
                                                .equalsIgnoreCase("ZSL_STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING")) {
                                    response.setStatus(
                                                    this.environment.getProperty(STATUS_FA_TNV_BPKENN_NO_ONLINE_BANKING));
                                } else if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_NOT_SENT")) {
                                    response.setStatus(this.environment.getProperty(STATUS_FA_NOT_SENT));
                                } else if (matrixResponse.getStatus()
                                                .equalsIgnoreCase("ZSL_STATUS_FA_NO_AVAIL_NOTIF_CONFIG")) {
                                    response.setStatus(this.environment.getProperty(STATUS_FA_NO_AVAIL_NOTIF_CONFIG));
                                } else if (matrixResponse.getStatus()
                                                .equalsIgnoreCase("ZSL_STATUS_FA_BPKENN_NOT_EXISTS")) {
                                    response.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                                } else
                                    if (matrixResponse.getStatus().equalsIgnoreCase("ZSL_STATUS_FA_NO_AVAIL_EMAIL")) {
                                    response.setStatus(this.environment.getProperty(STATUS_FA_NO_AVAIL_EMAIL));
                                } else if (matrixResponse.getStatus()
                                                .equalsIgnoreCase("ZSL_STATUS_FA_NO_ACTIVATED_CONFIG")) {
                                    response.setStatus(this.environment.getProperty(STATUS_FA_NO_ACTIVATED_CONFIG));
								} else if (matrixResponse.getStatus()
										.equalsIgnoreCase("ZSL_STATUS_FA_TNV_NOTIFICATION_REJECTED")) {
									response.setStatus(this.environment.getProperty(STATUS_FA_TNV_NOTIFICATION_REJECTED));
								} else if (matrixResponse.getStatus()
										.equalsIgnoreCase("ZSL_STATUS_FA_TNV_CANT_PROCESS_REQUEST")) {
									response.setStatus(
											this.environment.getProperty(STATUS_FA_TNV_CANT_PROCESS_REQUEST));
								}

                            }

                        } else {
                            notifResponse.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                        }
                    }

                    response.setSparte(branch);
                    response.setVereinbarungskennung(agreementID);
                    response.setAgreementNotifications(notifResponseList);

                } else {
                    response = setAgreementResponse(agreementNotificationRequest.getSparte(),
                                    agreementNotificationRequest.getVereinbarungskennung(),
                                    new ArrayList<NotificationResponse>(),
                                    this.environment.getProperty(STATUS_FA_AGREEMENT_ID_DOES_NOT_EXIST));
                }

            } else {

                response = setAgreementResponse(agreementNotificationRequest.getSparte(),
                                agreementNotificationRequest.getVereinbarungskennung(),
                                new ArrayList<NotificationResponse>(), status);

            }

        } catch (Exception e) {
            response.setStatus(this.environment.getProperty(STATUS_FA_FAILED_AGREEMENT_NOTIF));
            LOGGER.error(e.getMessage(), e);
        }

        return response;
    }

    /**
     * Method to create trigger and notify in the correct channel
     * 
     * @param person Person person object
     * @param agreementID String ID of the agreement
     * @param branch Integer branch number
     * @param channel NotificationMatrixChannel channel to notify
     * @param isAgreementRelated boolean determines if notification is
     *            agreementRelated
     * @return notifications Notifications notifications object
     * @throws UnsupportedEncodingException
     */
    private Notifications createNotificationChannel(Person person, String agreementID, Integer branch,
                    NotificationMatrixChannel channel, boolean isAgreementRelated) throws UnsupportedEncodingException {

        InformationChannelTypeE informationChannel = channel.getInformationChannelType();
        String notificationPath = channel.getNotificationPath();
        Notifications notifications = null;

        switch (informationChannel) {
        case EMAIL:
            notifications = this.emailTemplateService.createEmailNotification(person, agreementID, branch,
                            notificationPath, isAgreementRelated);
            break;
        case PUSH:
            notifications = this.createPushNotification(person, notificationPath);
            break;
        }

        return notifications;
    }

    /**
     * Method to notify in PUSH channel
     * 
     * @param person Person person object
     * @param notificationPath String Path to send the notification
     * @return notifications Notifications notifications object
     */
    private Notifications createPushNotification(Person person, String notificationPath)
                    throws UnsupportedEncodingException {

        String informationChannel = InformationChannelTypeE.PUSH.toString();
        String notifTextDE = this.settings.getLocaleField("DE", "subTextArea_DefaultText_Push");
        // String notifTextEN = this.settings.getLocaleField("EN",
        // "subTextArea_DefaultText_Push");
        Notifications notifications = new Notifications();

        notifications.setNotificationPath(notificationPath);
        notifications.setNotificationSubject(this.environment.getProperty(EMAIL_SUBJECT_KEY));
        notifications.setNotificationType(informationChannel);
        notifications.setNotificationText(this.tools.base64Encode(notifTextDE));

        return notifications;
    }

    /**
     * Set response if objects is null.
     * 
     * @param agreementNotif
     * @param sparte
     * @param vereinbarungskennung
     * @param property
     * @return
     */
    private RequestForAgreementNotificationResponse setAgreementResponse(Integer sparte, String vereinbarungskennung,
                    List<NotificationResponse> listNotifResponse, String status) {

        RequestForAgreementNotificationResponse response = new RequestForAgreementNotificationResponse();

        response.setSparte(sparte);
        response.setVereinbarungskennung(vereinbarungskennung);
        response.setStatus(status);
        response.setAgreementNotifications(listNotifResponse);

        return response;
    }

    /**
     * Method to validate data in AgreementNotification Request
     * 
     * @param Branch
     * @param AgreementID
     * 
     * @return String
     */
    private String validateRequestNull(AgreementNotificationRequest agreementNotificationRequest) {

        HashSet<String> invalidFields = new HashSet<String>();
        String invalidMsg;

        boolean nullAgreementID = this.isNullOrEmpty(agreementNotificationRequest.getVereinbarungskennung());
        boolean nullBranch = Objects.isNull(agreementNotificationRequest.getSparte());

        if (nullAgreementID) {
            invalidFields.add("vereinbarungskennung");
        }

        if (nullBranch) {
            invalidFields.add("sparte");
        }

        invalidMsg = requiredFieldValidation.requiredField(invalidFields);

        return invalidMsg;

    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return boolean
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        Boolean isValidString = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;
        return isValidString;

    }

    /**
     * Logic for request for batch agreement notification.
     * 
     * @param request BatchAgreementNotificationRequest
     * @return response RequestForBatchAgreementNotificationResponse
     */
    @Override
    public RequestForBatchAgreementNotificationResponse requestForBatchAgreementNotification(
                    RequestForBatchAgreementNotification request) {

        RequestForBatchAgreementNotificationResponse response = new RequestForBatchAgreementNotificationResponse();

        List<RequestForAgreementNotificationResponse> noErrors = new ArrayList<RequestForAgreementNotificationResponse>();
        List<RequestForAgreementNotificationResponse> withErrors = new ArrayList<RequestForAgreementNotificationResponse>();

        for (AgreementNotificationRequest agreement : request.getAgreementNotificationRequest()) {
            RequestForAgreementNotificationResponse result = this.requestForAgreementNotification(agreement);

            if (result.getStatus().equals(this.environment.getProperty(STATUS_OK))) {
                noErrors.add(result);
            } else {
                withErrors.add(result);
            }

        }

        response.setAgreementNotificationsResponse(noErrors);
        response.setAgreementNotificationsResponseWithErrors(withErrors);

        return response;
    }

}
