package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.KeyDAO;
import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.KeyService;

/**
 * Service Implementation Class used to implement the business logic in getting
 * the Key DB
 * 
 * @since 12/12/2017
 * @author ZE2MACL
 * @version 1.04
 * 
 * <pre>
 * Modified Date    Version     Author      Description
 * 12/12/2017       1.00        ZE2MACL     InitialVersion
 * 15/12/2017       1.01        ZE2MACL     Add condition to check parameter
 * 27/12/2017       1.02        ZE2MACL     Change key to list to support dao changes
 * 21/02/2018       1.03        ZE2BUEN     Added savingKeyRecords method
 * 08/03/2018       1.04        ZE2FUEN     Added shortTextValue for keyCode 04
 * </pre>
 */

@Service
@Transactional
public class KeyServiceImpl implements KeyService {
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(KeyServiceImpl.class);
	
	/**
	 * Key
	 */
	private Key key = new Key();

	/**
	 * Key DAO
	 */
    @Autowired
    private KeyDAO keyDAO;

    /**
     * Retrieves the short text records using a given schlussel type, schlussel
     * code and sparche
     * 
     * @param keyTyp
     * @param keyCode
     * @param language
     * @return String of short text
     */
    @Override
    public String getShortTextValue(String keyTyp, String keyCode, String language) {
        String shortTextValue = "";
        
        if (Objects.nonNull(keyCode) && Objects.nonNull(keyTyp)) {

            if (keyTyp.equals("BBANR") && keyCode.equals("01") && language.equals("000")) {
                shortTextValue = "Herr";
            } else if (keyTyp.equals("BBANR") && keyCode.equals("04") && language.equals("000")) {
                shortTextValue = "Frau";
            } else {
                key = keyDAO.findByKeyTypIgnoreCaseAndKeyCodeIgnoreCaseAndLanguage(keyTyp, keyCode, language);

                if (Objects.nonNull(key)) {
                    shortTextValue = key.getKeyShortText();
                }
            }
        }
        
        return shortTextValue;
    }

    /**
     * Retrieves the Long text records using a given schlussel type, schlussel
     * code and sparche
     * 
     * @param keyTyp
     * @param keyCode
     * @param language
     * @return String of long text
     */

    @Override
    public String getLongTextValue(String keyTyp, String keyCode, String language) {
        String longTextValue = "";
        
        if (Objects.nonNull(keyCode) && Objects.nonNull(keyTyp)) {

            key = keyDAO.findByKeyTypIgnoreCaseAndKeyCodeIgnoreCaseAndLanguage(keyTyp, keyCode, language);

            if (Objects.nonNull(key)) {
                longTextValue = key.getKeyLongText();
            }

        }
        
        return longTextValue;

    }

    /**
     * Retrieves the key code records using a given key type and text
     * 
     * @param keyType
     * @param text
     */
    @Override
    public String getKeyCodeByValue(String keyType, String text) {
        Key key = new Key();
        List<Key> keyList;
        String keyCode = null;
        String salutation = "BBANR";
        String salutationCode = "09";
        
        if (Objects.nonNull(keyType) && Objects.nonNull(text)) {

            keyList = keyDAO.findByKeyTypIgnoreCaseAndKeyShortText(keyType, text);
            if (!keyList.isEmpty()) {
                for (Key keyValue : keyList) {
                    keyCode = keyValue.getKeyCode();
                }

            } else {
                keyList = keyDAO.findByKeyTypIgnoreCaseAndKeyLongText(keyType, text);
                if (!keyList.isEmpty()) {
                    for (Key keyValue : keyList) {
                        keyCode = keyValue.getKeyCode();
                    }

                }

                if (keyType.equalsIgnoreCase(salutation)) {
                    key.setKeyCode(salutationCode);
                }

            }

        }

        return keyCode;
    }
    
	/**
	 * Save List of Key Records then return list of Key Records
	 * 
	 * @param keyList
	 *            extracted key records from DB2
	 * @param token
	 *            user identity model
	 * @return keyList persisted data.
	 */
	public List<Key> savingKeyRecords(List<Key> keyList, Tokenizer token) {

		try {
			keyList = Lists.newArrayList(this.keyDAO.save(keyList));
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		LOGGER.info("<<= User [{}] savingKeyRecords() Size:{} request was successfully processed.", token.getUserId(),
				keyList.size());

		return keyList;
	}
	
	/**
	 * Delete Key Records based on Key Type
	 * 
	 * @param keyType
	 *            Key Type
	 * @param token
	 *            user identity model
	 */
	public void deleteKeyRecords(String keyType, Tokenizer token) {

		try {
			this.keyDAO.deleteByKeyTyp(keyType);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		LOGGER.info("<<= User [{}] deleteKeyRecords() request was successfully processed.", token.getUserId());

	}

}
