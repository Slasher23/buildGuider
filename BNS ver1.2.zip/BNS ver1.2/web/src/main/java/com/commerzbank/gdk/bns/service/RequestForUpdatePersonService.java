package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.BatchUpdatePersonResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePerson;
import com.commerzbank.gdk.bns.model.RequestForUpdatePersonRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * Service Class used to RequestForUpdatePerson.
 * 
 * @since 27/11/2017
 * @author ZE2MENY
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2MENY    Initial Version
 * 29/11/2017        1.01       ZE2MENY    Added method for BatchProcessing
 * 4/12/2017         1.02       ZE2MENY    Refactor to use BatchUpdatePersonResponse
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface RequestForUpdatePersonService {

	/**
     * Method for requestingForUpdatePerson.
     * 
     * @param requestForUpdatePersonRequest RequestForUpdatePersonRequest Update Person Request sent
     *            by ZSL.
     * @return ZslUpdateResponse Update Person Response.
     */	
    ZslUpdateResponse requestForUpdResponse(RequestForUpdatePersonRequest requestForUpdatePersonRequest);

    /**
     * Method for requestingForBatchUpdatePerson.
     * 
     * @param requestForBatchUpdatePersonList RequestForUpdatePersonRequest list of update person to
     *            request
     * @return BatchUpdatePersonResponse batch update person response with success
     *         and errors.
     */
    BatchUpdatePersonResponse requestForBatchUpdatePerson(
            RequestForBatchUpdatePerson requestForBatchUpdatePersonList);
}
