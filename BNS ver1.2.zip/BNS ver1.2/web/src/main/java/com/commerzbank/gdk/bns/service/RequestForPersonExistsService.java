package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.BatchPersonExistsRequest;
import com.commerzbank.gdk.bns.model.BatchPersonExistsResponse;
import com.commerzbank.gdk.bns.model.PersonExistsRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * Service Class used to RequestForPersonExists.
 * 
 * @since 7/12/2017
 * @author ZE2MENY
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 7/12/2017         1.00       ZE2MENY    Initial Version
 * 11/12/2017        1.01       ZE2MENY    Added method for BatchProcessing
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface RequestForPersonExistsService {

    ZslUpdateResponse requestForPersonExistsResponse(PersonExistsRequest request);

    BatchPersonExistsResponse requestForPersonExistsResponse(BatchPersonExistsRequest requestForPersonExistsList);
}
