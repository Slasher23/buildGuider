package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for All Notif, Agreements, Email, and Channel.
 * This class returns and sets List of Agreement Types Wrapper, List of Email 
 * and List of Information Channel
 * 
 * @since 02/10/2017
 * @author ZE2BAUL
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 02/10/2017        1.01       ZE2BAUL    Initial Version
 * 										   This replaced the previous AgreementEmailChannelWrapper
 * </pre>
 */

@XmlRootElement(name = "MainAgreementTypeWrapper")
public class MainAgreementTypeWrapper {
	
	private AllNotificationConfig allNotificationConfig;
	
	private List<AgreementTypesWrapper> agreementTypes;
	
	private PersonConfigWrapper personConfigType;

	private List<Email> email;

	private List<InformationChannel> informationChannel;

	/**
	 * Returns AllNotificationConfig information.
	 *
	 * @return the allNotificationConfig
	 */
	public AllNotificationConfig getAllNotificationConfig() {
		return allNotificationConfig;
	}

	/**
	 * Sets AllNotificationConfig
	 *
	 * @param allNotificationConfig the allNotificationConfig to set
	 */
	public void setAllNotificationConfig(AllNotificationConfig allNotificationConfig) {
		this.allNotificationConfig = allNotificationConfig;
	}

	/**
	 * Returns the List of Agreement Types Wrapper
	 *
	 * @return the agreementTypes
	 */
	public List<AgreementTypesWrapper> getAgreementTypes() {
		return agreementTypes;
	}

	/**
	 * Sets the List of Agreement Types Wrapper
	 *
	 * @param agreementTypes the agreementTypes to set
	 */
	public void setAgreementTypes(List<AgreementTypesWrapper> agreementTypes) {
		this.agreementTypes = agreementTypes;
	}

	/**
	 * Returns the Person Config
	 *
	 * @return the personConfigType
	 */
	public PersonConfigWrapper getPersonConfigType() {
		return personConfigType;
	}

	/**
	 * Sets the Person Config
	 *
	 * @param personConfigType the personConfigType to set
	 */
	public void setPersonConfigType(PersonConfigWrapper personConfigType) {
		this.personConfigType = personConfigType;
	}

	/**
	 * Returns the List of Email
	 *
	 * @return the email
	 */
	public List<Email> getEmail() {
		return email;
	}

	/**
	 * Sets the List of Email
	 *
	 * @param email the email to set
	 */
	public void setEmail(List<Email> email) {
		this.email = email;
	}

	/**
	 * Returns the List of Information Channel
	 *
	 * @return the informationChannel
	 */
	public List<InformationChannel> getInformationChannel() {
		return informationChannel;
	}

	/**
	 * Sets the List of Information Channel
	 *
	 * @param informationChannel the informationChannel to set
	 */
	public void setInformationChannel(List<InformationChannel> informationChannel) {
		this.informationChannel = informationChannel;
	}
	
	/**
	 * Returns the String representation of Main Agreement Type Wrapper
	 * 
	 * @return String String representation of Main Agreement Type Wrapper
	 */
	@Override
	public String toString() {
		return "MainAgreementTypeWrapper [allNotificationConfig= " + allNotificationConfig + 
				" , agreementTypes= " + agreementTypes + " , personConfigType= " + personConfigType + 
				" , email= " + email + " , informationChannel= " + informationChannel + "]";
	}	
}
