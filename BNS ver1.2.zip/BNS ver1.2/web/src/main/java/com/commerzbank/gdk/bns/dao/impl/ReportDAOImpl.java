package com.commerzbank.gdk.bns.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.ReportCustomDAO;
import com.commerzbank.gdk.bns.model.Report;

/**
 * DAO Implementation Class to get the Report List
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.01
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 04/01/2018		1.00	    ZE2BUEN 	Initial Version
 * 03/02/2018       1.01        ZE2MACL     Added method to convert date to string
 *          </pre>
 */

@Repository
public class ReportDAOImpl implements ReportCustomDAO {

    @PersistenceContext
    EntityManager entityManager;


    /**
     * Retrieves the Report List using the given start date, end date and report
     * type
     * 
     * @param startDate Date Start Date
     * @param endDate Date End Date
     * @param reportType String Report Type
     * @return List Report List
     */
    @Override
    public List<Report> getReportList(Date startDate, Date endDate, String reportType) {

        String convertedStartDate = dateToString(startDate);
        String convertedEndDate = dateToString(endDate);

        StringBuilder query = new StringBuilder();
        query.append("SELECT r FROM Report r WHERE trunc(r.date) between trunc(");
        query.append("to_date('");
        query.append(convertedStartDate);
        query.append("', 'dd/MM/yyyy')) and trunc(");
        query.append("to_date('");
        query.append(convertedEndDate);
        query.append("', 'dd/MM/yyyy')) and ");
        query.append("r.reportType = :reportType ");
        query.append("ORDER BY r.date, r.time");

        List<Report> reportList = this.entityManager.createQuery(query.toString(), Report.class)
                        .setParameter("reportType", reportType).getResultList();

        return reportList;

    }

    private String dateToString(Date date) {
        
        final String DATE_FORMAT = "dd/MM/yyyy";

        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

        String coveredToString = sdf.format(date);
        
        return coveredToString;

    }

}
