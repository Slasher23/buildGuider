package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.PersonService;

/**
 * PersonController Accept request and return the expected record to client.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.08
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 25/09/2017      1.01      ZE2BAUL    Refactoring of GetMapping to PostMapping
 * 28/09/2017	   1.02		 ZE2BAUL    Applied the logging standards
 * 13/10/2017	   1.03	     ZE2RUBI    Clean Up and Implement JWT
 * 14/11/2017      1.04      ZE2MACL    Updated method to used response builder and added token parameter
 * 11/12/2017      1.05      ZE2SARO    Add Validation
 * 09/02/2018      1.06      ZE2MACL    Removed throws Exception
 * 12/02/2018      1.07      ZE2BUEN    Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018      1.08      ZE2FUEN    Updated implementation to CIF-Integration
 * </pre>
 */
@RestController
public class PersonController {

	@Autowired
	private PersonService personService;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(PersonController.class);

	/**
	 * Accept client request and call the service to retrieve the person record
	 * from database using bpkenn then return also consumes and produces json or
	 * xml format.
	 * 
	 * @param bnsInternal
	 *            BNS Internal (Parameter)
	 * @return return the person record.
	 * 
	 */
	@PostMapping(value = "/api/person")
	public ResponseEntity<Response<Person>> getPerson(HttpServletRequest request, Authentication auth) {

        Tokenizer token = Tokenizer.getUserToken(auth);
        
        LOGGER.info("=>> User [{}] getPerson({})", token.getUserId(), token.getBpkenn());
        
        ResponseBuilder<Person> builder = new ResponseBuilder<Person>(LOGGER, token, globalResponseWrapper);

        if (Tokenizer.validator(token)) {
            builder = this.personService.getPerson(token);
        } else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

		return builder.responseEntity();

	}

}
