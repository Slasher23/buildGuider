package com.commerzbank.gdk.bns.dao;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.InformationChannel;

/**
 * Information Channel DAO Interface
 * 
 * @since 03/07/2017
 * @author ZE2FUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 03/07/2017		1.01		ZE2FUEN 	Initial Version
 * </pre>
 */

public interface InformationChannelDAO extends CrudRepository<InformationChannel, Long>, InformationChannelCustomDAO{

}
