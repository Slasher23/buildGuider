package com.commerzbank.gdk.bns.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;

/**
 * Class for deletion of data in BNS DB
 * 
 * @author ZE2FUEN
 * @since 07/03/2018
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/03/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */
@Component
public class BNSDataRemover {

    @Autowired
    private AgreementDAO agreementDAO;

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Autowired
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Autowired
    private NotificationTextDAO notifTextDAO;

    @Autowired
    private PersonDAO personDAO;
    
    /**
     * Deletes person data in BNS
     * 
     * @param person Person person entity to delete
     */
    public void deletePerson(Person person) {

        Long personUID = person.getPersonUID();

        this.deleteAgreementText(personUID);
        this.deletePersonText(personUID);
        this.personDAO.delete(personUID);

    }

    /**
     * Deletes all agreement notificationText for a person
     * 
     * @param personUID Long Unique identifier of the person
     */
    private void deleteAgreementText(Long personUID) {

        List<Agreement> agreementList = this.agreementDAO.findByPersonUID(personUID);

        if (Objects.nonNull(agreementList) && !agreementList.isEmpty()) {
            List<Long> agreementUIDList = new ArrayList<Long>();
            
            for (Agreement agreement : agreementList) {
                agreementUIDList.add(agreement.getAgreementUID());
            }

            List<NotificationConfigAgreement> agreementConfigList = this.notificationConfigAgreementDAO
                    .findByAgreementUIDIn(agreementUIDList);

            if (Objects.nonNull(agreementConfigList) && !agreementConfigList.isEmpty()) {

                for (NotificationConfigAgreement notificationConfigAgreement : agreementConfigList) {
                    this.notifTextDAO.delete(notificationConfigAgreement.getNotificationTextUID());
                }

            }
        }

    }

    /**
     * Deletes all person notificationText for a person
     * 
     * @param personUID Long Unique identifier of the person
     */
    private void deletePersonText(Long personUID) {

        NotificationConfigPerson personConfig = this.notificationConfigPersonDAO.findByPersonUID(personUID);

        if (Objects.nonNull(personConfig)) {
            this.notifTextDAO.delete(personConfig.getNotificationTextUID());
        }

    }

}
