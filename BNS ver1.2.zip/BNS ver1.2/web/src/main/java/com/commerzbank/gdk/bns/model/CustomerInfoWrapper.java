package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for Customer Information
 * This class returns and sets Email, Notification Configuration Agreement 
 * and Notification Text
 * 
 * @since 31/07/2017
 * @author ZE2MACL
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 31/07/2017        1.01       ZE2MACL    Initial Version
 * </pre>
 */

@XmlRootElement(name="customer")
public class CustomerInfoWrapper {

	private Email email;
	
	private NotificationConfigAgreement notificationConfigAgreement;
	
	private NotificationText notificationText;
	
	/**
	 * Returns Email Model
	 * 
	 * @return Email Email Model
	 */
	public Email getEmail() {
		return email;
	}
	
	/**
	 * Sets Email Model
	 * 
	 * @param email Email Email Model to set
	 */
	public void setEmail(Email email) {
		this.email = email;
	}
	
	/**
	 * Returns Notification Configuration Model
	 * 
	 * @return NotificationConfigAgreement Notification Configuration Model
	 */
	public NotificationConfigAgreement getNotificationConfigAgreement() {
		return notificationConfigAgreement;
	}
	
	/**
	 * Sets Notification Configuration Model
	 * 
	 * @param notificationConfigAgreement NotificationConfigAgreement Notification Configuration Model to set
	 */
	public void setNotificationConfigAgreement(NotificationConfigAgreement notificationConfigAgreement) {
		this.notificationConfigAgreement = notificationConfigAgreement;
	}
	
	/**
	 * Returns Notification Text Model
	 * 
	 * @return NotificationText Notification Text Model
	 */
	public NotificationText getNotificationText() {
		return notificationText;
	}
	
	/**
	 * Sets Notification Text Model
	 * 
	 * @param notificationText NotificationText Notification Text Model to set
	 */
	public void setNotificationText(NotificationText notificationText) {
		this.notificationText = notificationText;
	}
	
	/**
	 * Returns the String representation of Customer Information Wrapper
	 * 
	 * @return String String representation of Customer Information Wrapper
	 */
	@Override
	public String toString() {
		return "CustomerInfoWrapper [email= " + email + " , notificationConfigAgreement= " + notificationConfigAgreement +
			   " , notificationText= " + notificationText + "]";
	}
	
}
