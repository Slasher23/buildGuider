package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.BatchNotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchNotification;

/**
 * Service Class used to access the BatchNotificationServiceImpl.
 * 
 * @since 13/11/2017
 * @author ZE2GOME
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface BatchNotificationService {

	/**
	 * This is to request to for a batch notification.
	 *
	 * @param notificationRequest The request.
	 * @return BatchNotificationResponse Response to be.
	 */
	BatchNotificationResponse requestForBatchNotification(RequestForBatchNotification notificationRequest);

}
