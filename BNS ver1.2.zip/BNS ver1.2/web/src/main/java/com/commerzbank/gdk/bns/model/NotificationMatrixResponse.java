package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model class for Dispatch matrix response.
 * 
 * @since 26/10/2017
 * @author ZE2GOME
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2GOME    Initial Version
 * 23/11/2017        1.01       ZE2SARO    Remove Participant
 *          </pre>
 *
 */
public class NotificationMatrixResponse {

    private String status;

    private List<NotificationMatrixChannel> notificationMatrixChannel;

    /**
     * Get get the value of status response
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Set the value of status response
     * 
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Return the value of notification matrix channel.
     * 
     * @return notificationMatrixChannel list
     */
    public List<NotificationMatrixChannel> getNotificationMatrixChannel() {
        return notificationMatrixChannel;
    }

    /**
     * Set the value of notificationMatrixChannel.
     * 
     * @param notificationMatrixChannel
     */
    public void setNotificationMatrixChannel(List<NotificationMatrixChannel> notificationMatrixChannel) {
        this.notificationMatrixChannel = notificationMatrixChannel;
    }

}
