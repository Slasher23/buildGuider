package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;

/**
 * Service Class that will handle Email Template Generation
 * 
 * @since 02/02/2018
 * @author ZE2FARI
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 02/02/2018        1.00       ZE2FARI    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 * </pre>
 */
public interface EmailTemplateService {

	Notifications createEmailNotification(Person person, String agreementID, Integer branch, String notificationPath, boolean isAgreementRelated);
	
}
