package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Response for Change Email Address
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2BUEN    Initial Version
 * 23/11/2017        1.01       ZE2BUEN    Added address ID on response
 * </pre>
 */

@XmlRootElement
public class ChangeEmailAddressResponse {

	private String bpkenn;

	private Long addressId;

	private String status;

	/**
	 * Returns the value of BPKENN
	 * 
	 * @return String BPKENN
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * Sets the value of BPKENN
	 * 
	 * @param bpkenn
	 *            String BPKENN to set
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the value of Address ID
	 * 
	 * @return Long Address ID
	 */
	public Long getAddressId() {
		return addressId;
	}

	/**
	 * Sets the value of Address ID
	 * 
	 * @param addressId
	 *            Long Address ID to set
	 */
	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	/**
	 * Returns the value of Status
	 * 
	 * @return String Status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the value of Status
	 * 
	 * @param status
	 *            String Status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Returns the String representation of Change Email Address Response Model
	 * 
	 * @return String String representation of Change Email Address Response
	 *         Model
	 * 
	 */
	@Override
	public String toString() {
		return "ChangeEmailAddressResponse [bpkenn=" + bpkenn + ", addressId=" + addressId + ", status=" + status + "]";
	}

}
