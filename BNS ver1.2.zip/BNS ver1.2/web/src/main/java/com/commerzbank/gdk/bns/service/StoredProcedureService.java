package com.commerzbank.gdk.bns.service;

/**
 * Service Class used to validate account
 * 
 * @since 21/12/2017
 * @author ZE2MENY
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/12/2017        1.00       ZE2MENY    Initial Version
 * 27/12/2017        1.01       ZE2MACL    Update method 
 *          </pre>
 */
public interface StoredProcedureService {

    public String validateAccount(String bpkenn, String agreementId, Integer sparte);
    public void deletePersonRelated(String bpkenn);
    public void deleteAgreementRelated(String agreementId, Integer sparte);
}
