package com.commerzbank.gdk.bns.dao.tnv.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.tnv.TnvCustomDAO;
import com.commerzbank.gdk.bns.model.tnv.Tnv;

/**
 * DAO Implementation Class to get the result of TNV stored procedure
 * 
 * @since 05/03/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 05/03/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
@Repository
public class TnvDAOImpl implements TnvCustomDAO {

	/**
	 * Logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(TnvDAOImpl.class);

	/**
	 * TNV JDBC Template
	 */
	@Autowired
	@Qualifier("tnvJdbcTemplate")
	JdbcTemplate tnvJdbcTemplate;
	
	private static final String VERSION = "TVP01 V001";
	private static final String FUNCTION_CODE = "PRUEFEN_BENACHRICHTIGUNGEN";
	private static final String FKT_VERSION = "1.00";
	private static final String MANDANT = "CB";
	
	/**
	 * Call TNV Stored Procedure (TVP01SPR)
	 * 
	 * @param keyType String BPKENN
	 * @param agreementId String Agreement ID
	 * @param sparte Integer Sparte
	 * @return result Tnv 
	 */
	@Override
	public Tnv callStoredProcedure(String bpkenn, String agreementId, Integer sparte) {

		Connection dbConnection = null;
		CallableStatement callableStatement = null;

		String storedProc = "{CALL CB.TVP01SPR(?,?,?,?,?,?,?,?,?,?,?,?,?)}";

		Tnv result = null;
		
		String strSparte = "";

		try {
			
			if(Objects.isNull(bpkenn)){
				bpkenn = BNSConstants.EMPTY_STRING;
			}
			
			if(Objects.isNull(agreementId)){
				agreementId = BNSConstants.EMPTY_STRING;
			}
			
			if(Objects.isNull(sparte)){
				strSparte = BNSConstants.EMPTY_STRING;
			} else {
				strSparte = String.valueOf(sparte);
			}
			
			dbConnection = this.tnvJdbcTemplate.getDataSource().getConnection();
			
			logger.info("TNV Driver Name: " + dbConnection.getMetaData().getDriverName());
			logger.info("TNV Driver Version: " + dbConnection.getMetaData().getDriverVersion());
			
			callableStatement = dbConnection.prepareCall(storedProc);
			callableStatement.setString(1, VERSION);
			callableStatement.setString(2, FUNCTION_CODE);
			callableStatement.setString(3, FKT_VERSION);
			callableStatement.setString(4, MANDANT);
			callableStatement.setString(5, bpkenn);
			callableStatement.setString(6, agreementId);
			callableStatement.setString(7, strSparte);
			callableStatement.registerOutParameter(8, Types.CHAR);
			callableStatement.registerOutParameter(9, Types.CHAR);
			callableStatement.registerOutParameter(10, Types.VARCHAR);
			callableStatement.registerOutParameter(11, Types.CHAR);
			callableStatement.registerOutParameter(12, Types.CHAR);
			callableStatement.registerOutParameter(13, Types.CHAR);
			
			// execute TVP01SPR stored procedure
			callableStatement.execute();
			
			result = new Tnv();
			result.setReturnCodeType(callableStatement.getString(8));
			result.setReturnCodeDetail(callableStatement.getString(9));
			result.setErrorMessage(callableStatement.getString(10));
			result.setErrorInProgram(callableStatement.getString(11));
			result.setErrorInSection(callableStatement.getString(12));
			result.setStateId(callableStatement.getString(13));
			
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
		} finally {

			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					logger.error(e.getMessage(), e);
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					logger.error(e.getMessage(), e);
				}
			}

		}

		return result;

	}

}
