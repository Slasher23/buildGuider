
/**
 * This package contains service contracts.
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.service;