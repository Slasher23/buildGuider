package com.commerzbank.gdk.bns.service.impl;

import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.commerzbank.gdk.bns.service.AuditLogListener;
/**
 * Audit Log Listener Implements- used to implement business logic in logging events
 * 
 * @author ZE2RUBI
 * @version 1.01
 * @since 04/08/2017
 * 
 * <pre>
 *  Modified Date	Version		Author		Description
 *  04/08/2017		1.01		ZE2RUBI 	InitialVersion
 *  </pre>
 */
public class AuditLogListenerImpl implements AuditLogListener{

	private static final Logger logger = LoggerFactory.getLogger(AuditLogListenerImpl.class);
	/**
	 * This method will be executed before data persistence in the database
	 * @param object this will be generic as long as the model/entity is annotated with
	 */
	@PrePersist
	@PreUpdate
	@PreRemove
	public void prePersist(Object object){

		logger.info("<<= User [{}] prePersist() request was successfully processed.", "user");
	}
	
	@PostLoad
	public void postPersist(Object object){

		logger.info("<<= User [{}] postPersist() request was successfully processed.", "user");
	}
}
