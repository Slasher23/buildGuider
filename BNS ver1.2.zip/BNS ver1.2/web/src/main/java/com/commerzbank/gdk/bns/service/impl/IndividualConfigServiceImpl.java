package com.commerzbank.gdk.bns.service.impl;

import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.IndividualConfigService;

/**
 * IndividualConfigServiceImpl Save notification text and agreement and person
 * config.
 * 
 * @since 09/08/2017
 * @author ZE2SARO
 * @version 1.04
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 09/08/2017      1.00      ZE2SARO    Initial Version
 * 27/09/2017      1.01      ZE2SARO    Change saving of notif text
 * 03/10/2017	   1.02		 ZE2BAUL	Added implementation for PersonConfig
 * 13/11/2017      1.03      ZE2MACL    Updated method to use response builder and added token parameter
 * 24/11/2017      1.04      ZE2MORA    Implemented Status Codes
 *          </pre>
 */
@Service
@Transactional
public class IndividualConfigServiceImpl implements IndividualConfigService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IndividualConfigServiceImpl.class);

	@Autowired
	private NotificationTextDAO notificationTextDAO;

	@Autowired
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Autowired
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Autowired
	private InformationChannelDAO infoChannelDAO;

	@Autowired
	private Environment environment;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	/**
	 * Save notification text and agreement config then return the wrapper
	 * model.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param noConfigWrapper
	 *            CustomAgreementConfig notification text and agreement config
	 *            values send by client.
	 * @return notification text and agreement config wrapper.
	 */
	@Override
	public ResponseBuilder<NotifTextAgreementConfigWrapper> saveNotifTextAndAgreementConfig(Tokenizer token,
			CustomNotifConfig noConfigWrapper) {

		ResponseBuilder<NotifTextAgreementConfigWrapper> builder = new ResponseBuilder<NotifTextAgreementConfigWrapper>(
				LOGGER, token, globalResponseWrapper);

		try {

			NotifTextAgreementConfigWrapper notifWrapper = new NotifTextAgreementConfigWrapper();
			// get all values send by client
			Long agreementUID = noConfigWrapper.getAgreementUID();
			boolean isActive = noConfigWrapper.isActive();
			Long emailUID = noConfigWrapper.getEmailUID();
			Long infoChannelUID = noConfigWrapper.getInformationChannelUID();
			String text = noConfigWrapper.getText();

			// get agreement
			NotificationText notifText = this.notificationTextDAO
					.getNotifText(environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY), agreementUID);
			// get notification config agreement
			NotificationConfigAgreement notifAgreement = this.notificationConfigAgreementDAO
					.getNotifConfigAgreement(agreementUID);

			// set notif text values and save
			notifWrapper = saveNotiftextAgreementValues(token, notifWrapper, notifText, text, agreementUID);

			// check if config is exist
			if (notifAgreement == null) {
				notifAgreement = new NotificationConfigAgreement();
				// check if information channel is exist
				if (infoChannelUID == null) {
					infoChannelUID = this.infoChannelDAO
							.getInformationChannelUID(environment.getProperty(BNSConstants.INFO_CHANNEL_KEY));
				}
				notifAgreement.setInformationChannelUID(infoChannelUID);
			} else {
				// check if information channel is exist
				if (infoChannelUID != null)
					notifAgreement.setInformationChannelUID(infoChannelUID);
			}
			// set notif agreement values and save
			notifWrapper = setNotifAgreementConfigValues(token, notifWrapper, notifAgreement, agreementUID, isActive,
					emailUID, notifWrapper.getNotificationText().getNotificationTextUID());

			builder.OK(notifWrapper);

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] saveNotifTextAndAgreementConfig({}) request was successfully processed.",
				token.getUserId(), noConfigWrapper.toString());

		return builder;
	}

	/**
	 * Save notification text and person config then return the wrapper model.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param noConfigWrapper
	 *            CustomAgreementConfig notification text and agreement config
	 *            values send by client.
	 * @return notification text and person config wrapper.
	 */
	@Override
	public ResponseBuilder<NotifTextPersonConfigWrapper> saveNotifTextAndPersonConfig(Tokenizer token,
			CustomNotifConfig noConfigWrapper) {

		ResponseBuilder<NotifTextPersonConfigWrapper> builder = new ResponseBuilder<NotifTextPersonConfigWrapper>(
				LOGGER, token, globalResponseWrapper);

		try {

			NotifTextPersonConfigWrapper notifWrapper = new NotifTextPersonConfigWrapper();

			// get all values send by client
			// Long participantNumberUID =
			// noConfigWrapper.getParticipantNumberUID();
			Long personUID = noConfigWrapper.getPersonUID();
			boolean isActive = noConfigWrapper.isActive();
			Long emailUID = noConfigWrapper.getEmailUID();
			Long infoChannelUID = noConfigWrapper.getInformationChannelUID();
			String text = noConfigWrapper.getText();

			// get notif text from personConfig
			NotificationText notifText = this.notificationTextDAO
					.getNotifText(environment.getProperty(BNSConstants.PERSON_TYPE_KEY), personUID);

			// get notification config person
			NotificationConfigPerson notifPerson = this.notificationConfigPersonDAO.findByPersonUID(personUID);

			// set notif text values and save
			notifWrapper = saveNotiftextPersonValues(token, notifWrapper, notifText, text, personUID);

			// check if config is exist
			if (notifPerson == null) {
				notifPerson = new NotificationConfigPerson();
				// check if information channel is exist
				if (infoChannelUID == null) {
					infoChannelUID = this.infoChannelDAO
							.getInformationChannelUID(environment.getProperty(BNSConstants.INFO_CHANNEL_KEY));
				}
				notifPerson.setInformationChannelUID(infoChannelUID);
			} else {
				// check if information channel is exist
				if (infoChannelUID != null)
					notifPerson.setInformationChannelUID(infoChannelUID);
			}
			// set notif agreement vaues and save
			notifWrapper = setNotifPersonConfigValues(token, notifWrapper, notifPerson, personUID, isActive, emailUID,
					notifWrapper.getNotificationText().getNotificationTextUID());

			builder.OK(notifWrapper);

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] saveNotifTextAndPersonConfig({}) request was successfully processed.",
				token.getUserId(), noConfigWrapper.toString());

		return builder;
	}

	/**
	 * Set the notification text and save in database then return the wrapper of
	 * Agreement.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param notifWrapper
	 *            NotifTextAgreementConfigWrapper wrapper of notif text and
	 *            agreement config.
	 * @param notifText
	 *            NotificationText list of notification text.
	 * @param text
	 *            String text value send by client.
	 * @param agreementUID
	 *            Long agreement UID send by client.
	 * @return return the saved Notification text and set to
	 *         NotifTextAgreementConfigWrapper.
	 */
	private NotifTextAgreementConfigWrapper saveNotiftextAgreementValues(Tokenizer token,
			NotifTextAgreementConfigWrapper notifWrapper, NotificationText notifText, String text, Long agreementUID) {

		notifText = setNotifTextValues(token, notifText, agreementUID, BNSConstants.VERLASSUNGS_TYPE_KEY, text);

		notifWrapper.setNotificationText(this.notificationTextDAO.save(notifText));

		LOGGER.info("<<= User [{}] saveNotiftextAgreementValues({},{},{},{}) request was successfully processed.",
				token.getUserId(), notifWrapper.toString(), notifText.toString(), text, agreementUID.toString());

		return notifWrapper;
	}

	/**
	 * Set the notification text and save in database then return the wrapper of
	 * Person.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param notifWrapper
	 *            NotifTextAgreementConfigWrapper wrapper of notif text and
	 *            agreement config.
	 * @param notifText
	 *            NotificationText list of notification text.
	 * @param text
	 *            String text value send by client.
	 * @param agreementUID
	 *            Long agreement UID send by client.
	 * @return return the saved Notification text and set to
	 *         NotifTextAgreementConfigWrapper.
	 */
	private NotifTextPersonConfigWrapper saveNotiftextPersonValues(Tokenizer token,
			NotifTextPersonConfigWrapper notifWrapper, NotificationText notifText, String text,
			Long participantNumberUID) {

		notifText = setNotifTextValues(token, notifText, participantNumberUID, BNSConstants.PERSON_TYPE_KEY, text);

		notifWrapper.setNotificationText(this.notificationTextDAO.save(notifText));

		LOGGER.info("<<= User [{}] saveNotiftextPersonValues({},{},{},{}) request was successfully processed.",
				token.getUserId(), notifWrapper.toString(), notifText.toString(), text,
				participantNumberUID.toString());

		return notifWrapper;
	}

	/**
	 * Set agreement config and save in database then return the wrapper.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param notifWrapper
	 *            NotifTextAgreementConfigWrapper notifWrapper wrapper of notif
	 *            text and agreement config
	 * @param notifAgreement
	 *            NotificationConfigAgreement agreement config values
	 * @param agreementUID
	 *            Long agreement UID send by client and set to model
	 * @param isActive
	 *            boolean status send by client and set to model
	 * @param emailUID
	 *            Long email UID send by client and set to model
	 * @param notifTextUID
	 *            Long set to model
	 * @return return the saved agreement config and set to
	 *         NotifTextAgreementConfigWrapper
	 */
	private NotifTextAgreementConfigWrapper setNotifAgreementConfigValues(Tokenizer token,
			NotifTextAgreementConfigWrapper notifWrapper, NotificationConfigAgreement notifAgreement, Long agreementUID,
			boolean isActive, Long emailUID, Long notifTextUID) {

		notifAgreement.setAgreementUID(agreementUID);
		notifAgreement.setActive(isActive);
		notifAgreement.setEmailUID(emailUID);
		notifAgreement.setNotificationTextUID(notifTextUID);

		notifWrapper.setNotificationConfigAgreement(this.notificationConfigAgreementDAO.save(notifAgreement));

		LOGGER.info(
				"<<= User [{}] setNotifAgreementConfigValues({},{},{},{},{},{}) request was successfully processed.",
				token.getUserId(), notifWrapper.toString(), notifAgreement.toString(), agreementUID.toString(),
				isActive, emailUID.toString(), notifTextUID.toString());

		return notifWrapper;
	}

	/**
	 * Set agreement config and save in database then return the wrapper.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param notifWrapper
	 *            NotifTextPersonConfigWrapper notifWrapper wrapper of notif
	 *            text and person config
	 * @param notifPerson
	 *            NotificationConfigPerson person config values
	 * @param participantNumberUID
	 *            Long participantNumber UID send by client and set to model
	 * @param isActive
	 *            boolean status send by client and set to model
	 * @param emailUID
	 *            Long email UID send by client and set to model
	 * @param notifTextUID
	 *            Long set to model
	 * @return return the saved person config and set to
	 *         NotifTextPersonConfigWrapper
	 */
	private NotifTextPersonConfigWrapper setNotifPersonConfigValues(Tokenizer token,
			NotifTextPersonConfigWrapper notifWrapper, NotificationConfigPerson notifPerson, Long personUID,
			boolean isActive, Long emailUID, Long notifTextUID) {

		notifPerson.setPersonUID(personUID);
		notifPerson.setActive(isActive);
		notifPerson.setEmailUID(emailUID);
		notifPerson.setNotificationTextUID(notifTextUID);

		notifWrapper.setNotificationConfigPerson(this.notificationConfigPersonDAO.save(notifPerson));

		LOGGER.info("<<= User [{}] setNotifPersonConfigValues({},{},{},{},{},{}) request was successfully processed.",
				token.getUserId(), notifWrapper.toString(), notifPerson.toString(), personUID.toString(), isActive,
				emailUID.toString(), notifTextUID.toString());

		return notifWrapper;
	}

	/**
	 * Sets the Notification Text values.
	 *
	 * @param token
	 *            identifier for the request's user
	 * @param notifText
	 *            NotificationText notificationText value
	 * @param uid
	 *            Long the eventID
	 * @param verlassungsTypeKey
	 *            String the eventType
	 * @param text
	 *            String the text to be saved
	 * @return the notificationText set
	 */
	private NotificationText setNotifTextValues(Tokenizer token, NotificationText notifText, Long uid,
			String verlassungsTypeKey, String text) {

		// check if notifText is null
		if (Objects.isNull(notifText)) {
			notifText = new NotificationText();
			notifText.setEventID(uid);
			notifText.setEventType(environment.getProperty(verlassungsTypeKey));
		}
		notifText.setText(text);
		String textType = Objects.isNull(text) ? BNSConstants.TEXT_TYPE_STD : BNSConstants.TEXT_TYPE_FREE;
		notifText.setNotificationTextType(textType);

		LOGGER.info("<<= User [{}] setNotifTextValues({},{},{},{}) request was successfully processed.",
				token.getUserId(), notifText.toString(), uid, verlassungsTypeKey, text);

		return notifText;
	}

}
