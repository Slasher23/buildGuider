package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Required Notification.
 * 
 * @author ZE2BAUL
 * @since 12/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017	     1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@XmlRootElement
public class RequestForRequiredBatchNotification {

	/**
	 * List for Required Notification Request.
	 */
	private List<RequiredNotificationRequest> requiredNotificationRequest;

	/**
	 * Returns the List of Required Notification Request.
	 *
	 * @return the requiredNotificationRequest
	 */
	public List<RequiredNotificationRequest> getRequiredNotificationRequest() {
		return requiredNotificationRequest;
	}

	/**
	 * Sets the List of Required Notification Request.
	 *
	 * @param requiredNotificationRequest
	 *            the requiredNotificationRequest to set
	 */
	public void setRequiredNotificationRequest(List<RequiredNotificationRequest> requiredNotificationRequest) {
		this.requiredNotificationRequest = requiredNotificationRequest;
	}

	/**
	 * Returns the String representation of Required Notification Batch Request
	 * Model.
	 * 
	 * @return String String representation of Required Notification Batch
	 *         Request Model
	 */
	@Override
	public String toString() {
		return "RequestForRequiredBatchNotification [requiredNotificationRequest=" + requiredNotificationRequest + "]";
	}

}
