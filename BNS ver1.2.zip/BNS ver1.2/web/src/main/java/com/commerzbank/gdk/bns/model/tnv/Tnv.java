package com.commerzbank.gdk.bns.model.tnv;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Model Class for TNV
 * 
 * @since 05/03/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 05/03/2018        1.00       ZE2BUEN    Initial Version
 * </pre>
*/
@Entity
public class Tnv {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tnvUID;

	private String returnCodeType;
	
	private String returnCodeDetail;
	
	private String errorMessage;
	
	private String errorInProgram;
	
	private String errorInSection;
	
	private String stateId;
	
	/**
	 * Returns the value of Unique Identifier of TNV Record
	 * 
	 * @return Long Unique Identifier of TNV Record
	 */
	public Long getTnvUID() {
		return tnvUID;
	}
	
	/**
	 * Sets the value of Unique Identifier of TNV Record
	 * 
	 * @param tnvUID
	 *            Long Unique Identifier of TNV Record to set
	 */
	public void setTnvUID(Long tnvUID) {
		this.tnvUID = tnvUID;
	}
	
	/**
	 * Returns the value of Record Code Type
	 * 
	 * @return String Record Code Type
	 */
	public String getReturnCodeType() {
		return returnCodeType;
	}
	
	/**
	 * Sets the value of Record Code Type
	 * 
	 * @param returnCodeType
	 *            String Record Code Type to set
	 */
	public void setReturnCodeType(String returnCodeType) {
		this.returnCodeType = returnCodeType;
	}
	
	/**
	 * Returns the value of Record Code Detail
	 * 
	 * @return String Record Code Detail
	 */
	public String getReturnCodeDetail() {
		return returnCodeDetail;
	}
	
	/**
	 * Sets the value of Record Code Detail
	 * 
	 * @param returnCodeDetail
	 *            String Record Code Detail to set
	 */
	public void setReturnCodeDetail(String returnCodeDetail) {
		this.returnCodeDetail = returnCodeDetail;
	}
	
	/**
	 * Returns the value of Error Message
	 * 
	 * @return String Error Message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	
	/**
	 * Sets the value of Error Message
	 * 
	 * @param errorMessage
	 *            String Error Message to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Returns the value of Error in Program
	 * 
	 * @return String Error in Program
	 */
	public String getErrorInProgram() {
		return errorInProgram;
	}
	

	/**
	 * Sets the value of Error in Program
	 * 
	 * @param errorInProgram
	 *            String Error in Program to set
	 */
	public void setErrorInProgram(String errorInProgram) {
		this.errorInProgram = errorInProgram;
	}
	
	/**
	 * Returns the value of Error in Section
	 * 
	 * @return String Error in Section
	 */
	public String getErrorInSection() {
		return errorInSection;
	}
	
	/**
	 * Sets the value of Error in Section
	 * 
	 * @param errorInSection
	 *            String Error in Section to set
	 */
	public void setErrorInSection(String errorInSection) {
		this.errorInSection = errorInSection;
	}
	
	/**
	 * Returns the value of Identifier of State
	 * 
	 * @return String Identifier of State
	 */
	public String getStateId() {
		return stateId;
	}
	
	/**
	 * Sets the value of Identifier of State
	 * 
	 * @param stateId
	 *            String Identifier of State to set
	 */
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
		
}
