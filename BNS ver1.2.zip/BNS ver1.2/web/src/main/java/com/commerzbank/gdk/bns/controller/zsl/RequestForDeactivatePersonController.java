package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.RequestForBatchDeactivatePerson;
import com.commerzbank.gdk.bns.model.RequestForDeactivatePersonResponse;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForDeactivatePersonService;

/**
 * RequestForDeactivatePersonController - Accept deactivate person request and
 * return the deactivate person response to ZSL.
 * 
 * @since 28/11/2017
 * @author ZE2GOME
 * @version 1.08
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2GOME    Initial Version
 * 29/11/2017        1.01       ZE2GOME    Add request for batch deactivate person.
 * 04/12/2017        1.02       ZE2GOME    Rename URL
 * 07/12/2017        1.03       ZE2SARO    Add Validation
 * 12/12/2017        1.05       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 13/12/2017        1.06       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.07       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.08       ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class RequestForDeactivatePersonController {

    @Autowired
    private RequestForDeactivatePersonService requestForDeactivatePersonService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForDeactivatePersonController.class);

    /**
     * Accept client post deactivate person then call service to get the
     * deactivate person response then return also produces XML or JSON format.
     * 
     * @param param
     * @param request
     * @return ResponseEntity Notification Response
     */
    @PostMapping(value = "/api/zsl/requestForDeactivatePerson")
    public ResponseEntity<ZslUpdateResponse> requestForDeactivatePerson(@Valid @RequestBody Parameter param,
                    HttpServletRequest request, BindingResult result)  {

        LOGGER.info("=>> System [{}] - requestForDeactivatePerson({})", "ZSL", param.toString());

        ZslUpdateResponse updateResponse = new ZslUpdateResponse();

        if (!result.hasErrors()) {
            updateResponse = this.requestForDeactivatePersonService.requestForDeactivatePerson(param);

            if (Objects.isNull(updateResponse)) {
                updateResponse = new ZslUpdateResponse();
            }

        }

        ResponseEntity<ZslUpdateResponse> response = new ResponseEntity<ZslUpdateResponse>(updateResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", updateResponse.toString());

        return response;
    }

    /**
     * Accept client post for list of deactivate person then call service to get
     * the deactivate person response and return, also produces XML or JSON
     * format.
     * 
     * @param param
     * @param request
     * @return ResponseEntity Notification Response
     */
    @PostMapping(value = "/api/zsl/requestForBatchDeactivatePerson")
    public ResponseEntity<RequestForDeactivatePersonResponse> requestForBatchDeactivatePerson(
                    @Valid @RequestBody RequestForBatchDeactivatePerson param, HttpServletRequest request,
                    BindingResult result)  {

        LOGGER.info("=>> System [{}] - requestForBatchDeactivatePerson({})", "ZSL", param.toString());

        RequestForDeactivatePersonResponse personResponse = new RequestForDeactivatePersonResponse();

        if (!result.hasErrors()) {
            personResponse = this.requestForDeactivatePersonService.requestFordeactivatePersonList(param);

            if (Objects.isNull(personResponse)) {
                personResponse = new RequestForDeactivatePersonResponse();
            }

        }

        ResponseEntity<RequestForDeactivatePersonResponse> response = new ResponseEntity<RequestForDeactivatePersonResponse>(
                personResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", personResponse.toString());

        return response;
    }

}
