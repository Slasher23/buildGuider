package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Parameter
 * 
 * @since 15/09/2017
 * @author ZE2SARO
 * @version 1.06
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 15/09/2017        1.00       ZE2SARO    Initial Version
 * 22/09/2017        1.01       ZE2SARO    Add participant number
 * 22/09/2017        1.02       ZE2BUEN    Added vereinbarungskennung and sparte parameters
 * 25/09/2017		 1.03		ZE2BAUL	   Added uid, eventType, eventId, lang
 * 23/11/2017        1.04       ZE2SARO    Remove participant number
 * 21/12/2017        1.05       ZE2BUEN    Added databackpack
 * 12/02/2018        1.06       ZE2FUEN    Changed databackpack to signedAndEncryptedDataBackPack
 * </pre>
 */

@XmlRootElement
public class Parameter {

	private String bpkenn;

	private Long uid;

	private String eventType;

	private Long eventId;

	private String lang;

	private String vereinbarungskennung;

	private int sparte;

	private String signedAndEncryptedDataBackPack;

	/**
	 * Returns the value of BPKENN
	 * 
	 * @return String BPKENN
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * Sets the value of BPKENN
	 * 
	 * @param BPKENN
	 *            String BPKENN to set
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the value of uid
	 * 
	 * @return the uid
	 */
	public Long getUid() {
		return uid;
	}

	/**
	 * Sets the value of uid
	 * 
	 * @param uid
	 *            the uid to set
	 */
	public void setUid(Long uid) {
		this.uid = uid;
	}

	/**
	 * Returns the value of eventType
	 * 
	 * @return the eventType
	 */
	public String getEventType() {
		return eventType;
	}

	/**
	 * Sets the value of eventType
	 * 
	 * @param eventType
	 *            the eventType to set
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	/**
	 * Returns the value of eventId
	 * 
	 * @return the eventId
	 */
	public Long getEventId() {
		return eventId;
	}

	/**
	 * Sets the value of eventId
	 * 
	 * @param eventId
	 *            the eventId to set
	 */
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	/**
	 * Returns the value of lang
	 * 
	 * @return the lang
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * Sets the value of lang
	 * 
	 * @param lang
	 *            the lang to set
	 */
	public void setLang(String lang) {
		this.lang = lang;
	}

	/**
	 * Returns the value of Agreement ID
	 * 
	 * @return String Agreement ID
	 */
	public String getVereinbarungskennung() {
		return vereinbarungskennung;
	}

	/**
	 * Sets the value of Agreement ID
	 * 
	 * @param vereinbarungskennung
	 *            String Agreement ID to set
	 */
	public void setVereinbarungskennung(String vereinbarungskennung) {
		this.vereinbarungskennung = vereinbarungskennung;
	}

	/**
	 * Returns the value of Branch
	 * 
	 * @return int Branch
	 */
	public int getSparte() {
		return sparte;
	}

	/**
	 * Sets the value of Branch
	 * 
	 * @param sparte
	 *            int Branch to set
	 */
	public void setSparte(int sparte) {
		this.sparte = sparte;
	}

	/**
	 * Returns the value of signedAndEncryptedDataBackPack
	 * 
	 * @return String signedAndEncryptedDataBackPack
	 */
	public String getSignedAndEncryptedDataBackPack() {
		return signedAndEncryptedDataBackPack;
	}

    /**
     * Sets the value of signedAndEncryptedDataBackPack
     * 
     * @param signedAndEncryptedDataBackPack
     *            String signedAndEncryptedDataBackPack to set
     */
    public void setSignedAndEncryptedDataBackPack(String signedAndEncryptedDataBackPack) {
        this.signedAndEncryptedDataBackPack = signedAndEncryptedDataBackPack;
    }

    /**
     * Returns the String representation of Parameter Model
     * 
     * @return String String representation of Parameter Model
     */
    @Override
    public String toString() {
        return "Parameter [bpkenn=" + bpkenn + ", uid=" + uid + ", eventType=" + eventType + ", eventId=" + eventId
                + ", lang=" + lang + ", vereinbarungskennung=" + vereinbarungskennung + ", sparte=" + sparte
                + ", signedAndEncryptedDataBackPack=" + signedAndEncryptedDataBackPack + "]";
    }

}
