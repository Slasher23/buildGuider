package com.commerzbank.gdk.bns.model;

/**
 * Model Class for Notifications
 * 
 * @since 14/09/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 14/09/2017        1.01       ZE2BUEN    Initial Version
 * 23/11/2017        1.02       ZE2GOME    Apply Camel case to notification type.
 * </pre>
 */
public class Notifications {
	
	private String notificationType;
	
	private String notificationPath;
	
	private String notificationText;
	
	private String notificationSubject;

	/**
	 * Returns the value of Notification Type
	 * 
	 * @return String Notification Type  
	 */
    public String getNotificationPath() {
        return notificationPath;
    }
	
	/**
	 * Sets the value of Notification Path
	 * 
	 * @param notificationtype String Notification Path to set
	 */
    public String getNotificationType() {
        return notificationType;
    }


    /**
     * @param notificationType the notificationType to set
     */
    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    /**
	 * Sets the value of Notification Path
	 * 
	 * @param notificationPath String Notification Path to set
	 */
	public void setNotificationPath(String notificationPath) {
		this.notificationPath = notificationPath;
	}

	/**
	 * Returns the value of Notification Text
	 * 
	 * @return String Notification Text  
	 */
	public String getNotificationText() {
		return notificationText;
	}

	/**
	 * Sets the value of Notification Text
	 * 
	 * @param notificationText String Notification Text to set
	 */
	public void setNotificationText(String notificationText) {
		this.notificationText = notificationText;
	}

	/**
	 * Returns the value of Notification Subject
	 * 
	 * @return String Notification Subject  
	 */
	public String getNotificationSubject() {
		return notificationSubject;
	}

	/**
	 * Sets the value of Notification Subject
	 * 
	 * @param notificationSubject String Notification Subject to set
	 */
	public void setNotificationSubject(String notificationSubject) {
		this.notificationSubject = notificationSubject;
	}
	
	/**
	 * Returns the String representation of Notifications
	 * 
	 * @return String String representation of Notifications
	 */
	@Override
	public String toString() {
		return "Notifications [notificationType=" + notificationType + ", notificationPath=" + notificationPath
				+ ", notificationText=" + notificationText + ", notificationSubject=" + notificationSubject + "]";
	}
	
}
