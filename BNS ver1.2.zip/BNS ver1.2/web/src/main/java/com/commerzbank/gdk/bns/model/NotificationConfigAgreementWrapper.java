package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for Notification Configuration Agreement 
 * Returns and set Agreement and Notification Configuration Agreement
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.04
 * 
 * <pre>
 * Modified Date     Version    Author     Description 
 * 08/08/2017        1.01       ZE2SARO    Initial Version
 * 02/10/2017		 1.02		ZE2BAUL	   Removed agreementHolderName and replaced it with
 * 										   firstName and lastName
 * 30/01/2018        1.03       ZE2FARI    Added agreementCustomerName
 * 30/01/2018        1.04       ZE2FARI    Removed the holdername and holdergivenname
 * </pre>
 */
@XmlRootElement(name = "agreements")
public class NotificationConfigAgreementWrapper {

	private String agreementId;
	private String textType;
	private String type;
	private NotificationConfigAgreement notificationConfigAgreement;
	private int branch;
	private String agreementCustomerNames;
	
	/**
	 * Returns the textType
	 * 
	 * @return the textType
	 */
	public String getTextType() {
		return textType;
	}
	/**
	 * @param textType String the textType to set
	 */
	public void setTextType(String textType) {
		this.textType = textType;
	}
	
	/**
	 * @return String
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * @param type String the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * Returns the value of Agreement
	 * 
	 * @return String Agreement
	 */
	public String getAgreement() {
		return agreementId;
	}

	/**
	 * Sets the value of Agreement
	 * 
	 * @param agreement String Agreement to set
	 */
	public void setAgreement(String agreement) {
		this.agreementId = agreement;
	}

	/**
	 * Returns the Notification Configuration Agreement Model
	 * 
	 * @return NotificationConfigAgreement Notification Configuration Agreement
	 *                                     Model
	 */
	public NotificationConfigAgreement getNotificationConfigAgreement() {
		return notificationConfigAgreement;
	}

	/**
	 * Sets the Notification Configuration Agreement Model
	 * 
	 * @param notificationConfigAgreement NotificationConfigAgreement 
	 *        Notification Configuration Agreement Model to set
	 */
	public void setNotificationConfigAgreement(NotificationConfigAgreement notificationConfigAgreement) {
		this.notificationConfigAgreement = notificationConfigAgreement;
	}
			
	/**
	 * @return the branch
	 */
	public int getBranch() {
		return branch;
	}
	
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(int branch) {
		this.branch = branch;
	}
	
	/**	
	 * @return concatenated names of agreement customers
	 */
	public String getAgreementCustomerNames() {
		return agreementCustomerNames;
	}
	
	/**
	 * Sets the agreement customer names
	 * 
	 * @param agreementCustomerNames
	 */
	public void setAgreementCustomerNames(String agreementCustomerNames) {
		this.agreementCustomerNames = agreementCustomerNames;
	}
	
	/**
	 * Returns the String representation of Notification Configuration 
	 * Agreement Wrapper
	 * 
	 * @return String String representation of Notification Configuration 
	 *                Agreement Wrapper
	 */
	@Override
	public String toString() {
		return "NotificationConfigAgreementWrapper [agreement= " + agreementId + ", textType= " + textType + 
				" ,type= " + type + " ,agreementCustomerName=" + agreementCustomerNames + 
				" ,  notificationConfigAgreement= " + notificationConfigAgreement + "]";
	}	
}
