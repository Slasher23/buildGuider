package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchUpdateSalutationResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequest;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.UpdateSalutationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to update records.
 * 
 * @since 28/11/2017
 * @author ZE2JAVO
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2JAVO    Initial Version
 * 29/11/2017        1.01       ZE2SARO    Add batch process
 * 12/12/2017        1.02       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 06/02/2018        1.03       ZE2MACL    Remove thorws Exception and replace with try catch
 * 21/02/2018        1.04       ZE2MACL    Added required field/s validation
 * 
 *          </pre>
 */

@Service
@Transactional
public class UpdateSalutationServiceImpl implements UpdateSalutationService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    private static final Logger LOGGER                      = LoggerFactory
                    .getLogger(UpdateSalutationServiceImpl.class);
    private static final String STATUS_OK                   = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST   = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_FAILED_SALUTATION = "ZSL_STATUS_FA_FAILED_SALUTATION";
    private static final String EMPTY_STRING                = "";

    /**
     * Updates salutation & title for a given valid BPKENN; and returns a
     * response.
     * 
     * @param request
     * @return response
     */
    @Override
    public ZslUpdateResponse requestUpdateSalutation(UpdateSalutationRequest request) {

        ZslUpdateResponse response = new ZslUpdateResponse();
        String status = EMPTY_STRING;

        try {
            status = validateRequest(request);
            if (isNullOrEmpty(status)) {
                Person person = this.personDAO.findByBpkennIgnoreCase(request.getBpkenn());

                if (Objects.nonNull(person)) {
                    // set person details
                    person.setSalutation(request.getSalutation());
                    person.setTitle(request.getTitle());

                    this.personDAO.save(person);

                    status = this.environment.getProperty(STATUS_OK);
                } else {
                    status = this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS);
                }

            } else {
                response.setStatus(status);
            }

        } catch (Exception e) {
            status = this.environment.getProperty(STATUS_FA_FAILED_SALUTATION);
            LOGGER.error(e.getMessage(), e);
        }

        response.setBpkenn(request.getBpkenn());
        response.setStatus(status);

        return response;
    }

    /**
     * Method to validate request
     * 
     * @param request
     * @return String
     */
    private String validateRequest(UpdateSalutationRequest request) {
        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        if (isNullOrEmpty(request.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;
    }

    /**
     * Method to check if string is null or empty.
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
    }

    /**
     * Process client request and update person details in database.
     * 
     * @param request UpdateSalutationRequests list of salutation
     * @return BatchZslUpdateResponse list of update response
     */
    @Override
    public BatchUpdateSalutationResponse requestUpdateSalutation(UpdateSalutationRequests request) {

        BatchUpdateSalutationResponse response = new BatchUpdateSalutationResponse();
        List<ZslUpdateResponse> noErrors = new ArrayList<ZslUpdateResponse>();
        List<ZslUpdateResponse> withErrors = new ArrayList<ZslUpdateResponse>();

        for (UpdateSalutationRequest sautation : request.getUpdateSalutationRequest()) {

            ZslUpdateResponse result = requestUpdateSalutation(sautation);

            if (result.getStatus().equals(this.environment.getProperty(STATUS_OK))) {
                noErrors.add(result);
            } else {
                withErrors.add(result);
            }

        }

        response.setUpdateSalutationResponse(noErrors);
        response.setUpdateSalutationResponseWithErrors(withErrors);

        return response;
    }

}
