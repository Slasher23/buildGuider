package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.BatchPersonExistsRequest;
import com.commerzbank.gdk.bns.model.BatchPersonExistsResponse;
import com.commerzbank.gdk.bns.model.PersonExistsRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForPersonExistsService;

/**
 * RequestForPersonExistsController - Inform if requested Person (identified by
 * the handed over BPKenn) exists in BNS.
 * 
 * @since 7/12/2017
 * @author ZE2MENY
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 7/12/2017         1.00       ZE2MENY    Initial Version
 * 11/12/2017        1.01       ZE2MENY    Implementation of BatchProcessing
 * 13/12/2017        1.02       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.03       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */

@RestController
public class RequestForPersonExistsController {

    @Autowired
    private RequestForPersonExistsService requestForPersonExistsService;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForPersonExistsController.class);

    /**
     * Accept client post request and call service to request for person exists
     * also consumes and produces json or xml format.
     * 
     * @param request
     *            Parameter
     * @param httpRequest
     *            HttpServletRequest
     * @return ZslUpdateResponse
     */
    @PostMapping(value = "/api/zsl/requestForPersonExists")
    public ResponseEntity<ZslUpdateResponse> requestForPersonExists(@Valid @RequestBody PersonExistsRequest request,
            HttpServletRequest httpRequest, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForPersonExists({})", "zsl", request.toString());
        ZslUpdateResponse updateResponse = new ZslUpdateResponse();

        if (!result.hasErrors()) {
            updateResponse = this.requestForPersonExistsService.requestForPersonExistsResponse(request);

            if (Objects.isNull(updateResponse)) {
                updateResponse = new ZslUpdateResponse();
            }

        }

        ResponseEntity<ZslUpdateResponse> response = new ResponseEntity<ZslUpdateResponse>(updateResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response({})", "ZSL", updateResponse.toString());

        return response;
    }

    /**
     * Accept client post request and call service to request for person exists
     * in list also consumes and produces json or xml format.
     * 
     * @param requestForBatchPersonExistsList
     *            List <RequestForBatchPersonExistsList>
     * @param request
     *            HttpServletRequest
     * @return BatchPersonExistsResponse
     */
    @PostMapping(value = "/api/zsl/requestForBatchPersonExists")
    public ResponseEntity<BatchPersonExistsResponse> requestForBatchPersonExists(
            @Valid @RequestBody BatchPersonExistsRequest requestForBatchPersonExistsList, HttpServletRequest request,
            BindingResult result)  {

        LOGGER.info("=>> System [{}] - requestForBatchPersonExists({})", "ZSL",
                requestForBatchPersonExistsList.toString());
        BatchPersonExistsResponse batchResponse = new BatchPersonExistsResponse();

        if (!result.hasErrors()) {
            batchResponse = this.requestForPersonExistsService
                    .requestForPersonExistsResponse(requestForBatchPersonExistsList);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new BatchPersonExistsResponse();
            }

        }

        ResponseEntity<BatchPersonExistsResponse> response = new ResponseEntity<BatchPersonExistsResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response({})", "ZSL", batchResponse.toString());

        return response;
    }

}
