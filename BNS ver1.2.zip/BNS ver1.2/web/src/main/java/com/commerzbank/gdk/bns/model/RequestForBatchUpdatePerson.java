package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Update Person.
 * 
 * @author 	ZE2BAUL
 * @since 	12/12/2017
 * @version 1.00
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017	     1.00       ZE2BAUL    Initial Version
 * </pre>
 */
@XmlRootElement
public class RequestForBatchUpdatePerson {

	/**
	 * List for Update Person Request.
	 */
	private List<RequestForUpdatePersonRequest> updatePersonRequest;

	/**
	 * Returns the List of Update Person Request.
	 *
	 * @return the updatePersonRequest
	 */
	public List<RequestForUpdatePersonRequest> getUpdatePersonRequest() {
		return updatePersonRequest;
	}

	/**
	 * Sets the List of Update Person Request.
	 *
	 * @param updatePersonRequest the updatePersonRequest to set
	 */
	public void setUpdatePersonRequest(List<RequestForUpdatePersonRequest> updatePersonRequest) {
		this.updatePersonRequest = updatePersonRequest;
	}
	
	/**
	 * Returns the String representation of Update Person Batch Request
	 * Model.
	 * 
	 * @return String String representation of Update Person Batch
	 *         Request Model
	 */
	@Override
	public String toString() {
		return "RequestForBatchUpdatePerson [updatePersonRequest=" + updatePersonRequest + "]";
	}
}
