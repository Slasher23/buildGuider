package com.commerzbank.gdk.bns.dao;

import java.util.List;

import com.commerzbank.gdk.bns.model.PushConfiguration;

/**
 * Custom Push Configuration DAO Interface
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2BUEN    Initial Version
 * 23/11/2017        1.01       ZE2SARO    Remove Participant
 * 09/02/2018        1.03       ZE2MACL    Removed throws Exception
 *          </pre>
 */

public interface PushConfigurationCustomDAO {

    List<PushConfiguration> getPushConfiguration(Long personUID);

    PushConfiguration getPushConfiguration(Long personUID, String deviceID);

}
