package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Databackpack Log.
 * 
 * @since 02/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 02/02/2018        1.00       ZE2BUEN    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "databackpackLog")
public class DatabackpackLog {

    /**
     * eventType for DatabackpackLog.
     */
    private String eventType;

    /**
     * description for DatabackpackLog.
     */
    private String description;

    /**
     * user for DatabackpackLog.
     */
    private String user;

    /**
     * bpkenn for DatabackpackLog.
     */
    private String bpkenn;

    /**
     * oldValue for DatabackpackLog.
     */
    private String oldValue;

    /**
     * newValue for DatabackpackLog.
     */
    private String newValue;
    
    /**
     * Returns the value of eventType.
     * 
     * @return String eventType.
     */
	public String getEventType() {
		return eventType;
	}

	/**
     * Sets the value of eventType.
     * 
     * @param eventType
     *            String eventType to set.
     */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	/**
     * Returns the value of description.
     * 
     * @return String description.
     */
	public String getDescription() {
		return description;
	}
	
	/**
     * Sets the value of description.
     * 
     * @param description
     *            String description to set.
     */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
     * Returns the value of user.
     * 
     * @return String user.
     */
	public String getUser() {
		return user;
	}
	
	/**
     * Sets the value of user.
     * 
     * @param user
     *            String user to set.
     */
	public void setUser(String user) {
		this.user = user;
	}
	
	/**
     * Returns the value of bpkenn.
     * 
     * @return String bpkenn.
     */
	public String getBpkenn() {
		return bpkenn;
	}
	
	/**
     * Sets the value of bpkenn.
     * 
     * @param bpkenn
     *            String bpkenn to set.
     */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}
	
	/**
     * Returns the value of oldValue.
     * 
     * @return String oldValue.
     */
	public String getOldValue() {
		return oldValue;
	}
	
	/**
     * Sets the value of oldValue.
     * 
     * @param oldValue
     *            String oldValue to set.
     */
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	
	/**
     * Returns the value of newValue.
     * 
     * @return String newValue.
     */
	public String getNewValue() {
		return newValue;
	}
	
	/**
     * Sets the value of newValue.
     * 
     * @param newValue
     *            String newValue to set.
     */
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	/**
     * Returns the String representation of Databackpack Log Model.
     * 
     * @return String String representation of Databackpack Log Model.
     */
	@Override
	public String toString() {
		return "DatabackpackLog [eventType=" + eventType + ", description=" + description + ", user=" + user
				+ ", bpkenn=" + bpkenn + ", oldValue=" + oldValue + ", newValue=" + newValue
				+ "]";
	}

}
    