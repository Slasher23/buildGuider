﻿# Sie haben Ihre erste Infodatei hinzugefügt!
Eine Datei "README.md" dient dazu, Lesern einen schnellen Überblick über die Funktionen Ihres Projekts zu geben. Ist Markdown neu für Sie? [Weitere Informationen](http://go.microsoft.com/fwlink/p/?LinkId=524306&clcid=0x409)

## Bearbeiten Sie diese Infodatei, und führen Sie für Ihre Änderung einen Commit in einen Topic-Branch aus.
Branches in Git sind unkompliziert. Nutzen Sie sie bei jeder Änderung an Ihrem Repository. Klicken Sie auf das entsprechende Symbol, um diese Datei zu bearbeiten.

Nehmen Sie dann Änderungen an dieser Infodatei vor.

> **Bearbeiten** Sie _dies_ blockquote

Wenn Sie fertig sind, klicken Sie auf den Dropdownpfeil neben der Schaltfläche zum Speichern: Sie können dann einen Commit für Ihre Änderungen in einen neuen Branch ausführen.

## Erstellen Sie einen Pull Request, um Ihre Änderungen wieder zum Hauptbranch beizusteuern.
Mit Pull Requests werden Änderungen aus einem Topic-Branch zurück in den Hauptbranch verschoben.

Klicken Sie im **CODEHUB** auf die Seite **Pull Requests** und dann auf "Neuer Pull Request", um einen neuen Pull Request aus Ihrem Topic-Branch in den Hauptbranch zu erstellen.

Nachdem Sie alle Details hinzugefügt haben, klicken Sie auf "Pull Request erstellen". Sobald ein Pull Request gesendet wurde, können Reviewer Ihre Änderungen anzeigen, Änderungen empfehlen oder sogar Folgecommits mithilfe von Push übertragen.

Erstellen Sie zum ersten Mal einen Pull Request? [Weitere Informationen](http://go.microsoft.com/fwlink/?LinkId=533211&clcid=0x409)

### Herzlichen Glückwunsch! Sie haben den Rundgang durch den CODEHUB abgeschlossen!

# Nächste Schritte

Wenn dies noch nicht geschehen ist, [installieren Sie Git](http://git-scm.com/downloads) (sowie die [Git-Anmeldeinformationenverwaltung](https://java.visualstudio.com/Downloads/gitcredentialmanager/Index) für Linux oder Mac OS)

Wählen Sie eine dieser unterstützten IDEs aus, und installieren Sie diese:
* [Visual Studio](http://go.microsoft.com/fwlink/?LinkId=309297&clcid=0x409&slcid=0x409)
* [Android Studio](https://developer.android.com/studio) (mit dem [Team Services-Plug-In](https://java.visualstudio.com/Downloads/intellijplugin/Index))
* [Eclipse](http://www.eclipse.org/downloads) (mit [Team Explorer Everywhere](https://java.visualstudio.com/Downloads/eclipseplugin/Index))
* [IntelliJ IDEA](https://www.jetbrains.com/idea/download) (mit dem [Team Services-Plug-In](https://java.visualstudio.com/Downloads/intellijplugin/Index))
* [Visual Studio Code](https://code.visualstudio.com/Download) (mit [Team Services Extension](https://java.visualstudio.com/Downloads/visualstudiocode/Index))

Klonen Sie anschließend dieses Repository auf Ihren lokalen Computer, um mit der Arbeit an Ihrem eigenen Projekt zu beginnen.

Viel Spaß beim Programmieren!

Dies ist ein Test um zu sehen ob ein Git Push von einem LISA Rechner auf Origin Funktioniert.