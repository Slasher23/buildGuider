package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.model.DailyReportLog;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.model.RequiredNotificationResponseWithErrors;
import com.commerzbank.gdk.bns.service.RequestForRequiredNotificationService;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * JUnit test class for Request For Required Notification Service Implementation
 * 
 * @author ZE2BAUL
 * @since 13/11/2017
 * @version 1.04
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017	     1.00       ZE2BAUL    Initial Version
 * 07/12/2017        1.01       ZE2CRUH    Updated RequiredNotification to include UUID
 * 12/12/2017        1.02       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.03       ZE2BUEN    Refactor/clean up for status messages
 * 05/02/2018        1.04       ZE2FUEN    Removed ProcessRunID in request
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForRequiredNotificationServiceImplTest {

    @Mock
    private RequestForRequiredNotificationService requestForRequiredNotificationService;

    @Mock
    private Tools base64;

    @Mock
    private Environment environment;

    @Mock
    private DailyReportLogDAO dailyReportLogDAO;

    @InjectMocks
    private RequestForRequiredNotificationServiceImpl requestForRequiredNotificationServiceImpl;

    private RequiredNotificationRequest requiredNotifRequest;
    private NotificationResponse notificationResponse = new NotificationResponse();
    private List<Notifications> notificationList = Lists.newArrayList();
    private Notifications notification = new Notifications();
    private RequestForRequiredBatchNotification reqBatch = new RequestForRequiredBatchNotification();
    private Tools tools = new Tools();

    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_REQ_NOTIF_NOT_SENT = "ZSL_STATUS_FA_REQ_NOTIF_NOT_SENT";
    private static final String processRunIdKey = "ProcessRunID";
    private static final String eventType = "04";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        ReflectionTestUtils.setField(requestForRequiredNotificationServiceImpl,
                "processRunIdKey", processRunIdKey);

        ReflectionTestUtils.setField(requestForRequiredNotificationServiceImpl,
                "eventType", eventType);

        String notifTextToBeBase64 = "Notification Text Test";
        String encoded = "";
        try {
            encoded = tools.base64Encode(notifTextToBeBase64);
        } catch (Exception e) {
            e.printStackTrace();
        }

        requiredNotifRequest = new RequiredNotificationRequest();
        requiredNotifRequest.setBpkenn("BPKENNTEST");
        requiredNotifRequest.setNotificationpath("email@email.com");
        requiredNotifRequest.setNotificationsubject("subject test");
        requiredNotifRequest.setNotificationtext(encoded);
        requiredNotifRequest.setNotificationtype("email");
        requiredNotifRequest.setUuid("test");

        notificationResponse.setBPKENN(requiredNotifRequest.getBpkenn());
        notification.setNotificationType(requiredNotifRequest.getNotificationtype());
        notification.setNotificationPath(requiredNotifRequest.getNotificationpath());
        notification.setNotificationText(requiredNotifRequest.getNotificationtext());
        notification.setNotificationSubject(requiredNotifRequest.getNotificationsubject());

    }

    @Test
    public void requestForRequiredNotification_HappyPath() throws Exception {

        String notifTextToBeBase64 = "Notification Text Test";
        String encoded = "";
        try {
            encoded = tools.base64Encode(notifTextToBeBase64);
        } catch (Exception e) {
            e.printStackTrace();
        }
        when(this.base64.base64Decode(anyString())).thenReturn(encoded);
        notificationList.add(notification);
        notificationResponse.setNotification(notificationList);
        notificationResponse.setStatus("OK- Successful");

        DailyReportLog dailyReportLog = new DailyReportLog();

        when(this.dailyReportLogDAO.save(any(DailyReportLog.class))).thenReturn(dailyReportLog);

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        assertEquals(notificationResponse.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredNotification(requiredNotifRequest).toString());

    }

    @Test
    public void requestForRequiredNotification_EmptyRequest() throws Exception {

        requiredNotifRequest = new RequiredNotificationRequest();

        notificationResponse.setBPKENN(null);
        notificationResponse.setNotification(null);
        notificationResponse.setStatus("FA- Invalid Request");

        DailyReportLog dailyReportLog = new DailyReportLog();

        when(this.dailyReportLogDAO.save(any(DailyReportLog.class))).thenReturn(dailyReportLog);

        when(this.environment.getProperty(anyString())).thenReturn("FA- Invalid Request");

        assertEquals(notificationResponse.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredNotification(requiredNotifRequest).toString());

    }

    @Test
    public void requestForRequiredNotification_NullUuid() throws Exception {

        requiredNotifRequest.setUuid(null);

        notificationResponse.setNotification(null);
        notificationResponse.setStatus("FA- Invalid Request");

        DailyReportLog dailyReportLog = new DailyReportLog();

        when(this.dailyReportLogDAO.save(any(DailyReportLog.class))).thenReturn(dailyReportLog);

        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        assertEquals(notificationResponse.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredNotification(requiredNotifRequest).toString());

    }

    /*
     * @Test public void requestForRequiredNotification_NullRequest() throws
     * Exception {
     * 
     * requiredNotifRequest = null;
     * 
     * notificationResponse.setBPKENN(null);
     * notificationResponse.setNotification(null);
     * notificationResponse.setStatus("FA- Required Notification Not Sent");
     * 
     * when(this.environment.getProperty(anyString())).thenReturn(
     * "FA- Required Notification Not Sent");
     * 
     * assertEquals(notificationResponse.toString(),
     * this.requestForRequiredNotificationServiceImpl
     * .requestForRequiredNotification(requiredNotifRequest,
     * processRunID).toString());
     * 
     * }
     */

    @Test
    public void requestForRequiredNotification_MissingField() throws Exception {

        notificationResponse.setBPKENN("BPKENNTEST");
        notificationList.add(notification);
        notificationResponse.setNotification(null);
        notificationResponse.setStatus("FA- Invalid Request");

        requiredNotifRequest.setNotificationtype(null);

        DailyReportLog dailyReportLog = new DailyReportLog();

        when(this.dailyReportLogDAO.save(any(DailyReportLog.class))).thenReturn(dailyReportLog);

        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        assertEquals(notificationResponse.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredNotification(requiredNotifRequest).toString());

    }

    @Test
    public void requestForRequiredNotification_NotBase64() throws Exception {

        notificationResponse.setNotification(null);
        notificationResponse.setStatus("FA- Invalid Request");

        requiredNotifRequest.setNotificationtext("Notif Text Not Base 64");

        DailyReportLog dailyReportLog = new DailyReportLog();

        when(this.dailyReportLogDAO.save(any(DailyReportLog.class))).thenReturn(dailyReportLog);

        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        assertEquals(notificationResponse.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredNotification(requiredNotifRequest).toString());

    }

    @Test
    public void requestForRequiredBatchNotification_HappyPath_StatusIsOK() throws Exception {

        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        List<RequiredNotificationRequest> reqNotifList = new ArrayList<>();

        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();

        for (int i = 0; i < 2; i++) {

            Notifications notification = new Notifications();
            NotificationResponse response = new NotificationResponse();
            RequiredNotificationRequest requiredNotifRequest = new RequiredNotificationRequest();
            List<Notifications> notificationList = Lists.newArrayList();

            String notifTextToBeBase64 = "Notification Text Test " + i;
            String encoded = "";
            try {
                encoded = tools.base64Encode(notifTextToBeBase64);
            } catch (Exception e) {
                e.printStackTrace();
            }

            requiredNotifRequest.setNotificationpath("Notif Path " + i);
            requiredNotifRequest.setNotificationsubject("Notif Subject " + i);
            requiredNotifRequest.setNotificationtext(encoded);
            requiredNotifRequest.setNotificationtype("Notif Type" + i);
            requiredNotifRequest.setBpkenn("BPKENNTEST" + i);
            requiredNotifRequest.setUuid("Uuid" + i);

            reqNotifList.add(requiredNotifRequest);
            reqBatch.setRequiredNotificationRequest(reqNotifList);

            notification.setNotificationPath("Notif Path " + i);
            notification.setNotificationSubject("Notif Subject " + i);
            notification.setNotificationText(encoded);
            notification.setNotificationType("Notif Type" + i);
            notificationList.add(notification);
            response.setBPKENN("BPKENNTEST" + i);
            response.setNotification(notificationList);
            response.setStatus("OK- Successful");

            reqNotifResponseList.add(response);
        }

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);

        assertEquals(responseWrapper.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredBatchNotification(reqBatch).toString());

    }

    @Test
    public void requestForRequiredBatchNotification_requestIsEmpty() throws Exception {

        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        List<RequiredNotificationRequest> reqNotifList = new ArrayList<>();
        RequiredNotificationRequest requiredNotifRequest = new RequiredNotificationRequest();

        reqNotifList.add(requiredNotifRequest);
        reqBatch.setRequiredNotificationRequest(reqNotifList);

        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();
        RequiredNotificationResponseWithErrors reqNotifResponseErrors = new RequiredNotificationResponseWithErrors();

        reqNotifResponseErrors.setStatus("FA- Invalid Request");
        reqNotifResponseWithErrorsList.add(reqNotifResponseErrors);

        when(this.environment.getProperty(anyString())).thenReturn("FA- Invalid Request");
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);

        assertEquals(responseWrapper.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredBatchNotification(reqBatch).toString());

    }

    @Test
    public void requestForRequiredBatchNotification_requestIsNull() throws Exception {

        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        List<RequiredNotificationRequest> reqNotifList = new ArrayList<>();

        reqNotifList.add(null);

        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();
        RequiredNotificationResponseWithErrors reqNotifResponseErrors = new RequiredNotificationResponseWithErrors();

        reqNotifResponseErrors.setStatus("FA- Required Notification Not Sent");
        reqNotifResponseWithErrorsList.add(reqNotifResponseErrors);

        when(this.environment.getProperty(STATUS_FA_REQ_NOTIF_NOT_SENT))
                .thenReturn("FA- Required Notification Not Sent");

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);

        assertEquals(responseWrapper.toString(),
                this.requestForRequiredNotificationServiceImpl.requestForRequiredBatchNotification(null).toString());

    }

    @Test
    public void requestForRequiredBatchNotification_BPKENNIsNull() throws Exception {

        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        List<RequiredNotificationRequest> reqNotifList = new ArrayList<>();

        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();

        for (int i = 0; i < 2; i++) {

            Notifications notification = new Notifications();
            RequiredNotificationResponseWithErrors responseError = new RequiredNotificationResponseWithErrors();
            NotificationResponse response = new NotificationResponse();
            RequiredNotificationRequest requiredNotifRequest = new RequiredNotificationRequest();
            List<Notifications> notificationList = Lists.newArrayList();

            String notifTextToBeBase64 = "Notification Text Test " + i;
            String encoded = "";
            try {
                encoded = tools.base64Encode(notifTextToBeBase64);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (i == 1) {
                requiredNotifRequest.setBpkenn(null);
            } else {
                requiredNotifRequest.setBpkenn("BPKENNTEST" + i);
            }

            requiredNotifRequest.setNotificationpath("Notif Path " + i);
            requiredNotifRequest.setNotificationsubject("Notif Subject " + i);
            requiredNotifRequest.setNotificationtext(encoded);
            requiredNotifRequest.setNotificationtype("Notif Type" + i);
            requiredNotifRequest.setUuid("Uuid" + i);

            reqNotifList.add(requiredNotifRequest);
            reqBatch.setRequiredNotificationRequest(reqNotifList);

            // Expected
            notification.setNotificationPath("Notif Path " + i);
            notification.setNotificationSubject("Notif Subject " + i);
            notification.setNotificationText(encoded);
            notification.setNotificationType("Notif Type" + i);
            notificationList.add(notification);

            if (i == 1) {
                responseError.setBpkenn(null);
                responseError.setStatus("FA- Invalid Request");
                responseError.setNotification(null);
                reqNotifResponseWithErrorsList.add(responseError);
            } else {
                response.setBPKENN("BPKENNTEST" + i);
                response.setStatus("OK- Successful");
                response.setNotification(notificationList);
                reqNotifResponseList.add(response);
            }

        }

        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);
        
        assertEquals(responseWrapper.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredBatchNotification(reqBatch).toString());
    }

    @Test
    public void requestForRequiredBatchNotification_AllStatusIsFA() throws Exception {

        List<NotificationResponse> reqNotifResponseList = new ArrayList<>();
        List<RequiredNotificationResponseWithErrors> reqNotifResponseWithErrorsList = new ArrayList<>();
        List<RequiredNotificationRequest> reqNotifList = new ArrayList<>();

        RequiredBatchNotificationResponseWrapper responseWrapper = new RequiredBatchNotificationResponseWrapper();

        for (int i = 0; i < 2; i++) {

            Notifications notification = new Notifications();
            RequiredNotificationResponseWithErrors responseError = new RequiredNotificationResponseWithErrors();
            RequiredNotificationRequest requiredNotifRequest = new RequiredNotificationRequest();
            List<Notifications> notificationList = Lists.newArrayList();

            String notifTextToBeBase64 = "Notification Text Test " + i;
            String encoded = "";
            try {
                encoded = tools.base64Encode(notifTextToBeBase64);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (i == 1) {
                requiredNotifRequest.setBpkenn(null);
            } else {
                requiredNotifRequest.setBpkenn("BPKENNTEST" + i);
                requiredNotifRequest.setNotificationpath(null);
            }

            requiredNotifRequest.setNotificationsubject("Notif Subject " + i);
            requiredNotifRequest.setNotificationtext(encoded);
            requiredNotifRequest.setNotificationtype("Notif Type" + i);

            reqNotifList.add(requiredNotifRequest);
            reqBatch.setRequiredNotificationRequest(reqNotifList);

            // Expected
            notification.setNotificationPath("Notif Path " + i);
            notification.setNotificationSubject("Notif Subject " + i);
            notification.setNotificationText(encoded);
            notification.setNotificationType("Notif Type" + i);
            notificationList.add(notification);

            if (i == 1) {
                responseError.setBpkenn(null);
            } else {
                responseError.setBpkenn("BPKENNTEST" + i);
            }

            responseError.setStatus("FA- Invalid Request");
            responseError.setNotification(null);
            reqNotifResponseWithErrorsList.add(responseError);
        }

        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        responseWrapper.setRequiredNotificationResponse(reqNotifResponseList);
        responseWrapper.setRequiredNotificationResponseWithErrors(reqNotifResponseWithErrorsList);

        assertEquals(responseWrapper.toString(), this.requestForRequiredNotificationServiceImpl
                .requestForRequiredBatchNotification(reqBatch).toString());

    }

}
