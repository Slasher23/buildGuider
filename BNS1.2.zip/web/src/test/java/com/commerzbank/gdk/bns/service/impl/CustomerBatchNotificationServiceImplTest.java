package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsResponse;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.service.CustomerNotificationService;

/**
 * JUnit test class for CustomerBatchNotificationServiceImpl
 * 
 * @since 20/11/2017
 * @author ZE2GOME
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2GOME    Initial Version
 *          </pre>
 */

public class CustomerBatchNotificationServiceImplTest {

    private static final String SUCCESS_MESS = "OK- Successful";
    private static final String KUNDE_NOT_EXIST_MESS = "FA- Kundennumber does not exist in BNS";
    private CustomerBatchNotificationsRequest request = new CustomerBatchNotificationsRequest();

    @Mock
    private Environment environment;
    
    @Mock
    private CustomerNotificationService custNotificationServiceMock;

    @InjectMocks
    private CustomerBatchNotificationServiceImpl serviceImplMock;

    private CustomerNotificationRequest custRequest1 = new CustomerNotificationRequest();
    private CustomerNotificationRequest custRequest2 = new CustomerNotificationRequest();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        List<CustomerNotificationRequest> listCustRequest = new ArrayList<CustomerNotificationRequest>();
        custRequest1.setKundennummer("12345");
        custRequest2.setKundennummer("54321");
        listCustRequest.add(custRequest1);
        listCustRequest.add(custRequest2);
        request.setCustomerNotificationsRequest(listCustRequest);
    }

    @Test
    public void CustomerBatchNotificationServiceImpl_Test() throws Exception {

        CustomerBatchNotificationsResponse response = new CustomerBatchNotificationsResponse();
        List<CustomerNotificationsResponse> withoutErrors = new ArrayList<CustomerNotificationsResponse>();
        List<CustomerNotificationsResponse> withErors = new ArrayList<CustomerNotificationsResponse>();

        CustomerNotificationsResponse withoutError = Mockito.mock(CustomerNotificationsResponse.class);
        withoutError.setKundennummer("12345");
        withoutError.setCustomerNotifications(new ArrayList<NotificationResponse>());
        when(withoutError.getStatus()).thenReturn(SUCCESS_MESS);

        CustomerNotificationsResponse withError = Mockito.mock(CustomerNotificationsResponse.class);
        withError.setKundennummer("54321");
        withError.setCustomerNotifications(new ArrayList<NotificationResponse>());
        when(withError.getStatus()).thenReturn(KUNDE_NOT_EXIST_MESS);

        withoutErrors.add(withoutError);
        withErors.add(withError);
        response.setCustomerNotificationResponseWithErrors(withErors);
        response.setCustomerNotificationResponse(withoutErrors);

        when(this.environment.getProperty(any(String.class))).thenReturn(SUCCESS_MESS);
        when(this.custNotificationServiceMock.getResponse(any(CustomerNotificationRequest.class)))
                .thenReturn(withoutError, withError);

        assertEquals(this.serviceImplMock.getResponse(request).toString(), response.toString());
    }

}
