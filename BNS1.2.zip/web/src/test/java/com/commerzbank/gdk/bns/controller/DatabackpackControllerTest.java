package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.DatabackpackService;

/**
 * Junit for Databackpack Controller
 * 
 * @author ZE2BUEN
 * @since 27/12/2017
 * @version 1.00
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/12/2017	     1.00       ZE2BUEN    Initial Version
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class DatabackpackControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private DatabackpackService databackpackService;

	@InjectMocks
	private DatabackpackController databackpackController;
	
	private String encryptedDatabackpack;
	
	private String databackpackString;

	private MockMvc mockMvc;

	private Parameter parameter;

	private Tokenizer token;

	private ResponseBuilder<Databackpack> builder;

	private List<Customer> customerList;

	private Customer customer1;

	private Customer customer2;

	private List<Agreement> agreementList;

	private Agreement agreement1;

	private Agreement agreement2;

	private Person person;

	private NotificationConfigPerson notificationConfigPerson;

	private List<Email> emailList;

	private Email email1;

	private Email email2;

	private Databackpack databackpack;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(DatabackpackController.class);

	@Before
	public void init() {

		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(databackpackController).build();
		
		encryptedDatabackpack = "a2Rucj0xMjM0NTY3ODkwO2tkbnI9MTIzNDU2Nzg5MTtwcm9kSWQ9REUwMSAyMzQ1IDY3ODkgMTAxMSAxMjEzIDE0LHByb2RjYXQ9S1RPLG5hbWU9UHJlbWl1bSBLb250byxpYmFuPURFMDEgMjM0NSA2Nzg5IDEwMTEgMTIxMyAxNDtwcm9kSWQ9MTIzNCA0NTY3IDg5MTAgMTExMyxwcm9kY2F0PUtBUixuYW1lPU1hc3RlcmNhcmQgUHJlbWl1bTtwZXJzb25Eb2N1bWVudHNBY3RpdmF0ZWQ9MDtmaXJzdG5hbWU9U2ltb24sbGFzdG5hbWU9TWVpZXIsdGl0bGU9UHJvZmVzc29yLHRpdGxlRXh0ZW5zaW9uPWFiYyx0aXRsZU9mTm9iaWxpdHk9LHNhbHV0YXRpb249SGVycmVuLHNhbHV0YXRpb25FeHRlbnNpb249LGluZGl2aWR1YWxTYWx1dGF0aW9uPTtlbWFpbGFkZD1lbWFpbEBjb2JhLmNvbSxhZGRJRD0xO2VtYWlsYWRkPWVtYWlsQGdtYWlsLmNvbSxhZGRJRD0yOw==";
		databackpackString = "kdnr=1234567890;kdnr=1234567891;prodId=DE01 2345 6789 1011 1213 14,prodcat=KTO,name=Premium Konto,iban=DE01 2345 6789 1011 1213 14;prodId=1234 4567 8910 1113,prodcat=KAR,name=Mastercard Premium;personDocumentsActivated=0;firstname=Simon,lastname=Meier,title=Professor,titleExtension=abc,titleOfNobility=,salutation=Herren,salutationExtension=,individualSalutation=;emailadd=email@coba.com,addID=1;emailadd=email@gmail.com,addID=2;";
		
		parameter = new Parameter();
		parameter.setDatabackpack(encryptedDatabackpack);

		token = new Tokenizer();
		token.setUserId("User Test");
		token.setError(false);

		customer1 = new Customer();
		customer1.setCustomerNumber("1234567890");

		customer2 = new Customer();
		customer2.setCustomerNumber("1234567891");

		customerList = new ArrayList<>();
		customerList.add(customer1);
		customerList.add(customer2);

		agreement1 = new Agreement();
		agreement1.setAgreementID("DE01 2345 6789 1011 1213 14");
		agreement1.setAgreementType("KTO");
		agreement1.setType("Premium Konto");
		agreement1.setIban("DE01 2345 6789 1011 1213 14");

		agreement2 = new Agreement();
		agreement2.setAgreementID("1234 4567 8910 1113");
		agreement2.setAgreementType("KAR");
		agreement2.setType("Mastercard Premium");

		agreementList = new ArrayList<>();
		agreementList.add(agreement1);
		agreementList.add(agreement2);

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(false);

		person = new Person();
		person.setGivenName("Simon");
		person.setLastName("Meier");
		person.setSalutation("02");
		person.setTitle("01");

		email1 = new Email();
		email1.setAddressId(1L);
		email1.setEmailAddress("email@coba.com");

		email2 = new Email();
		email2.setAddressId(2L);
		email2.setEmailAddress("email@gmail.com");

		emailList = new ArrayList<>();
		emailList.add(email1);
		emailList.add(email2);

		databackpack = new Databackpack();
		databackpack.setAgreementList(agreementList);
		databackpack.setCustomerList(customerList);
		databackpack.setEmailList(emailList);
		databackpack.setNotificationConfigPerson(notificationConfigPerson);
		databackpack.setPerson(person);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<Databackpack>(logger, token, globalRWrapper);

	}

	@Test
	public void databackpackProcessor_JSONResponseCode_Test() throws Exception {

		when(this.databackpackService.databackpackProcessor(any(Tokenizer.class), any(String.class)))
				.thenReturn(builder.OK(databackpack));

		this.mockMvc
				.perform(post("/api/databackpack").contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
				.andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());
	}

	@Test
	public void databackpackProcessorJSON_Test() throws Exception {

		when(this.databackpackService.databackpackProcessor(any(Tokenizer.class), any(String.class)))
				.thenReturn(builder.OK(databackpack));

		this.mockMvc
				.perform(post("/api/databackpack").contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

}
