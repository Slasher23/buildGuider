package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for EmailServiceImpl Test
 * 
 * @author 	ZE2MACL
 * @since 	14/11/2017
 * @version 1.02
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 14/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Updated Email Address Model
 * 28/11/2017        1.02       ZE2MORA    Updated Status Codes
 * </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class EmailServiceImplTest {
    
	@Autowired
	private GlobalResponseWrapper globalRWrapper;
    
	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
	
    @Mock
    private EmailDAO emailDAO;
    
    @Mock
    private PersonDAO personDAO;
    
    @InjectMocks
    private EmailServiceImpl emailServiceImpl;
    
    private Tokenizer token;
    
    private Email email;
    
    private List<Email> emailList = new ArrayList<Email>();
    
    private Person person;
    
    private ResponseBuilder<List<Email>> builder;
    
    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    private Map<Integer, String> statusCodesMap;
   
    
    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        
        person = new Person();
        person.setPersonUID(1L);
        
        token = new Tokenizer();
        token.setUserId("test");
        token.setError(false);
        
        email = new Email();
        email.setEmailAddress("test");
        email.setEmailUID(1L);
        email.setPersonUID(1L);
        
        emailList.add(email);
        
        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
        builder = new ResponseBuilder<List<Email>>(logger, token, globalRWrapper);
       
        
    }
    
    @Test
    public void getEmailList_Success_Test() throws Exception{
    	
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.OK(emailList);
        
        when(personDAO.getPerson(anyString())).thenReturn(person);
        when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }
    
    @Test
    public void getEmailList_SuccessNoResultFound_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);
        
        when(personDAO.getPerson(anyString())).thenReturn(person);
        when(emailDAO.getEmailList(anyLong())).thenReturn(null);
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }
    
    @Test
    public void getEmailList_SuccessNoPersonFound_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.OK(Response.SUCCESS_NO_PERSON_FOUND);
        
        when(personDAO.getPerson(anyString())).thenReturn(null);
        when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }
    
    @Test
    public void getEmailList_DataAccessException_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.notOK(Response.DATA_ACCESS_EXCEPTION);
        
        when(personDAO.getPerson(anyString())).thenReturn(person);
        when(emailDAO.getEmailList(anyLong())).thenThrow(new DataRetrievalFailureException("test"));
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }
    
    @Test
    public void getEmailList_NullPointerException_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.notOK(Response.NULL_POINTER_EXCEPTION);
        
        when(personDAO.getPerson(anyString())).thenThrow(new NullPointerException("test"));
        when(emailDAO.getEmailList(anyLong())).thenThrow(new NullPointerException("test"));
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }
    
    @Test
    public void getEmailList_GeneralException_Test() throws Exception{
        
    	when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder.notOK(Response.GENERAL_FUNCTION_ERROR);
        
        when(personDAO.getPerson(anyString())).thenReturn(person);
        when(emailDAO.getEmailList(anyLong())).thenThrow(new RuntimeException());
        
        assertEquals(builder.toString(), this.emailServiceImpl.getEmailList(token, "test").toString());
        
    }

    

}
