package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.BatchUpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ComplexElectronicAddress;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForBatchUpdatePartyService;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;

/**
 * <description>
 * 
 * @author ZE2GOME
 * @since 11/12/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2GOME    Added test method for batch
 * 14/12/2017        1.02       ZE2MENY    Change complexelectronicalAddress into electronicalAddress
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForUpdatePartyControllerTest {
    
    private MockMvc mockMvc;
    
    @Mock
    private RequestForUpdatePartyService requestForUpdatePartyService;
    
    @Mock
    private RequestForBatchUpdatePartyService requestForBatchUpdatePartyService;
    
    @InjectMocks
    private RequestForUpdatePartyController forUpdatePartyController;
    
    private ZslUpdateResponse zslUpdateResponse;
    
    private UpdatePartyRequest updatePartyRequest;
    
    private BatchUpdatePartyRequest batchUpdatePartyRequest;
    
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        
        this.mockMvc = MockMvcBuilders.standaloneSetup(forUpdatePartyController).build();
        
        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST");
        zslUpdateResponse.setStatus("OK- Successful");
        
        updatePartyRequest = new UpdatePartyRequest();
        
        updatePartyRequest.setBpkenn("BPKENNTEST");
        updatePartyRequest.setFirstName("TestName");
        updatePartyRequest.setLastName("TestLastname");
        updatePartyRequest.setSalutation("SalutationTest");
        updatePartyRequest.setTitle("TitleTest");
        
        ComplexElectronicAddress cea = new ComplexElectronicAddress();
        cea.setAddressId(1L);
        cea.setEmailAddress("test@test.com");
        
        List<ComplexElectronicAddress> ceaList = new ArrayList<>();
        ceaList.add(cea);
        
        updatePartyRequest.setElectronicalAddress(ceaList);
        
        List<UpdatePartyRequest> listUpdatePartyRequest = new ArrayList<>();
        listUpdatePartyRequest.add(updatePartyRequest);
        
        batchUpdatePartyRequest = new BatchUpdatePartyRequest();
        batchUpdatePartyRequest.setUpdatePartyRequest(listUpdatePartyRequest);
        
    }
    
    @Test
    public void requestForUpdateParty_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForUpdateParty").content(Parser.asJsonString(updatePartyRequest))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
    
    @Test
    public void requestForUpdateParty_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForUpdateParty")
                .content(Parser.xmlConverter(updatePartyRequest))
                .contentType(MediaType.APPLICATION_XML)).andExpect(status().isOk());
    }
    
    @Test
    public void requestForBatchUpdateParty_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdateParty").content(Parser.asJsonString(batchUpdatePartyRequest))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }
    
    @Test
    public void requestForBatchUpdateParty_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdateParty")
                .content(Parser.xmlConverter(batchUpdatePartyRequest))
                .contentType(MediaType.APPLICATION_XML)).andExpect(status().isOk());
    }

}
