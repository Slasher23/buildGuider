package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotifConfigPersonWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonConfigWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for AgreementTypesWrapperServiceImpl
 * 
 * @author ZE2MACL
 * @since 20/11/2017
 * @version 1.03
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 20/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Removed Participant Number
 * 28/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 * 22/12/2017        1.03       ZE2CRUH    Added test for Iban
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class AgreementTypesWrapperServiceImplTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private PersonDAO personDAO;

	@Mock
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Mock
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Mock
	private AgreementDAO agreementDAO;

	@Mock
	private EmailDAO emailDAO;

	@Mock
	private InformationChannelDAO informationChannelDAO;

	@Mock
	Environment environment;

	@Mock
	private AllNotificationConfigDAO allNotificationConfigDAO;

	@Mock
	private NotificationTextDAO notificationTextDAO;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@InjectMocks
	private AgreementTypesWrapperServiceImpl agreementTypesWrapperServiceImpl;

	private NotificationConfigAgreementWrapper notificationConfigAgreementWrapper;

	private List<NotificationConfigAgreementWrapper> notificationConfigAgreementWrapperList = new ArrayList<NotificationConfigAgreementWrapper>();
	
	private List<AgreementTypesWrapper> agreementTypesWrapperList = new ArrayList<AgreementTypesWrapper>();
	
	private NotificationConfigPerson notificationConfigPerson;
	
	private NotifConfigPersonWrapper notifConfigPersonWrapper;
	
	private PersonConfigWrapper personConfigWrapper;
	
	private AllNotificationConfig allNotificationConfig;
	
	private AgreementTypesWrapper agreementTypesWrapper;
	
	private Email email;
	
	private List<Email> emailList = new ArrayList<Email>();
	
	private InformationChannel informationChannel;
	
	private List<InformationChannel> informationChannelList;
	
	private MainAgreementTypeWrapper mainAgreementTypeWrapper;
	
	private List<Agreement> agreementlist;
	
	private Agreement agreement;
	
	private NotificationConfigAgreement notificationConfigAgreement;
	
	private NotificationText notificationText;
	
	private Parameter parameter;
	
	private Tokenizer token;
	
	private ResponseBuilder<MainAgreementTypeWrapper> builder;
	
	private Person person;
	
	private static final Logger logger = LoggerFactory.getLogger(AgreementTypesWrapperServiceImpl.class);
	
	private Map<Integer, String> statusCodesMap;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);

		person = new Person();
		person.setBPKENN("BPKENNTEST");
		person.setPersonUID(1L);

		parameter = new Parameter();
		parameter.setBpkenn("BPKENNTEST");

		token = new Tokenizer();
		token.setUserId("test");
		token.setError(false);

		notificationConfigAgreement = new NotificationConfigAgreement();
		notificationConfigAgreement.setActive(true);
		notificationConfigAgreement.setAgreementUID(1L);
		notificationConfigAgreement.setEmailUID(1L);
		notificationConfigAgreement.setInformationChannelUID(1L);
		notificationConfigAgreement.setNotifConfigAgreementUID(1L);
		notificationConfigAgreement.setNotificationTextUID(1L);

		notificationConfigAgreementWrapper = new NotificationConfigAgreementWrapper();
		notificationConfigAgreementWrapper.setAgreement("test");
		notificationConfigAgreementWrapper.setTextType("test");
		notificationConfigAgreementWrapper.setType("Type");
		notificationConfigAgreementWrapper.setNotificationConfigAgreement(notificationConfigAgreement);

		notificationConfigAgreementWrapperList.add(notificationConfigAgreementWrapper);

		notificationText = new NotificationText();
		notificationText.setText("notif text test");
		notificationText.setEventType("KTO");
		notificationText.setNotificationTextType("test");

		agreement = new Agreement();
		agreement.setAgreementUID(1L);
		agreement.setAgreementID("1");
		agreement.setBranch(100);
		agreement.setAgreementType("KTO");
		agreement.setType("Type");
		agreement.setIban("test");

		agreementlist = new ArrayList<Agreement>();
		agreementlist.add(agreement);

		agreementTypesWrapper = new AgreementTypesWrapper();
		agreementTypesWrapper.setAgreementType("KTO");
		agreementTypesWrapper.setAgreements(notificationConfigAgreementWrapperList);

		agreementTypesWrapperList.add(agreementTypesWrapper);

		allNotificationConfig = new AllNotificationConfig();
		allNotificationConfig.setAllNotificationConfigUID(1L);
		allNotificationConfig.setEmailUID(1L);
		allNotificationConfig.setInformationChannelUID(1L);

		email = new Email();
		email.setEmailAddress("test email address");
		email.setEmailUID(1L);
		email.setPersonUID(1L);

		emailList.add(email);

		informationChannel = new InformationChannel();
		informationChannel.setInformationChannelType("test");
		informationChannel.setInformationChannelUID(1L);

		informationChannelList = new ArrayList<InformationChannel>();
		informationChannelList.add(informationChannel);

		notificationConfigPerson = new NotificationConfigPerson();
		notificationConfigPerson.setActive(false);
		notificationConfigPerson.setEmailUID(1L);
		notificationConfigPerson.setInformationChannelUID(1L);
		notificationConfigPerson.setNotifConfigPersonUID(1L);
		notificationConfigPerson.setNotificationTextUID(1L);

		notifConfigPersonWrapper = new NotifConfigPersonWrapper();
		notifConfigPersonWrapper.setTextType("test");
		notifConfigPersonWrapper.setNotificationConfigPerson(notificationConfigPerson);

		personConfigWrapper = new PersonConfigWrapper();
		personConfigWrapper.setAgreementType("PER");
		personConfigWrapper.setPersonAgreement(notifConfigPersonWrapper);

		mainAgreementTypeWrapper = new MainAgreementTypeWrapper();
		mainAgreementTypeWrapper.setAgreementTypes(agreementTypesWrapperList);
		mainAgreementTypeWrapper.setAllNotificationConfig(allNotificationConfig);
		mainAgreementTypeWrapper.setEmail(emailList);
		mainAgreementTypeWrapper.setInformationChannel(informationChannelList);
		mainAgreementTypeWrapper.setPersonConfigType(personConfigWrapper);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<MainAgreementTypeWrapper>(logger, token, globalResponseWrapper);
	}

	@Test
	public void getMainAgreementTypeWrapperList_Successful__KTO_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(informationChannelList);
		when(allNotificationConfigDAO.findByPersonUID(anyLong())).thenReturn(allNotificationConfig);

		when(agreementDAO.getAgreementList(anyLong())).thenReturn(agreementlist);
		when(notificationConfigAgreementDAO.getNotifConfigAgreement(1L)).thenReturn(notificationConfigAgreement);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(notificationText);

		when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
		when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(notificationConfigAgreement);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(notificationText);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);

		when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);

		assertEquals(builder.OK(mainAgreementTypeWrapper).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}
	
	@Test
	public void getMainAgreementTypeWrapperList_Successful__Non_KTO_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(informationChannelList);
		when(allNotificationConfigDAO.findByPersonUID(anyLong())).thenReturn(allNotificationConfig);

		when(agreementDAO.getAgreementList(anyLong())).thenReturn(agreementlist);
		when(notificationConfigAgreementDAO.getNotifConfigAgreement(1L)).thenReturn(notificationConfigAgreement);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(notificationText);

		when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
		when(notificationConfigAgreementDAO.getNotifConfigAgreement(anyLong())).thenReturn(notificationConfigAgreement);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(notificationText);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);

		when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);

		assertEquals(builder.OK(mainAgreementTypeWrapper).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_SuccessPersonNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(null);
		mainAgreementTypeWrapper = new MainAgreementTypeWrapper();

		assertEquals(builder.OK(mainAgreementTypeWrapper, Response.SUCCESS_NO_PERSON_FOUND).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_ErrorEmailListNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(null);

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_ErrorInforChannelListNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(null);

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_ErrorAllNotifConfigNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(null);
		when(allNotificationConfigDAO.findByPersonUID(anyLong())).thenReturn(null);

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_ErrorAgreementTypesListNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(informationChannelList);
		when(allNotificationConfigDAO.findByPersonUID(anyLong())).thenReturn(allNotificationConfig);

		when(agreementDAO.getAgreementList(anyLong())).thenReturn(agreementlist);
		when(notificationConfigAgreementDAO.getNotifConfigAgreement(1L)).thenReturn(notificationConfigAgreement);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(null);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(null);

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_ErrorPersonAgreementTypeWrapperListNull_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenReturn(person);
		when(emailDAO.getEmailList(anyLong())).thenReturn(emailList);
		when(informationChannelDAO.getInformationChannelList()).thenReturn(informationChannelList);
		when(allNotificationConfigDAO.findByPersonUID(anyLong())).thenReturn(allNotificationConfig);

		when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
		when(notificationTextDAO.findOne(anyLong())).thenReturn(notificationText);
		when(notificationTextDAO.getNotifText(anyString(), anyLong())).thenReturn(notificationText);

		notificationConfigPerson.setNotificationTextUID(null);
		when(notificationTextDAO.findOne(notificationConfigPerson.getNotificationTextUID())).thenReturn(null);

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_DataAccessException_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenThrow(new DataRetrievalFailureException("test"));

		assertEquals(builder.notOK(Response.DATA_ACCESS_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_NullPointerException_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenThrow(new NullPointerException("test"));

		assertEquals(builder.notOK(Response.NULL_POINTER_EXCEPTION).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

	@Test
	public void getMainAgreementTypeWrapperList_Exception_Test() throws Exception {

		when(personDAO.getPerson(anyString())).thenThrow(new Exception("test"));

		assertEquals(builder.notOK(Response.GENERAL_FUNCTION_ERROR).toString(),
				this.agreementTypesWrapperServiceImpl.getMainAgreementTypeWrapperList(token, parameter).toString());
	}

}
