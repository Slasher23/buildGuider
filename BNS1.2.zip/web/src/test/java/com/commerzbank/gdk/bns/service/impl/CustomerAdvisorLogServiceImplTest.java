/**
 * 
 *
 */
package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.CustomerAdvisorLog;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for CustomerAdvisorLogServiceImpl
 * 
 * @author ZE2MACL
 * @since 10/01/2018
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/01/2018	     1.00       ZE2MACL    Initial Version
 *          </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerAdvisorLogServiceImplTest {

    @InjectMocks
    private CustomerAdvisorLogServiceImpl customerAdvisorLogServiceImpl;

    @Mock
    private AgreementDAO agreementDAO;

    @Mock
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Mock
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Mock
    private EmailDAO emailDAO;

    private AuditLog auditLog;

    private Tokenizer token;

    private CustomerAdvisorLog customerAdvisorLog;

    private Agreement agreement;

    private NotificationConfigAgreement notificationConfigAgreement;

    private NotificationConfigPerson notificationConfigPerson;

    private Email email;

    @Before
    public void init() {

    }

    @Test
    public void getAgreementToggle_Succesfull_Test() {
        token = new Tokenizer();
        token.setCobaActivityID("comsciID_test");

        agreement = new Agreement();
        agreement.setAgreementUID(1L);
        agreement.setAgreementID("agreementID_test");

        notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setEmailUID(1L);

        email = new Email();
        email.setEmailAddress("test@test.com");

        auditLog = new AuditLog();
        auditLog.setBpkenn("test");
        auditLog.setEventType("1002");
        auditLog.setNewValue("true");
        auditLog.setObjectID("1");

        customerAdvisorLog = new CustomerAdvisorLog();
        customerAdvisorLog.setBpkenn(auditLog.getBpkenn());
        customerAdvisorLog.setAgreementID(agreement.getAgreementID());
        customerAdvisorLog.setCustomerEmail(email.getEmailAddress());
        customerAdvisorLog.setAgreementActive(auditLog.getNewValue());
        customerAdvisorLog.setCustomerAdvisorsWindowsID(token.getCobaActivityID());

        when(agreementDAO.findByAgreementUID(anyLong())).thenReturn(agreement);
        when(notificationConfigAgreementDAO.findByAgreementUID(anyLong())).thenReturn(notificationConfigAgreement);
        when(emailDAO.findByEmailUID(anyLong())).thenReturn(email);

        assertEquals(customerAdvisorLog.toString(), customerAdvisorLogServiceImpl.saveLog(token, auditLog).toString());

    }

    @Test
    public void getPersonToggle_Succesfull_Test() {
        String personAgreemnt = "Person";
        token = new Tokenizer();
        token.setCobaActivityID("comsciID_test");

        notificationConfigPerson = new NotificationConfigPerson();
        notificationConfigPerson.setEmailUID(1L);

        email = new Email();
        email.setEmailUID(1L);
        email.setEmailAddress("test@test.com");

        auditLog = new AuditLog();
        auditLog.setBpkenn("test");
        auditLog.setEventType("1008");
        auditLog.setNewValue("true");
        auditLog.setObjectID("1");
        auditLog.setUserID("1");

        customerAdvisorLog = new CustomerAdvisorLog();
        customerAdvisorLog.setBpkenn(auditLog.getBpkenn());
        customerAdvisorLog.setAgreementID(personAgreemnt);
        customerAdvisorLog.setCustomerEmail(email.getEmailAddress());
        customerAdvisorLog.setAgreementActive(auditLog.getNewValue());
        customerAdvisorLog.setCustomerAdvisorsWindowsID(token.getCobaActivityID());

        when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
        when(emailDAO.findByEmailUID(anyLong())).thenReturn(email);

        assertEquals(customerAdvisorLog.toString(), customerAdvisorLogServiceImpl.saveLog(token, auditLog).toString());

    }

    @Test
    public void getAgreementChangeEmail_Succesfull_Test() {
        String active = "true";
        token = new Tokenizer();
        token.setCobaActivityID("comsciID_test");

        agreement = new Agreement();
        agreement.setAgreementUID(1L);
        agreement.setAgreementID("agreementID_test");

        notificationConfigAgreement = new NotificationConfigAgreement();
        notificationConfigAgreement.setEmailUID(1L);

        email = new Email();
        email.setEmailAddress("test@test.com");

        auditLog = new AuditLog();
        auditLog.setBpkenn("test");
        auditLog.setEventType("1003");
        auditLog.setNewValue("true");
        auditLog.setObjectID("1");

        customerAdvisorLog = new CustomerAdvisorLog();
        customerAdvisorLog.setBpkenn(auditLog.getBpkenn());
        customerAdvisorLog.setAgreementID(agreement.getAgreementID());
        customerAdvisorLog.setCustomerEmail(email.getEmailAddress());
        customerAdvisorLog.setAgreementActive(active);
        customerAdvisorLog.setCustomerAdvisorsWindowsID(token.getCobaActivityID());

        when(agreementDAO.findByAgreementUID(anyLong())).thenReturn(agreement);
        when(notificationConfigAgreementDAO.findByAgreementUID(anyLong())).thenReturn(notificationConfigAgreement);
        when(emailDAO.findByEmailUID(anyLong())).thenReturn(email);

        assertEquals(customerAdvisorLog.toString(), customerAdvisorLogServiceImpl.saveLog(token, auditLog).toString());

    }

    @Test
    public void getPersonChangeEmail_Succesfull_Test() {
        String active = "true";
        String personAgreemnt = "Person";
        token = new Tokenizer();
        token.setCobaActivityID("comsciID_test");

        notificationConfigPerson = new NotificationConfigPerson();
        notificationConfigPerson.setEmailUID(1L);

        email = new Email();
        email.setEmailUID(1L);
        email.setEmailAddress("test@test.com");

        auditLog = new AuditLog();
        auditLog.setBpkenn("test");
        auditLog.setEventType("1010");
        auditLog.setNewValue("true");
        auditLog.setObjectID("1");
        auditLog.setUserID("1");

        customerAdvisorLog = new CustomerAdvisorLog();
        customerAdvisorLog.setBpkenn(auditLog.getBpkenn());
        customerAdvisorLog.setAgreementID(personAgreemnt);
        customerAdvisorLog.setCustomerEmail(email.getEmailAddress());
        customerAdvisorLog.setAgreementActive(active);
        customerAdvisorLog.setCustomerAdvisorsWindowsID(token.getCobaActivityID());

        when(notificationConfigPersonDAO.findByPersonUID(anyLong())).thenReturn(notificationConfigPerson);
        when(emailDAO.findByEmailUID(anyLong())).thenReturn(email);

        assertEquals(customerAdvisorLog.toString(), customerAdvisorLogServiceImpl.saveLog(token, auditLog).toString());

    }

}
