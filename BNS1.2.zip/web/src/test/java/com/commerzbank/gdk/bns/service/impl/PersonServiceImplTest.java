/**
 * 
 *
 */
package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * JUnit for PersonServiceImpl test
 * 
 * @author 	ZE2MACL
 * @since 	15/11/2017
 * @version 1.00
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 15/11/2017	     1.00       ZE2MACL    Initial Version
 * 29/11/2017        1.01       ZE2MORA    Implemented Status Codes update
 * </pre>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
public class PersonServiceImplTest {
	
	@Autowired
	private GlobalResponseWrapper globalRWrapper;
    
	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
    
    @Mock
    private PersonDAO personDAO;
    
    @InjectMocks
    private PersonServiceImpl personServiceImpl;
    
    private Person person;
    
    private Tokenizer token;
    
    private ResponseBuilder<Person> builder;
    
    private static final Logger logger = LoggerFactory.getLogger(PersonServiceImpl.class);

    private Map<Integer, String> statusCodesMap;
   
    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        
        token = new Tokenizer();
        token.setUserId("test");
        token.setError(false);
        
		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<Person>(logger, token, globalRWrapper);
        
    }
    
    @Test
    public void getPerson_Success_Test() throws Exception{
        
        person = new Person();
        person.setBPKENN("BPKENNTEST");
        String bpkenn = "BPKENNTEST";

        builder.OK(person);
        
        when(personDAO.getPerson(anyString())).thenReturn(person);
        assertEquals(builder.toString(), this.personServiceImpl.getPerson(token, bpkenn).toString());

    }

    @Test
    public void getPerson_SuccessNoResult_Test() throws Exception{
        
        person = new Person();
        person.setBPKENN("BPKENNTEST");
        String bpkenn = "BPKENNTEST";

        builder.OK(null, Response.SUCCESS_NO_RESULTS_FOUND);
        
        when(personDAO.getPerson(anyString())).thenReturn(null);
        assertEquals(builder.toString(), this.personServiceImpl.getPerson(token, bpkenn).toString());

    }
    
    @Test
    public void getPerson_DataAccessException_Test() throws Exception{
        
        person = new Person();
        person.setBPKENN("BPKENNTEST");
        String bpkenn = "BPKENNTEST";

        builder.OK(Response.DATA_ACCESS_EXCEPTION);
        
        when(personDAO.getPerson(anyString())).thenThrow(new DataRetrievalFailureException("test"));
        assertEquals(builder.toString(), this.personServiceImpl.getPerson(token, bpkenn).toString());

    }
    
    @Test
    public void getPerson_NullPointerException_Test() throws Exception{
        
        person = new Person();
        person.setBPKENN("BPKENNTEST");
        String bpkenn = "BPKENNTEST";

        builder.OK(Response.NULL_POINTER_EXCEPTION);
        
        when(personDAO.getPerson(anyString())).thenThrow(new NullPointerException("test"));
        assertEquals(builder.toString(), this.personServiceImpl.getPerson(token, bpkenn).toString());

    }
    
    @Test
    public void getPerson_GeneralException_Test() throws Exception{
        
        person = new Person();
        person.setBPKENN("BPKENNTEST");
        String bpkenn = "BPKENNTEST";

        builder.OK(Response.GENERAL_FUNCTION_ERROR);
        
        when(personDAO.getPerson(anyString())).thenThrow(new RuntimeException());
        assertEquals(builder.toString(), this.personServiceImpl.getPerson(token, bpkenn).toString());

    }

}
