package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.Agreements;
import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.service.ChangeConfigurationService;

/**
 * JUnit test class for Change Configuration Controller.
 * 
 * @author ZE2BAUL
 * @since 26/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/12/2017	     1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@EnableWebMvc
public class ChangeConfigurationControllerTest {

    MockMvc mockMvc;

    @Mock
    private ChangeConfigurationService changeConfigurationService;

    @InjectMocks
    private ChangeConfigurationController changeConfigurationController;

    private ChangeConfigurationRequest changeConfigRequest;
    private Agreements agreements;
    private List<Agreements> agreementsList;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(changeConfigurationController).build();

        agreements = new Agreements();
        agreements.setActive(true);
        agreements.setSparte(100);
        agreements.setVereinbarungskennung("DE72938910231");

        agreementsList = new ArrayList<Agreements>();
        agreementsList.add(agreements);

        changeConfigRequest = new ChangeConfigurationRequest();
        changeConfigRequest.setBpkenn("BPKENN");
        changeConfigRequest.setActive(true);
        changeConfigRequest.setAgreements(agreementsList);

    }

    @Test
    public void requestForChangeConfiguration_JSON_Test() throws Exception {
        this.mockMvc.perform(post("/api/zsl/requestForChangeConfiguration")
                        .content(Parser.asJsonString(changeConfigRequest)).contentType(MediaType.APPLICATION_JSON))
                        .andExpect(status().isOk());
    }

    @Test
    public void requestForChangeConfiguration_XML_Test() throws Exception {
        this.mockMvc.perform(post("/api/zsl/requestForChangeConfiguration")
                        .content(Parser.xmlConverter(changeConfigRequest))
                        .contentType(MediaType.APPLICATION_XML)).andExpect(status().isOk());
    }

}
