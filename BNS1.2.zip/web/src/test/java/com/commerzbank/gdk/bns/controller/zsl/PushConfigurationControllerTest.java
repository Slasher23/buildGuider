package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.service.PushConfigurationService;

/**
 * JUnit test class for Push Configuration Controller
 * 
 * @since 27/10/2017
 * @author ZE2BUEN
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 27/10/2017      1.00      ZE2BUEN    Initial Version
 * </pre>
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@EnableWebMvc
public class PushConfigurationControllerTest {

	MockMvc mockMvc;
	@Mock
	private PushConfigurationService pushConfigurationService;
	
	@InjectMocks
	private PushConfigurationController pushConfigurationController;
	
	private PushConfigurationRequest pushConfiguration;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(pushConfigurationController).build();
		
		pushConfiguration = new PushConfigurationRequest();
		pushConfiguration.setActivate(true);
		pushConfiguration.setAppName("App Name Test");
		pushConfiguration.setAppVersion("App Version Test");
		pushConfiguration.setAppId("12345");
		pushConfiguration.setBpkenn("test");
		pushConfiguration.setDeviceId("12345");
	}
	
	@Test
	public void requestForPushConfiguration_JSON_Test() throws Exception {
		
		mockMvc.perform(post("/api/zsl/requestForPushConfiguration").contentType(MediaType.APPLICATION_JSON)
			.content(Parser.asJsonString(pushConfiguration)))
			.andExpect(status().isOk());
	}
	
	@Test
	public void requestForPushConfiguration_XML_Test() throws Exception {
		
		mockMvc.perform(post("/api/zsl/requestForPushConfiguration").contentType(MediaType.APPLICATION_XML)
            .content(Parser.xmlConverter(pushConfiguration)))
			.andExpect(status().isOk());
	}
	
}
