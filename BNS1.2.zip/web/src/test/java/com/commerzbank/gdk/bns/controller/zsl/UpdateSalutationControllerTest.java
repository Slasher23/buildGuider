package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequest;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.UpdateSalutationService;

/**
 * JUnit test class for UpdateSalutationController
 * 
 * @since 29/11/2017
 * @author ZE2JAVO
 * @version 1.01
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 29/11/2017      1.00      ZE2JAVO    Initial Version
 * 29/11/2017      1.01      ZE2SARO    Add junit for batch update
 *          </pre>
 * 
 */
@EnableWebMvc
public class UpdateSalutationControllerTest {

    MockMvc                            mockMvc;

    @Mock
    private UpdateSalutationService    updateSalutationService;

    @InjectMocks
    private UpdateSalutationController updaSalutationController;

    private ZslUpdateResponse          zslUpdateResponse;

    private UpdateSalutationRequests   request = new UpdateSalutationRequests();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(updaSalutationController).build();

        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST1");
        zslUpdateResponse.setStatus("OK- Successful");

        List<UpdateSalutationRequest> listSalutationRequest = new ArrayList<UpdateSalutationRequest>();
        UpdateSalutationRequest salutationRequest = new UpdateSalutationRequest();
        salutationRequest.setBpkenn("TEST");
        salutationRequest.setSalutation("Mr");
        salutationRequest.setTitle("TEST");
        listSalutationRequest.add(salutationRequest);
        request.setUpdateSalutationRequest(listSalutationRequest);
    }

    @Test
    public void requestUpdateSalutation_JSON_TEST() throws Exception {
        mockMvc.perform(post("/api/zsl/requestForUpdateSalutation").contentType(MediaType.APPLICATION_JSON)
                .content(Parser.asJsonString(zslUpdateResponse))).andExpect(status().isOk());
    }

    @Test
    public void requestUpdateSalutation_XML_TEST() throws Exception {
        mockMvc.perform(post("/api/zsl/requestForUpdateSalutation").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(zslUpdateResponse))).andExpect(status().isOk());
    }

    @Test
    public void batchUpdateSalutation_Json_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdateSalutation").contentType(MediaType.APPLICATION_JSON)
                .content(Parser.asJsonString(request))).andExpect(status().isOk());

    }

    @Test
    public void batchUpdateSalutation_Xml_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchUpdateSalutation").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(request))).andExpect(status().isOk());

    }

}
