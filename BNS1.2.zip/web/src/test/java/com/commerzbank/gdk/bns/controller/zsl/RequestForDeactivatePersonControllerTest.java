package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.RequestForBatchDeactivatePerson;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForDeactivatePersonService;

/**
 * <description>
 * 
 * @author ZE2GOME
 * @since 28/11/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForDeactivatePersonControllerTest {

    private MockMvc                              mockMvc;

    @Mock
    private RequestForDeactivatePersonService    requestForDeactivatePersonService;

    @InjectMocks
    private RequestForDeactivatePersonController controller;

    private ZslUpdateResponse                    zslUpdateResponse;

    private Parameter                            param;

    private List<Parameter>                      paramList;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();

        zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("BPKENNTEST");
        zslUpdateResponse.setStatus("OK- Successful");

        param = new Parameter();
        param.setBpkenn("BPKENNTEST");

        paramList = new ArrayList<Parameter>();
        paramList.add(param);
    }

    @Test
    public void requestForDeactivatePerson_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForDeactivatePerson").content(Parser.asJsonString(param))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

    }

    @Test
    public void requestForDeativatePerson_XML_Test() throws Exception {
        this.mockMvc
                .perform(post("/api/zsl/requestForDeactivatePerson")
                        .content(Parser.jaxbObjectToXML(param, Parameter.class)).contentType(MediaType.APPLICATION_XML))
                .andExpect(status().isOk());
    }

    @Test
    public void requestForBatchDeactivatePerson_JSON_Test() throws Exception {
        RequestForBatchDeactivatePerson batchRequest = new RequestForBatchDeactivatePerson();
        batchRequest.setDeactivatePersonRequest(paramList);
        this.mockMvc.perform(post("/api/zsl/requestForBatchDeactivatePerson").content(Parser.asJsonString(batchRequest))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

    }

    @Test
    public void requestForBatchDeativatePerson_XML_Test() throws Exception {
        RequestForBatchDeactivatePerson batchRequest = new RequestForBatchDeactivatePerson();
        batchRequest.setDeactivatePersonRequest(paramList);
        this.mockMvc.perform(post("/api/zsl/requestForBatchDeactivatePerson").content(Parser.xmlConverter(batchRequest))
                .contentType(MediaType.APPLICATION_XML)).andExpect(status().isOk());
    }

}
