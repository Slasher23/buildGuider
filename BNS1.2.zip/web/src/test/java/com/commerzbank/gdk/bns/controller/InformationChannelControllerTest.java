package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.InformationChannelService;

/**
 * JUnit test for Informational Channel Controller
 * 
 * @author ZE2MACL
 * @since 13/11/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017	     1.00       ZE2MACL    Initial Version
 * 29/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class InformationChannelControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private InformationChannelService informationChannelService;

	@InjectMocks
	private InformationChannelController informationChannelController;

	private MockMvc mockMvc;

	private InformationChannel informationChannel;

	private List<InformationChannel> informationChannelList = new ArrayList<InformationChannel>();

	private Tokenizer token;

	private ResponseBuilder<List<InformationChannel>> builder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(InformationChannelController.class);

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(informationChannelController).build();

		informationChannel = new InformationChannel();
		informationChannel.setInformationChannelType("test");
		informationChannel.setInformationChannelUID(1L);

		informationChannelList.add(informationChannel);

		token = new Tokenizer();
		token.setUserId("test");
		token.setProcessRunID("test123");
		token.setError(false);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<List<InformationChannel>>(logger, token, globalRWrapper);

	}

	@Test
	public void getInformationChannelList_JSONReponseCode_Test() throws Exception {

		when(informationChannelService.getInformationChannelList(any(Tokenizer.class)))
				.thenReturn(builder.OK(informationChannelList));

		mockMvc.perform(
				post("/api/infoChannels").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());

	}

	@Test
	public void getInformationChannelList_JSON_Test() throws Exception {

		when(informationChannelService.getInformationChannelList(any(Tokenizer.class)))
				.thenReturn(builder.OK(informationChannelList));

		mockMvc.perform(
				post("/api/infoChannels").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());

	}

}
