package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.CustomerDAO;
import com.commerzbank.gdk.bns.dao.DailyReportLogDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.NotificationService;

/**
 * JUnit test class for CustomerNotificationServiceImpl
 * 
 * @since 20/11/2017
 * @author ZE2GOME
 * @version 1.01
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2GOME    Initial Version
 * 14/12/2017      1.01      ZE2BUEN    Refactor/ clean up for ZSL status messages
 * </pre>
 */
public class CustomerNotificationServiceImplTest {

    @Mock
    private PersonDAO personDAO;

    @Mock
    private CustomerDAO customerDAO;

    @Mock
    private NotificationService notifService;
    
    @Mock
    private Environment environment;

    @Mock
    private DailyReportLogDAO dailyReportLogDAO;
    
    @InjectMocks
    private CustomerNotificationServiceImpl custNotifServiceImplMock;

    private List<Customer> listCustomer = new ArrayList<Customer>();
    private Customer customer = new Customer();
    private Person person = new Person();
    private NotificationRequest notifRequest = new NotificationRequest();

    private static final String SUCCESS_MESS = "OK- Successful";
    private static final String KUNDE_NOT_EXIST_MESS = "FA- Kundennumber does not exist in BNS";
    private static final String INVALID_REQ_MESS = "FA- Invalid Request";
    private static final String NOTIFICATION_ERR_MESS = "FA- No valid Customer Notification";
    private static final String STATUS_OK = "ZSL_STATUS_OK";
    private static final String STATUS_FA_KUNDE_NOT_EXISTS = "ZSL_STATUS_FA_KUNDE_NOT_EXISTS";
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_NO_VALID_CUSTOMER_NOTIF = "ZSL_STATUS_FA_NO_VALID_CUSTOMER_NOTIF";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        customer.setCustomerUID(1L);
        customer.setPersonUID(1L);
        customer.setLongTermCustomerNumber("test");
        listCustomer.add(customer);

        person.setBPKENN("12345");
        person.setPersonUID(1L);
        person.setGivenName("test");
        person.setSalutation("01");
        person.setTitle("01");

        notifRequest.setBpkenn("12345");
    }

    @Test
    public void getResponse_Success_Test() throws Exception {

        CustomerNotificationRequest request = new CustomerNotificationRequest();
        request.setKundennummer("test");
        request.setSparte(0);
        request.setVereinbarungskennung("test");

        customer.setCustomerNumber(request.getKundennummer());
        notifRequest.setSparte(request.getSparte());
        notifRequest.setVereinbarungskennung(request.getVereinbarungskennung());

        NotificationResponse response = new NotificationResponse();
        response.setBPKENN("12345");
        response.setNotification(Arrays.asList(new Notifications()));
        response.setStatus(SUCCESS_MESS);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn(SUCCESS_MESS);
        when(this.customerDAO.findByCustomerNumber(request.getKundennummer())).thenReturn(listCustomer);
        when(this.personDAO.findOne(1L)).thenReturn(person);
        when(this.notifService.sendNotification(any(NotificationRequest.class))).thenReturn(response);

        List<NotificationResponse> listResponse = new ArrayList<NotificationResponse>();
        listResponse.add(response);

        CustomerNotificationsResponse customerNotificationsResponse = new CustomerNotificationsResponse();
        customerNotificationsResponse.setKundennummer(request.getKundennummer());
        customerNotificationsResponse.setCustomerNotifications(listResponse);
        customerNotificationsResponse.setStatus(SUCCESS_MESS);

        assertEquals(this.custNotifServiceImplMock.getResponse(request).toString(),
                customerNotificationsResponse.toString());
    }

    @Test
    public void getResponse_KundennumberNullEmpty_Test() throws Exception {

        CustomerNotificationRequest request = new CustomerNotificationRequest();
        List<NotificationResponse> listResponse = new ArrayList<NotificationResponse>();
        NotificationResponse response = new NotificationResponse();
        CustomerNotificationsResponse customerNotificationsResponse = new CustomerNotificationsResponse();

        request.setKundennummer("");
        request.setSparte(0);
        request.setVereinbarungskennung("test");

        when(this.notifService.sendNotification(any(NotificationRequest.class))).thenReturn(response);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn(INVALID_REQ_MESS);
        
        customerNotificationsResponse.setKundennummer(request.getKundennummer());
        customerNotificationsResponse.setCustomerNotifications(listResponse);
        customerNotificationsResponse.setStatus(INVALID_REQ_MESS);
        
        assertEquals(this.custNotifServiceImplMock.getResponse(request).toString(),
                customerNotificationsResponse.toString());

    }
    
    @Test
    public void getResponse_KundennumberNotExist_Test() throws Exception {

        CustomerNotificationRequest request = new CustomerNotificationRequest();
        List<NotificationResponse> listResponse = new ArrayList<NotificationResponse>();
        NotificationResponse response = new NotificationResponse();
        CustomerNotificationsResponse customerNotificationsResponse = new CustomerNotificationsResponse();

        request.setKundennummer("test");
        request.setSparte(0);
        request.setVereinbarungskennung("test");

        when(this.notifService.sendNotification(any(NotificationRequest.class))).thenReturn(response);
        
        when(this.environment.getProperty(STATUS_FA_KUNDE_NOT_EXISTS)).thenReturn(KUNDE_NOT_EXIST_MESS);

        customerNotificationsResponse.setKundennummer(request.getKundennummer());
        customerNotificationsResponse.setCustomerNotifications(listResponse);
        customerNotificationsResponse.setStatus(KUNDE_NOT_EXIST_MESS);

        assertEquals(this.custNotifServiceImplMock.getResponse(request).toString(),
                customerNotificationsResponse.toString());

    }
    
    @Test
    public void getResponse_NoValidNotification_Test() throws Exception {

        CustomerNotificationRequest request = new CustomerNotificationRequest();
        request.setKundennummer("test");
        request.setSparte(0);
        request.setVereinbarungskennung("test");

        customer.setCustomerNumber(request.getKundennummer());
        notifRequest.setSparte(request.getSparte());
        notifRequest.setVereinbarungskennung(request.getVereinbarungskennung());

        NotificationResponse response = new NotificationResponse();
        response.setBPKENN("12345");
        response.setNotification(Arrays.asList(new Notifications()));
        response.setStatus(INVALID_REQ_MESS);

        when(this.environment.getProperty(any(String.class))).thenReturn(SUCCESS_MESS);
        when(this.customerDAO.findByCustomerNumber(request.getKundennummer())).thenReturn(listCustomer);
        when(this.personDAO.findOne(1L)).thenReturn(person);
        when(this.notifService.sendNotification(any(NotificationRequest.class))).thenReturn(response);

        List<NotificationResponse> listResponse = new ArrayList<NotificationResponse>();
        listResponse.add(response);
        
        when(this.environment.getProperty(STATUS_FA_NO_VALID_CUSTOMER_NOTIF)).thenReturn(NOTIFICATION_ERR_MESS);

        CustomerNotificationsResponse customerNotificationsResponse = new CustomerNotificationsResponse();
        customerNotificationsResponse.setKundennummer(request.getKundennummer());
        customerNotificationsResponse.setCustomerNotifications(listResponse);
        customerNotificationsResponse.setStatus(NOTIFICATION_ERR_MESS);
        
        assertEquals(this.custNotifServiceImplMock.getResponse(request).toString(),
                customerNotificationsResponse.toString());
    }

}
