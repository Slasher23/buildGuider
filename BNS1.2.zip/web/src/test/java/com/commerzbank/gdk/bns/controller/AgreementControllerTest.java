package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementService;

/**
 * JUnit Test Class for AgreementController
 * 
 * @author ZE2MACL
 * @since 10/11/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017        1.00       ZE2MACl    Initial Version
 * 13/11/2017        1.01       ZE2MACl    Updated method to used response builder and added token parameter
 * 29/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class AgreementControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;

	@Mock
	private AgreementService agreementService;

	@InjectMocks
	private AgreementController agreementController;

	private MockMvc mockMvc;

	private Agreement agreement;

	private List<Agreement> agreementList;

	private Parameter parameter;

	private Tokenizer token;

	private ResponseBuilder<List<Agreement>> builder;

	private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(AgreementController.class);

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(agreementController).build();

		parameter = new Parameter();
		parameter.setBpkenn("test");

		agreement = new Agreement();
		agreement.setAgreementUID(1L);
		agreement.setAgreementID("test");
		agreement.setAgreementType("test");
		agreement.setBranch(100);
		agreement.setType("test");

		agreementList = new ArrayList<Agreement>();
		agreementList.add(agreement);

		token = new Tokenizer();
		token.setUserId("test");
		token.setError(false);

		statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
		builder = new ResponseBuilder<List<Agreement>>(logger, token, globalRWrapper);

	}

	@Test
	public void postAgreement_JSONResponseCode_Test() throws Exception {

		when(agreementService.getAgreementList(any(Tokenizer.class), any(Parameter.class)))
				.thenReturn(builder.OK(agreementList));

		mockMvc.perform(post("/api/agreements").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
				.andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());
	}

	@Test
	public void postAgreement_JSON_Test() throws Exception {

		when(agreementService.getAgreementList(any(Tokenizer.class), any(Parameter.class)))
				.thenReturn(builder.OK(agreementList));

		mockMvc.perform(post("/api/agreements").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

}
