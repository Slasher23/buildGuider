package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchUpdateSalutationResponse;
import com.commerzbank.gdk.bns.model.BatchZslUpdateResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequest;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * JUnit test class for Change Email Address Service Impl.
 * 
 * @since 29/11/2017
 * @author ZE2JAVO
 * @version 1.02
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 29/11/2017      1.00      ZE2JAVO    Initial Version
 * 29/11/2017      1.01      ZE2SARO    Add junit for batch update
 * 04/12/2017      1.02      ZE2MACL    Change batch response model
 * 14/12/2017      1.03      ZE2BUEN    Refactor/Clean-up of ZSL Status Messages
 * </pre>
 */
@EnableWebMvc
public class UpdateSalutationServiceImplTest {

    @Mock
    private PersonDAO                     personDAO;
    
    @Mock
    private Environment                   environment;
        
    @InjectMocks
    private UpdateSalutationServiceImpl   updateSalutationServiceImpl;
      
    private UpdateSalutationRequest       request;
    private Person                        person;
    private ZslUpdateResponse             response;
    private UpdateSalutationRequests      batchRequest              = new UpdateSalutationRequests();
    private List<UpdateSalutationRequest> listSalutationRequest     = new ArrayList<UpdateSalutationRequest>();
    
    private static final String STATUS_OK = "ZSL_STATUS_OK";
	private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_FA_BPKENN_NOT_EXISTS = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
	private static final String STATUS_FA_FAILED_SALUTATION = "ZSL_STATUS_FA_FAILED_SALUTATION";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        person = new Person();
        person.setBPKENN("BPKENNTEST");
        person.setGivenName("GIVEN NAME TEST");
        person.setLastName("LAST NAME TEST");
        person.setPersonUID(1L);
        person.setSalutation("01");
        person.setTitle("01");

        UpdateSalutationRequest salutationRequest = new UpdateSalutationRequest();
        UpdateSalutationRequest salutationRequest1 = new UpdateSalutationRequest();
        salutationRequest.setBpkenn("TEST");
        salutationRequest.setSalutation("02");
        salutationRequest.setTitle("02");
        listSalutationRequest.add(salutationRequest);
        salutationRequest1.setBpkenn("");
        salutationRequest1.setSalutation("02");
        salutationRequest1.setTitle("02");
        listSalutationRequest.add(salutationRequest1);
        batchRequest.setUpdateSalutationRequest(listSalutationRequest);
    }

    @Test
    public void requestUpdateSalutation_OK_Successful_A_Test() throws Exception {
        request = new UpdateSalutationRequest();
        request.setBpkenn("BPKENNTEST");
        request.setSalutation("03");
        request.setTitle("03");

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");
        
        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        
        assertEquals(response.toString(), this.updateSalutationServiceImpl.requestUpdateSalutation(request).toString());
    }

    @Test
    public void requestUpdateSalutation_OK_Successful_B_Test() throws Exception {
        request = new UpdateSalutationRequest();
        request.setBpkenn("BPKENNTEST");
        request.setSalutation(null);
        request.setTitle(null);

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST");
        response.setStatus("OK- Successful");

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        
        assertEquals(response.toString(), this.updateSalutationServiceImpl.requestUpdateSalutation(request).toString());
    }

    @Test
    public void requestUpdateSalutation_BPKENN_NOT_EXISTS_Test() throws Exception {
        request = new UpdateSalutationRequest();
        request.setBpkenn("BPKENNTEST3");
        request.setSalutation("03");
        request.setTitle("03");

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENNTEST3");
        response.setStatus("FA- BPKENN does not exists in BNS");

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(null);
        
        when(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS)).thenReturn("FA- BPKENN does not exists in BNS");
        
        assertEquals(response.toString(), this.updateSalutationServiceImpl.requestUpdateSalutation(request).toString());
    }

    @Test
    public void requestUpdateSalutation_INVALID_REQUEST_Test() throws Exception {
        request = new UpdateSalutationRequest();
        request.setBpkenn(null);
        request.setSalutation("03");
        request.setTitle("03");

        response = new ZslUpdateResponse();
        response.setBpkenn(null);
        response.setStatus("FA- Invalid Request");

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");
        
        assertEquals(response.toString(), this.updateSalutationServiceImpl.requestUpdateSalutation(request).toString());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void requestUpdateSalutation_Exception_Test() throws Exception {
        request = new UpdateSalutationRequest();
        request.setBpkenn("BPKENTEST");
        request.setSalutation("03");
        request.setTitle("03");

        response = new ZslUpdateResponse();
        response.setBpkenn("BPKENTEST");
        response.setStatus("FA- Request for Update Salutation not processed");

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenThrow(Exception.class);
        
        when(this.environment.getProperty(STATUS_FA_FAILED_SALUTATION)).thenReturn("FA- Request for Update Salutation not processed");
        
        assertEquals(response.toString(), this.updateSalutationServiceImpl.requestUpdateSalutation(request).toString());
    }

    @Test
    public void batchUpdateSalutation_Test() throws Exception {

        
        BatchUpdateSalutationResponse response = new BatchUpdateSalutationResponse();
        List<ZslUpdateResponse> listNoErrors = new ArrayList<ZslUpdateResponse>();
        List<ZslUpdateResponse> listWithErrors = new ArrayList<ZslUpdateResponse>();
        ZslUpdateResponse noError = new ZslUpdateResponse();
        ZslUpdateResponse withError = new ZslUpdateResponse();
        noError.setBpkenn("TEST");
        noError.setStatus("OK- Successful");
        withError.setBpkenn("");
        withError.setStatus("FA- Invalid Request");
        listNoErrors.add(noError);
        listWithErrors.add(withError);
        response.setUpdateSalutationResponse(listNoErrors);
        response.setUpdateSalutationResponseWithErrors(listWithErrors);

        when(this.personDAO.findByBpkennIgnoreCase(any(String.class))).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_OK)).thenReturn("OK- Successful");
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");
        
        assertEquals(response.toString(),
                this.updateSalutationServiceImpl.requestUpdateSalutation(batchRequest).toString());

    }

}
