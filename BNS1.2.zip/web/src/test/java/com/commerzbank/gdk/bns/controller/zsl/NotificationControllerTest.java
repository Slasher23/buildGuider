package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.controller.zsl.NotificationController;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.RequestForBatchNotification;
import com.commerzbank.gdk.bns.service.BatchNotificationService;
import com.commerzbank.gdk.bns.service.NotificationService;

/**
 * JUnit test class for Notification controller
 * 
 * @author ZE2GOME
 * @since 13/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017        1.00       ZE2GOME    Initial Version
 * 29/11/2017        1.01       ZE2BAUL    Code clean up
 *          </pre>
 */

@RunWith(MockitoJUnitRunner.class)
public class NotificationControllerTest {

    @Mock
    private NotificationService      notificationService;

    @Mock
    private BatchNotificationService batchNorificationService;

    @InjectMocks
    private NotificationController   notificationController;

    private MockMvc                  mockMvc;

    private NotificationRequest      notificationRequest  = new NotificationRequest();

    private NotificationResponse     notificationResponse = new NotificationResponse();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(notificationController).build();

        notificationRequest.setBpkenn("BPKENNTEST");
        notificationRequest.setSparte(100);
        notificationRequest.setVereinbarungskennung("agreementTest");

        Notifications notif = new Notifications();
        notif.setNotificationPath("email@test.com");
        notif.setNotificationSubject("Test");
        notif.setNotificationText("Test");
        notif.setNotificationType("Test");

        List<Notifications> notifList = new ArrayList<Notifications>();
        notifList.add(notif);

        notificationResponse.setBPKENN("BPKENNTEST");
        notificationResponse.setNotification(notifList);

    }

    @Test
    public void requestForNotification_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForNotification").content(Parser.asJsonString(notificationRequest))
                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
    }

    @Test
    public void requestForNotification_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForNotification")
                .content(Parser.jaxbObjectToXML(notificationRequest, NotificationRequest.class))
                .contentType(MediaType.APPLICATION_XML)).andExpect(status().isOk());
    }

    @Test
    public void requestForBatchNotification_JSON_Test() throws Exception {
        RequestForBatchNotification batchRequest = new RequestForBatchNotification();
        List<NotificationRequest> notificationRequestList = new ArrayList<NotificationRequest>();
        notificationRequestList.add(notificationRequest);
        batchRequest.setNotificationRequest(notificationRequestList);

        this.mockMvc
                .perform(post("/api/zsl/requestForBatchNotification")
                        .content(Parser.asJsonString(batchRequest)).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void requestForBatchNotification_XML_Test() throws Exception {
        RequestForBatchNotification batchRequest = new RequestForBatchNotification();
        List<NotificationRequest> notificationRequestList = new ArrayList<NotificationRequest>();
        notificationRequestList.add(notificationRequest);
        batchRequest.setNotificationRequest(notificationRequestList);

        this.mockMvc.perform(post("/api/zsl/requestForBatchNotification").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(batchRequest))).andExpect(status().isOk());

    }

}
