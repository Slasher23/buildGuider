package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.controller.zsl.ChangeEmailAddressController;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressBatchService;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressService;

/**
 * JUnit test class for Change Email Address Controller
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.00
 *
 * <pre>
 * Modified Date   Version   Author     Description
 * 08/11/2017      1.00      ZE2BUEN    Initial Version
 * </pre>
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@EnableWebMvc
public class ChangeEmailAddressControllerTest {

	MockMvc mockMvc;
	@Mock
	private ChangeEmailAddressService changeEmailAddressService;
	
	@Mock
	private ChangeEmailAddressBatchService changeEmailAddressBatchService;
	
	@InjectMocks
	private ChangeEmailAddressController changeEmailAddressController;
	
	private ChangeEmailAddressRequest changeEmailAddressRequest;
	
	private ChangeEmailAddressRequest changeEmailAddressRequest1;
	
	private ChangeEmailAddressRequest changeEmailAddressRequest2;
	
	private ChangeEmailAddressBatchRequest changeEmailAddressBatchRequest;
	
	private List<ChangeEmailAddressRequest> changeEmailAddressRequestList;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(changeEmailAddressController).build();
		
		changeEmailAddressRequest = new ChangeEmailAddressRequest();
		changeEmailAddressRequest.setAddressId(1L);
		changeEmailAddressRequest.setBpkenn("BPKENNTEST");
		changeEmailAddressRequest.setChangeEventType("CreateAddressEvent");
		changeEmailAddressRequest.setEmailAddress("new_email@coba.com");
		
		changeEmailAddressRequest1 = new ChangeEmailAddressRequest();
		changeEmailAddressRequest1.setAddressId(2L);
		changeEmailAddressRequest1.setBpkenn("BPKENNTEST1");
		changeEmailAddressRequest1.setChangeEventType("UpdateAddressEvent");
		changeEmailAddressRequest1.setEmailAddress("update_email@coba.com");
		
		changeEmailAddressRequest2 = new ChangeEmailAddressRequest();
		changeEmailAddressRequest2.setAddressId(3L);
		changeEmailAddressRequest2.setBpkenn("BPKENNTEST1");
		changeEmailAddressRequest2.setChangeEventType("DeleteAddressEvent");
		changeEmailAddressRequest2.setEmailAddress("delete_email@coba.com");
		
		changeEmailAddressRequestList = new ArrayList<ChangeEmailAddressRequest>();
		changeEmailAddressRequestList.add(changeEmailAddressRequest1);
		changeEmailAddressRequestList.add(changeEmailAddressRequest2);
		
		changeEmailAddressBatchRequest = new ChangeEmailAddressBatchRequest();
		changeEmailAddressBatchRequest.setChangeEmailAddressRequest(changeEmailAddressRequestList);
		
	}
	
	@Test
	public void requestForChangeEmailAddress_JSON_Test() throws Exception {
		
		this.mockMvc.perform(post("/api/zsl/requestForChangeEmailAddress")
                .contentType(MediaType.APPLICATION_JSON).content(Parser.asJsonString(changeEmailAddressRequest)))
                .andExpect(status().isOk());

	}
	
	@Test
	public void requestForChangeEmailAddress_XML_Test() throws Exception {
		
		  this.mockMvc.perform(post("/api/zsl/requestForChangeEmailAddress").contentType(MediaType.APPLICATION_XML)
	                .content(Parser.xmlConverter(changeEmailAddressRequest))).andExpect(status().isOk());
		  
	}
	
	@Test
	public void requestForBatchChangeEmailAddress_JSON_Test() throws Exception {
		
		this.mockMvc.perform(post("/api/zsl/requestForBatchChangeEmailAddress")
                .contentType(MediaType.APPLICATION_JSON).content(Parser.asJsonString(changeEmailAddressBatchRequest)))
                .andExpect(status().isOk());
		
	}
	
	@Test
	public void requestForBatchChangeEmailAddress_XML_Test() throws Exception {
		
		this.mockMvc.perform(post("/api/zsl/requestForBatchChangeEmailAddress").contentType(MediaType.APPLICATION_XML)
                .content(Parser.xmlConverter(changeEmailAddressBatchRequest))).andExpect(status().isOk());
		
	}
	
}
