package com.commerzbank.gdk.bns.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.EmailService;

/**
 * JUnit test class for Email controller
 * 
 * @author ZE2MACL
 * @since 13/11/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 13/11/2017	     1.00       ZE2MACL    Initial Version
 * 27/11/2017        1.01       ZE2CRUH    Updated Email Address Model
 * 29/11/2017        1.02       ZE2BAUL    Implemented Status Codes update
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class EmailControllerTest {

	@Autowired
	private GlobalResponseWrapper globalRWrapper;

	@Mock
	private GlobalResponseWrapper globalResponseWrapper;
	
    @Mock
    private EmailService emailService;

    @InjectMocks
    private EmailController emailController;

    private MockMvc mockMvc;

    private Tokenizer token;

    private ResponseBuilder<List<Email>> builder;

    private Parameter parameter;

    private Email email;

    private List<Email> emailList = new ArrayList<Email>();
    
    private Map<Integer, String> statusCodesMap;

	private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(emailController).build();

        token = new Tokenizer();
        token.setUserId("test");
        token.setProcessRunID("test123");
        token.setError(false);

        parameter = new Parameter();
        parameter.setBpkenn("bpkenntest");

        email = new Email();
        email.setEmailAddress("TestAddress");
        email.setEmailUID(1L);
        email.setPersonUID(1L);

        emailList.add(email);
        
        statusCodesMap = this.globalRWrapper.getStatusCodesMap();
		when(this.globalResponseWrapper.getStatusCodesMap()).thenReturn(statusCodesMap);
        builder = new ResponseBuilder<List<Email>>(logger, token, globalRWrapper);

    }

    @Test
    public void getEmailList_JSONResponseCode_Test() throws Exception {

        when(emailService.getEmailList(any(Tokenizer.class), anyString())).thenReturn(builder.OK(emailList));

        mockMvc.perform(post("/api/person/emails").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(jsonPath("$.code", is(1001))).andExpect(status().isOk());
    }

    @Test
    public void getEmailList_JSON_Test() throws Exception {

        when(emailService.getEmailList(any(Tokenizer.class), anyString())).thenReturn(builder.OK(emailList));

        mockMvc.perform(post("/api/person/emails").contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON).content(Parser.asJsonString(parameter)))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
    }

}
