package com.commerzbank.gdk.bns.controller;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementConfig;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchResponse;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.model.ContactList;
import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsRequest;
import com.commerzbank.gdk.bns.model.CustomerBatchNotificationsResponse;
import com.commerzbank.gdk.bns.model.CustomerInfoWrapper;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.ErrorMessage;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotifConfigPersonWrapper;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.Notification;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationMatrixChannel;
import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonConfig;
import com.commerzbank.gdk.bns.model.PersonConfigWrapper;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;
import com.commerzbank.gdk.bns.model.RequiredNotificationResponseWithErrors;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.ResponseMessage;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.model.Trigger;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.Version;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thoughtworks.xstream.XStream;

/**
 * 
 * Converts Input JSON or XML format to String
 * 
 * @since 10/02/2017
 * @author ZE2CRUH
 * @version 1.03
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 10/02/2017      1.00      ZE2CRUH    Initial Version
 * 13/11/2017      1.01      ZE2SARO    Add converter for object to xml using xstream
 * 27/11/2017      1.02      ZE2CRUH    Removed Participant Number and Required Notification Response
 * 26/12/2017      1.03      ZE2BAUL    Added ChangeConfiguration class in the xmlConverter
 *          </pre>
 */
public class Parser {

    /**
     * Converts an input JSON to String
     * 
     * @param jsonObj input JSON
     * @return String
     */
    public static String asJsonString(final Object jsonObj) {
        try {
            return new ObjectMapper().writeValueAsString(jsonObj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Converts an input XML to String
     * 
     * @param xmlObj input XML
     * @param classObject Object class of the input XML
     * @return String
     */
    public static String jaxbObjectToXML(final Object xmlObj, Class<?> classObject) {
        String xmlString = "";

        try {
            JAXBContext context = JAXBContext.newInstance(classObject);
            Marshaller m = context.createMarshaller();

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            m.marshal(xmlObj, sw);
            xmlString = sw.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return xmlString;
    }

    /**
     * Convert object to xml using xstream
     * 
     * @param objectClass
     * @return converted object
     */
    public static String xmlConverter(Object objectClass) {

        XStream xstream = new XStream();
        
        xstream.alias("Agreement", Agreement.class);
        xstream.alias("notificationConfigAgreement", AgreementConfig.class);
        xstream.alias("agreementTypes", AgreementTypesWrapper.class);
        xstream.alias("AllNotificationConfig", AllNotificationConfig.class);
        xstream.alias("auditLog", AuditLog.class);
        xstream.alias("ContactList", ContactList.class);
        xstream.alias("KUNDE", Customer.class);
        xstream.alias("CustomerBatchNotificationsRequest", CustomerBatchNotificationsRequest.class);
        xstream.alias("CustomerBatchNotificationsResponse", CustomerBatchNotificationsResponse.class);
        xstream.alias("customer", CustomerInfoWrapper.class);
        xstream.alias("CustomerNotificationRequest", CustomerNotificationRequest.class);
        xstream.alias("CustomerNotificationsResponse", CustomerNotificationsResponse.class);
        xstream.alias("CustomNotifConfig", CustomNotifConfig.class);
        xstream.alias("EMAIL", Email.class);
        xstream.alias("ErrorMessage", ErrorMessage.class);
        xstream.alias("EventType", EventType.class);
        xstream.alias("GlobalEventTypeWrapper", GlobalEventTypeWrapper.class);
        xstream.alias("GlobalResponseWrapper", GlobalResponseWrapper.class);
        xstream.alias("INFORMATIONS_KANAL", InformationChannel.class);
        xstream.alias("MainAgreementTypeWrapper", MainAgreementTypeWrapper.class);
        xstream.alias("agreements", NotifConfigPersonWrapper.class);
        xstream.alias("BENACHRICHTIGUNG", Notification.class);
        xstream.alias("NotificationConfigAgreement", NotificationConfigAgreement.class);
        xstream.alias("agreements", NotificationConfigAgreementWrapper.class);
        xstream.alias("NotificationConfigPerson", NotificationConfigPerson.class);
        xstream.alias("NotificationMatrixChannel", NotificationMatrixChannel.class);
        xstream.alias("NotificationMatrixResponse", NotificationMatrixResponse.class);
        xstream.alias("NotificationRequest", NotificationRequest.class);
        xstream.alias("NotificationResponse", NotificationResponse.class);
        xstream.alias("Notifications", Notifications.class);
        xstream.alias("BENACHRICHTIGUNGS_TEXT", NotificationText.class);
        xstream.alias("notifTextAndAgreementConfigWrapper", NotifTextAgreementConfigWrapper.class);
        xstream.alias("notifTextAndPersonConfigWrapper", NotifTextPersonConfigWrapper.class);
        xstream.alias("Parameter", Parameter.class);
        xstream.alias("PERSON", Person.class);
        xstream.alias("notificationConfigPerson", PersonConfig.class);
        xstream.alias("personConfigType", PersonConfigWrapper.class);
        xstream.alias("PUSH_KONFIG", PushConfiguration.class);
        xstream.alias("PushConfigurationRequest", PushConfigurationRequest.class);
        xstream.alias("PushConfigurationResponse", PushConfigurationResponse.class);
        xstream.alias("RequiredBatchNotificationResponseWrapper", RequiredBatchNotificationResponseWrapper.class);
        xstream.alias("RequiredNotificationRequest", RequiredNotificationRequest.class);
        xstream.alias("RequiredNotificationResponseWithErrors", RequiredNotificationResponseWithErrors.class);
        xstream.alias("Response", Response.class);
        xstream.alias("ResponseBuilder", ResponseBuilder.class);
        xstream.alias("ResponseMessage", ResponseMessage.class);
        xstream.alias("Settings", Settings.class);
        xstream.alias("Tokenizer", Tokenizer.class);
        xstream.alias("AUSLOSER", Trigger.class);
        xstream.alias("auditLog", AuditLog.class);
        xstream.alias("Version", Version.class);
        xstream.alias("ZslUpdateResponse", ZslUpdateResponse.class);
        xstream.alias("ChangeEmailAddressRequest", ChangeEmailAddressRequest.class);
        xstream.alias("ChangeEmailAddressResponse", ChangeEmailAddressResponse.class);
        xstream.alias("ChangeEmailAddressBatchRequest", ChangeEmailAddressBatchRequest.class);
        xstream.alias("ChangeEmailAddressBatchResponse", ChangeEmailAddressBatchResponse.class);
        xstream.alias("UpdateSalutationRequests", UpdateSalutationRequests.class);
        xstream.alias("ChangeConfigurationRequest", ChangeConfigurationRequest.class);
        return xstream.toXML(objectClass);
    }
}
