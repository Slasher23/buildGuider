package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.AgreementNotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.Notifications;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.service.RequestForAgreementNotificationService;

/**
 * JUnit test for RequestForAgreementNotificationController.
 * 
 * @author ZE2GOME
 * @since 12/2/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2JAVO    Added test unit for batch
 * 14/12/2017        1.02       ZE2MENY    Remove response for customerNotification
 *          </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForAgreementNotificationControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RequestForAgreementNotificationService requestForAgreementNotificationService;

    @InjectMocks
    private RequestForAgreementNotificationController controller;

    private AgreementNotificationRequest agreementNotificationRequest;

    private RequestForRequiredBatchNotification agreementNotificationRequestList;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        List<Notifications> notification = new ArrayList<Notifications>();

        Notifications notif = new Notifications();
        notif.setNotificationPath("test");
        notif.setNotificationSubject("test");
        notif.setNotificationText("test");
        notif.setNotificationType("test");

        notification.add(notif);

        NotificationResponse notifResponse = new NotificationResponse();
        notifResponse.setBPKENN("Test");
        notifResponse.setStatus("OK");
        notifResponse.setNotification(notification);

        List<NotificationResponse> customerNotifications = new ArrayList<NotificationResponse>();
        customerNotifications.add(notifResponse);

        agreementNotificationRequest = new AgreementNotificationRequest();
        agreementNotificationRequest.setSparte(1);
        agreementNotificationRequest.setVereinbarungskennung("test");

        agreementNotificationRequestList = new RequestForRequiredBatchNotification();

    }

    @Test
    public void requestForAgreementNotification_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForAgreementNotification")
                .content(Parser.asJsonString(agreementNotificationRequest)).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void requestForDeativatePerson_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForAgreementNotification")
                .content(Parser.xmlConverter(agreementNotificationRequest)).contentType(MediaType.APPLICATION_XML))
                .andExpect(status().isOk());
    }

    @Test
    public void requestForBatchAgreementNotification_JSON_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchAgreementNotification")
                .content(Parser.asJsonString(agreementNotificationRequestList)).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void requestForBatchDeativatePerson_XML_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForBatchAgreementNotification")
                .content(Parser.xmlConverter(agreementNotificationRequestList)).contentType(MediaType.APPLICATION_XML))
                .andExpect(status().isOk());
    }

}
