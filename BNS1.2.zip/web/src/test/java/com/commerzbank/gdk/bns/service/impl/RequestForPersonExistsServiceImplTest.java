package com.commerzbank.gdk.bns.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.BatchPersonExistsRequest;
import com.commerzbank.gdk.bns.model.BatchPersonExistsResponse;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonExistsRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForPersonExistsService;

/**
 * JUnit test class for Request For Person Exists Service Implementation
 * 
 * @author ZE2MENY
 * @since 7/12/2017
 * @version 1.03
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 7/12/2017         1.00       ZE2MENY    Initial Version
 * 11/12/2017        1.01       ZE2MENY    Implementation of BatchProcessing
 * 14/12/2017        1.02       ZE2BUEN    Refactor/clean up for status messages
 * </pre>
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestForPersonExistsServiceImplTest {

    @Mock
    RequestForPersonExistsService requestForPersonExistsServiceMock;

    @Mock
    PersonDAO personDAO;
    
    @Mock
    Environment environment;

    @InjectMocks
    RequestForPersonExistsServiceImpl requestForPersonExistsServiceImpl;
    
    private static final String STATUS_FA_INVALID_REQUEST = "ZSL_STATUS_FA_INVALID_REQUEST";
	private static final String STATUS_TRUE = "ZSL_STATUS_TRUE";
	private static final String STATUS_FALSE = "ZSL_STATUS_FALSE";

    private PersonExistsRequest request;

    private Person person;

    PersonExistsRequest personExistsrequest = new PersonExistsRequest();

    ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();

    private List<PersonExistsRequest> requestList = new ArrayList<PersonExistsRequest>();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        request = new PersonExistsRequest();
        request.setBpkenn("12345");

        requestList = new ArrayList<PersonExistsRequest>();
        requestList.add(request);

        person = new Person();
        person.setBPKENN("12345");
        person.setGivenName("Joy");
        person.setLastName("Mendoza");
        person.setPersonUID(1L);
        person.setSalutation("01");
        person.setTitle("01");

    }

    @Test
    public void getResponseSuccessful_Test() throws Exception {

        ZslUpdateResponse responseExpected = new ZslUpdateResponse();
        responseExpected.setBpkenn("12345");
        responseExpected.setStatus("TRUE");

        when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_TRUE)).thenReturn("TRUE");

        ZslUpdateResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(this.request);

        assertEquals(response.toString(), responseExpected.toString());

    }

    @Test
    public void getResponseBPKENNDOesNOTExist_Test() throws Exception {

        ZslUpdateResponse responseExpected = new ZslUpdateResponse();
        responseExpected.setBpkenn("12345");
        responseExpected.setStatus("FALSE");

        when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(person);
        
        when(this.environment.getProperty(STATUS_FALSE)).thenReturn("FALSE");
        
        ZslUpdateResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(this.request);

        assertEquals(response.toString(), responseExpected.toString());

    }

    @Test
    public void requestForUpdatePerson_Null_Invalid_Request() throws Exception {
        ZslUpdateResponse responseExpected = new ZslUpdateResponse();
        responseExpected.setStatus("FA- Invalid Request");

        request.setBpkenn(null);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        ZslUpdateResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(this.request);

        assertEquals(response.toString(), responseExpected.toString());

    }

    @Test
    public void RequestForBatchPersonExists_Test() throws Exception {

        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("12345");
        zslUpdateResponse.setStatus("FALSE");

        request.setBpkenn("12345");
        requestList = new ArrayList<PersonExistsRequest>();
        requestList.add(request);
        BatchPersonExistsResponse batchPersonExistsResponse = new BatchPersonExistsResponse();
        when(this.personDAO.findByBpkennIgnoreCase("test")).thenReturn(this.person);

        List<ZslUpdateResponse> personExistsResponse = new ArrayList<ZslUpdateResponse>();
        
        when(this.environment.getProperty(STATUS_FALSE)).thenReturn("FALSE");

        personExistsResponse.add(zslUpdateResponse);

        batchPersonExistsResponse.setPersonExistsResponse(personExistsResponse);
        when(this.requestForPersonExistsServiceMock.requestForPersonExistsResponse(request))
                .thenReturn(zslUpdateResponse);
        BatchPersonExistsRequest request = new BatchPersonExistsRequest();
        request.setPersonExistsRequest(requestList);
        BatchPersonExistsResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(request);

        assertEquals(personExistsResponse.toString(), response.getPersonExistsResponse().toString());
    }

    @Test
    public void RequestForBatchPersonExists_WithError_Test() throws Exception {

        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("");
        zslUpdateResponse.setStatus("FA- Invalid Request");

        request.setBpkenn("");

        requestList = new ArrayList<PersonExistsRequest>();
        requestList.add(request);
        BatchPersonExistsResponse batchPersonExistsResponse = new BatchPersonExistsResponse();
        when(this.personDAO.findByBpkennIgnoreCase("")).thenReturn(this.person);
        
        when(this.environment.getProperty(STATUS_FA_INVALID_REQUEST)).thenReturn("FA- Invalid Request");

        List<ZslUpdateResponse> personExistsResponseWithErrors = new ArrayList<ZslUpdateResponse>();
        personExistsResponseWithErrors.add(zslUpdateResponse);
        
        batchPersonExistsResponse.setPersonExistsResponseWithErrors(personExistsResponseWithErrors);
        when(this.requestForPersonExistsServiceMock.requestForPersonExistsResponse(request))
                .thenReturn(zslUpdateResponse);

        BatchPersonExistsRequest request = new BatchPersonExistsRequest();
        request.setPersonExistsRequest(requestList);
        BatchPersonExistsResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(request);

        assertEquals(personExistsResponseWithErrors.toString(),
                response.getPersonExistsResponseWithErrors().toString());
    }

    @Test
    public void RequestForBatchPersonExists_TRUE_Test() throws Exception {

        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
        zslUpdateResponse.setBpkenn("12345");
        zslUpdateResponse.setStatus("TRUE");

        request.setBpkenn("12345");
        requestList = new ArrayList<PersonExistsRequest>();
        requestList.add(request);
        
        when(this.environment.getProperty(STATUS_TRUE)).thenReturn("TRUE");

        BatchPersonExistsResponse batchPersonExistsResponse = new BatchPersonExistsResponse();
        when(this.personDAO.findByBpkennIgnoreCase("12345")).thenReturn(this.person);

        List<ZslUpdateResponse> personExistsResponse = new ArrayList<ZslUpdateResponse>();
        personExistsResponse.add(zslUpdateResponse);

        batchPersonExistsResponse.setPersonExistsResponse(personExistsResponse);
        when(this.requestForPersonExistsServiceMock.requestForPersonExistsResponse(request))
                .thenReturn(zslUpdateResponse);

        BatchPersonExistsRequest request = new BatchPersonExistsRequest();
        request.setPersonExistsRequest(requestList);
        BatchPersonExistsResponse response = this.requestForPersonExistsServiceImpl
                .requestForPersonExistsResponse(request);

        assertEquals(personExistsResponse.toString(), response.getPersonExistsResponse().toString());
    }
}
