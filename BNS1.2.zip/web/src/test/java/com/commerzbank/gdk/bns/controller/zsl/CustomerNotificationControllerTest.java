package com.commerzbank.gdk.bns.controller.zsl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.controller.Parser;
import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.service.CustomerNotificationService;

/**
 * JUnit test class for CustomerNotificationController 
 * 
 * @since 20/11/2017
 * @author ZE2GOME
 * @version 1.00
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 20/11/2017      1.00      ZE2GOME    Initial Version
 *          </pre>
 */

@EnableWebMvc
public class CustomerNotificationControllerTest {

    private MockMvc mockMvc;

    private CustomerNotificationRequest request = new CustomerNotificationRequest();

    @Mock
    private CustomerNotificationService custNotifServiceMock;
    
    @InjectMocks
    private CustomerNotificationController custNotifControllerMock;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(custNotifControllerMock).build();
        
        request.setKundennummer("test");
        request.setSparte(000);
        request.setVereinbarungskennung("test");
    }

    @Test
    public void requestForCustomerNotif_Json_Test() throws Exception {

        this.mockMvc.perform(post("/api/zsl/requestForCustomerNotification").contentType(MediaType.APPLICATION_JSON)
                .content(Parser.asJsonString(request))).andExpect(status().isOk());

    }
    
    @Test
    public void requestForCustomerNotif_Xml_Test() throws Exception {
        
        this.mockMvc.perform(post("/api/zsl/requestForCustomerNotification").contentType(MediaType.APPLICATION_XML)
                .content(Parser.jaxbObjectToXML(request, CustomerNotificationRequest.class))).andExpect(status().isOk());

    }

}
