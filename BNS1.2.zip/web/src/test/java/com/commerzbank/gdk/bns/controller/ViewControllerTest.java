package com.commerzbank.gdk.bns.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.DatabackpackService;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * Junit for Person Controller
 * 
 * @author ZE2RUBI
 * @since 19/01/2018
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 19/01/2018	     1.00       ZE2RUBI    Initial Version
 *          </pre>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:configuration.xml" })
@WebAppConfiguration
@EnableWebMvc
public class ViewControllerTest {
    
    @Autowired
    private GlobalResponseWrapper globalRWrapper;

    @Mock
    private GlobalResponseWrapper globalResponseWrapper;
    
    @Mock
    private DatabackpackService databackpackServiceMock;

    @Mock
    private MockHttpServletRequest request;
    
    @InjectMocks
    private ViewController viewController;

    private MockMvc mockMvc;

    private Parameter parameter = new Parameter();

    private Tokenizer token;

    private Databackpack databackpack;
    
    private ResponseBuilder<Databackpack> builder;

    static String datbackpack64 = "";
    
    private static final Logger logger = LoggerFactory.getLogger(ViewController.class);
   
    static String data = "kdnr=8303078128;prodId=830307812821400,prodcat=Depots,prodname=KlassikDepot;prodId=830307812820100EU R,prodcat=Konten,prodname=0-Euro-Konto,iban=DE33850400000307812820;FALSE;firstname=Pbfjeeb,lastname=Peeeecabgbjefeb,title=,salutation=Herrn,emailadd=dkkmobiletankunde@commerzbank.com,addID=0000000000000001;";
    static String result = "LPLbCkoZCUo6oLF08V-rmTD5pm3oR46tc1iug-u5X9daelxaPNf6nxZCfwflTPdnmqsKs44amGuawBjO7w5XETnixnEpwr23yNqDRfJoctzatco1ujtPMostWhuZWUaigT-P_Qqm9bnO5vNwsRndcZSEk-Dj332FqMlahu7Aojsc8e-1 wimIUiptzRER58z5wJespN-lMYwPfsooH4DWiPdQ6j1Kw9egjn7TVKMikkwJBVLd-A-FDpXyQWaz14idWvnFrLrV-ipyy1uhpthA7LdWsbEE7Mn588Y5pKIgFv6l6qlxq_inKqgWZ56Q_RosBzdNPmyu__NHSt-tsGWdmi5Mo7UY4I2rC8-YdNzzMqG3apdCyNmtk1JBQeWIQMNp6yPeZ24SCNQR5uy3HTst8W8cCp7lSDGV77k5VDnIxzaw6sI3UghNXZZK";

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(viewController).build();
        parameter.setDatabackpack(result);
        
        Email email = new Email();
        email.setEmailAddress("dkkmobiletankunde@commerzbank.com");
        List<Email> listEmail = new ArrayList<>();
        listEmail.add(email);
        
        databackpack = new Databackpack();
        databackpack.setEmailList(listEmail);
        Tools tools = new Tools();
        
        try {
            datbackpack64 = tools.base64Encode(tools.jsonify(databackpack));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        builder = new ResponseBuilder<Databackpack>(logger, token, globalRWrapper);
    }

    @Test
    public void getDatabackpack_Success_Test() throws Exception {

        when(this.databackpackServiceMock.databackpackProcessor(any(Tokenizer.class), anyString())).thenReturn(builder.OK(databackpack));
             
        HttpHeaders h = new HttpHeaders();
        h.add("bpkenn", "BPKENNTEST01");

        
        MockHttpServletResponse response = this.mockMvc
                .perform(post("/register").contentType(MediaType.TEXT_HTML_VALUE)
                        .param("databackpack", parameter.getDatabackpack()).headers(h)).andReturn().getResponse();
       
        assertEquals(datbackpack64, response.getCookie("databackpack").getValue());
        assertEquals(URLEncoder.encode(result, "UTF-8"), response.getCookie("dbpToken").getValue());
        
    }
    
}
