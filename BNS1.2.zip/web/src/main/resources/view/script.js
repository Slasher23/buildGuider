const fs = require('fs');
const path = require('path');
const filePath = './../static/index.html';
const newFilePath = './../templates/index.html';
const windowScripts = '<script th:inline="javascript">window.bnsCif = [[${BNSCif}]];</script>';

fs.unlink(newFilePath, (err) => {

    if (err) {
        console.log(newFilePath + ' does not exist');
    }

    fs.readFile(filePath, 'utf8', (err, contents) => {

        if (err) {
            return console.log(err);
        }

        let result = contents.replace(/<link([^>]*)"\s?\/?>/g, '<link$1"></link>');
        result = result.replace('<body>', '<body>' + windowScripts);
        result = result.replace('/css/main', '/css/bns');

        fs.writeFile(newFilePath, result, 'utf8', err => {

            if (err) {
                return console.log(err);
            }

            console.log(newFilePath + ' written successfully');
        });

        fs.unlinkSync(filePath);
    });

});

var editAndRenameFile = function (fileToEdit, oldString, newString, oldFilename, newFilename) {
    fs.readFile(fileToEdit, 'utf8', (err, contents) => {
        
        if (err) {
            console.log('error reading');
            return console.log(err);
        }

        let result = contents.replace(new RegExp(oldString, 'g'), newString);

        fs.writeFile(fileToEdit, result, 'utf8', err => {

            if (err) {
                console.log('error writing');
                return console.log(err);
            }

            let newFile = fileToEdit.replace(oldFilename, newFilename);

            fs.rename(fileToEdit, newFile, function (err) {
                if (err) {
                    console.log('error renaming');
                    return console.log(err);
                }

                console.log(fileToEdit + ' processed successfully');
            });

        });

    });
}

var fileLooper = function (mypath) {
    fs.readdir(mypath, function (error, files) {
        if (error)
            console.log('error ' + error.code + ' : ' + error.message);
        else {
            files.map(function (file) {
                let filePath = mypath + file;

                if (filePath.indexOf('map') > -1) {
                    editAndRenameFile(filePath, '/css/main', '/css/bns', '/css/main', '/css/bns');
                } else {
                    editAndRenameFile(filePath, 'sourceMappingURL=main', 'sourceMappingURL=bns', '/css/main', '/css/bns');
                }
                
            });
        }
    })
}

fileLooper('./../static/static/css/');
editAndRenameFile('./../static/service-worker.js', '/css/main', '/css/bns');
editAndRenameFile('./../static/asset-manifest.json', '/css/main', '/css/bns');