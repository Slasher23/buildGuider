import React from 'react';
import createReactClass from 'create-react-class';

const instances = [];
const history = window.history;
const location = window.location;
const addEventListener = window.addEventListener;
const removeEventListener = window.removeEventListener;
const register = (comp) => instances.push(comp);
const unregister = (comp) => instances.splice(instances.indexOf(comp), 1);

export const historyPush = (path) => {
  history.pushState({}, null, path);
  instances.forEach(instance => instance.forceUpdate());
};

export const historyReplace = (path) => {
  history.replaceState({}, null, path);
  instances.forEach(instance => instance.forceUpdate());
};

const matchPath = (pathname, options) => {
  pathname = location.hash || pathname;
  const exact = options.exact || false;
  const path = options.path;

  if (!path) {
    return {
      path: null,
      url: pathname,
      isExact: true
    };
  }

  const match = new RegExp(`^${path}`).exec(pathname);

  if (!match) return null;

  const url = match[0];
  const isExact = pathname === url;

  if (exact && !isExact) return null;

  return {
    path,
    url,
    isExact,
  };
};

const renderMergedProps = (component, ...rest) => {
  const finalProps = Object.assign({}, ...rest);
  return React.createElement(component, finalProps);
};

export const Route = createReactClass({
  componentWillMount() {
    addEventListener('popstate', this.handlePop);
    register(this);
  },

  componentWillUnmount() {
    unregister(this);
    removeEventListener('popstate', this.handlePop);
  },

  handlePop() {
    this.forceUpdate();
  },

  render() {
    const {
      path,
      exact,
      component,
      render,
    } = this.props;

    const match = matchPath(location.pathname, { path, exact });

    if (!match) return null;

    if (component) return React.createElement(component, { match });

    if (render) return render({ match });

    return null;
  }
});

export const ExtendedRoute = ({ component, ...rest }) => {
  return (
    <Route {...rest} render={routeProps => {
      return renderMergedProps(component, routeProps, rest);
    } }/>
  );
};

export const Link = createReactClass({
  handleClick(event) {
    const {
      replace,
      to,
      onClick
    } = this.props;

    event.preventDefault();
    if (onClick) onClick(event);
    replace ? historyReplace(to) : historyPush(to);
  },

  render() {
    const {
      to,
      children,
      className,
      disabled
    } = this.props;

    return <a href={to} className={className} disabled={disabled} onClick={this.handleClick}>{children}</a>;
  }
});

export const Redirect = createReactClass({
  componentDidMount() {
    const {
      to,
      push
    } = this.props;

    push ? historyPush(to) : historyReplace(to);
  },

  render() {
    return null;
  }
});