import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class PersonConfigServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH;
  }

  postConfig(data) {
    return RestService.post(this.url + '/personConfig', data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const PersonConfigService = new PersonConfigServiceClass();

export default PersonConfigService;
