import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class AgreementConfigServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH;
  }

  postConfigList() {
    return RestService.post(this.url + '/agreementConfigList')
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }

  postConfig(data) {
    return RestService.post(this.url + '/agreementConfig', data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const AgreementConfigService = new AgreementConfigServiceClass();

export default AgreementConfigService;
