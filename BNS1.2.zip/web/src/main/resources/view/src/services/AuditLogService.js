import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class AuditLogServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH + '/auditLogs';
  }

  getLogById(UID) {
    const path = '/auditLog/' + UID;
    return RestService.get(path)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }

  postLog(data) {
    return RestService.post(this.url, data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const AuditLogService = new AuditLogServiceClass();

export default AuditLogService;
