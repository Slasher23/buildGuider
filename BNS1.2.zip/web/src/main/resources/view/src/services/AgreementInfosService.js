import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class AgreementInfosServiceClass {
  constructor(bpkenn) {
    this.url = ConfigConstants.API_PATH + '/agreementInfos';
    this._bpkenn = bpkenn;
  }

  get bpkenn() {
    return this._bpkenn;
  }

  set bpkenn(bpkenn) {
    this._bpkenn = bpkenn ? bpkenn : this._bpkenn;
  }

  getAgreementInfos() {
    const data = {
      bpkenn: this.bpkenn,
    };
    return RestService.post(this.url, data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const AgreementInfosService = new AgreementInfosServiceClass(ConfigConstants.DEFAULT_BPKENN);

export default AgreementInfosService;
