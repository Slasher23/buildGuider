import 'whatwg-fetch';

class RestServiceClass {
  isError(code) {
    return code >= 2000 && code < 4000;
  }

  _checkStatus(response) {
    if (response.ok) {
      return response;
    } else {
      const error = new Error(response.statusText);
      error.response = response;
      throw error;
    }
  }

  _parseJSON(response) {
    return response.json();
  }

  get(url) {
    const headers = new Headers({
      Accept: 'application/json',
      Pragma: 'no-cache',
      'Cache-Control': 'no-cache',
    });
    const options = {
      method: 'GET',
      headers: headers,
    };
    return fetch(url, options)
      .then(this._checkStatus)
      .then(this._parseJSON)
      .then(json => Promise.resolve(json))
      .catch(error => Promise.reject(error));
  }

  post(url, data) {
    const headers = new Headers({
      Accept: 'application/json',
      'Content-Type': 'application/json'
    });

    const options = {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(data),
      credentials: 'same-origin'
    };
    return fetch(url, options)
      .then(this._checkStatus)
      .then(this._parseJSON)
      .then(json => Promise.resolve(json))
      .catch(error => Promise.reject(error));
  }
}

const RestService = new RestServiceClass();

export default RestService;
