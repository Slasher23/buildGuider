import RestService from './RestService';
import { ConfigConstants } from '../constants/ConfigConstants';

class NotifTextServiceClass {
  constructor() {
    this.url = ConfigConstants.API_PATH + '/notifText';
  }

  getNotifText(eventType, eventId) {
    const data = {
      eventType: eventType,
      eventId: eventId,
    };
    return RestService.post(this.url, data)
      .then(response => {
        if (RestService.isError(response.code)) {
          return Promise.reject(response.data);
        } else {
          return Promise.resolve(response.data);
        }
      })
      .catch(error => Promise.reject(error));
  }
}

const NotifTextService = new NotifTextServiceClass();

export default NotifTextService;
