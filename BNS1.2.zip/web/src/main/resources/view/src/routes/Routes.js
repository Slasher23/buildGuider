import { UrlConstants } from './../constants/UrlConstants';
import NotifPage from './../pages/NotifPage';
import ErrorPage from './../pages/ErrorPage';

export const routes = [
    {
        path: UrlConstants.HOME_PAGE,
        exact: true,
        component: NotifPage
    },
    {
        path: UrlConstants.HOME_PAGE + 'index.html',
        exact: true,
        component: NotifPage
    },
    {
        path: UrlConstants.ERROR_PAGE,
        component: ErrorPage
    },
];
