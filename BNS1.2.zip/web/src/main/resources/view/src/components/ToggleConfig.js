import React, { Component } from 'react';
import NotifActions from '../actions/NotifActions';
import { HelperService } from '../services';
import Config from './Config';
import _ from 'lodash';

class ToggleConfig extends Component {
    constructor(props) {
        super(props);
        this.hideEncryptionText = this.hideEncryptionText.bind(this);
        this.determineIfCustomConfig = this.determineIfCustomConfig.bind(this);
        this.setStiftClass = this.setStiftClass.bind(this);
        this.setProductDescription = this.setProductDescription.bind(this);
        this.setProductDescriptionClass = this.setProductDescriptionClass.bind(this);
        this.setConfig = this.setConfig.bind(this);
        this._toggleClick = this._toggleClick.bind(this);
        this._configClick = this._configClick.bind(this);
    }

    componentDidMount() {
        this.hideEncryptionText();
    }

    componentDidUpdate() {
        this.hideEncryptionText();
    }

    hideEncryptionText() {
        const hide_encryption_info_text = document.getElementById('encryption-info-text');
        HelperService.addClass(hide_encryption_info_text, 'hidden');
    }

    determineIfCustomConfig() {
        let isCustomConfig = false;

        if (this.props.isCustomObj.textType !== 'STD') {
            isCustomConfig = true;
        }

        return isCustomConfig;
    }

    setStiftClass() {
        let stiftClass = "edit icon i-pencil pull-right";

        if (this.props.id === "allToggleConfig") {
            stiftClass += " f-09"
            this.props.emailList.length > 1 ? stiftClass += "" : stiftClass += " hide";
        } else {
            this.determineIfCustomConfig() ? stiftClass += " f-01" : stiftClass += " f-09";
            this.props.toggleStatus ? stiftClass += "" : stiftClass += " hide";
        }

        return stiftClass;
    }

    setProductDescription() {
        let productDescription = "";

        if (this.props.id !== "allToggleConfig") {
            let activeEmailAddressList = _.filter(this.props.emailList, ['emailUID', this.props.config.emailUID]);
            let activeEmailAddress = activeEmailAddressList.length > 0 ? activeEmailAddressList[0].emailAddress : "";
            let email = '<b>' + activeEmailAddress + '</b>';
            productDescription = HelperService.parseStr(this.props.staticTexts.subLabel_TextUnderneath, email);
        }

        return productDescription;
    }

    setProductDescriptionClass() {
        let productDescriptionClass = "description";
        this.props.toggleStatus ? productDescriptionClass += "" : productDescriptionClass += " hide";

        return productDescriptionClass;
    }

    setConfig() {
        let config = null;

        if (this.props.expandConfig) {
            let textType = this.props.isCustomObj ? this.props.isCustomObj.textType : null;
            config = (
                <Config
                    id={this.props.id + "config"}
                    config={this.props.config}
                    configObj={this.props.configObj}
                    emailList={this.props.emailList}
                    informationChannelList={this.props.informationChannelList}
                    textType={textType}
                    notificationText={this.props.notificationText}
                    staticTexts={this.props.staticTexts}
                    permissions={this.props.permissions}
                    />
            );
        }

        return config;
    }

    _toggleClick() {

        if (this.props.id === "allToggleConfig") {
            NotifActions.toggleAllNotif();
        } else {
            NotifActions.toggleAgreementNotif(this.props.configObj);
        }

    }

    _configClick() {

        if (this.props.id === "allToggleConfig") {
            NotifActions.clickAllConfig();
        } else {
            NotifActions.clickAgreementStiff(this.props.configObj);
        }

    }


    render() {
        let hideClass = this.props.hidden ? "hide" : "";
        let config = this.setConfig();

        return (
            <div className={hideClass}>
                <div className="group">
                    <div className="col-md-12">
                        <label className="switch pull-left">
                            <input
                                type="checkbox"
                                checked={this.props.toggleStatus}
                                onChange={this._toggleClick}
                                disabled={!this.props.permissions.enableToggle}
                                />
                            <span className="slider round" />
                        </label>
                        <span className="text-container pull-left">
                            <p className="text">{this.props.toggleText}</p>
                            <p className={this.setProductDescriptionClass() }
                                id={this.props.id + '-productDescription'}
                                dangerouslySetInnerHTML={{ __html: this.setProductDescription() }} />
                        </span>
                        <i className={this.setStiftClass() } aria-hidden="true" onClick={this._configClick} />
                    </div>
                    <div className="clearfix" />
                    {config}

                </div>

            </div >
        );
    }
}

export default ToggleConfig;
