import React, { Component } from 'react';
import NotifActions from '../actions/NotifActions';
import EmailRadio from './EmailRadio';
import { HelperService } from '../services';
import _ from 'lodash';

class Config extends Component {
    constructor(props) {
        super(props);
        this._onEmailChange = this._onEmailChange.bind(this);
        this._onFocus = this._onFocus.bind(this);
        this._onBlur = this._onBlur.bind(this);
        this._resetText = this._resetText.bind(this);
        this._textSize = this._textSize.bind(this);
        this._clearText = this._clearText.bind(this);
        this._cancel = this._cancel.bind(this);
        this._save = this._save.bind(this);
        this.standardText = this.props.staticTexts.subTextArea_DefaultText;
        this.initialText = this.getInitialText();
        this.textLimit = 500;

        this.state = {
            config: {
                initialConfig: {
                    emailUID: this.props.config.emailUID,
                    informationChannelUID: this.props.config.informationChannelUID,
                    text: this.initialText,
                },
                newConfig: {
                    emailUID: this.props.config.emailUID,
                    informationChannelUID: this.props.config.informationChannelUID,
                    text: this.initialText,
                },
            },
            remainingText: this.textLimit - this.initialText.length,
        };

        this.informationChannelKey = this.getInformationChannelKey();
        this.isAllConfig = this.props.id.indexOf('allToggleConfig') > -1 ? true : false;
    }

    componentDidMount() {
        this.hideEncryptionText();

        if (!this.isAllConfig) {
            const textAreaElement = document.getElementById(this.props.id + '-textarea');
            this.textareaHeight = textAreaElement.offsetHeight;
            this.resizeTextarea(textAreaElement);
        }

    }

    componentDidUpdate() {
        this.hideEncryptionText();
    }

    hideEncryptionText() {
        const hide_encryption_info_text = document.getElementById('encryption-info-text');
        HelperService.addClass(hide_encryption_info_text, 'hidden');
    }

    getInformationChannelText(informationChannelKey) {
        let informationChannelText = 'Per ';

        switch (informationChannelKey) {
            case 'EMAIL':
                informationChannelText += this.props.staticTexts.subLabel_InfoChannelEmail;
                break;

            default:
                informationChannelText = 'None';
        }

        return informationChannelText;
    }

    getInformationChannelKey() {
        let informationChannelArr = _.filter(this.props.informationChannelList, ['informationChannelUID', this.state.config.newConfig.informationChannelUID]);
        let informationChannel = informationChannelArr.length > 0 ? informationChannelArr[0].informationChannelType : '';

        return informationChannel;
    }

    getInitialText() {
        let text = null;

        if (this.props.textType === 'STD' || this.props.textType === null) {
            text = this.standardText;
        } else {
            text = this.props.notificationText.text;
        }

        return text;
    }

    setEmailList() {
        const emailList = [];

        if (this.props.emailList) {
            this.props.emailList.map((email, index) => {
                return emailList.push(
                    <EmailRadio
                        key={index}
                        index={index}
                        itemId={this.props.id}
                        email={email}
                        onChange={emailUID => this._onEmailChange(emailUID) }
                        isChecked={email.emailUID === this.state.config.newConfig.emailUID}
                        disabled={!this.props.permissions.enableEmailChange}
                        />
                );
            });
        }

        return emailList;
    }

    setTextArea() {
        let textArea;

        if (!this.isAllConfig) {
            textArea = (
                <div>
                    <label>{this.props.staticTexts.subHeading_CustomTextArea}</label>
                    <div className="textarea">
                        <textarea
                            id={this.props.id + "-textarea"}
                            className={this.setTextAreaClass() }
                            defaultValue={this.setDisplayText() }
                            maxLength={this.textLimit}
                            onFocus={this._onFocus}
                            onBlur={this._onBlur}
                            onKeyUp={this._textSize}
                            disabled={!this.props.permissions.enableTextEdit}
                            />
                        <div className="textarea-counter">
                            <span className="reset-text" onClick={this._resetText}>
                                {this.props.staticTexts.subButton_TextProposal}
                            </span>
                            <span className="pull-right">
                                {this.props.staticTexts.subLabel_RemainingText}: {this.state.remainingText}
                            </span>
                        </div>
                    </div>
                </div>
            );
        }

        return textArea;
    }

    setTextAreaClass() {
        let textAreaClass = "";

        if (this.props.textType === "STD" || !this.props.permissions.enableTextEdit) {
            textAreaClass += "f-08 std"
        } else {
            textAreaClass += " f-04"
        }

        return textAreaClass;
    }

    setDisplayText() {
        let text = null;

        if (this.props.permissions.enableTextEdit) {
            text = this.state.config.newConfig.text;
        } else {
            text = this.props.staticTexts.subTextArea_CustomerText;
        }

        return text;
    }

    resizeTextarea(element) {
        element.style.height = this.textareaHeight + 'px';
        element.style.height = element.scrollHeight + 'px';
    }

    _onEmailChange(emailUID) {
        this.setState({
            config: {
                initialConfig: this.state.config.initialConfig,
                newConfig: {
                    emailUID: emailUID,
                    informationChannelUID: this.state.config.newConfig.informationChannelUID,
                    text: this.state.config.newConfig.text
                }
            },
            remainingText: this.state.remainingText,
        });
    }

    _onFocus(e) {
        let textareaElement = document.getElementById(this.props.id + "-textarea");
        HelperService.removeClass(textareaElement, 'f-08');
        HelperService.addClass(textareaElement, 'f-04');

        if (e.target.value === this.standardText) {
            e.target.value = '';
            this.resizeTextarea(e.target);
            this.setState({
                config: {
                    initialConfig: this.state.config.initialConfig,
                    newConfig: {
                        emailUID: this.state.config.newConfig.emailUID,
                        informationChannelUID: this.state.config.newConfig.informationChannelUID,
                        text: '',
                    },
                },
                remainingText: this.textLimit,
            });
        }

    }

    _onBlur() {
        if (this.state.config.newConfig.text === '') {
            this._resetText();
        }
    }

    _resetText() {

        if (!this.props.permissions.enableTextEdit) {
            return false;
        } else {
            let hide_encryption_info_text = document.getElementById('encryption-info-text');
            HelperService.addClass(hide_encryption_info_text, 'hidden');
            let resetText = document.getElementById(this.props.id + '-textarea');
            resetText.value = this.standardText;
            this.resizeTextarea(resetText);
            HelperService.removeClass(resetText, 'f-04');
            HelperService.addClass(resetText, 'f-08');
            HelperService.addClass(resetText, 'std');
            this.setState({
                config: {
                    initialConfig: this.state.config.initialConfig,
                    newConfig: {
                        emailUID: this.state.config.newConfig.emailUID,
                        informationChannelUID: this.state.config.newConfig.informationChannelUID,
                        text: this.standardText,
                    },
                },
                remainingText: this.textLimit - this.standardText.length,
            });
        }
    }

    _textSize(e) {
        this.resizeTextarea(e.target);
        let textareaElement = document.getElementById(this.props.id + '-textarea');
        HelperService.removeClass(textareaElement, 'f-08');
        HelperService.addClass(textareaElement, 'f-04');
        HelperService.removeClass(textareaElement, 'std');
        this.setState({
            config: {
                initialConfig: this.state.config.initialConfig,
                newConfig: {
                    emailUID: this.state.config.newConfig.emailUID,
                    informationChannelUID: this.state.config.newConfig.informationChannelUID,
                    text: e.target.value,
                },
            },
            remainingText: this.textLimit - e.target.value.length,
        });
    }

    _clearText() {
        let textarea = document.getElementById(this.props.id + '-textarea');
        textarea.value = '';
        textarea.focus();
        this.resizeTextarea(textarea);
        this.setState({
            config: {
                initialConfig: this.state.config.initialConfig,
                newConfig: {
                    emailUID: this.state.config.newConfig.emailUID,
                    informationChannelUID: this.state.config.newConfig.informationChannelUID,
                    text: '',
                },
            },
            remainingText: this.textLimit,
        });
    }

    _cancel() {
        if (this.isAllConfig) {
            NotifActions.cancelAllConfig();
        } else {
            NotifActions.cancelNotifConfig(this.props.configObj);
        }
    }

    _save() {
        if (this.isAllConfig) {
            NotifActions.saveAllConfig(this.state.config.newConfig);
        } else {
            NotifActions.saveNotifConfig(this.props.configObj, this.state.config);
        }
    }

    render() {

        return (
            <div id={this.props.id} className="notif-config">
                <label>{this.props.staticTexts.subHeading_InfoChannel}</label>
                <p>{this.getInformationChannelText(this.informationChannelKey) }</p>
                <label>{this.props.staticTexts.subHeading_ChooseEmail}</label>
                <div className="radio-group">{this.setEmailList()}</div>
                {this.setTextArea()}
                <div className="buttons-div row">
                    <div className="col-md-12">
                        <button
                            type="button"
                            className="btn btn-primary pull-right"
                            onClick={this._save}
                            disabled={!this.props.permissions.enableSave}>
                            {this.props.staticTexts.subButton_Confirm}
                        </button>
                        <button type="button" className="btn btn-default pull-right" onClick={this._cancel}>
                            {this.props.staticTexts.subButton_Cancel}
                        </button>
                    </div>
                </div>
            </div>
        );
    }
}

export default Config;
