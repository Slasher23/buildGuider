import React, { Component } from 'react';

class EmailRadio extends Component {
  constructor(props) {
    super(props);
    this._handleEmailChange = this._handleEmailChange.bind(this);
  }

  _handleEmailChange() {
    this.props.onChange(this.props.email.emailUID);
  }

  render() {

    return (
      <div className="radio">
        <label>
          <input
            name={this.props.itemId + '-radio' + this.props.index}
            type="radio"
            value={this.props.email.emailUID}
            onChange={() => this._handleEmailChange()}
            checked={this.props.isChecked}
            disabled={!this.props.isChecked && this.props.disabled}
          />
          <span /> {this.props.email.emailAddress}
        </label>
      </div>
    );
  }
}

export default EmailRadio;
