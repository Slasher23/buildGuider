import React, { Component } from 'react';
import { historyPush } from './../services/Router';

class Modal extends Component {
    constructor(props) {
        super(props);
        this._onCloseClick = this._onCloseClick.bind(this);
        this._onContainerClick = this._onContainerClick.bind(this);
    }

    componentDidMount() {
        this.containerElement = document.getElementById(this.props.id);
    }

    _onCloseClick() {
        document.getElementById(this.props.id + '-btn-close').click();
        if (this.props.okayURL) {
            if (this.props.okayURL !== "back") {
                historyPush(this.props.okayURL);
            } else {
                window.history.back();
            }
        }
    }

    _onContainerClick(e) {
        if (e.target === this.containerElement) {
            this._onCloseClick();
        }
    }

    render() {
        let iconHTML = null;
        let headerHTML = null;
        let bodyHTML = null;
        let okayButtonHTML = (
            <button type="button" className="btn btn-primary" onClick={this._onCloseClick}>{this.props.okayText}</button>
        );

        if (this.props.type === 'success') {
            iconHTML = <div className="checkmark" />;
        }

        if (this.props.type === 'error') {
            iconHTML = <img className="center-block" src="./assets/images/icon-80x80px-error.svg" alt="Error" />;
        }

        if (this.props.headerText) {
            headerHTML = (
                <div className="modal-header">
                    <button id={this.props.id + '-btn-close'} type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={this._onCloseClick}/>
                    {iconHTML}
                    <h2 className="modal-title">{this.props.headerText}</h2>
                </div>
            );
        }

        bodyHTML = (
            <div className="modal-body">
                <p>{this.props.message}</p>
                <p>{this.props.message2}</p>
            </div>
        );

        return (
            <div className="modal" id={this.props.id} tabIndex="-1" role="dialog" data-backdrop="static" onClick={this._onContainerClick}>
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        {headerHTML}
                        {bodyHTML}
                        <div className="modal-footer">
                            {okayButtonHTML}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Modal;