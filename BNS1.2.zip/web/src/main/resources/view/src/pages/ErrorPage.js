import React, { Component } from 'react';
import NotifStore from './../stores/NotifStore';

class Error extends Component {

    render() {
        let staticTexts = NotifStore.getStaticTexts()
        let errorMessage = NotifStore.getErrorMessage();

        return (
            <div className="col-12">
                <div className="errLabel col-12">
                    <h2>{staticTexts.errorHeading_TechnicalError}</h2>
                    <p>{staticTexts.errorLabel_IssueOccured}</p>
                </div>
                <div className="errLabel col-12">
                    <h2>{staticTexts.errorHeading_Hotlines}</h2>
                    <ul>
                        <li className="li">{staticTexts.errorList_OnlineBanking}: {errorMessage.contactList.contact.contact}</li>
                        <li className="li">
                            {staticTexts.errorList_BlockOnlineBanking}: {errorMessage.contactList.contact.contact1}
                        </li>
                        <li className="li">{staticTexts.errorList_BlockCreditCard}: {errorMessage.contactList.contact.contact2}</li>
                        <li className="li">
                            {staticTexts.errorList_BlockECSavingsCard}: {errorMessage.contactList.contact.contact3}
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}

export default Error;
