import React, { Component } from 'react';
import NotifActions from './../actions/NotifActions';
import { Route } from './../services/Router';
import { routes } from './../routes/Routes';

class Overview extends Component {
    constructor() {
        super();
        NotifActions.readBNSCif();

        this.handlePageView = this.handlePageView.bind(this);
    }

    handlePageView() {
        let pageView = [];

        routes.map((route, index) => {
            return (pageView.push(
                <Route
                    key={index}
                    path={route.path}
                    exact={route.exact}
                    component={route.component}
                    />));
        });

        return pageView;
    }

    render() {
        let pageView = this.handlePageView();

        return (
            <div className="App">
                {pageView}
            </div>
        );
    }
}

export default Overview;