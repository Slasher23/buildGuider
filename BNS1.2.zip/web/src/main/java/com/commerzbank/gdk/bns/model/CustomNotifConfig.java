package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/** 
* CustomNotifConfig wrapper for notif text and agreement config fields.
* @since 09/08/2017
* @author ZE2SARO
* @version 1.03
*
* <pre>
* Modified Date   Version   Author     Description
* 09/08/2017      1.01      ZE2SARO    Initial Version
* 30/08/2017      1.02      ZE2RUBI    Add XMLROOTELEMENT annotation
* 03/10/2017	  1.03		ZE2BAUL	   Added participantNumberUID and renamed the class to CustomNotifConfig
* </pre>
*/
@XmlRootElement
public class CustomNotifConfig {

	private Long agreementUID;
	private Long personUID;
    private boolean active;
	private Long informationChannelUID;
	private Long emailUID;
	private String text;
	
	public Long getPersonUID() {
        return personUID;
    }

    public void setPersonUID(Long personUID) {
        this.personUID = personUID;
    }


	/**
	 * @return the agreementUID
	 */
	public Long getAgreementUID() {
		return agreementUID;
	}

	/**
	 * @param agreementUID Long 
	 *            the agreementUID to set
	 */
	public void setAgreementUID(Long agreementUID) {
		this.agreementUID = agreementUID;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * @param active boolean
	 *            the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * @return the informationChannelUID
	 */
	public Long getInformationChannelUID() {
		return informationChannelUID;
	}

	/**
	 * @param informationChannelUID Long
	 *            the informationChannelUID to set
	 */
	public void setInformationChannelUID(Long informationChannelUID) {
		this.informationChannelUID = informationChannelUID;
	}

	/**
	 * @return the emailUID
	 */
	public Long getEmailUID() {
		return emailUID;
	}

	/**
	 * @param emailUID Long
	 *            the emailUID to set
	 */
	public void setEmailUID(Long emailUID) {
		this.emailUID = emailUID;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text String
	 *            the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	
	/**
	 * Convert values to string
	 * @return return the string converted value
	 */
	
	@Override
    public String toString() {
        return "CustomNotifConfig [agreementUID=" + agreementUID + ", active=" + active + ", informationChannelUID="
                + informationChannelUID + ", emailUID=" + emailUID + ", text=" + text + "]";
    }
	

}
