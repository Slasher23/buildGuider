package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Response for Batch Change Email Address
 * 
 * @since 27/11/2017
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2BUEN    Initial Version
 * </pre>
 */

@XmlRootElement
public class ChangeEmailAddressBatchResponse {

	private List<ChangeEmailAddressResponse> changeEmailAddressResponse;

	private List<ChangeEmailAddressResponse> changeEmailAddressResponseWithErrors;

	/**
	 * Returns the List of Change Email Address Response
	 * 
	 * @return List List of Change Email Address Response
	 */
	public List<ChangeEmailAddressResponse> getChangeEmailAddressResponse() {
		return changeEmailAddressResponse;
	}

	/**
	 * Sets the List of Change Email Address Response
	 * 
	 * @param changeEmailAddressResponse
	 *            String List of Change Email Address Response to set
	 */
	public void setChangeEmailAddressResponse(List<ChangeEmailAddressResponse> changeEmailAddressResponse) {
		this.changeEmailAddressResponse = changeEmailAddressResponse;
	}

	/**
	 * Returns the List of Change Email Address Response With Errors
	 * 
	 * @return List List of Change Email Address Response With Errors
	 */
	public List<ChangeEmailAddressResponse> getChangeEmailAddressResponseWithErrors() {
		return changeEmailAddressResponseWithErrors;
	}

	/**
	 * Sets the List of Change Email Address Response With Errors
	 * 
	 * @param changeEmailAddressResponseWithErrors
	 *            String List of Change Email Address Response With Errors to
	 *            set
	 */
	public void setChangeEmailAddressResponseWithErrors(
			List<ChangeEmailAddressResponse> changeEmailAddressResponseWithErrors) {
		this.changeEmailAddressResponseWithErrors = changeEmailAddressResponseWithErrors;
	}

	/**
	 * Returns the String representation of Change Email Address Batch Response
	 * Model
	 * 
	 * @return String String representation of Change Email Address Batch
	 *         Response Model
	 */
	@Override
	public String toString() {
		return "ChangeEmailAddressBatchResponse [changeEmailAddressResponse=" + changeEmailAddressResponse
				+ ", changeEmailAddressResponseWithErrors=" + changeEmailAddressResponseWithErrors + "]";
	}

}
