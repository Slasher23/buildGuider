package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for CustomerNotificationsResponse
 * 
 * @since 10/11/2017
 * @author ZE2SARO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017        1.00       ZE2SARO    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "CustomerNotificationsResponse")
public class CustomerNotificationsResponse {

    private String kundennummer;

    private List<NotificationResponse> customerNotifications;

    private String status;

    /**
     * @return the kundennummer
     */
    public String getKundennummer() {
        return kundennummer;
    }

    /**
     * @param kundennummer the kundennummer to set
     */
    public void setKundennummer(String kundennummer) {
        this.kundennummer = kundennummer;
    }

    /**
     * @return the customerNotifications
     */
    public List<NotificationResponse> getCustomerNotifications() {
        return customerNotifications;
    }

    /**
     * @param customerNotifications the customerNotifications to set
     */
    public void setCustomerNotifications(List<NotificationResponse> customerNotifications) {
        this.customerNotifications = customerNotifications;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CustomerNotificationsResponse [kundennummer=" + kundennummer + ", customerNotifications="
                + customerNotifications + ", status=" + status + "]";
    }

}
