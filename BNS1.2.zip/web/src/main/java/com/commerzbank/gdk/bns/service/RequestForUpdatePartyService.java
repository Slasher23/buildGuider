package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;

/**
 * Service Class used to access the RequestForUpdatePartyServiceImpl
 * 
 * @since 07/12/2017
 * @author ZE2GOME
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 07/12/2017        1.00       ZE2GOME    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface RequestForUpdatePartyService {
    
    ZslUpdateResponse requestForUpdateParty(UpdatePartyRequest updatePartyRequest);
}
