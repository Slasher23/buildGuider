package com.commerzbank.gdk.bns.service;

import java.io.PrintWriter;
import java.util.List;

import org.supercsv.io.ICsvBeanWriter;

import com.commerzbank.gdk.bns.model.GenerateReportRequest;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * GenerateReportService Interface to generate CSV report files based on the
 * start date, end date and report type provided.
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2BUEN    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface GenerateReportService {

    ResponseBuilder<List<Report>> retrieveReportData(Tokenizer token, GenerateReportRequest generateReportRequest);

    ICsvBeanWriter generateCSVFile(PrintWriter printWriter, String reportType, List<Report> reportList, Tokenizer token);

}
