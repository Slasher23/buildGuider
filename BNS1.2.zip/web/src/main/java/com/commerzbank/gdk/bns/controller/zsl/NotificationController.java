package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.BatchNotificationResponse;
import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchNotification;
import com.commerzbank.gdk.bns.service.BatchNotificationService;
import com.commerzbank.gdk.bns.service.NotificationService;

/**
 * NotificationController - Accept notification request and return the
 * notification response to ZSL.
 * 
 * @since 14/09/2017
 * @author ZE2BUEN
 * @version 1.08
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 14/09/2017        1.01       ZE2BUEN    Initial Version
 * 26/10/2017		 1.02		ZE2FUEN	   Changed request type to NotificationRequest Model
 * 03/11/2017	  	 1.03		ZE2BAUL	   Added implementation for ProcessRunID requirement
 * 13/11/2017        1.04       ZE2GOME    Added method for request for batch notification
 * 07/12/2017        1.05       ZE2SARO    Add Validation
 * 12/12/2017        1.06       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 05/02/2018        1.07       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.08       ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private BatchNotificationService batchNotificationService;

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationController.class);

    /**
     * Accept client post notification request then call service to get
     * notification response then return also produces xml or json format.
     * 
     * @param notificationRequest
     *            NotificationRequest Notification Request
     * @param request
     * @return ResponseEntity Notification Response
     */
    @PostMapping(value = "/api/zsl/requestForNotification")
    public ResponseEntity<NotificationResponse> requestForNotification(
            @Valid @RequestBody NotificationRequest notificationRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForNotification({})", "ZSL", notificationRequest.toString());

        NotificationResponse notifResponse = new NotificationResponse();

        if (!result.hasErrors()) {
            notifResponse = this.notificationService.sendNotification(notificationRequest);

            if (Objects.isNull(notifResponse)) {
                notifResponse = new NotificationResponse();
            }

        }

        ResponseEntity<NotificationResponse> response = new ResponseEntity<NotificationResponse>(notifResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", notifResponse.toString());

        return response;
    }

    /**
     * Accept client post notification request then call service to get
     * notification response then return also produces xml or json format.
     * 
     * @param notificationRequest
     *            NotificationRequest Notification Request
     * @param request
     * @return ResponseEntity Notification Response
     */
    @PostMapping(value = "/api/zsl/requestForBatchNotification")
    public ResponseEntity<BatchNotificationResponse> requestForBatchNotification(
            @Valid @RequestBody RequestForBatchNotification notificationRequest, HttpServletRequest request,
            BindingResult result) throws Exception {

        LOGGER.info("=>> System [{}] - requestForBatchNotification({})", "ZSL", notificationRequest.toString());

        BatchNotificationResponse batchResponse = new BatchNotificationResponse();

        if (!result.hasErrors()) {
            batchResponse = this.batchNotificationService.requestForBatchNotification(notificationRequest);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new BatchNotificationResponse();
            }
        }

        ResponseEntity<BatchNotificationResponse> response = new ResponseEntity<BatchNotificationResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;
    }

}
