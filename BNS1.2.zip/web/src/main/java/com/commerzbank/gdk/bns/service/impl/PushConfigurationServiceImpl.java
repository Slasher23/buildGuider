package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.dao.PushConfigurationDAO;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PushConfiguration;
import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;
import com.commerzbank.gdk.bns.service.PushConfigurationService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to process request to enable and disable
 * push configuration
 * 
 * @since 20/09/2017
 * @author ZE2BUEN
 * @version 1.05
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2BUEN    Initial Version
 * 03/11/2017		 1.01		ZE2BAUL	   Standardized ZSL logging
 * 07/12/2017        1.02       ZE2SARO    Add Validation
 * 12/12/2017        1.03       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 06/02/2018        1.04       ZE2MACL    Remove throws Exception and replace with try catch block
 * 21/02/2018        1.05       ZE2MACL    Added required field/s validation
 *          </pre>
 */

@Service
@Transactional
public class PushConfigurationServiceImpl implements PushConfigurationService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private PushConfigurationDAO pushConfigurationDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    private static final Logger LOGGER = LoggerFactory.getLogger(PushConfigurationServiceImpl.class);

    private static final String EMPTY_STRING                 = "";
    private static final String STATUS_OK                    = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST    = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS  = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_FAILED_PUSH_CONFIG = "ZSL_STATUS_FA_FAILED_PUSH_CONFIG";
    String                      status                       = EMPTY_STRING;

    /**
     * Create/update push configuration record and returns push configuration
     * response
     * 
     * @param request PushConfigurationRequest Push Configuration Request sent
     *            by ZSL.
     * @return PushConfigurationResponse Push Configuration Response
     */
    @Override
    public PushConfigurationResponse requestForPushConfiguration(PushConfigurationRequest request) {

        String status = EMPTY_STRING;

        PushConfigurationResponse response = new PushConfigurationResponse();

        try {
            PushConfiguration pushConfiguration = null;
            // Check if Push Configuration Request Details is Valid
            status = isValidRequest(request);
            if (isNullOrEmpty(status)) {
                // Get Push Configuration Request Details
                String bpkenn = request.getBpkenn();
                String deviceID = request.getDeviceId();
                String appID = request.getAppId();
                String appName = request.getAppName();
                String appVersion = request.getAppVersion();
                Boolean activate = request.getActivate();
                // Get Person Details
                Person person = this.personDAO.getPerson(bpkenn);
                // Get Participant Number Details
                if (Objects.isNull(person)) {
                    status = this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS);
                } else {
                    // Save Push Configuration Details
                    pushConfiguration = this.savePushConfiguration(person.getPersonUID(), deviceID, appName, appID,
                                    appVersion, activate);
                }

            } else {
                response.setStatus(status);
            }

            if (Objects.nonNull(pushConfiguration) && status.isEmpty()) {
                status = this.environment.getProperty(STATUS_OK);
            } else if (Objects.isNull(pushConfiguration) && status.isEmpty()) {
                status = this.environment.getProperty(STATUS_FA_FAILED_PUSH_CONFIG);
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            status = this.environment.getProperty(STATUS_FA_FAILED_PUSH_CONFIG);
        }

        response.setStatus(status);

        return response;
    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        Boolean isNullOrEmpty = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;
        return isNullOrEmpty;

    }

    /**
     * Method to validate request
     * 
     * @param request PushConfigurationRequest
     * @return String
     */
    private String isValidRequest(PushConfigurationRequest request) {
        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        boolean nullBpkenn = this.isNullOrEmpty(request.getBpkenn());
        boolean nullDeviceID = this.isNullOrEmpty(request.getDeviceId());
        boolean nullAppID = this.isNullOrEmpty(request.getAppId());
        boolean nullAppName = this.isNullOrEmpty(request.getAppName());
        boolean nullAppVersion = this.isNullOrEmpty(request.getAppVersion());
        boolean nullActivate = Objects.isNull(request.getActivate());

        if (nullBpkenn) {
            invalidFields.add("bpkenn");
        }

        if (nullDeviceID) {
            invalidFields.add("deviceId");
        }

        if (nullAppID) {
            invalidFields.add("appId");
        }

        if (nullDeviceID) {
            invalidFields.add("deviceId");
        }

        if (nullAppName) {
            invalidFields.add("appName");
        }

        if (nullAppVersion) {
            invalidFields.add("appVersion");
        }

        if (nullActivate) {
            invalidFields.add("activate");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;
    }

    /**
     * Method to save push configuration record
     * 
     * @param personUID Long person
     * @param deviceID String Device ID
     * @param appName String Application Name
     * @param appID String Application ID
     * @param appVersion String Application Version
     * @param active boolean Active
     * @return PushConfiguration Push Configuration
     */
    private PushConfiguration savePushConfiguration(Long personUID, String deviceID, String appName, String appID,
                    String appVersion, boolean active) {

        PushConfiguration pushConfiguration = this.pushConfigurationDAO.getPushConfiguration(personUID, deviceID);

        if (Objects.isNull(pushConfiguration)) {
            pushConfiguration = new PushConfiguration();
        }

        pushConfiguration.setPersonUID(personUID);
        pushConfiguration.setDeviceID(deviceID);
        pushConfiguration.setAppName(appName);
        pushConfiguration.setAppID(appID);
        pushConfiguration.setAppVersion(appVersion);
        pushConfiguration.setActive(active);

        PushConfiguration result = this.pushConfigurationDAO.save(pushConfiguration);

        return result;

    }

}
