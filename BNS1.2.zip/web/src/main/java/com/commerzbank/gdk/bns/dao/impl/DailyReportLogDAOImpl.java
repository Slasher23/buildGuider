package com.commerzbank.gdk.bns.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.DailyReportLogCustomDAO;

/**
 * DAO Implementation Class to get the Report List
 * 
 * @since 11/01/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 11/01/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */

@Repository
public class DailyReportLogDAOImpl implements DailyReportLogCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    private static final String DATE_FORMAT = "dd/MM/yyyy";

    @Override
    public Integer countDailyReportLog(Date date, String eventType, String status) {
        
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

        StringBuilder query = new StringBuilder();
        query.append("SELECT count(distinct d.bpkenn) FROM DailyReportLog d WHERE trunc(d.timestamp) = ");
        query.append("to_date('");
        query.append(sdf.format(date));
        query.append("', 'dd/MM/yyyy')) and ");
        query.append("d.eventType = '");
        query.append(eventType);
        query.append("' and d.status = '");
        query.append(status);
        query.append("'");

        Integer count = (int) (long) this.entityManager.createQuery(query.toString()).getSingleResult();
                
        return count;
        
    }

}
