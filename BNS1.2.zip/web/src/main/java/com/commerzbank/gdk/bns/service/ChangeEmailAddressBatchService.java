package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchResponse;

/**
 * Service Class used to process Batch Change Email Address
 * 
 * @since 27/11/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2BUEN   Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 * </pre>
 */
public interface ChangeEmailAddressBatchService {

	ChangeEmailAddressBatchResponse requestForBatchChangeEmailAddress(ChangeEmailAddressBatchRequest request);

}
