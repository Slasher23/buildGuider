package com.commerzbank.gdk.bns.model;

import java.util.Map;

/**
 * Model Class for Contact List
 * 
 * @since 21/09/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description 
 * 21/09/2017        1.00       ZE2GOME    Initial Version
 * </pre>
 */
public class ContactList {
	
	private Map<String, String> contact;

	/**
	 *  Return contact 
	 *  
	 * @return the contact
	 */
	public Map<String, String> getContact() {
		return contact;
	}

	/**
	 *  Set contact 
	 *  
	 * @param contact the contact to set
	 */
	public void setContact(Map<String, String> contact) {
		this.contact = contact;
	}

	/**
	 * Returns the String representation of Contact List Wrapper
	 * 
	 * @return String String representation of Contact List Wrapper
	 */
	@Override
	public String toString() {
		return "ContactList [contact=" + contact + "]";
	}

}
