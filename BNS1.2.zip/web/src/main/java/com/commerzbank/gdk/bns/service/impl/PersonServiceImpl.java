/**
 * 
 */
package com.commerzbank.gdk.bns.service.impl;

import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.PersonService;

/**
 * Service Implementation Class used to implement business logic service in
 * getting the Person
 * 
 * @author ZE2SARO
 * @version 1.03
 * @since 08/08/2017
 * 
 *        <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 15/11/2017       1.01        ZE2MACL     Updated method to used response builder and added token parameter
 * 24/11/2017       1.02        ZE2MORA     Implemented Status Codes
 * 20/02/2018       1.03        ZE2FUEN     Updated implementation to CIF-Integration
 *        </pre>
 */
@Service
@Transactional
public class PersonServiceImpl implements PersonService {

    private static final Logger logger = LoggerFactory.getLogger(PersonServiceImpl.class);

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    /**
     * Retrieves the value of Person using BPKENN
     * 
     * @param token
     *            to identify the user
     * @param bpkenn
     *            String BPKENN of Person Record to set
     * 
     * @return list of Person based on BPKENN
     */
    @Override
    public ResponseBuilder<Person> getPerson(Tokenizer token) {

        ResponseBuilder<Person> builder = new ResponseBuilder<Person>(logger, token, globalResponseWrapper);

        String bpkenn = token.getBpkenn();

        try {

            Person result = this.personDAO.getPerson(bpkenn);

            if (Objects.nonNull(result)) {
                builder.OK(result);
            } else {
                builder.OK(result, Response.SUCCESS_NO_RESULTS_FOUND);
            }

        } catch (DataAccessException e) {
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        } catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
            builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        logger.info("<<= User [{}] getPerson({}) request was successfully processed.", token.getUserId(), bpkenn);

        return builder;
    }

}
