
/**
 * This package contains the entry point of the application.
 * @author ZE2MACL
 *
 */
package com.commerzbank.gdk.bns;