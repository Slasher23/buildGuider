package com.commerzbank.gdk.bns.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.BNSInternal;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AllNotificationConfigService;

/**
 * AllNotificationConfigController class accept request and send response to
 * client.
 * 
 * @since 09/22/2017
 * @author ze2saro
 * @version 1.08
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 09/22/2017		1.00		ZE2SARO 	InitialVersion
 * 02/10/2017		1.01		ZE2BAUL		Changed the AgreementEmailChannelWrapper to MainAgreementTypeWrapper
 * 13/10/2017	    1.02		ZE2RUBI	    Clean Up and Implement JWT
 * 14/11/2017       1.03        ZE2MACL     Updated method to used response builder and added token parameter
 * 11/12/2017       1.04        ZE2SARO     Add Validation
 * 09/02/2018       1.05        ZE2MACL    Removed throws Exception
 * 12/02/2018       1.06        ZE2BUEN     Modified Internal APIs request to BNSInternalRequest Object
 * 20/02/2018       1.07        ZE2FUEN    Updated implementation to CIF-Integration
 * 28/02/2018       1.08        ZE2FUEN    Implemented BNStoken builder
 * </pre>
 */
@RestController
public class AllNotificationConfigController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AllNotificationConfigController.class);

	@Autowired
	private AllNotificationConfigService allNotificationConfigService;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	/**
	 * Accept client request and call service to get the all notif config from
	 * database using bpkenn then return also consumes and produces json or xml
	 * format.
	 * 
	 * @param bnsInternal
	 *            BNS Internal (Parameter)
	 * @return all notif config
	 * 
	 */
	@PostMapping(value = "/api/allNotificationConfig")
	public ResponseEntity<Response<AllNotificationConfig>> getAllNotifConfig(HttpServletRequest request, Authentication auth) {

	    Tokenizer token = Tokenizer.getUserToken(auth);

		LOGGER.info("=>> User [{}] getAllNotifConfig({})", token.getUserId(), token.getBpkenn());
		
		ResponseBuilder<AllNotificationConfig> builder = new ResponseBuilder<AllNotificationConfig>(LOGGER, token,
				globalResponseWrapper);

		if (Tokenizer.validator(token)) {
			builder = this.allNotificationConfigService.getAllNotifConfig(token);
		} else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

		return builder.responseEntity();
	}

	/**
	 * Accept client request and call service to save all notif config from
	 * database also consumes and produces json or xml format.
	 * 
	 * @param bnsInternal
	 *            BNSInternal (AllNotificationConfig)
	 * @return AgreementTypesWrapper to client
	 * 
	 */
	@PostMapping(value = "/api/allNotificationConfig/save")
	public ResponseEntity<Response<MainAgreementTypeWrapper>> saveAllNotifConfig(
			@Valid @RequestBody BNSInternal<AllNotificationConfig> bnsRequest, BindingResult result, HttpServletRequest request, Authentication auth) {

	    Tokenizer token = Tokenizer.getUserToken(auth);

		LOGGER.info("=>> User [{}] saveAllNotifConfig({})", token.getUserId(), bnsRequest.getRequest());
		
		ResponseBuilder<MainAgreementTypeWrapper> builder = new ResponseBuilder<MainAgreementTypeWrapper>(LOGGER, token,
				globalResponseWrapper);

		if (!result.hasErrors() && Tokenizer.validator(token)) {
			builder = this.allNotificationConfigService.saveAllNotifConfig(token, bnsRequest.getRequest(), bnsRequest.getBnsToken());
		} else {
            builder.notOK(Response.INVALID_AUTHORIZATION_EXCEPTION);
        }

		return builder.responseEntity();
	}

}
