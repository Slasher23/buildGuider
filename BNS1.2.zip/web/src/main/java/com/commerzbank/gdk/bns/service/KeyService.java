package com.commerzbank.gdk.bns.service;

import java.util.List;

import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class used to access the Schlussel DB
 * 
 * @since 12/12/2017
 * @author ZE2MACL
 * @version 1.01
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2MACL    Initial Version
 * 21/02/2018        1.01       ZE2BUEN    Added savingKeyRecords and deleteKeyRecords method 
 * </pre>
 */

public interface KeyService {

    public String getShortTextValue(String keyTyp, String keyCode, String language);

    public String getLongTextValue(String keyTyp, String keyCode, String language);
    
    public String getKeyCodeByValue(String keyType, String text);
    
    public List<Key> savingKeyRecords(List<Key> keyList, Tokenizer token);
    
    public void deleteKeyRecords(String keyType, Tokenizer token);
    
}
