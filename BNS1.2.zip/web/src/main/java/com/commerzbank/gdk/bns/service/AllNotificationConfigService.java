package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Interface used to access the AllNotificationConfigServiceImpl
 * 
 * @since 22/09/2017
 * @author ZE2SARO
 * @version 1.04
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 22/09/2017        1.00       ZE2SARO    Initial Version
 * 02/10/2017		 1.01		ZE2BAUL	   Changed the AgreementEmailChannelWrapper to MainAgreementTypeWrapper
 * 10/11/2017        1.02       ZE2MACL    Changed method to used Response builder and added token parameter
 * 20/02/2018        1.03       ZE2FUEN    Updated implementation to CIF-Integration
 * 28/02/2018        1.04       ZE2FUEN    Implemented BNStoken builder
 * </pre>
 */
public interface AllNotificationConfigService {
	
	ResponseBuilder<AllNotificationConfig> getAllNotifConfig(Tokenizer token);
	
	ResponseBuilder<MainAgreementTypeWrapper> saveAllNotifConfig(Tokenizer token, AllNotificationConfig allNotificationConfig, String bnsToken);
	
}
