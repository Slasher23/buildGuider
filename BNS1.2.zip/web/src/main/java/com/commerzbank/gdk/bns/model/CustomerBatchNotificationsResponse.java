package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for CustomerNotificationsBatchResponse
 * 
 * @since 10/11/2017
 * @author ZE2SARO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017        1.00       ZE2SARO    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "CustomerNotificationsBatchResponse")
public class CustomerBatchNotificationsResponse {

    private List<CustomerNotificationsResponse> customerNotificationResponse;

    private List<CustomerNotificationsResponse> customerNotificationResponseWithErrors;

    /**
     * @return the customerNotificationResponse
     */
    public List<CustomerNotificationsResponse> getCustomerNotificationResponse() {
        return customerNotificationResponse;
    }

    /**
     * @param customerNotificationResponse the customerNotificationResponse to
     *            set
     */
    public void setCustomerNotificationResponse(List<CustomerNotificationsResponse> customerNotificationResponse) {
        this.customerNotificationResponse = customerNotificationResponse;
    }

    /**
     * @return the customerNotificationResponseWithErrors
     */
    public List<CustomerNotificationsResponse> getCustomerNotificationResponseWithErrors() {
        return customerNotificationResponseWithErrors;
    }

    /**
     * @param customerNotificationResponseWithErrors the
     *            customerNotificationResponseWithErrors to set
     */
    public void setCustomerNotificationResponseWithErrors(
            List<CustomerNotificationsResponse> customerNotificationResponseWithErrors) {
        this.customerNotificationResponseWithErrors = customerNotificationResponseWithErrors;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CustomerNotificationsBatchResponse [customerNotificationResponse=" + customerNotificationResponse
                + ", customerNotificationResponseWithErrors=" + customerNotificationResponseWithErrors + "]";
    }

}
