package com.commerzbank.gdk.bns.conf.security;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

/**
 * Holder for JWT token from the request.
 * <p/>
 * Other fields aren't used but necessary to comply to the contracts of
 * AbstractUserDetailsAuthenticationProvider
 * 
 * @author ZE2RUBI
 * @since 03/10/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017	     1.00       ZE2RUBI    Initial Version
 * 20/02/2018        1.01       ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
public class CifAuthorizationToken extends UsernamePasswordAuthenticationToken {

    private static final long serialVersionUID = 1L;
    private String token;

    public CifAuthorizationToken(String token) {
        super(null, null);
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }
}