package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.NotificationRequest;
import com.commerzbank.gdk.bns.model.NotificationResponse;

/**
 * Service Class used to send Standard and Individual Notifications
 * 
 * @since 20/09/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 20/09/2017        1.01       ZE2BUEN    Initial Version
 * 26/10/2017		 1.02		ZE2FUEN	   Changed request type to NotificationRequest Model
 * 09/02/2018        1.03       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface NotificationService {

	NotificationResponse sendNotification(NotificationRequest notifRequest);

}
