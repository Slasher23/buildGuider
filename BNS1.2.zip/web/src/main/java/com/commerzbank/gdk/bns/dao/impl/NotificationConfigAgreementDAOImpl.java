package com.commerzbank.gdk.bns.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementCustomDAO;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;

/**
 * DAO Implementation Class to get the Notification Configuration Agreement List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.03
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.01		ZE2SARO 	InitialVersion
 * 26/10/2017       1.02        ZE2GOME     Added findByAgreementUID
 * 23/11/2017       1.03        ZE2SARO     Remove Participant
 *          </pre>
 */
@Repository
public class NotificationConfigAgreementDAOImpl implements NotificationConfigAgreementCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    /**
     * Retrieves the List of Notification Configuration Agreement records using
     * a given Unique Identifier of Agreement record
     * 
     * @param agreementUID Long Unique Identifier of Agreement Record to set
     * @return List List of Notification Configuration Agreement
     */
    @Override
    public NotificationConfigAgreement getNotifConfigAgreement(Long agreementUID) {

        NotificationConfigAgreement notificationConfigAgreement = null;
        TypedQuery<NotificationConfigAgreement> query = this.entityManager.createQuery(
                "FROM NotificationConfigAgreement WHERE agreementUID = " + agreementUID,
                NotificationConfigAgreement.class);
        if (query.getResultList().size() != 0)
            notificationConfigAgreement = query.setMaxResults(1).getSingleResult();

        return notificationConfigAgreement;
    }

    /**
     * Get agreement
     * 
     * @param personUID Long
     * @param branch Integer
     * @param agreementId String
     * @return agreement config
     */
	@Override
	public NotificationConfigAgreement findByAgreementUID(Long personUID, Integer branch, String agreementId) {
		
		NotificationConfigAgreement notificationConfigAgreement = null;
		StringBuilder query = new StringBuilder();
		query.append("SELECT notifConfig FROM NotificationConfigAgreement notifConfig ");
		query.append("WHERE notifConfig.agreementUID IN");
		query.append("(SELECT agr.agreementUID FROM Agreement agr ");
		query.append("WHERE agr.personUID = ").append(personUID).append(" AND ");
		query.append("agr.branch = ").append(branch).append(" AND ");
		query.append("lower(agr.agreementID) = lower('").append(agreementId).append("'))");
		
		TypedQuery<NotificationConfigAgreement> queryResult = this.entityManager.createQuery(query.toString(),
		        NotificationConfigAgreement.class);
        if (queryResult.getResultList().size() > 0) {
            notificationConfigAgreement = queryResult.setMaxResults(1).getSingleResult();
        }
		
		return notificationConfigAgreement;
	}

}
