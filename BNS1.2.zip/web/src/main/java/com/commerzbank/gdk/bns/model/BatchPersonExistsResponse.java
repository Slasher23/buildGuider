package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for Batch Person Exists Response.
 * 
 * @since 11/12/2017
 * @author ZE2MENY
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description 
 * 11/12/2017        1.00       ZE2MENY    Initial Version
 *          </pre>
 */
public class BatchPersonExistsResponse {

    List<ZslUpdateResponse> personExistsResponse;

    List<ZslUpdateResponse> personExistsResponseWithErrors;

    /**
     * Get list of ZSL update response without error.
     * 
     * @return the personExistsResponse
     */
    public List<ZslUpdateResponse> getPersonExistsResponse() {
        return personExistsResponse;
    }

    /**
     * Set list of ZSL update response without error.
     * 
     * @param personExistsResponse the personExistsResponse to set
     */
    public void setPersonExistsResponse(List<ZslUpdateResponse> personExistsResponse) {
        this.personExistsResponse = personExistsResponse;
    }

    /**
     * Get list of ZSL update response with error.
     * 
     * @return the personExistsResponseWithErrors
     */
    public List<ZslUpdateResponse> getPersonExistsResponseWithErrors() {
        return personExistsResponseWithErrors;
    }

    /**
     * Set list of ZSL update response with error.
     * 
     * @param personExistsResponseWithErrors the personExistsResponseWithErrors
     *            to set
     */
    public void setPersonExistsResponseWithErrors(List<ZslUpdateResponse> personExistsResponseWithErrors) {
        this.personExistsResponseWithErrors = personExistsResponseWithErrors;
    }

    /**
     * Returns the String representation of Batch Person Exists Response Model.
     * 
     * @return String String representation of Batch Person Exists Response
     *         Model
     * 
     */
    @Override
    public String toString() {
        return "BatchPersonExistsResponse [personExistsResponse=" + personExistsResponse
                + ", personExistsResponseWithErrors=" + personExistsResponseWithErrors + "]";
    }

}
