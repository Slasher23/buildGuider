package com.commerzbank.gdk.bns.service.db2;

import java.util.List;

import com.commerzbank.gdk.bns.model.Key;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Service Class to get the result of key database stored procedure
 * 
 * @since 22/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 22/02/2018		1.00	    ZE2BUEN 	Initial Version
 * </pre>
 */
public interface KeyDB2Service {
	
	List<Key> extractKeyDB2Records(String keyCode, Tokenizer token);
		
}
