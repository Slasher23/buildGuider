package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.model.BatchUpdatePartyRequest;
import com.commerzbank.gdk.bns.model.RequestForBatchUpdatePartyResponse;
import com.commerzbank.gdk.bns.model.UpdatePartyRequest;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForBatchUpdatePartyService;
import com.commerzbank.gdk.bns.service.RequestForUpdatePartyService;

/**
 * Service Class used to access the RequestForBatchUpdatePartyServiceImpl
 * 
 * @since 12/12/2017
 * @author ZE2GOME
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2GOME    Initial Version
 * 14/12/2017        1.01       ZE2BUEN    Refactor/clean up for status messages
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * </pre>
 */
@Service
@Transactional
public class RequestForBatchUpdatePartyServiceImpl implements RequestForBatchUpdatePartyService {

    @Autowired
    private RequestForUpdatePartyService requestForUpdatePartyService;

    @Autowired
    private Environment environment;

    private static final String STATUS_OK = "ZSL_STATUS_OK";

    /**
     * Logic to get batch update party.
     * 
     * @param updatePartyRequest BatchUpdatePartyRequest
     * @return response RequestForBatchUpdatePartyResponse
     */
    @Override
    public RequestForBatchUpdatePartyResponse requestForBatchUpdateParty(BatchUpdatePartyRequest updatePartyRequest) {
        RequestForBatchUpdatePartyResponse response = new RequestForBatchUpdatePartyResponse();
        List<ZslUpdateResponse> zslUpdateResponseNoError = new ArrayList<>();
        List<ZslUpdateResponse> zslUpdateResponseWithError = new ArrayList<>();

        for (UpdatePartyRequest request : updatePartyRequest.getUpdatePartyRequest()) {
            ZslUpdateResponse zslResponse = this.requestForUpdatePartyService.requestForUpdateParty(request);

            if (zslResponse.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))) {

                zslUpdateResponseNoError.add(zslResponse);
            } else {

                zslUpdateResponseWithError.add(zslResponse);
            }

        }
        response.setUpdatePartyResponse(zslUpdateResponseNoError);
        response.setUpdatePartyResponseWithErrors(zslUpdateResponseWithError);

        return response;
    }

}
