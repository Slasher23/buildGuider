package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Deactivate Person.
 * 
 * @author ZE2GOME
 * @since 19/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 19/12/2017	     1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@XmlRootElement
public class RequestForBatchAgreementNotification {

	List<AgreementNotificationRequest> agreementNotificationRequest;

	/**
	 * @return the agreementNotificationRequest
	 */
	public List<AgreementNotificationRequest> getAgreementNotificationRequest() {
		return agreementNotificationRequest;
	}

	/**
	 * @param agreementNotificationRequest
	 *            the agreementNotificationRequest to set
	 */
	public void setAgreementNotificationRequest(List<AgreementNotificationRequest> agreementNotificationRequest) {
		this.agreementNotificationRequest = agreementNotificationRequest;
	}

	/**
	 * Returns the String representation of agreementNotificationRequest Batch
	 * Request Model.
	 * 
	 * @return String String representation of agreementNotificationRequest
	 *         Batch Request Model
	 */
	@Override
	public String toString() {
		return "RequestForBatchAgreementNotification [agreementNotificationRequest=" + agreementNotificationRequest
				+ "]";
	}

}
