package com.commerzbank.gdk.bns.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.commerzbank.gdk.bns.dao.KeyCustomDAO;
import com.commerzbank.gdk.bns.model.Key;

/**
 * Key DAO Implementation Class
 * 
 * @since 22/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 22/02/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */

public class KeyDAOImpl implements KeyCustomDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void deleteByKeyTyp(String keyType) {

		List<Key> keyList = this.entityManager.createQuery("FROM Key WHERE keyTyp = '" + keyType + "'", Key.class)
				.getResultList();

		for (Key key : keyList) {
			this.entityManager.remove(key);
		}

		this.entityManager.flush();

	}

}
