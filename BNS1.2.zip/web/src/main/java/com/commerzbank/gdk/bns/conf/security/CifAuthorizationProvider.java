package com.commerzbank.gdk.bns.conf.security;

import java.util.List;
import java.util.Random;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * Used for checking the token from the request and supply the UserDetails if
 * the token is valid
 * 
 * @author ZE2RUBI
 * @since 03/10/2017
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017	     1.01       ZE2RUBI    Initial Version
 * 20/02/2018        1.02       ZE2FUEN    Updated implementation to CIF-Integration
 *          </pre>
 */
@Component
public class CifAuthorizationProvider extends AbstractUserDetailsAuthenticationProvider {

    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication)
            throws AuthenticationException {
        CifAuthorizationToken cifAuthorizationToken = (CifAuthorizationToken) authentication;
        String cifToken = cifAuthorizationToken.getToken();

        Tokenizer token = Tokenizer.parseAuthHeader(cifToken);

        if (!token.getError()) {
            List<GrantedAuthority> authorityList = AuthorityUtils
                    .commaSeparatedStringToAuthorityList("ROLE_" + token.getRole());
            return new AuthenticatedUser(new Random(10).nextLong(), token.getUserId(), token, authorityList);
        }

        List<GrantedAuthority> authorityList = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_ANONYMOUS");
        return new AuthenticatedUser(new Random(10).nextLong(), "anonymousUser", token, authorityList);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return (CifAuthorizationToken.class.isAssignableFrom(authentication));
    }

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails,
            UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
    }

}
