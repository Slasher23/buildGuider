
/**
 * This package contains the Data Access Object contracts.
 * @author ZE2RUBI
 *
 */
package com.commerzbank.gdk.bns.dao;