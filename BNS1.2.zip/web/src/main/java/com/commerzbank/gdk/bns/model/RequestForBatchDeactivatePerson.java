package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Deactivate Person.
 * 
 * @author 	ZE2BAUL
 * @since 	12/12/2017
 * @version 1.00
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017	     1.00       ZE2BAUL    Initial Version
 * </pre>
 */
@XmlRootElement
public class RequestForBatchDeactivatePerson {
	
	/**
	 * List for Deactivate Person Request.
	 */
	private List<Parameter> deactivatePersonRequest;

	/**
	 * Returns the List of Deactivate Person Request.
	 *
	 * @return the deactivatePersonRequest
	 */
	public List<Parameter> getDeactivatePersonRequest() {
		return deactivatePersonRequest;
	}

	/**
	 * Sets the List of Deactivate Person Request.
	 *
	 * @param deactivatePersonRequest the deactivatePersonRequest to set
	 */
	public void setDeactivatePersonRequest(List<Parameter> deactivatePersonRequest) {
		this.deactivatePersonRequest = deactivatePersonRequest;
	}
	
	/**
	 * Returns the String representation of Deactivate Person Batch Request Model.
	 * 
	 * @return String String representation of Deactivate Person Batch Request
	 *         Model
	 */
	@Override
	public String toString() {
		return "RequestForBatchDeactivatePerson [deactivatePersonRequest=" + deactivatePersonRequest + "]";
	}
}
