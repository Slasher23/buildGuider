package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for RequestForAgreementNotificationResponse.
 * 
 * @since 12/12/2017
 * @author ZE2JAVO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2JAVO    Initial Version
 *          </pre>
 */
public class RequestForBatchAgreementNotificationResponse {
	List<RequestForAgreementNotificationResponse> agreementNotificationsResponse;

	List<RequestForAgreementNotificationResponse> agreementNotificationsResponseWithErrors;

	/**
	 * @return the agreementNotificationsResponse
	 */
	public List<RequestForAgreementNotificationResponse> getAgreementNotificationsResponse() {
		return agreementNotificationsResponse;
	}

	/**
	 * @param agreementNotificationsResponse
	 *            the agreementNotificationsResponse to set
	 */
	public void setAgreementNotificationsResponse(
			List<RequestForAgreementNotificationResponse> agreementNotificationsResponse) {
		this.agreementNotificationsResponse = agreementNotificationsResponse;
	}

	/**
	 * @return the agreementNotificationsResponseWithErrors
	 */
	public List<RequestForAgreementNotificationResponse> getAgreementNotificationsResponseWithErrors() {
		return agreementNotificationsResponseWithErrors;
	}

	/**
	 * @param agreementNotificationsResponseWithErrors
	 *            the agreementNotificationsResponseWithErrors to set
	 */
	public void setAgreementNotificationsResponseWithErrors(
			List<RequestForAgreementNotificationResponse> agreementNotificationsResponseWithErrors) {
		this.agreementNotificationsResponseWithErrors = agreementNotificationsResponseWithErrors;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RequestForBatchAgreementNotificationResponse [agreementNotificationsResponse="
				+ agreementNotificationsResponse + ", agreementNotificationsResponseWithErrors="
				+ agreementNotificationsResponseWithErrors + "]";
	}

}
