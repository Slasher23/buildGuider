package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * Model Class for CustomerNotificationsBatchResponse
 * 
 * @since 12/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "RequestForBatchUpdatePartyResponse")
public class RequestForBatchUpdatePartyResponse {

    private List<ZslUpdateResponse> updatePartyResponse; 
    
    private List<ZslUpdateResponse> updatePartyResponseWithErrors;

    /**
     * @return the updatePartyResponse
     */
    public List<ZslUpdateResponse> getUpdatePartyResponse() {
        return updatePartyResponse;
    }

    /**
     * @param updatePartyResponse the updatePartyResponse to set
     */
    public void setUpdatePartyResponse(List<ZslUpdateResponse> updatePartyResponse) {
        this.updatePartyResponse = updatePartyResponse;
    }

    /**
     * @return the updatePartyResponseWithErrors
     */
    public List<ZslUpdateResponse> getUpdatePartyResponseWithErrors() {
        return updatePartyResponseWithErrors;
    }

    /**
     * @param updatePartyResponseWithErrors the updatePartyResponseWithErrors to set
     */
    public void setUpdatePartyResponseWithErrors(List<ZslUpdateResponse> updatePartyResponseWithErrors) {
        this.updatePartyResponseWithErrors = updatePartyResponseWithErrors;
    }

    /* 
     * @return
     */
    @Override
    public String toString() {
        return "RequestForBatchUpdatePartyResponse [updatePartyResponse=" + updatePartyResponse
                + ", updatePartyResponseWithErrors=" + updatePartyResponseWithErrors + "]";
    } 
    
}
