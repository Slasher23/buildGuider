package com.commerzbank.gdk.bns.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Settings;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.TranslationService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Service Class implementation to retrieve translatedTexts
 * 
 * @since 21/12/2017
 * @author ZE2FUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/02/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */
@Service
public class TranslationServiceImpl implements TranslationService {

    @Autowired
    private Settings settings;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger LOGGER = LoggerFactory.getLogger(TranslationServiceImpl.class);

    private static final String acceptLanuageKey = "Accept-Language";

    @Override
    public ResponseBuilder<Map<String, String>> getTranslatedTexts(HttpServletRequest request, Tokenizer token) {

        ResponseBuilder<Map<String, String>> builder = new ResponseBuilder<>(LOGGER, token, globalResponseWrapper);

        String acceptLanguage = request.getHeader(acceptLanuageKey).toUpperCase();
        String locale = "EN";

        if (acceptLanguage.contains("DE")) {
            locale = "DE";
        }

        LOGGER.info("=>> User [{}] getTranslation({})", token.getUserId(), acceptLanguage);

        try {
            String lang = this.settings.getLocale(locale);
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() {
            };
            Map<String, String> map = mapper.readValue(lang, typeRef);
            builder.OK(map, Response.SUCCESS_RESULTS_FOUND);
        } catch (Exception e) {
            builder.notOK(Response.GENERAL_FUNCTION_ERROR);
            LOGGER.error(e.getMessage());
        }

        return builder;
    }

}
