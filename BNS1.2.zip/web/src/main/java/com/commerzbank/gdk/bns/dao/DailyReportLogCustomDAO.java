package com.commerzbank.gdk.bns.dao;

import java.util.Date;

/**
 * Custom Daily Report Log DAO Interface
 * 
 * @since 11/01/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 11/01/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */

public interface DailyReportLogCustomDAO {
    
    Integer countDailyReportLog(Date date, String eventType, String status);
    
}
