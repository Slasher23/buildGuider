package com.commerzbank.gdk.bns.controller.report;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.GenerateReportRequest;
import com.commerzbank.gdk.bns.model.Report;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.GenerateReportService;

/**
 * Report Generator Controller - Accept request to generate CSV report files
 * based on the start date, end date and report type provided
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2BUEN    Initial Version
 * 09/01/2018        1.01       ZE2BUEN    Added method GET
 * 06/02/2018        1.02       ZE2FUEN    Activated controller only for local, dev and tuc
 *          </pre>
 */

@RestController
@Profile({ "local", "dev", "tuc" })
public class ReportGeneratorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportGeneratorController.class);

    private static final String FILE_FORMAT = ".csv";

    private static final String RPT001 = "RPT001";
    private static final String RPT002 = "RPT002";
    private static final String RPT003 = "RPT003";
    private static final String RPT004 = "RPT004";
    private static final String RPT005 = "RPT005";
    private static final String RPT006 = "RPT006";
    private static final String RPT007 = "RPT007";

    @Autowired
    Environment environment;

    @Autowired
    private GenerateReportService generateReportService;

    /**
     * Accept client post generate report request then call service to generate
     * CSV report files based on the start date, end date and report type
     * provided then return CSV file
     *
     * @param response
     *            HttpServletResponse HTTP Servlet Response
     * @param result
     *            BindingResult Binding Result
     * @return ResponseEntity Generate Report Response Entity
     * @throws Exception
     *             Throws when an error occurs
     * 
     */
    @PostMapping(value = "/api/generateReport/")
    public ResponseEntity<Resource> postGenerateCsvReport(
            @Valid @RequestBody GenerateReportRequest generateReportRequest, HttpServletRequest request,
            HttpServletResponse response, BindingResult result, Authentication auth) throws Exception {

        Tokenizer token = Tokenizer.getUserToken(auth);

        LOGGER.info("=>> User [{}] postGenerateCsvReport({})", "Admin", generateReportRequest.toString());

        List<Report> reportList = new ArrayList<>();

        reportList = this.generateReportService.retrieveReportData(token, generateReportRequest).getData();

        if (!reportList.isEmpty()) {

            this.setHeaders(response, this.getReportFileName(generateReportRequest.getReportType()));

            this.generateReportService.generateCSVFile(response.getWriter(), generateReportRequest.getReportType(),
                    reportList, token);
        }

        return new ResponseEntity<Resource>(HttpStatus.OK);

    }

    /**
     * Accept client get generate report request then call service to generate
     * CSV report files based on the start date, end date and report type
     * provided then return CSV file
     *
     * @param startDate
     *            String Start Date Request Parameter
     * @param endDate
     *            String End Date Request Parameter
     * @param reportType
     *            String Report Type Request Parameter
     * @param request
     *            HttpServletRequest HTTP Servlet Request
     * @param response
     *            HttpServletResponse HTTP Servlet Response
     * @return ResponseEntity Generate Report Response Entity
     * @throws Exception
     *             Throws when an error occurs
     * 
     */
    @GetMapping(value = "/api/generateReport/")
    public ResponseEntity<Resource> getGenerateCsvReport(@RequestParam("startDate") String startDate,
            @RequestParam("endDate") String endDate, @RequestParam("reportType") String reportType,
            HttpServletRequest request, HttpServletResponse response) throws Exception {

        Tokenizer token = new Tokenizer();

        GenerateReportRequest generateReportRequest = new GenerateReportRequest();
        generateReportRequest.setStartDate(startDate);
        generateReportRequest.setEndDate(endDate);
        generateReportRequest.setReportType(reportType);

        LOGGER.info("=>> User [{}] getGenerateCsvReport({})", "Admin", generateReportRequest.toString());

        List<Report> reportList = new ArrayList<>();

        this.setHeaders(response, this.getReportFileName(generateReportRequest.getReportType()));

        reportList = this.generateReportService.retrieveReportData(token, generateReportRequest).getData();

        if (!reportList.isEmpty()) {
            this.generateReportService.generateCSVFile(response.getWriter(), generateReportRequest.getReportType(),
                    reportList, token);
        }

        return new ResponseEntity<Resource>(HttpStatus.OK);

    }

    /**
     * Sets the required header for the HTTP Response
     * 
     * @param response
     *            HttpServletResponse HTTP Servlet Response
     * @param fileName
     *            String Report File Name
     */
    private void setHeaders(HttpServletResponse response, String fileName) {

        response.setContentType("text/csv");
        String headerKey = "Content-Disposition";
        String headerValue;
        headerValue = String.format("attachment; filename=\"%s\"", fileName);

        response.setHeader(headerKey, headerValue);

    }

    /**
     * Returns Report File Name based on the Report Type
     * 
     * @param reportType
     *            String Report Type
     * @return String Report File Name
     */
    private String getReportFileName(String reportType) {

        String timeStamp = new SimpleDateFormat("_yyyyMMdd_hhmmss").format(Calendar.getInstance().getTime());
        String fileName = null;

        switch (reportType) {

            case RPT001:
                fileName = RPT001 + "_" + this.environment.getProperty(RPT001);
                break;

            case RPT002:
                fileName = RPT002 + "_" + this.environment.getProperty(RPT002);
                break;

            case RPT003:
                fileName = RPT003 + "_" + this.environment.getProperty(RPT003);
                break;

            case RPT004:
                fileName = RPT004 + "_" + this.environment.getProperty(RPT004);
                break;

            case RPT005:
                fileName = RPT005 + "_" + this.environment.getProperty(RPT005);
                break;

            case RPT006:
                fileName = RPT006 + "_" + this.environment.getProperty(RPT006);
                break;

            case RPT007:
                fileName = RPT007 + "_" + this.environment.getProperty(RPT007);
                break;

        }

        return fileName + timeStamp + FILE_FORMAT;

    }

}
