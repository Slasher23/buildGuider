package com.commerzbank.gdk.bns.common.exception;

import java.sql.SQLException;

import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.commerzbank.frame.architecture.exception.SystemException;
import com.commerzbank.frame.security.ticket.core.validator.TicketException;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;

import io.jsonwebtoken.SignatureException;

/**
 * GlobalExceptionHandler Handles exception and return the expected response
 * message to client.
 * 
 * @since 09/08/2017
 * @author ZE2CRUH
 * @version 1.04
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 09/08/2017        1.00       ZE2CRUH    Initial Version
 * 21/09/2017        1.01       ZE2GOME    Updated Version 
 * 15/11/2017        1.02       ZE2MACL    Updated Version 
 * 16/11/2017        1.03       ZE2MACK    Updated Http Statuses and Added new exception handler
 * 23/02/2018        1.04       ZE2BUEN    Added new exception handler
 * </pre>
 */
@ControllerAdvice
@Order(2)
public class GlobalExceptionHandler {

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Exception Handler for HttpMessageNotReadableException
     * 
     * @param e HttpMessageNotReadableException
     * @return the Response
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Response<String>> returnNotReadableException(HttpMessageNotReadableException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString());

        logger.info(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.BAD_REQUEST);
    }

    /**
     * Exception Handler for DataAccessException
     * 
     * @param e DataAccessException
     * @return the ResponseMessage
     */
    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<Response<String>> returnDataAccessException(DataAccessException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        logger.error(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler for IllegalArgumentException
     * 
     * @param e IllegalArgumentException
     * @return the ResponseMessage
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Response<String>> returnIllegalArgumentsException(IllegalArgumentException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        logger.error(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler for NullPointerException
     * 
     * @param e NullPointerException
     * @return the ResponseMessage
     */
    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<Response<String>> returnNullPointerException(NullPointerException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        logger.error(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler for SQLException
     * 
     * @param e SQLException
     * @return the ResponseMessage
     */
    @ExceptionHandler(SQLException.class)
    public ResponseEntity<Response<String>> returnSQLException(SQLException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        logger.error(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler for ConstraintViolationException
     * 
     * @param e ConstraintViolationException
     * @return the ResponseMessage
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Response<String>> returnConstraintViolationException(ConstraintViolationException e) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        logger.error(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Exception Handler for NoHandlerFoundException
     * 
     * @param e NoHandlerFoundException
     * @return the ResponseMessage
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<Response<String>> handleNoHandlerFoundException(NoHandlerFoundException ex) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString());

        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    /**
     * Exception Handler for Frame's SignatureException
     * 
     * @param e SignatureException
     * @return the ResponseMessage
     */
    @ExceptionHandler(SignatureException.class)
    public ResponseEntity<Response<String>> handleSignatureException(SignatureException ex) {
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString());

        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    /**
     * Exception Handler for Frame's TicketException
     * 
     * @param e TicketException
     * @return the ResponseMessage
     */
    @ExceptionHandler(TicketException.class)
    public ResponseEntity<Response<String>> handleTicketException(TicketException ex) {
       
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString());

        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    /**
     * Exception Handler for Frame's ValidationException
     * 
     * @param e ValidationException
     * @return the ResponseMessage
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Response<String>> handleValidationException(TicketException ex) {
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString());

        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    /**
     * Exception Handler for Frame's SystemException
     * 
     * @param e SystemException
     * @return the ResponseMessage
     */
    @ExceptionHandler(SystemException.class)
    public ResponseEntity<Response<String>> handleSystemException(TicketException ex) {
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.SERVICE_UNAVAILABLE.toString());

        logger.error(ex.getMessage(), ex);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    /**
     * Exception Handler for MethodArgumentNotValidException
     * 
     * @param e MethodArgumentNotValidException
     * @return the Response
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Response<String>> returnMethodArgumentNotValidException(MethodArgumentNotValidException  e) {

		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        Response<String> respMsg = globalResponseWrapper.get(HttpStatus.BAD_REQUEST.toString());
        
        logger.info(e.getMessage(), e);

        return new ResponseEntity<Response<String>>(respMsg, headers, HttpStatus.BAD_REQUEST);
	}

}
