package com.commerzbank.gdk.bns.dao.impl;

import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.ScheduleLockerCustomDAO;
import com.commerzbank.gdk.bns.model.ScheduleLocker;

/**
 * DAO Implementation Class to manage ScheduleLocker
 * 
 * @since 14/02/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 14/02/2018       1.00        ZE2RUBI     Initial Version
 *          </pre>
 */
@Repository
public class ScheduleLockerDAOImpl implements ScheduleLockerCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    /**
     * Check if the node is active by identifying if it has the minimum random
     * number
     * 
     * @param nodeName a concatenation of server name and nodename for
     *        uniqueness
     * @return Boolean true if it is an active node
     */
    @Override
    public boolean getActiveScheduleLocker(String nodeName) {

        ScheduleLocker scheduleLocker = this.entityManager
                .createQuery("FROM ScheduleLocker s WHERE random =(SELECT MIN(s.random) FROM s )", ScheduleLocker.class)
                .getSingleResult();

        if (Objects.nonNull(scheduleLocker)) {

            if (scheduleLocker.getNodeName().equals(nodeName)) {

                return true;

            }
        }

        return false;
    }

}
