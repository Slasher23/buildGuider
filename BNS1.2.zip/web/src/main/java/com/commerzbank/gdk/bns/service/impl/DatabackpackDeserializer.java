package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Customer;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.KeyService;

/**
 * Service Class used to implement the business logic in
 * converting String Databackpack from CIF to BNS Object
 * 
 * @since 26/02/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 26/02/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */

@Service
public class DatabackpackDeserializer {

	private static final String KDNR = "kdnr";

	private static final String EMAIL_ADD = "emailadd";
	private static final String ADD_ID = "addID";

	private static final String PROD_ID = "prodId";
	private static final String PROD_CAT = "prodcat";
	private static final String PROD_NAME = "prodname";
	private static final String IBAN = "iban";
	private static final String PROD_BRANCH = "prodbranch";

	private static final String PERSON_DOCUMENTS_ACTIVATED = "personDocumentsActivated";

	private static final String FIRST_NAME = "firstname";
	private static final String LAST_NAME = "lastname";
	private static final String TITLE = "title";
	private static final String SALUTATION = "salutation";

	private static final String TITLE_KEY_TYPE = "PAKTL";
	private static final String SALUTATION_KEY_TYPE = "BBANR";

	@Autowired
	private KeyService keyService;

	/**
	 * Converts String Databackpack from CIF to BNS Object
	 * 
	 * @param databackpack
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	public Databackpack databackpackDeserializer(String databackpack) {

		Databackpack result = new Databackpack();

		result.setIsValid(true);

		try {

			List<String> dataList = this.splitByDelimiter(databackpack, ";", null);

			for (String data : dataList) {
				result = this.convertToBNSObject(result, data);
			}

			result = this.validateBNSObject(result);

		} catch (Exception e) {
			result.setIsValid(false);
		}

		return result;
	}

	/**
	 * Convert String Databackpack to BNS Object
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack convertToBNSObject(Databackpack databackpack, String data) {

		if (data.contains(KDNR)) {
			this.setCustomer(databackpack, data);
		} else if (data.contains(EMAIL_ADD)) {
			this.setEmail(databackpack, data);
		} else if (data.contains(PROD_ID)) {
			this.setAgreement(databackpack, data);
		} else if (data.contains(PERSON_DOCUMENTS_ACTIVATED)) {
			this.setNotifConfigPerson(databackpack, data);
		} else if (data.contains(FIRST_NAME)) {
			this.setPerson(databackpack, data);
		}

		return databackpack;

	}

	/**
	 * Set Customer details
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack setCustomer(Databackpack databackpack, String data) {

		try {

			List<String> keyValueList = this.splitByDelimiter(data, "=", 2);

			String value = null;

			List<Customer> customerList = databackpack.getCustomerList();

			if (Objects.isNull(customerList)) {
				customerList = new ArrayList<>();
			}

			if (keyValueList.size() == 2) {

				value = keyValueList.get(1);

				if (!value.isEmpty() && Objects.nonNull(value)) {

					Customer customer = new Customer();
					customer.setCustomerNumber(value);

					customerList.add(customer);
				} else {
					databackpack.setIsValid(false);
				}

			} else {
				databackpack.setIsValid(false);
			}

			databackpack.setCustomerList(customerList);

		} catch (Exception e) {
			databackpack.setIsValid(false);
		}

		return databackpack;

	}

	/**
	 * Set Email details
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack setEmail(Databackpack databackpack, String data) {

		try {

			List<String> paramList = this.splitByDelimiter(data, ",", null);
			List<Email> emailList = databackpack.getEmailList();

			if (Objects.isNull(emailList)) {
				emailList = new ArrayList<>();
			}

			Email email = new Email();

			for (String param : paramList) {

				List<String> keyValueList = this.splitByDelimiter(param, "=", 2);

				String key = null;
				String value = null;

				if (keyValueList.size() == 2) {

					key = keyValueList.get(0);
					value = keyValueList.get(1);

					if (!value.isEmpty() && Objects.nonNull(value)) {

						switch (key) {
						case EMAIL_ADD:
							email.setEmailAddress(value);
							break;

						case ADD_ID:
							email.setAddressId(Long.valueOf(value));
							break;
						}
					}

				}

			}

			if (Objects.nonNull(email.getEmailAddress()) && Objects.nonNull(email.getAddressId())) {
				emailList.add(email);
			} else {
				databackpack.setIsValid(false);
			}

			databackpack.setEmailList(emailList);

		} catch (Exception e) {
			databackpack.setIsValid(false);
		}

		return databackpack;

	}

	/**
	 * Set Notification Configuration Person
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack setNotifConfigPerson(Databackpack databackpack, String data) {

		try {

			List<String> keyValueList = this.splitByDelimiter(data, "=", 2);
			String value = null;

			if (keyValueList.size() == 2) {

				value = keyValueList.get(1);

				if (!value.isEmpty() && Objects.nonNull(value)) {

					NotificationConfigPerson notifConfigPerson = new NotificationConfigPerson();

					notifConfigPerson.setActive(Boolean.parseBoolean(value));

					databackpack.setNotificationConfigPerson(notifConfigPerson);

				} else {
					databackpack.setIsValid(false);
				}

			} else {
				databackpack.setIsValid(false);
			}

		} catch (Exception e) {
			databackpack.setIsValid(false);
		}

		return databackpack;

	}

	/**
	 * Set Agreement details
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack setAgreement(Databackpack databackpack, String data) {

		try {

			// Extract the customer first and then delete them from the list
			String customerName = "";

			// Search customer from middle and last pattern in the DBPack
			String searchPattern = "(customername=(.*?)(?=iban|prod|;|person)|customername=(.*))";

			Pattern pattern = Pattern.compile(searchPattern, Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(data);

			if (matcher.find()) {
				customerName = matcher.group(1);
			}

			// remove it from the list
			data = data.replaceAll(searchPattern, "");

			// Now continue with the same old implementation
			List<String> paramList = this.splitByDelimiter(data, ",", null);
			List<Agreement> agreementList = databackpack.getAgreementList();

			if (Objects.isNull(agreementList)) {
				agreementList = new ArrayList<>();
			}

			Agreement agreement = new Agreement();

			// We add first the customer
			agreement.setCustomerName(this.concatAgreementCustomerName(customerName));

			for (String param : paramList) {

				List<String> keyValueList = this.splitByDelimiter(param, "=", 2);

				String key = null;
				String value = null;

				if (keyValueList.size() == 2) {

					key = keyValueList.get(0);
					value = keyValueList.get(1);

					if (!value.isEmpty() && Objects.nonNull(value)) {

						switch (key) {
						case PROD_ID:
							agreement.setAgreementID(value);
							break;

						case PROD_CAT:
							agreement.setAgreementType(convertAgreemenType(value));
							break;

						case PROD_NAME:
							agreement.setType(value);
							break;

						case IBAN:
							agreement.setIban(value);
							break;

						case PROD_BRANCH:
							agreement.setBranch(Integer.valueOf(value));
							break;

						}
					}

				}

			}

			if (Objects.nonNull(agreement.getAgreementID()) && Objects.nonNull(agreement.getBranch())) {
				agreementList.add(agreement);
			} else {
				databackpack.setIsValid(false);
			}

			databackpack.setAgreementList(agreementList);

		} catch (Exception e) {
			databackpack.setIsValid(false);
		}

		return databackpack;

	}

	/**
	 * Convert Word type to COde
	 * 
	 * @param type
	 *            agreementType in words
	 * @return type String on code
	 */
	private String convertAgreemenType(String type) {
		String newType = "";

		type = type.toUpperCase();

		switch (type) {
		case "KONTEN":
			newType = "KTO";
			break;

		case "KARTEN":
			newType = "KAR";
			break;

		case "DEPOTS":
			newType = "WP";
			break;

		case "KREDIT":
			newType = "KRE";
			break;

		case "VORSORGE":
			newType = "VOR";
			break;

		case "ACCOUNTS":
			newType = "KTO";
			break;

		case "CARDS":
			newType = "KAR";
			break;

		case "SECURITIES":
			newType = "WP";
			break;

		case "LOANS":
			newType = "KRE";
			break;

		case "INSURANCE AND BAUSPAREN":
			newType = "VOR";
			break;

		}

		return newType;

	}

	/**
	 * Set Person details
	 * 
	 * @param databackpack
	 *            databackpack
	 * @param data
	 *            String
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack setPerson(Databackpack databackpack, String data) {

		try {

			List<String> paramList = this.splitByDelimiter(data, ",", null);
			Person person = new Person();

			for (String param : paramList) {

				List<String> keyValueList = this.splitByDelimiter(param, "=", 2);
				String key = null;
				String value = null;

				if (keyValueList.size() == 2) {

					key = keyValueList.get(0);
					value = keyValueList.get(1);

					if (!value.isEmpty() && Objects.nonNull(value)) {

						switch (key) {
						case FIRST_NAME:
							person.setGivenName(value);
							break;

						case LAST_NAME:
							person.setLastName(value);
							break;

						case TITLE:
							person.setTitle(this.keyService.getKeyCodeByValue(TITLE_KEY_TYPE, value));
							break;

						case SALUTATION:
							person.setSalutation(this.keyService.getKeyCodeByValue(SALUTATION_KEY_TYPE, value));
							break;

						}
					}

				}

			}

			if (Objects.nonNull(person.getGivenName()) && Objects.nonNull(person.getLastName())) {
				databackpack.setPerson(person);
			} else {
				databackpack.setIsValid(false);
			}

		} catch (Exception e) {
			databackpack.setIsValid(false);
		}

		return databackpack;

	}

	/**
	 * Will clean the customer name list
	 * 
	 * @param agreementCustomerName
	 * @return String Concatenated Name
	 */
	private String concatAgreementCustomerName(String agreementCustomerName) {

		// Remove the customername in the agreementCustomerName
		List<String> customerName = this.splitByDelimiter(agreementCustomerName, "=", 2);

		// Replace the UND with comma instead
		String cleanCustomerName = customerName.get(1).replaceAll("\\s(UND|AND|und|and)(,|\\s)?", ", ");

		List<String> customerList = this.splitByDelimiter(cleanCustomerName, ",", null);

		StringBuilder concatenatedName = new StringBuilder();

		boolean stringExceeds = false;

		for (String name : customerList) {
			if ((name.length() + concatenatedName.length()) < 500) {
				concatenatedName.append(name + ",");
			} else {
				stringExceeds = true;
				break;
			}
		}

		if (!stringExceeds) {
			return concatenatedName.toString().substring(0, concatenatedName.toString().length() - 1);
		}

		return concatenatedName.toString();
	}

	/**
	 * Split String by Delimiter
	 * 
	 * @param data
	 *            String
	 * @param delimiter
	 *            String
	 * @param splitCount
	 *            Integer
	 * @return List List of Strings
	 */
	private List<String> splitByDelimiter(String data, String delimiter, Integer splitCount) {

		List<String> dataList = new ArrayList<>();

		if (Objects.nonNull(splitCount)) {
			dataList = Arrays.asList(data.split(delimiter, splitCount));
		} else {
			dataList = Arrays.asList(data.split(delimiter));
		}

		return dataList;

	}

	/**
	 * Validate BNS Object
	 * 
	 * @param databackpack
	 *            databackpack
	 * @return Databackpack Databackpack BNS Object
	 */
	private Databackpack validateBNSObject(Databackpack databackpack) {

		if (Objects.nonNull(databackpack)) {

			if (Objects.isNull(databackpack.getCustomerList())
					|| Objects.isNull(databackpack.getNotificationConfigPerson())
					|| Objects.isNull(databackpack.getPerson())) {
				databackpack.setIsValid(false);
			}

		}

		return databackpack;

	}

}
