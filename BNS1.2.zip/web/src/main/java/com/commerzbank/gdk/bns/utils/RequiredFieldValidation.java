/**
 * 
 *
 */
package com.commerzbank.gdk.bns.utils;

import java.util.HashSet;

import org.springframework.stereotype.Component;

/**
 * Class for String builder of required field validation
 * 
 * @since 21/02/2018
 * @author ZE2MENY
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 21/02/2018        1.00       ZE2MACL    Initial Version
 *          </pre>
 */
@Component
public class RequiredFieldValidation {

    StringBuilder stringBuilderField  = new StringBuilder("FA- Invalid request field ");
    StringBuilder stringBuilderFields = new StringBuilder("FA- Invalid request -fields ");
    String        faFields            = "FA- Invalid request - fields ";
    String        faField             = "FA- Invalid request - field ";
    String        isMandatory         = " is mandatory";
    String        areMandatory        = " are mandatory";

    String inValidMsg = null;

    public String requiredField(HashSet<String> requiredField) {
        String delim = "";
        inValidMsg = "";
        for (String reqField : requiredField) {
            if (requiredField.size() > 1) {
                inValidMsg = stringBuilderFields.append(delim).append(reqField).toString();
            } else {
                inValidMsg = stringBuilderField.append(reqField).append(isMandatory).toString();
            }
            delim = ",";

        }

        stringBuilderField.setLength(0);
        stringBuilderField = new StringBuilder(faField);
        stringBuilderFields.setLength(0);
        stringBuilderFields = new StringBuilder(faFields);

        if (requiredField.size() > 1) {
            inValidMsg += (areMandatory);
        }

        return inValidMsg;

    }

}
