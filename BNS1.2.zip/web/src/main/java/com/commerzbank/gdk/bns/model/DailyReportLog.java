package com.commerzbank.gdk.bns.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for DailyReportLog Table
 * 
 * @since 04/01/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2RUBI    Initial Version
 * </pre>
 */

@Entity
@Table(name = "DAILY_REPORT_LOG")
@XmlRootElement
public class DailyReportLog {

	@Id
	@Column(name = "DAILY_REPORT_LOG_UID")
	@GeneratedValue(generator = "DAILY_REPORT_LOG_ID_SEQ")
	@SequenceGenerator(name = "DAILY_REPORT_LOG_ID_SEQ", sequenceName = "DAILY_REPORT_LOG_SEQ")
	private Long dailyReportLogUID;
	
    @Pattern(regexp = "^[a-zA-Z0-9. /-]*$")
    @Size(min = 0, max = 16)
    @Column(name = "BPKENN")
    private String bpkenn;
    
    @Column(name = "EVENT_TYPE")
    private String eventType;

    @Column(name = "STATUS")
    private String status;

    @Basic(optional = false)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "TIMESTAMP", insertable = true, updatable = false)
    private Date timestamp;

    /**
     * @return the dailyReportLogUID
     */
    public Long getDailyReportLogUID() {
        return dailyReportLogUID;
    }

    /**
     * @param dailyReportLogUID the dailyReportLogUID to set
     */
    public void setDailyReportLogUID(Long dailyReportLogUID) {
        this.dailyReportLogUID = dailyReportLogUID;
    }

    /**
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * @param bpkenn the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * @return the eventType
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * @param eventType the eventType to set
     */
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the timestamp
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DailyReportLog [dailyReportLogUID=" + dailyReportLogUID + ", bpkenn=" + bpkenn + ", eventType="
                + eventType + ", status=" + status + ", timestamp=" + timestamp + "]";
    }
    
    
}
