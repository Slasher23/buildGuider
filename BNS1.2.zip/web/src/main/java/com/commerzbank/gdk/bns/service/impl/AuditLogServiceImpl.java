package com.commerzbank.gdk.bns.service.impl;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.EventType;
import com.commerzbank.gdk.bns.model.GlobalEventTypeWrapper;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AuditLogService;
import com.commerzbank.gdk.bns.service.CustomerAdvisorLogService;

/**
 * Service Implementation Class used to implement business logic service in
 * logging events
 * 
 * @author ZE2RUBI
 * @version 1.04
 * @since 04/08/2017
 * 
 *        <pre>
 *  
 * Modified Date	Version		Author		Description
 * 04/08/2017		1.00		ZE2RUBI 	InitialVersion
 * 10/04/2017       1.01        ZE2MACK     Remove unneeded service method
 * 14/11/2017       1.02        ZE2MACL     Updated method to used response builder and added token parameter
 * 24/11/2017       1.03        ZE2MORA     Implemented Status Codes
 * 07/12/2017       1.04        ZE2BUEN     Refactor Audit Log service to save details on log file
 * 23/02/2018       1.05        ZE2FUEN     Logged Customer advisor logs based on roles
 *        </pre>
 */
@Transactional
@Service
public class AuditLogServiceImpl implements AuditLogService{

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditLogServiceImpl.class);

    @Value("${CBE_ROLE}")
    private String cbeRole;
    
    @Autowired
    private GlobalEventTypeWrapper globalEventType;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;
    
    @Autowired
    private CustomerAdvisorLogService customerAdvisorLog;

    /**
     * Retrieves the value of Audit Log using Event Type
     * 
     * @param token to identify the user
     * @param auditLog AuditLog to set
     * @return AuditLog Save auditLog
     */
    @Override
    public ResponseBuilder<AuditLog> save(Tokenizer token, AuditLog auditLog) {

        ResponseBuilder<AuditLog> builder = new ResponseBuilder<AuditLog>(LOGGER, token, globalResponseWrapper);

        try {

            EventType event = globalEventType.get(auditLog.getEventType());
            auditLog.setObjectType(event.getObjectType());
            auditLog.setEventType(event.getType());
            auditLog.setDescription(event.getDescription());

            builder.OK(auditLog);

        } catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
            builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        LOGGER.info("<<= User [{}] save({}) request was successfully processed.", token.getUserId(),
                        auditLog.toString());

        if(token.getRole().toUpperCase().equals(cbeRole.toUpperCase())){
            customerAdvisorLog.saveLog(token, auditLog);
        } else {
            LOGGER.info("=>> AUDIT LOG: [{}]", auditLog.toString());
        }
        
        return builder;
    }

 

}
