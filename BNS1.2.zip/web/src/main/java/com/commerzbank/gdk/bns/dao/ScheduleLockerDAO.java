package com.commerzbank.gdk.bns.dao;

import org.springframework.data.repository.CrudRepository;

import com.commerzbank.gdk.bns.model.ScheduleLocker;

/**
 * ScheduleLocker DAO Interface
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 15/02/2018		1.00		ZE2RUBI 	Initial Version
 *          </pre>
 */

public interface ScheduleLockerDAO extends CrudRepository<ScheduleLocker, Long>, ScheduleLockerCustomDAO {

}
