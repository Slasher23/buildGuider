package com.commerzbank.gdk.bns.service.impl;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.InitialContext;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.ScheduleLockerDAO;
import com.commerzbank.gdk.bns.model.ScheduleLocker;
import com.commerzbank.gdk.bns.service.ScheduleLockerService;

/**
 * Service Implementation Class used to implement the business logic in locking
 * schedule task
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.00
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 15/02/2018       1.00        ZE2RUBI     Initial Version
 *          </pre>
 */
@Service
@Transactional
public class ScheduleLockerServiceImpl implements ScheduleLockerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleLockerServiceImpl.class);

    @Autowired
    private ScheduleLockerDAO scheduleLockerDAO;
   
    /**
     * Initialise Schedule Locker by cleaning old data and inserting new data on the database
     * 
     */
    private void initLocker() {

        final ZoneId defaultZoneId = ZoneId.systemDefault();
        
        LocalDateTime current = LocalDateTime.now(defaultZoneId);
 
        this.cleanScheduleNodes(current,defaultZoneId);
        
        Date schedDate = Date.from(current.atZone(ZoneId.systemDefault()).toInstant());
        
        SecureRandom secRan = new SecureRandom();

        this.scheduleLockerDAO.save(new ScheduleLocker(Long.valueOf(0), nodeName() , secRan.nextInt(100000),schedDate));

    }
    
    /**
     * Check if the node is active by identifying if it has the minimum random
     * number
     * 
     * @return Boolean true if it is an active node
     */
    @Override
    public boolean isNodeActive() {
        
        this.initLocker();
        
        String nodeName = this.nodeName();
        
        if(this.scheduleLockerDAO.getActiveScheduleLocker(nodeName)){
            
            LOGGER.info("Scheduled Job's will be executed by node: " + nodeName);
            
            return true;
        }
        
        return false;
        
    }
    
    /**
     * Cleans or delete existing Schedule Nodes data in the database.
     * All data later than the current time subtracted by 2 seconds 
     * will be deleted in the database.
     * 
     */
    private void cleanScheduleNodes(LocalDateTime current, ZoneId defaultZoneId) {
        
        List<Long> uid = new ArrayList<Long>();
        
        scheduleLockerDAO.findAll().forEach(item -> {

            current.plusSeconds(-2);

            Instant instant = item.getUpdated_at().toInstant();

            LocalDateTime dbData = instant.atZone(defaultZoneId).toLocalDateTime();

            if (current.isAfter(dbData)) {
                uid.add(item.getUid());
            }
            
        });

        uid.forEach(i -> {
            scheduleLockerDAO.delete(i);
        });
        
    }
    
    /**
     * Retrieve the server name and node name of the host.
     * 
     * @return String server name concatenated by node name
     */
    public String nodeName() {
        
        String serverName = null;
        String node = null;
        
        try {
            
            InitialContext ic = new javax.naming.InitialContext();

            serverName = ic.lookup("servername").toString();

            node = ic.lookup("thisNode/nodename").toString();
            
            ic.close();
            
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }
        
        return serverName.concat("_").concat(node);

    }
    
}
