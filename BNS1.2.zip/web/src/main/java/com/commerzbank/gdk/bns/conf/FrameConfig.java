package com.commerzbank.gdk.bns.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import com.commerzbank.frame.jws.rest.standards.CommerzbankStandardsHandlerInterceptor;
import com.commerzbank.frame.jws.rest.standards.ticket.ApplicationTicketProcessingAdapter;
import com.commerzbank.frame.jws.rest.standards.ticket.JWTTicketConverter;
import com.commerzbank.frame.jws.rest.standards.ticket.UserTicketProcessingAdapter;
import com.commerzbank.frame.jws.rest.standards.tracing.ActivityIdProcessingAdapter;
import com.commerzbank.frame.jws.rest.standards.tracing.MachineNameProcessingAdapter;
/**
 * This class handles the configuration of the frame-security and validations
 * 
 * @author ZE2RUBI
 * @since 12/02/2018
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 12/02/2018        1.00       ZE2RUBI    Initial Version
 * </pre>
 * **/

@Configuration
@ImportResource({
    "classpath:/spring/security/ticket/converter-defaults.xml",
    "classpath:/spring/security/ticket/validator-defaults.xml",
    "classpath:/spring/jws/rest/jaxrs-client-defaults.xml"})
public class FrameConfig {

    @Bean
    public CommerzbankStandardsHandlerInterceptor commerzbankStandardsHandlerInterceptor() {
        return new CommerzbankStandardsHandlerInterceptor();
    }
    
    @Bean(name = "jaxrs.rest.jwtTicketConverter")
    public JWTTicketConverter jwtTicketConverter() {
        return new JWTTicketConverter();
    }
    
    @Bean
    public UserTicketProcessingAdapter userTicketProcessingAdapter() {
        return new UserTicketProcessingAdapter();
    }

    @Bean
    public ApplicationTicketProcessingAdapter applicationTicketProcessingAdapter() {
        return new ApplicationTicketProcessingAdapter();
    }

    @Bean
    public MachineNameProcessingAdapter machineNameProcessingAdapter() {
        return new MachineNameProcessingAdapter();
    }

    @Bean
    public ActivityIdProcessingAdapter activityIdProcessingAdapter() {
        return new ActivityIdProcessingAdapter();
    }



//    @Bean(name = "security.ticket.noSignatureCommonTicketValidator")
//    public CommonTicketValidator commonTicketValidator() {
//        CommonTicketValidator ctv = new CommonTicketValidator();
//        ctv.setTicketConverter(commonTicketConverter());
//        ctv.setSignatureService(DefaultAsymmetricSignatureService());
//        
//        return ctv;
//    }
//    @Bean(name = "security.ticket.commonTicketConverter")
//    public CommonTicketConverter commonTicketConverter() {
//        return new CommonTicketConverter();
//    }
//    @Bean(name="security.crypto.asymmetricSignatureService")
//    public DefaultAsymmetricSignatureService DefaultAsymmetricSignatureService() {
//        return new DefaultAsymmetricSignatureService();
//    }
    
}
