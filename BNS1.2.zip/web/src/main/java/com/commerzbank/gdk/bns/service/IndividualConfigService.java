package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.CustomNotifConfig;
import com.commerzbank.gdk.bns.model.NotifTextAgreementConfigWrapper;
import com.commerzbank.gdk.bns.model.NotifTextPersonConfigWrapper;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;

/**
 * IndividualConfigService Interface to save notification text and agreement and
 * person config.
 * 
 * @since 03/10/2017
 * @author ZE2BAUL
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 03/10/2017        1.00       ZE2BAUL    Initial Version
 * 13/11/2017        1.01       ZE2MACL    Updated method to used Response builder and added token parameter
 *          </pre>
 */
public interface IndividualConfigService {

    ResponseBuilder<NotifTextAgreementConfigWrapper> saveNotifTextAndAgreementConfig(Tokenizer token,
            CustomNotifConfig agreementConfig);

    ResponseBuilder<NotifTextPersonConfigWrapper> saveNotifTextAndPersonConfig(Tokenizer token,
            CustomNotifConfig agreementConfig);
}
