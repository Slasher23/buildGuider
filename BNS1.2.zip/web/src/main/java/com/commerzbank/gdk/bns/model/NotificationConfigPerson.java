package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Benachrichtigung Konfig Person (Notification Configuration
 * Person) Table
 * 
 * @since 28/07/2017
 * @author ZE2BUEN
 * @version 1.05
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 28/07/2017        1.01       ZE2BUEN    Initial Version
 * 14/08/2017        1.02       ZE2BUEN    Modified data type of Active from int to boolean
 * 02/10/2017        1.03       ZE2BUEN    Added participant number UID
 * 15/11/2017        1.04       ZE2SARO    Add constructor
 * 23/11/2017        1.05       ZE2BUEN    Modified TEILNEHMENUMMER_UID to PERSON_UID
 * </pre>
 */

@XmlRootElement(name = "NotificationConfigPerson")
@Entity
@Table(name = "BENACH_KONFIG_PERSON")
public class NotificationConfigPerson {

    @Id
    @Column(name = "BENACH_KONFIG_PERSON_UID")
    @GeneratedValue(generator = "BENACH_KONFIG_PERSON_ID_SEQ")
    @SequenceGenerator(name = "BENACH_KONFIG_PERSON_ID_SEQ", sequenceName = "BENACH_KONFIG_PERSON_SEQ")
    private Long notifConfigPersonUID;

    @NotNull
    @Column(name = "AKTIV")
    private boolean active;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "INFORMATIONS_KANAL_UID")
    private Long informationChannelUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "EMAIL_UID")
    private Long emailUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "BENACHRICHTIGUNGS_TEXT_UID")
    private Long notificationTextUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "PERSON_UID")
    private Long personUID;

    /**
     * Constructor
     */
    public NotificationConfigPerson() {

    }

    /**
     * Set all records
     * @param active
     * @param informationChannelUID
     * @param emailUID
     * @param notificationTextUID
     * @param personUID
     */
    public NotificationConfigPerson(boolean active, Long informationChannelUID, Long emailUID, Long notificationTextUID,
            Long personUID) {
        this.setActive(active);
        this.setEmailUID(emailUID);
        this.setInformationChannelUID(informationChannelUID);
        this.setNotificationTextUID(notificationTextUID);
        this.setPersonUID(personUID);
    }

    /**
     * Returns the value of Unique Identifier of Notification Configuration
     * Person Record
     * 
     * @return Long Unique Identifier of Notification Configuration Person
     *         Record
     */
    public Long getNotifConfigPersonUID() {
        return notifConfigPersonUID;
    }

    /**
     * Sets the value of Unique Identifier of Notification Configuration Person
     * Record
     * 
     * @param notifConfigPersonUID Long Unique Identifier of Notification
     *            Configuration Person Record to set
     */
    public void setNotifConfigPersonUID(Long notifConfigPersonUID) {
        this.notifConfigPersonUID = notifConfigPersonUID;
    }

    /**
     * Returns the value of Active Notification Configuration Flag
     * 
     * @return boolean Active Notification Configuration Flag
     */
    public boolean getActive() {
        return active;
    }

    /**
     * Sets the value of Active Notification Configuration Flag
     * 
     * @param active boolean Active Notification Configuration Flag to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Returns the value of Unique Identifier of Information Channel Record
     * 
     * @return Long Unique Identifier of Information Channel Record
     */
    public Long getInformationChannelUID() {
        return informationChannelUID;
    }

    /**
     * Sets the value of Unique Identifier of Information Channel Record
     * 
     * @param informationChannelUID Long Unique Identifier of Information
     *            Channel Record
     */
    public void setInformationChannelUID(Long informationChannelUID) {
        this.informationChannelUID = informationChannelUID;
    }

    /**
     * Returns the value of Unique Identifier of Email Record
     * 
     * @return Long Unique Identifier of Email Record
     */
    public Long getEmailUID() {
        return emailUID;
    }

    /**
     * Sets the value of Unique Identifier of Email Record
     * 
     * @param emailUID Long Unique Identifier of Email Record
     */
    public void setEmailUID(Long emailUID) {
        this.emailUID = emailUID;
    }

    /**
     * Returns the value of Unique Identifier of Notification Text Record
     * 
     * @return Long Unique Identifier of Notification Text Record
     */
    public Long getNotificationTextUID() {
        return notificationTextUID;
    }

    /**
     * Sets the value of Unique Identifier of Notification Text Record
     * 
     * @param notificationTextUID Long Unique Identifier of Notification Text
     *            Record
     */
    public void setNotificationTextUID(Long notificationTextUID) {
        this.notificationTextUID = notificationTextUID;
    }

    /**
     * Returns the value of Unique Identifier of Person Record
     * 
     * @return Long Unique Identifier of Person Record
     */
    public Long getPersonUID() {
        return personUID;
    }

    /**
     * Sets the value of Unique Identifier of Person Record
     * 
     * @param personUID Long Unique Identifier of Person
     *            Record
     */
    public void setPersonUID(Long personUID) {
        this.personUID = personUID;
    }

    /**
     * Returns the String representation of Notification Configuration Person
     * Model
     * 
     * @return String String representation of Notification Configuration Person
     *         Model
     */
    @Override
    public String toString() {
        return "NotificationConfigPerson [notifConfigPersonUID= " + notifConfigPersonUID + " , active= " + active
                + " , informationChannelUID= " + informationChannelUID + " , emailUID= " + emailUID
                + " , notificationTextUID= " + notificationTextUID + " , personUID= " + personUID
                + "]";
    }

}
