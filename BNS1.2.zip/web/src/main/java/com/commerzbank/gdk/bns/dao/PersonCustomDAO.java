package com.commerzbank.gdk.bns.dao;

import com.commerzbank.gdk.bns.model.Person;

/**
 * Custom Person DAO Interface to get Person
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.02
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.01		ZE2SARO 	InitialVersion
 * 09/02/2018       1.02        ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface PersonCustomDAO {
	
	Person getPerson(String bpkenn);

}
