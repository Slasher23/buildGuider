package com.commerzbank.gdk.bns.dao;

import java.util.List;

import com.commerzbank.gdk.bns.model.Agreement;

/**
 * Custom Agreement DAO Interface to get the Agreement List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.03
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	Initial Version
 * 14/09/2017		1.01		ZE2SARO 	Change personUID to participantNumberUID for getting agreement
 * 22/09/2017		1.02		ZE2SARO 	Change parameter data type from List<Long> to Long
 * 20/09/2017		1.03		ZE2BUEN 	Add new getAgreementList() method using Participant Number UID list, Agreement ID and 
 * 										    Branch
 * 23/11/2017       1.04        ZE2MACL     Removed participantNumber and used personUID parameter
 * </pre>
 */

public interface AgreementCustomDAO {
	
	
	List<Agreement> getAgreementList(Long personUID);
    
    List<Agreement> getAgreementList(Long personUID, String agreementID, int branch);
    
    List<Long> getAgreementUIDList(Long personUID);
	
}
