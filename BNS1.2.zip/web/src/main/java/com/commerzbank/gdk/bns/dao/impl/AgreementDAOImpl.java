package com.commerzbank.gdk.bns.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.AgreementCustomDAO;
import com.commerzbank.gdk.bns.model.Agreement;

/**
 * DAO Implementation Class to get the Agreement List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.04
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00	    ZE2SARO 	InitialVersion
 * 14/09/2017       1.01        ZE2SARO		Change person_Uid to participantNumberUID for getting agreement list
 * 22/09/2017       1.02        ZE2SARO		Change parameter data type from List<Long> to Long
 * 20/09/2017		1.03		ZE2BUEN 	Add new getAgreement using Participant Number UID list, agreement ID and 
 * 										    branch
 * 23/11/2017       1.04        ZE2MACL     Used pesrsonUID to get list of agreements
 *          </pre>
 */
@Repository
public class AgreementDAOImpl implements AgreementCustomDAO {

    @PersistenceContext
    EntityManager entityManager;

    /**
     * Retrieves the List of Agreement records using a given Unique Identifier
     * of Person record
     * 
     * @param personUID Long Unique Identifier of Person record to set
     * @return List List of Agreements
     */
    @Override
    public List<Agreement> getAgreementList(Long personUID) {

        List<Agreement> agreementList = this.entityManager.createQuery(
                "FROM Agreement WHERE personUID =" + personUID
                        + " ORDER BY decode(agreementType, 'KTO', 1, 'KAR', 2, 'WP', 3, 'KRE', 4, 'VOR', 5, 'PER', 6), agreementType",
                Agreement.class).getResultList();

        return agreementList;
    }

    /**
     * Retrieves the List of Agreement records using Unique Identifier of
     * Person, agreement ID and branch
     * 
     * @param personUID Long Unique Identifier of Person record set
     * @param agreementID String Agreement ID
     * @param branch int Branch
     * @return List Agreement List
     */

    @Override
    public List<Agreement> getAgreementList(Long personUID, String agreementID, int branch) {

        List<Agreement> agreementList = this.entityManager.createQuery("FROM Agreement WHERE personUID = " + personUID
                + " AND branch = " + branch + "" + " AND agreementID = '" + agreementID + "'", Agreement.class)
                .getResultList();

        return agreementList;
    }

    /**
     * Retrieves the List of AgreementUID using a given Unique Identifier of
     * Person record
     * 
     * @param personUID Long Unique Identifier of Person record to set
     * @return List of AgreementUID
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Long> getAgreementUIDList(Long personUID) {

        List<Long> listAgreementUID = this.entityManager
                .createQuery("SELECT agreementUID FROM Agreement WHERE personUID = " + personUID).getResultList();

        return listAgreementUID;
    }

}
