package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.ChangeConfigurationRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to create, update and delete email address
 * records and update notification configuration records
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2BUEN    Initial Version
 * 23/11/2017        1.01       ZE2BUEN    Modified service class to reflect actual implementation
 * 07/12/2017        1.02       ZE2SARO    Add Validation
 * 12/12/2017        1.03       ZE2BUEN    Refactor/clean up for status messages
 * 06/02/2018        1.04       ZE2MACL    Remove throws Exception and replace with try catch
 * 21/02/2018        1.05       ZE2MACL    Added required field/s validation
 * 26/02/2018        1.06       ZE2MACL    Used personId and addressId to find email
 *          </pre>
 */

@Service
@Transactional
public class ChangeEmailAddressServiceImpl implements ChangeEmailAddressService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private EmailDAO emailDAO;

    @Autowired
    private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

    @Autowired
    private NotificationConfigPersonDAO notificationConfigPersonDAO;

    @Autowired
    private AllNotificationConfigDAO allNotificationConfigDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    private static final Logger LOGGER                          = LoggerFactory
                    .getLogger(ChangeEmailAddressServiceImpl.class);
    private static final String STATUS_OK                       = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST       = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS     = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_ADDRESS_ID_EXISTS     = "ZSL_STATUS_FA_ADDRESS_ID_EXISTS";
    private static final String STATUS_FA_ADDRESS_ID_NOT_EXISTS = "ZSL_STATUS_FA_ADDRESS_ID_NOT_EXISTS";
    private static final String STATUS_FA_FAILED_CHANGE_EMAIL   = "ZSL_STATUS_FA_FAILED_CHANGE_EMAIL";

    private static final String EVENT_CREATE = "CreateAddressEvent";
    private static final String EVENT_UPDATE = "UpdateAddressEvent";
    private static final String EVENT_DELETE = "DeleteAddressEvent";
    private static final String EMPTY_STRING = "";

    /**
     * Create/update push configuration record and returns push configuration
     * response
     * 
     * @param request ChangeEmailAddressRequest Change Email Address Request
     *            sent by ZSL.
     * @return ChangeEmailAddressResponse Change Email Address Response
     */
    @Override
    public ChangeEmailAddressResponse requestForChangeEmailAddress(ChangeEmailAddressRequest request) {

        String bpkenn = null;
        Long addressId = null;
        String emailAddress = null;
        String changeEventType = null;

        String status = EMPTY_STRING;

        ChangeEmailAddressResponse response = new ChangeEmailAddressResponse();

        try {
            status = isValidRequest(request);

            // Check if Change Email Address Request Details is Valid
            if (isNullOrEmpty(status)) {

                // Get Change Email Address Request Details
                bpkenn = request.getBpkenn();
                addressId = request.getAddressId();
                emailAddress = request.getEmailAddress();
                changeEventType = request.getChangeEventType();

            } else {
                response.setStatus(status);
            }

            Person person = null;
            Email email = null;

            if (Objects.isNull(status) || status.isEmpty()) {

                // Get Person Details
                person = this.personDAO.getPerson(bpkenn);

                if (Objects.nonNull(person) && Objects.nonNull(changeEventType)) {

                    // Get Existing Email Addresses
                    email = this.emailDAO.findByPersonUIDAndAddressId(person.getPersonUID(), addressId);

                    switch (changeEventType) {

                    case EVENT_CREATE:
                        status = this.createEmailAddress(person.getPersonUID(), emailAddress, addressId, email);
                        break;

                    case EVENT_UPDATE:
                        status = this.updateEmailAddress(person.getPersonUID(), emailAddress, addressId, email);
                        break;

                    case EVENT_DELETE:
                        status = this.deleteEmailAddress(person.getPersonUID(), emailAddress, addressId, email);
                        break;
                    }

                } else {

                    status = this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS);

                }
            }

        } catch (Exception ex) {
            status = this.environment.getProperty(STATUS_FA_FAILED_CHANGE_EMAIL);
            LOGGER.error(ex.getMessage(), ex);
        }

        if (status.isEmpty()) {
            status = this.environment.getProperty(STATUS_OK);
        }

        response.setBpkenn(request.getBpkenn());
        response.setAddressId(request.getAddressId());
        response.setStatus(status);

        return response;
    }

    /**
     * Method to check if string is null or empty
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        Boolean isNullOrEmpty = Objects.nonNull(stringToCheck) && !stringToCheck.isEmpty() ? false : true;

        return isNullOrEmpty;

    }

    /**
     * Method to validate request
     * 
     * @param request ChangeEmailAddressRequest
     * @return boolean isValidRequest
     */
    private String isValidRequest(ChangeEmailAddressRequest request) {

        String inValidMsg;
        HashSet<String> invalidFields = new HashSet<String>();

        boolean nullBpkenn = this.isNullOrEmpty(request.getBpkenn());
        boolean nullAddressId = Objects.isNull(request.getAddressId());
        boolean nullEmailAddress = this.isNullOrEmpty(request.getEmailAddress());
        boolean nullChangeEventType = this.isNullOrEmpty(request.getChangeEventType());

        if (nullBpkenn) {
            invalidFields.add("bpkenn");
        }

        if (nullAddressId) {
            invalidFields.add("addressId");
        }

        if (nullEmailAddress) {
            invalidFields.add("emailAddress");
        }

        if (nullChangeEventType) {
            invalidFields.add("changeEventType");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        if (!nullChangeEventType) {
            if (!request.getChangeEventType().equals(EVENT_CREATE) && !request.getChangeEventType().equals(EVENT_DELETE)
                            && !request.getChangeEventType().equals(EVENT_UPDATE)) {
                if (isNullOrEmpty(inValidMsg)) {
                    inValidMsg = this.environment.getProperty(STATUS_FA_INVALID_REQUEST);
                }

            }
        }

        return inValidMsg;

    }

    /**
     * Create email address record
     * 
     * @param personUID Long Person UID
     * @param emailAddress String Email Address from request
     * @param addressId Long Address Identifier from request
     * @param email Email Existing email record
     * @return String Status
     */
    private String createEmailAddress(Long personUID, String emailAddress, Long addressId, Email email) {

        String status = EMPTY_STRING;

        if (Objects.nonNull(email)) {
            status = this.environment.getProperty(STATUS_FA_ADDRESS_ID_EXISTS);
        } else {
            email = new Email();
            email.setPersonUID(personUID);
            email.setEmailAddress(emailAddress);
            email.setAddressId(addressId);
            this.emailDAO.save(email);
        }

        return status;

    }

    /**
     * Update email address record
     * 
     * @param personUID Long Person UID
     * @param emailAddress String Email Address from request
     * @param addressId Long Address Identifier from request
     * @param email Email Existing email record
     * @return String Status
     */
    private String updateEmailAddress(Long personUID, String emailAddress, Long addressId, Email email) {

        String status = EMPTY_STRING;

        if (Objects.isNull(email)) {
            status = this.environment.getProperty(STATUS_FA_ADDRESS_ID_NOT_EXISTS);
        } else {
            email.setEmailAddress(emailAddress);
            this.emailDAO.save(email);
        }

        return status;

    }

    /**
     * Delete email address record
     * 
     * @param personUID Long Person UID
     * @param emailAddress String Email Address from request
     * @param addressId Long Address Identifier from request
     * @param email Email Existing email record
     * @return String Status
     */
    private String deleteEmailAddress(Long personUID, String emailAddress, Long addressId, Email email) {

        String status = EMPTY_STRING;

        if (Objects.isNull(email)) {
            status = this.environment.getProperty(STATUS_FA_ADDRESS_ID_NOT_EXISTS);
        } else {
            this.deleteNotificationConfigurations(email);
            this.emailDAO.delete(email);
        }

        return status;

    }

    /**
     * Method to delete notification configurations related to the existing
     * email address
     * 
     * @param email Email Existing Email Address to delete
     */
    private void deleteNotificationConfigurations(Email email) {

        // Delete Agreement Notification Configurations
        List<NotificationConfigAgreement> notificationConfigAgreementList = this.notificationConfigAgreementDAO
                        .findByEmailUID(email.getEmailUID());

        if (Objects.nonNull(notificationConfigAgreementList)) {

            for (NotificationConfigAgreement notificationConfigAgreement : notificationConfigAgreementList) {
                this.notificationConfigAgreementDAO.delete(notificationConfigAgreement);
            }

        }

        // Delete Person Notification Configurations
        List<NotificationConfigPerson> notificationConfigPersonList = this.notificationConfigPersonDAO
                        .findByEmailUID(email.getEmailUID());

        if (Objects.nonNull(notificationConfigPersonList)) {

            for (NotificationConfigPerson notificationConfigPerson : notificationConfigPersonList) {
                this.notificationConfigPersonDAO.delete(notificationConfigPerson);
            }

        }

        // Delete All Notification Configurations
        List<AllNotificationConfig> allNotificationConfigList = this.allNotificationConfigDAO
                        .findByEmailUID(email.getEmailUID());

        if (Objects.nonNull(allNotificationConfigList)) {

            for (AllNotificationConfig allNotificationConfig : allNotificationConfigList) {
                this.allNotificationConfigDAO.delete(allNotificationConfig);
            }

        }

    }

}
