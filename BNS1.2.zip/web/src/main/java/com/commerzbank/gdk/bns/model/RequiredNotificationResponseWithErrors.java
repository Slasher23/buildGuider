package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Response Model Class for RequestForRequiredNotification for Errors
 * 
 * @since 10/11/2017
 * @author ZE2BAUL
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 10/11/2017        1.00       ZE2BAUL    Initial Version
 * </pre>
 */
public class RequiredNotificationResponseWithErrors {

	private String bpkenn;
	
	private List<Notifications> notification;

	private String status;

	/**
	 * Returns the value of bpkenn
	 * 
	 * @return String bpkenn
	 */
	public String getBpkenn() {
		return bpkenn;
	}
	
	/**
	 * Sets the value of bpkenn
	 * 
	 * @param String bpkenn
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns a List of ComplexNotification model
	 * 
	 * @return List ComplexNotification
	 */
	public List<Notifications> getNotification() {
		return notification;
	}

	/**
	 * Sets the value of notification
	 * 
	 * @param List ComplexNotification
	 */
	public void setNotification(List<Notifications> notification) {
		this.notification = notification;
	}

	/**
	 * Returns a the value of status
	 * 
	 * @return String status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the value of status
	 * 
	 * @param String status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Returns the String representation of Response Model class RequestForRequiredNotification
	 * 
	 * @return String String representation of Response Model class RequestForRequiredNotification
	 */
	@Override
	public String toString() {
		return "RequestForRequiredNotificationResponseWithErrors [bpkenn=" + bpkenn + ", notification=" + notification
				+ ", status=" + status + "]";
	}
	
}
