package com.commerzbank.gdk.bns.rules;

import com.commerzbank.gdk.bns.model.NotificationMatrixResponse;

/**
 * 
 * Interface used to access Dispatch Rule book implementation.
 * 
 * @since 26/10/2017
 * @author ZE2GOME
 * @version 1.02
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2GOME    Initial Version
 * 23/11/2017        1.01       ZE2SARO    Change list result to single result
 * 02/01/2018        1.02       ZE2MACL    Remove general exception(throws exception)
 *          </pre>
 *
 */
public interface NotificationRuleBook {

    NotificationMatrixResponse checkDecisionLevel(String bpkenn, Integer branch, String agreementID,
            boolean isAgreementRelated);

}
