package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Key(Schlussel) Table
 * 
 * @since 12/12/2017
 * @author ZE2MACL
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2MACL    Initial Version
 *          </pre>
 */
@Entity
@Table(name = "SCHLUSSEL_DB")
@XmlRootElement
public class Key {

    @Id
    @Column(name = "SCHLUSSEL_UID")
    @GeneratedValue(generator = "SCHLUSSEL_UID_SEQ")
    @SequenceGenerator(name = "SCHLUSSEL_UID_SEQ", sequenceName = "SCHLUSSEL_SEQ")
    private Long keyUID;

    @Pattern(regexp = "^[A-Z]*")
    @NotNull
    @Column(name = "SCHLTYP")
    private String keyTyp;

    @NotNull
    @Max(value = 9)
    @Column(name = "SCHLCODE")
    private String keyCode;

    @Size(max = 3)
    @NotNull
    @Column(name = "SPRACHE")
    private String language;

    @Size(max = 65)
    @NotNull
    @Column(name = "SCHLKTXT")
    private String keyShortText;

    @Size(max = 200)
    @NotNull
    @Column(name = "SCHLLTXT")
    private String keyLongText;

    /**
     * @return the keyUID
     */
    public Long getKeyUID() {
        return keyUID;
    }

    /**
     * @param keyUID the keyUID to set
     */
    public void setKeyUID(Long keyUID) {
        this.keyUID = keyUID;
    }

    /**
     * @return the keyTyp
     */
    public String getKeyTyp() {
        return keyTyp;
    }

    /**
     * @param keyTyp the keyTyp to set
     */
    public void setKeyTyp(String keyTyp) {
        this.keyTyp = keyTyp;
    }

    /**
     * @return the keyCode
     */
    public String getKeyCode() {
        return keyCode;
    }

    /**
     * @param keyCode the keyCode to set
     */
    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    /**
     * @return the language
     */
    public String getLanguage() {
        return language;
    }

    /**
     * @param language the language to set
     */
    public void setLanguage(String language) {
        this.language = language;
    }

    /**
     * @return the keyShortText
     */
    public String getKeyShortText() {
        return keyShortText;
    }

    /**
     * @param keyShortText the keyShortText to set
     */
    public void setKeyShortText(String keyShortText) {
        this.keyShortText = keyShortText;
    }

    /**
     * @return the keyLongText
     */
    public String getKeyLongText() {
        return keyLongText;
    }

    /**
     * @param keyLongText the keyLongText to set
     */
    public void setKeyLongText(String keyLongText) {
        this.keyLongText = keyLongText;
    }

    /**
     * Returns the String representation of Key Model
     * 
     * @return String String representation of Key Model
     */

    @Override
    public String toString() {
        return "Schlussel [keyTyp=" + keyTyp + ", keyCode=" + keyCode + ", language=" + language + ", keyShortText="
                + keyShortText + ", keyLongText=" + keyLongText + "]";
    }

}
