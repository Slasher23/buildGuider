package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Kunde(Customer) Table
 * 
 * @since 28/07/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 28/07/2017        1.01       ZE2BUEN    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 29/09/2017        1.03 		ZE2BUEN    Modified customer number column from Nullable to Not Nullable and data type from Long to String.
 * </pre>
 */

@Entity
@Table(name = "KUNDE")
@XmlRootElement
public class Customer {

	@Id
	@Column(name = "KUNDE_UID")
	@GeneratedValue(generator = "KUNDE_ID_SEQ")
	@SequenceGenerator(name = "KUNDE_ID_SEQ", sequenceName = "KUNDE_SEQ")
	private Long customerUID;
	
	@NotNull
	@Size(max = 10)
	@Column(name = "KUNDEN_NUMMER")
	private String customerNumber;

	@Pattern(regexp = "^[a-zA-Z0-9. /-]*$")
	@Size(min = 0, max = 16)
	@Column(name = "LANGZEIT_KUNDEN_NUMMER")
	private String longTermCustomerNumber;

	@NotNull
	@Max(value = 99999999999L)
	@Column(name = "PERSON_UID")
	private Long personUID;

	/**
	 * Returns the value of Unique Identifier of Customer Record
	 * 
	 * @return Long Unique Identifier of Customer Record
	 */
	public Long getCustomerUID() {
		return customerUID;
	}

	/**
	 * Sets the value of Unique Identifier of Customer Record
	 * 
	 * @param customerUID Long Unique Identifier of Customer Record to set
	 */
	public void setCustomerUID(Long customerUID) {
		this.customerUID = customerUID;
	}

	/**
	 * Returns the value of Customer Number
	 * 
	 * @return String Customer Number
	 */
	public String getCustomerNumber() {
		return customerNumber;
	}

	/**
	 * Sets the value of Customer Number
	 * 
	 * @param customerNumber String Customer Number to set
	 */
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	/**
	 * Returns the value of Long Term Customer Number
	 * 
	 * @return String Long Term Customer Number
	 */
	public String getLongTermCustomerNumber() {
		return longTermCustomerNumber;
	}

	/**
	 * Sets the value of Long Term Customer Number
	 * 
	 * @param longTermCustomerNumber String Long Term Customer Number to set
	 */
	public void setLongTermCustomerNumber(String longTermCustomerNumber) {
		this.longTermCustomerNumber = longTermCustomerNumber;
	}

	/**
	 * Returns the value of Unique Identifier for Person Record
	 * 
	 * @return Long Unique Identifier for Person Record
	 */
	public Long getPersonUID() {
		return personUID;
	}

	/**
	 * Sets the value of Unique Identifier for Person Record
	 * 
	 * @param personUID Long Unique Identifier for Person Record to set
	 */
	public void setPersonUID(Long personUID) {
		this.personUID = personUID;
	}
	
	/**
	 * Returns the String representation of Customer Model
	 * 
	 * @return String String representation of Customer Model
	 */
	@Override
	public String toString() {
		return "Customer [customerUID= " + customerUID + 
			   " , customerNumber= " + customerNumber + 
			   " , longTermCustomerNumber= " + longTermCustomerNumber + 
			   " , personUID= " + personUID + "]";
	}

}
