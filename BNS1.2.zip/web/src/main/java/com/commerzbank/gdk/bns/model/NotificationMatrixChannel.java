package com.commerzbank.gdk.bns.model;

import com.commerzbank.gdk.bns.enums.InformationChannelTypeE;

public class NotificationMatrixChannel {

    InformationChannelTypeE informationChannelType;
    
    String notificationPath;
    
    
    /**
     * Get the value of information number.
     * 
     * @return the informationChannelType
     */
    public InformationChannelTypeE getInformationChannelType() {
        return informationChannelType;
    }

    /**
     * Set the value of information number.
     * 
     * @param informationChannelType the informationChannelType to set
     */
    public void setInformationChannelType(InformationChannelTypeE informationChannelType) {
        this.informationChannelType = informationChannelType;
    }

    /**
     * Get the notification path.
     * 
     * @return notificationPath string
     */
    public String getNotificationPath() {
        return notificationPath;
    }

    /**
     * Set notification path.
     * 
     * @param notificationPath notification path.
     */
    public void setNotificationPath(String notificationPath) {
        this.notificationPath = notificationPath;
    }
    
}
