package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.EmailDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.AgreementTypesWrapper;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.Databackpack;
import com.commerzbank.gdk.bns.model.Email;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotifConfigPersonWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreementWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.PersonConfigWrapper;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementTypesWrapperService;
import com.commerzbank.gdk.bns.service.DatabackpackService;

/**
 * Service Implementation Class used to implement business logic service in
 * getting the person information.
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.16
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 14/09/2017       1.01        ZE2SARO     Get agreement list using participant number UID
 * 22/09/2017       1.02        ZE2SARO     Change bpkenn parameter to Parameter Model
 * 27/09/2017       1.03        ZE2SARO     Standard text get in json
 * 02/10/2017		1.04		ZE2BAUL		Implementation of the Person / MainAgreementTypeWrapper
 * 10/11/2017       1.05        ZE2MACL     Updated method to used response builder and added token parameter
 * 23/11/2017       1.06        ZE2MACL     Removed ParticipantDAO and used personUID parameter instead of participantNumber
 * 24/11/2017       1.07        ZE2MORA     Implemented Status Codes 
 * 27/11/2017       1.08        ZE2BAUL     Implemented Status Codes and BNSConstants
 * 22/12/2017       1.09        ZE2CRUH     Updated code to include IBAN
 * 15/01/2018       1.10        ZE2FUEN     Updated code to create person config entry when it is null
 * 30/01/2018       1.11        ZE2FARI     Updated the code to handle the addition of agreement customer names
 * 30/01/2018       1.12        ZE2FARI     Removed the HolderLastname and HolderGivenName
 * 09/02/2018       1.13        ZE2MACL     Removed throws Exception
 * 22/02/2018       1.14        ZE2BUEN     Handle null agreement types
 * 23/02/2018       1.15        ZE2FUEN     Updated implementation to CIF-Integration
 * 28/02/2018       1.16        ZE2FUEN     Implemented BNStoken builder
 * </pre>
 */
@Service
@Transactional
public class AgreementTypesWrapperServiceImpl implements AgreementTypesWrapperService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AgreementTypesWrapperServiceImpl.class);

	@Autowired
	private PersonDAO personDAO;

	@Autowired
	private NotificationConfigAgreementDAO notificationConfigAgreementDAO;

	@Autowired
	private NotificationConfigPersonDAO notificationConfigPersonDAO;

	@Autowired
	private AgreementDAO agreementDAO;

	@Autowired
	private EmailDAO emailDAO;

	@Autowired
	private InformationChannelDAO informationChannelDAO;

	@Autowired
	Environment environment;

	@Autowired
	private AllNotificationConfigDAO allNotificationConfigDAO;

	@Autowired
	private NotificationTextDAO notificationTextDAO;

	@Autowired
	private GlobalResponseWrapper globalResponseWrapper;

	@Autowired
    private DatabackpackService databackpackService;
	
	/**
	 * Retrieves the MainAgreementTypeWrapper.
	 * 
	 * @param token
	 *            Tokenizer used for identifying user
	 * @param agreementUIDList
	 *            List<Long> used for process
	 * @return MainAgreementTypeWrapper the object MainAgreementTypeWrapper	 
	 */
	@Override
	public ResponseBuilder<MainAgreementTypeWrapper> getMainAgreementTypeWrapperList(Tokenizer token, List<Long> agreementUIDList) {

		ResponseBuilder<MainAgreementTypeWrapper> builder = new ResponseBuilder<MainAgreementTypeWrapper>(LOGGER, token,
				globalResponseWrapper);
		
		String bpkenn = token.getBpkenn();

		try {

			// get personUID
			Person person = this.personDAO.getPerson(bpkenn);
			MainAgreementTypeWrapper mainAgreementTypeWrapper = new MainAgreementTypeWrapper();

			if (Objects.nonNull(person)) {

				List<Email> emailList = this.emailDAO.getEmailList(person.getPersonUID());

				List<InformationChannel> informationChannelList = this.informationChannelDAO
						.getInformationChannelList();

				AllNotificationConfig allNotificationConfig = getAllNotifConfig(token, person.getPersonUID(), emailList,
						informationChannelList);

				List<AgreementTypesWrapper> agreementTypesWrapperList = constructAgreementTypes(agreementUIDList, token,
						person.getPersonUID(), emailList, informationChannelList);

				PersonConfigWrapper personAgreementTypeWrapperList = constructPersonConfigType(token,
						person.getPersonUID(), emailList, informationChannelList);

				mainAgreementTypeWrapper.setAllNotificationConfig(allNotificationConfig);
				mainAgreementTypeWrapper.setAgreementTypes(agreementTypesWrapperList);
				mainAgreementTypeWrapper.setPersonConfigType(personAgreementTypeWrapperList);
				mainAgreementTypeWrapper.setEmail(emailList);
				mainAgreementTypeWrapper.setInformationChannel(informationChannelList);

				builder.OK(mainAgreementTypeWrapper);
			} else {
				builder.OK(mainAgreementTypeWrapper, Response.SUCCESS_NO_PERSON_FOUND);
			}

		} catch (DataAccessException e) {
			builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
		} catch (NullPointerException e) {
			builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
		} catch (Exception e) {
			builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
		}

		LOGGER.info("<<= User [{}] getMainAgreementTypeWrapperList({}) request was successfully processed.",
				token.getUserId(), bpkenn);

		return builder;
	}

	/**
	 * Gets the AllNotificationConfig.
	 * 
	 * @param participantNumberUID
	 *            Long to set in all notif config
	 * @param emailList
	 *            List<Email> to set in all notif config
	 * @param informationChannelList
	 *            List<InformationChannel> to set in all notif config
	 * @return allNotificationConfig info
	 */
	private AllNotificationConfig getAllNotifConfig(Tokenizer token, Long personUID, List<Email> emailList,
			List<InformationChannel> informationChannelList) {

		AllNotificationConfig allNotificationConfig = this.allNotificationConfigDAO.findByPersonUID(personUID);

		if (Objects.isNull(allNotificationConfig)) {
			allNotificationConfig = new AllNotificationConfig();
			allNotificationConfig.setEmailUID(getInitialEmailUID(token, emailList));
			allNotificationConfig.setInformationChannelUID(getInitialInfoChannelUID(token, informationChannelList));
			allNotificationConfig.setPersonUID(personUID);
		}

		LOGGER.info("<<= User [{}] getAllNotifConfig({},{},{}) request was successfully processed.", token.getUserId(),
				personUID, emailList.toString(), informationChannelList.toString());

		return allNotificationConfig;
	}

	/**
	 * Retrieves the List of Agreement Type records using a given Unique
	 * Identifier, Email List and Information Channel List.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param personUID
	 *            Long Unique Identifier to set
	 * @param emailList
	 *            List of Email to set
	 * @param informationChannelList
	 *            List of Information Channel to set
	 * @return list of Agreement Types Wrapper
	 */
	private List<AgreementTypesWrapper> constructAgreementTypes(List<Long> agreementUIDList, Tokenizer token, Long personUID, List<Email> emailList,
			List<InformationChannel> informationChannelList) {

		NotificationConfigAgreementWrapper notiWrapper;
		String prevAgreementType = BNSConstants.EMPTY_STRING;
		AgreementTypesWrapper agreementTypesWrapper = new AgreementTypesWrapper();
		List<Agreement> agreementList = agreementDAO.getAgreementList(personUID);
		List<AgreementTypesWrapper> agreementTypesWrapperList = new ArrayList<AgreementTypesWrapper>();
		List<NotificationConfigAgreementWrapper> notiWrapperList = new ArrayList<NotificationConfigAgreementWrapper>();

		if (Objects.isNull(agreementUIDList)) {
		    Databackpack databackpack = this.databackpackService.databackpackDecryptor(token.getDatabackpack());
		    agreementList = this.databackpackService.agreementFilterByDatabackpack(databackpack, agreementList, personUID);
		} else {
		    agreementList = agreementDAO.findByAgreementUIDIn(agreementUIDList);
		}

		String formattedId = "";

		int agreementSize = agreementList.size();
		int agreementCtr = 1;

		for (Agreement agreement : agreementList) {
			notiWrapper = new NotificationConfigAgreementWrapper();
			
			if(Objects.isNull(agreement.getAgreementType())) {
				agreement.setAgreementType("");
			}
			
			// save notif list if type is new
			if (!prevAgreementType.equalsIgnoreCase(agreement.getAgreementType())
					&& !prevAgreementType.equals(BNSConstants.EMPTY_STRING)) {
				agreementTypesWrapper.setAgreements(notiWrapperList);
				agreementTypesWrapperList.add(agreementTypesWrapper);
				notiWrapperList = new ArrayList<NotificationConfigAgreementWrapper>();
				agreementTypesWrapper = new AgreementTypesWrapper();
			}
			
			// check if type is not equal to previous type
			if (!prevAgreementType.equalsIgnoreCase(agreement.getAgreementType())) {
				agreementTypesWrapper.setAgreementType(agreement.getAgreementType());
			}
			
			if (agreement.getBranch() == 100 && agreement.getAgreementType().equalsIgnoreCase("KTO")) {
				formattedId = formatID(token, agreement.getIban(), agreementTypesWrapper.getAgreementType());
			} else {
				// formats the agreementId based on the agreementType
				formattedId = formatID(token, agreement.getAgreementID(), agreementTypesWrapper.getAgreementType());
			}
		
			// set notif config agreement
			notiWrapper.setAgreement(formattedId);
			notiWrapper.setType(agreement.getType());
			
			notiWrapper.setAgreementCustomerNames(agreement.getCustomerName());
			

			NotificationConfigAgreement agreementConfig = notificationConfigAgreementDAO
					.getNotifConfigAgreement(agreement.getAgreementUID());
			
			if (agreementConfig != null) {
				notiWrapper.setTextType(this.notificationTextDAO.findOne(agreementConfig.getNotificationTextUID())
						.getNotificationTextType());
				notiWrapper.setNotificationConfigAgreement(agreementConfig);
			} else {
				// set initial values
				NotificationConfigAgreement initialConfig = new NotificationConfigAgreement();
				initialConfig.setActive(false);
				initialConfig.setAgreementUID(agreement.getAgreementUID());
				initialConfig.setEmailUID(getInitialEmailUID(token, emailList));
				initialConfig.setInformationChannelUID(getInitialInfoChannelUID(token, informationChannelList));

				// check if notiftext has value even there's notifconfig
				NotificationText notifText = notificationTextDAO.getNotifText(
						environment.getProperty(BNSConstants.VERLASSUNGS_TYPE_KEY), agreement.getAgreementUID());
				if (Objects.nonNull(notifText)) {
					initialConfig.setNotificationTextUID(notifText.getNotificationTextUID());
					notiWrapper.setTextType(notifText.getNotificationTextType());

				} else {
					initialConfig.setNotificationTextUID(null);
					notiWrapper.setTextType(BNSConstants.TEXT_TYPE_STD);
				}

				notiWrapper.setNotificationConfigAgreement(initialConfig);
			}
			// add notif to list
			notiWrapperList.add(notiWrapper);
			// add notif to wrapper if data is last
			if (agreementSize == agreementCtr) {
				agreementTypesWrapper.setAgreements(notiWrapperList);
				agreementTypesWrapperList.add(agreementTypesWrapper);
			}

			prevAgreementType = agreement.getAgreementType();
			agreementCtr++;
		}

		LOGGER.info("<<= User [{}] constructAgreementTypes({},{},{}) request was successfully processed.",
				token.getUserId(), personUID, emailList.toString(), informationChannelList.toString());

		return agreementTypesWrapperList;
	}

	/**
	 * Retrieves the List of Person Config record using a given Unique
	 * Identifier, Email List and Information Channel List.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param personUID
	 *            Long Unique Identifier to set
	 * @param emailList
	 *            List of Email to set
	 * @param informationChannelList
	 *            List of Information Channel to set
	 * @return List List of Person Config Wrapper
	 */
	private PersonConfigWrapper constructPersonConfigType(Tokenizer token, Long personUID, List<Email> emailList,
			List<InformationChannel> informationChannelList) {

		NotifConfigPersonWrapper notiPersonWrapper = new NotifConfigPersonWrapper();
		PersonConfigWrapper personConfigWrapper = new PersonConfigWrapper();
		NotificationConfigPerson personConfig = this.notificationConfigPersonDAO.findByPersonUID(personUID);

		if (Objects.nonNull(personConfig)) {
			notiPersonWrapper.setTextType(
					this.notificationTextDAO.findOne(personConfig.getNotificationTextUID()).getNotificationTextType());
			notiPersonWrapper.setNotificationConfigPerson(personConfig);
		} else {
			// set initial values
			NotificationConfigPerson initialPersonConfig = new NotificationConfigPerson();
			initialPersonConfig.setActive(true);
			initialPersonConfig.setEmailUID(getInitialEmailUID(token, emailList));
			initialPersonConfig.setInformationChannelUID(getInitialInfoChannelUID(token, informationChannelList));
			initialPersonConfig.setPersonUID(personUID);

			// check if notiftext has value even there's notifconfig
			NotificationText notifText = notificationTextDAO
					.getNotifText(environment.getProperty(BNSConstants.PERSON_TYPE_KEY), personUID);

			if (Objects.nonNull(notifText)) {
				initialPersonConfig.setNotificationTextUID(notifText.getNotificationTextUID());
				notiPersonWrapper.setTextType(notifText.getNotificationTextType());

			} else {
			    NotificationText newNotifText = new NotificationText();
			    newNotifText.setNotificationTextType(BNSConstants.TEXT_TYPE_STD);
			    newNotifText.setEventType("PER");
			    newNotifText.setEventID(personUID);
			    
			    newNotifText = this.notificationTextDAO.save(newNotifText);
			    
				initialPersonConfig.setNotificationTextUID(newNotifText.getNotificationTextUID());
				notiPersonWrapper.setTextType(newNotifText.getNotificationTextType());
			}
			
			initialPersonConfig = this.notificationConfigPersonDAO.save(initialPersonConfig);
			notiPersonWrapper.setNotificationConfigPerson(initialPersonConfig);
		}

		personConfigWrapper.setAgreementType("PER");
		personConfigWrapper.setPersonAgreement(notiPersonWrapper);

		LOGGER.info("<<= User [{}] constructPersonConfigType({},{},{}) request was successfully processed.",
				token.getUserId(), personUID, emailList.toString(), informationChannelList.toString());

		return personConfigWrapper;
	}

	/**
	 * Retrieves the value of Information Channel using a given Unique
	 * Identifier.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param informationChannelList
	 *            list of the InformationChannel
	 * @return InfoChannelUID List of Information Channel
	 */
	private Long getInitialInfoChannelUID(Tokenizer token, List<InformationChannel> informationChannelList) {

		Long infoChannelUID = null;

		for (InformationChannel informationChannel : informationChannelList) {
			if (informationChannel.getInformationChannelType()
					.equalsIgnoreCase(environment.getProperty(BNSConstants.INFO_CHANNEL_KEY))) {
				infoChannelUID = informationChannel.getInformationChannelUID();
				break;
			}
		}

		LOGGER.info("<<= User [{}] getInitialInfoChannelUID({}) request was successfully processed.", token.getUserId(),
				informationChannelList.toString());

		return infoChannelUID;
	}

	/**
	 * Retrieves the value of UID of the Email List passed.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param List
	 *            List of Emails
	 * @return Long Email UID List of Email
	 */
	private Long getInitialEmailUID(Tokenizer token, List<Email> emailList) {

		Long emailUID = emailList.get(0).getEmailUID();

		LOGGER.info("<<= User [{}] getInitialEmailUID({}) request was successfully processed.", token.getUserId(),
				emailList.toString());

		return emailUID;
	}

	/**
	 * Returns the formatted ID.
	 * 
	 * @param token
	 *            identifier for the request's user
	 * @param agreementId
	 *            id of the agreement
	 * @param agreementType
	 *            type of the agreement
	 * @return formatID formatted id
	 */
	private String formatID(Tokenizer token, String agreementId, String agreementType) {

		StringBuilder formatted = new StringBuilder();
		String result = "";
		String formattedInput = agreementId.replaceAll("\\s", "");

		if (agreementType.equalsIgnoreCase("KTO") || agreementType.equalsIgnoreCase("WP")
				|| agreementType.equalsIgnoreCase("KRE") || agreementType.equalsIgnoreCase("KAR")) {

			for (int i = 0; i < formattedInput.length(); i++) {
				if (i % 4 == 0 && i != 0) {
					formatted.append(" ");
				}
				formatted.append(formattedInput.charAt(i));
			}
			result = formatted.toString();

		} else if (agreementType.equalsIgnoreCase("VOR")) {
			result = formattedInput;

		} else {
			result = agreementId;
		}

		LOGGER.info("<<= User [{}] formatUID({},{},{}) request was successfully processed.", token.getUserId(),
				agreementId, agreementType);

		return result;
	}

}
