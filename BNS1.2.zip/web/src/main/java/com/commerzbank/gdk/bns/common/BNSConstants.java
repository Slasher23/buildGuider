package com.commerzbank.gdk.bns.common;

/**
 * Class for constants
 * 
 * @author ZE2BAUL
 * @since 27/11/2017
 * @version 1.01
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017	     1.00       ZE2BAUL    Initial Version
 * 06/02/2018        1.01       ZE2FARI    Added the Email Subject
 *          </pre>
 */
public class BNSConstants {

    public static final String EMPTY_STRING = "";
    public static final String INFO_CHANNEL_KEY = "INFO_CHANNEL_EMAIL";
    public static final String VERLASSUNGS_TYPE_KEY = "VERLASSUNGS_TYPE_VER";
    public static final String PERSON_TYPE_KEY = "VERLASSUNGS_TYPE_PER";
    public static final String TEXT_TYPE_STD = "STD";
    public static final String TEXT_TYPE_FREE = "FREE";
    public static final String EMAIL_SUBJECT_KEY = "EMAIL_SUBJECT";
    public static final String CUST_EMAIL_SUBJECT_KEY = "INDIV_EMAIL_SUBJECT";

}
