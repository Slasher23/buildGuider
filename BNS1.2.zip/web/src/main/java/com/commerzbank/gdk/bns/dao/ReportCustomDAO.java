package com.commerzbank.gdk.bns.dao;

import java.util.Date;
import java.util.List;

import com.commerzbank.gdk.bns.model.Report;

/**
 * Custom Report DAO Interface
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 04/01/2018		1.00		ZE2BUEN 	Initial Version
 * </pre>
 */

public interface ReportCustomDAO {
    
    List<Report> getReportList(Date startDate, Date endDate, String reportType);
    
}
