package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.CustomerNotificationRequest;
import com.commerzbank.gdk.bns.model.CustomerNotificationsResponse;
import com.commerzbank.gdk.bns.service.CustomerNotificationService;

/**
 * CustomerNotificationController - Accept customer notification request and
 * return the notification response to ZSL.
 * 
 * @since 09/11/2017
 * @author ZE2SARO
 * @version 1.04
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 09/11/2017        1.00       ZE2SARO    Initial Version
 * 07/12/2017        1.01       ZE2SARO    Add Validation
 * 13/12/2017        1.02       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.03       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.04       ZE2MACL    Removed throws Exception
 *          </pre>
 */
@RestController
public class CustomerNotificationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomerNotificationController.class);

    @Autowired
    private CustomerNotificationService customerNotifService;

    /**
     * Receive the client request and call the service to process
     * 
     * @param request
     *            CustomerNotificationRequest use to get notification
     * @param httpRequest
     *            HttpServletRequest use for authentication
     * @return List<NotificationResponse> list of notification
     */
    @PostMapping(value = "/api/zsl/requestForCustomerNotification")
    public ResponseEntity<CustomerNotificationsResponse> requestForCustomerNotif(
            @Valid @RequestBody CustomerNotificationRequest request, HttpServletRequest httpRequest,
            BindingResult result)  {

        LOGGER.info("=>> System [{}] - requestForCustomerNotification({})", "ZSL", request.toString());

        CustomerNotificationsResponse custResponse = new CustomerNotificationsResponse();

        if (!result.hasErrors()) {
            custResponse = this.customerNotifService.getResponse(request);

            if (Objects.isNull(custResponse)) {
                custResponse = new CustomerNotificationsResponse();
            }

        }

        ResponseEntity<CustomerNotificationsResponse> response = new ResponseEntity<CustomerNotificationsResponse>(
                custResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", custResponse.toString());

        return response;
    }

}
