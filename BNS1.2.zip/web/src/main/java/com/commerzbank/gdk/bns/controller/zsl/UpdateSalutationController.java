package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.BatchUpdateSalutationResponse;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequest;
import com.commerzbank.gdk.bns.model.UpdateSalutationRequests;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.UpdateSalutationService;

/**
 * UpdateSalutation to Accept request and return the expected response.
 * 
 * @since 28/11/2017
 * @author ZE2JAVO
 * @version 1.05
 *
 *          <pre>
 * Modified Date   Version   Author     Description
 * 28/11/2017      1.00      ZE2JAVO    Initial Version
 * 29/11/2017      1.01      ZE2JAVO    Add batch process
 * 07/12/2017      1.02      ZE2SARO    Add Validation
 * 13/12/2017      1.03      ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018      1.04      ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018      1.05      ZE2MACL    Removed throws Exception
 *          </pre>
 */

@RestController
public class UpdateSalutationController {

    @Autowired
    private UpdateSalutationService updateSalutationService;

    private static final Logger     LOGGER = LoggerFactory.getLogger(UpdateSalutationController.class);

    /**
     * Accepts salutation request, then call service to update salutation and
     * title record, this returns a BPKENN and a status response.
     * 
     * @param updateSalutationRequest
     * @param request
     * @return ResponseEntity<ZslUpdateResponse>
     */
    @PostMapping(value = "/api/zsl/requestForUpdateSalutation")
    public ResponseEntity<ZslUpdateResponse> requestUpdateSalutation(
            @Valid @RequestBody UpdateSalutationRequest updateSalutationRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForUpdateSalutation({})", "ZSL", updateSalutationRequest.toString());

        ZslUpdateResponse updateResponse = new ZslUpdateResponse();

        if (!result.hasErrors()) {
            updateResponse = this.updateSalutationService.requestUpdateSalutation(updateSalutationRequest);

            if (Objects.isNull(updateResponse)) {
                updateResponse = new ZslUpdateResponse();
            }

        }

        ResponseEntity<ZslUpdateResponse> response = new ResponseEntity<ZslUpdateResponse>(updateResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", updateResponse.toString());

        return response;
    }

    /**
     * Accept the client request and response.
     * 
     * @param request
     * @param httpRequest
     * @return ResponseEntity<BatchZslUpdateResponse> status of update each
     *         request
     */
    @PostMapping(value = "/api/zsl/requestForBatchUpdateSalutation")
    public ResponseEntity<BatchUpdateSalutationResponse> batchUpdateSalutation(
            @Valid @RequestBody UpdateSalutationRequests request, HttpServletRequest httpRequest, BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForBatchUpdateSalutation({})", "ZSL", request.toString());

        BatchUpdateSalutationResponse batchResponse = new BatchUpdateSalutationResponse();

        if (!result.hasErrors()) {
            batchResponse = this.updateSalutationService.requestUpdateSalutation(request);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new BatchUpdateSalutationResponse();
            }

        }

        ResponseEntity<BatchUpdateSalutationResponse> response = new ResponseEntity<BatchUpdateSalutationResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;
    }

}
