package com.commerzbank.gdk.bns.conf;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.commerzbank.ccb.fw.mt.api.crypto.encryption.SymmetricEncryptionCoreService;
import com.commerzbank.ccb.fw.mt.api.crypto.encryption.SymmetricEncryptionParams;

/**
 * This class handles the configuration of CCB Crypto Services.
 * 
 * @author 	ZE2RUBI
 * @since 	10/01/2018
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 10/01/2018        1.00       ZE2RUBI    Initial Version
 *          </pre>
 */
@Component
public class CryptoServiceConfig {
	
	private static Logger  LOGGER = Logger.getLogger(CryptoServiceConfig.class);

    @Autowired
    private SymmetricEncryptionCoreService encryptionCoreService;
   
    /**
     * Register BouncyCastleProvider to the JVM Security provider for the AES/EAX/NoPadding algorithm
     */
    static {
        Security.addProvider(new BouncyCastleProvider());
    }
    
    /**
     * Initialise CCB SymmetricEncryption 
     */
    private SymmetricEncryptionParams initialEcryptionParameters() {
    	
        SymmetricEncryptionParams encryptionParams = new SymmetricEncryptionParams();
        encryptionParams.setAlgorithm("AES");
        encryptionParams.setPrependIvInEncryption(true);
        encryptionParams.setBase64UrlSave(true);
        encryptionParams.setUseHexAfterBase64Encoding(false);
        encryptionParams.setTransformation("AES/EAX/NoPadding");
        encryptionParams.setKey(Base64.decodeBase64("EhISEhISEhISEhISEhISEg=="));
        
        try {
        	
            Cipher cipher = Cipher.getInstance("AES/EAX/NoPadding");
            final int blockSize = cipher.getBlockSize();
            final byte[] ivData = new byte[blockSize];
            final SecureRandom secRan = SecureRandom.getInstance("SHA1PRNG");
            secRan.nextBytes(ivData);
            encryptionParams.setIvData(ivData);
            
        } catch (NoSuchAlgorithmException e) {
        	LOGGER.error(e.getMessage());
        } catch (NoSuchPaddingException e) {
        	LOGGER.error(e.getMessage());
        }

        return encryptionParams;
    }
    /**
     * Accept encrypted data to be decrypted using the SymmetricEncrption service.
     * @param data String
     * @return object decrypted datad
     */
    public String decrypt(String data) {
    	
    	try {

        	LOGGER.debug("Decrypting: " + data);
    		data = encryptionCoreService.decrypt(data,initialEcryptionParameters());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
    
    	return data;
    }
    
    /**
     * Accept string data to be encrypted using the SymmetricEncrption service.
     * @param data String
     * @return object encrypted data
     */
    public String encrypt(String data) {
        
        try {

            LOGGER.debug("Encrypting: " + data);
            data = encryptionCoreService.encrypt(data,initialEcryptionParameters());
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }
    
        return data;
    }


}
