package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Person(Person) Table.
 * 
 * @since 28/07/2017
 * @author ZE2CRUH
 * @version 1.10
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/07/2017        1.01       ZE2CRUH    Initial Version
 * 30/08/2017        1.02       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 14/09/2017        1.03       ZE2SARO    Add new columns
 * 29/09/2017        1.04       ZE2BUEN    Modified salutation column data type from Long to String.
 *                                         Modified last name column max size from 70 to 50.
 *                                         Modified given name column max size from 35 to 50.
 *                                         Added last name from address and given name from address columns.
 * 02/11/2017		 1.05		ZE2FUEN	   Modified BPKENN element to bpkenn.
 * 23/11/2017		 1.06		ZE2BUEN	   Added ANREDE_ERWEITERUNG, INDIVIDUELLE_ANREDE, TITEL_DES_ADELS and TITEL_ERWEITERUNG
 *                                         Removed ADD_FAMILIENNAME and ADD_VORNAME columns
 * 28/11/2017		 1.07		ZE2BUEN	   Removed ANREDE_ERWEITERUNG, INDIVIDUELLE_ANREDE, TITEL_DES_ADELS and 
 *                                         TITEL_ERWEITERUNG columns
 * 13/12/2017        1.08       ZE2MACL    Update size for title field
 * 27/12/2017        1.09       ZE2MORA    Update Regexp of Lastname and Firstname that accepts spaces.            
 * 09/02/2018        1.02       ZE2MACL    Use ASCII value for regEx                       
 *          </pre>
 */
@Entity
@Table(name = "PERSON")
@XmlRootElement
public class Person {

    @Id
    @Column(name = "PERSON_UID")
    @GeneratedValue(generator = "PERSON_ID_SEQ")
    @SequenceGenerator(name = "PERSON_ID_SEQ", sequenceName = "PERSON_SEQ")
    private Long personUID;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9. /-]*$")
    @Size(min = 0, max = 16)
    @Column(name = "BPKENN")
    private String bpkenn;

    @Size(max = 2)
    @Pattern(regexp = "^[0-9]*$")
    @Column(name = "ANREDE")
    private String salutation;

    @Size(max = 2)
    @Pattern(regexp = "^[0-9]*$")
    @Column(name = "TITEL")
    private String title;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df\\u0020]*$")
    @Size(max = 50)
    @Column(name = "FAMILIENNAME")
    private String lastName;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z\\u00c4\\u00e4\\u00d6\\u00f6\\u00dc\\u00fc\\u00df\\u0020]*$")
    @Size(max = 50)
    @Column(name = "VORNAME")
    private String givenName;

    /**
     * Return salutation.
     * 
     * @return String salutation.
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * Set salutation.
     * 
     * @param salutation String to set.
     */
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    /**
     * Return title.
     * 
     * @return String title.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Set Title.
     * 
     * @param title String to set.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Return last name.
     * 
     * @return String lastName.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Set Last name.
     * 
     * @param lastName String to set.
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Return given name.
     * 
     * @return String givenName.
     */
    public String getGivenName() {
        return givenName;
    }

    /**
     * Set Given name.
     * 
     * @param givenName String to set.
     */
    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    /**
     * Returns the value of Unique Identifier of Person Record.
     * 
     * @return Long Unique Identifier of Person Record.
     */
    public Long getPersonUID() {
        return personUID;
    }

    /**
     * Sets the value of Unique Identifier of Person Record.
     * 
     * @param personUID Long Unique Identifier of Person Record to set.
     */
    public void setPersonUID(Long personUID) {
        this.personUID = personUID;
    }

    /**
     * Returns the value of bpkenn.
     * 
     * @return String bpkenn.
     */
    public String getBPKENN() {
        return bpkenn;
    }

    /**
     * Sets the value of bpkenn.
     * 
     * @param bpkenn String bpkenn to set.
     */
    public void setBPKENN(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Returns the String representation of Person Model.
     * 
     * @return String String representation of Person Model.
     */
    @Override
    public String toString() {
        return "Person [personUID=" + personUID + ", bpkenn=" + bpkenn + ", salutation=" + salutation + ", title="
                + title + ", lastName=" + lastName + ", givenName=" + givenName + "]";
    }

}
