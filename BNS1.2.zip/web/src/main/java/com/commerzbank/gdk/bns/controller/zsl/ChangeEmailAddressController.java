package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressBatchResponse;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressBatchService;
import com.commerzbank.gdk.bns.service.ChangeEmailAddressService;

/**
 * Change Email Address Controller - Accept Change Email Address request to
 * create, update and delete email address records, update notification
 * configuration records and return the response to ZSL.
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.05
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2BUEN    Initial Version
 * 27/11/2017        1.01       ZE2BUEN    Added Implementation of Batch Processing
 * 07/12/2017        1.02       ZE2SARO    Add Validation
 * 13/12/2017        1.03       ZE2BUEN    Clean up for ZSL logging  
 * 05/02/2018        1.04       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.05       ZE2MACL    Removed throws Exception
 *          </pre>
 */

@RestController
public class ChangeEmailAddressController {

    @Autowired
    private ChangeEmailAddressService changeEmailAddressService;

    @Autowired
    private ChangeEmailAddressBatchService changeEmailAddressBatchService;

    private static final Logger LOGGER = LoggerFactory.getLogger(ChangeEmailAddressController.class);

    /**
     * Accept client change email address request then call service to create,
     * update and delete email address records, update notification
     * configuration records and return the status response to ZSL then return
     * also produces xml or json format.
     * 
     * @param changeEmailAddressRequest
     *            ChangeEmailAddressRequest Change Email Address Request
     * @param request
     *            HttpServletRequest Http Servlet Request
     * @return ResponseEntity Change Email Address Response
     */
    @PostMapping(value = "/api/zsl/requestForChangeEmailAddress")
    public ResponseEntity<ChangeEmailAddressResponse> requestForChangeEmailAddress(
            @Valid @RequestBody ChangeEmailAddressRequest changeEmailAddressRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForChangeEmailAddress({})", "ZSL", changeEmailAddressRequest.toString());

        ChangeEmailAddressResponse emailResponse = new ChangeEmailAddressResponse();

        if (!result.hasErrors()) {
            emailResponse = this.changeEmailAddressService.requestForChangeEmailAddress(changeEmailAddressRequest);

            if (Objects.isNull(emailResponse)) {
                emailResponse = new ChangeEmailAddressResponse();
            }

        }

        ResponseEntity<ChangeEmailAddressResponse> response = new ResponseEntity<ChangeEmailAddressResponse>(
                emailResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", emailResponse.toString());

        return response;
    }

    /**
     * Accept client change email address batch request then call service to
     * create, update and delete email address records, update notification
     * configuration records and return the status response to ZSL then return
     * also produces xml or json format.
     * 
     * @param changeEmailAddressBatchRequest
     *            ChangeEmailAddressBatchRequest Change Email Address Batch
     *            Request
     * @param request
     *            HttpServletRequest Http Servlet Request
     * @return ResponseEntity Change Email Address Batch Response
     */
    @PostMapping(value = "/api/zsl/requestForBatchChangeEmailAddress")
    public ResponseEntity<ChangeEmailAddressBatchResponse> requestForBatchChangeEmailAddress(
            @Valid @RequestBody ChangeEmailAddressBatchRequest changeEmailAddressBatchRequest,
            HttpServletRequest request, BindingResult result) throws Exception {

        LOGGER.info("=>> System [{}] - requestForBatchChangeEmailAddress({})", "ZSL",
                changeEmailAddressBatchRequest.toString());

        ChangeEmailAddressBatchResponse batchResponse = new ChangeEmailAddressBatchResponse();

        if (!result.hasErrors()) {
            batchResponse = this.changeEmailAddressBatchService
                    .requestForBatchChangeEmailAddress(changeEmailAddressBatchRequest);

            if (Objects.isNull(batchResponse)) {
                batchResponse = new ChangeEmailAddressBatchResponse();
            }

        }

        ResponseEntity<ChangeEmailAddressBatchResponse> response = new ResponseEntity<ChangeEmailAddressBatchResponse>(
                batchResponse, HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", batchResponse.toString());

        return response;
    }

}
