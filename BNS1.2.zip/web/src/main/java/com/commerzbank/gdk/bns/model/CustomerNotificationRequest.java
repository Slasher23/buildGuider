package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for CustomerNotificationRequest
 * 
 * @since 09/11/2017
 * @author ZE2SARO
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 09/11/2017        1.00       ZE2SARO    Initial Version
 * 14/12/2017        1.01       ZE2MENY    Change the length limit of vereinbarungskennung into 50 
 *          </pre>
 */
@XmlRootElement(name = "CustomerNotificationRequest")
public class CustomerNotificationRequest {

    @NotNull
    @Size(max = 10)
    private String kundennummer;

    @Size(max = 50)
    private String vereinbarungskennung;

    @Max(value = 999)
    private Integer sparte;

    /**
     * @return the kundennummer
     */
    public String getKundennummer() {
        return kundennummer;
    }

    /**
     * @param kundennummer the kundennummer to set
     */
    public void setKundennummer(String kundennummer) {
        this.kundennummer = kundennummer;
    }

    /**
     * @return the vereinbarungskennung
     */
    public String getVereinbarungskennung() {
        return vereinbarungskennung;
    }

    /**
     * @param vereinbarungskennung the vereinbarungskennung to set
     */
    public void setVereinbarungskennung(String vereinbarungskennung) {
        this.vereinbarungskennung = vereinbarungskennung;
    }

    /**
     * @return the sparte
     */
    public Integer getSparte() {
        return sparte;
    }

    /**
     * @param sparte the sparte to set
     */
    public void setSparte(Integer sparte) {
        this.sparte = sparte;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CustomerNotificationRequest [kundennummer=" + kundennummer + ", vereinbarungskennung="
                + vereinbarungskennung + ", sparte=" + sparte + "]";
    }

}
