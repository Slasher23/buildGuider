package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.Email;

/**
 * Email DAO Interface
 * 
 * @since 30/06/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 30/06/2017		1.00		ZE2BUEN 	Initial Version
 * 26/10/2017       1.01        ZE2GOME     Added findByEmailUID
 * 23/11/2017		1.02		ZE2BUEN 	Added findByPersonUIDAndAddressId
 * 28/11/2017		1.03		ZE2BUEN 	Added findByAddressId
 * </pre>
 */

public interface EmailDAO extends PagingAndSortingRepository<Email, Long>, EmailCustomDAO{

	List<Email> findByPersonUID(Long personUID);
	
	Email findByEmailUID(Long emailUID);
	
	Email findByPersonUIDAndAddressId(Long personUID, Long addressId);
	
	Email findByAddressId(Long addressId);
	
}
