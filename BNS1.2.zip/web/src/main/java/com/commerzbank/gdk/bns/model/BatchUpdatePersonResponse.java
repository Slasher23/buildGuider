package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for Batch Update Person Response.
 * 
 * @since 4/12/2017
 * @author ZE2MENY
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description 
 * 4/12/2017         1.00       ZE2MENY    Initial Version
 *          </pre>
 */
public class BatchUpdatePersonResponse {

    List<ZslUpdateResponse> updatePersonResponse;

    List<ZslUpdateResponse> updatePersonResponseWithErrors;

    /**
     * Get list of ZSL update response without error.
     * 
     * @return the updatePersonResponse
     */
    public List<ZslUpdateResponse> getUpdatePersonResponse() {
        return updatePersonResponse;
    }

    /**
     * Set list of ZSL update response without error.
     * 
     * @param updatePersonResponse the updatePersonResponse to set
     */
    public void setUpdatePersonResponse(List<ZslUpdateResponse> updatePersonResponse) {
        this.updatePersonResponse = updatePersonResponse;
    }

    /**
     * Get list of ZSL update response with error.
     * 
     * @return the updatePersonResponseWithErrors
     */
    public List<ZslUpdateResponse> getUpdatePersonResponseWithErrors() {
        return updatePersonResponseWithErrors;
    }

    /**
     * Set list of ZSL update response with error.
     * 
     * @param updatePersonResponseWithErrors the updatePersonResponseWithErrors
     *            to set
     */
    public void setUpdatePersonResponseWithErrors(List<ZslUpdateResponse> updatePersonResponseWithErrors) {
        this.updatePersonResponseWithErrors = updatePersonResponseWithErrors;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "BatchUpdatePersonResponse [updatePersonResponse=" + updatePersonResponse
                + ", updatePersonResponseWithErrors=" + updatePersonResponseWithErrors + "]";
    }

    /**
     * Returns the String representation of Batch Update Person Response Model.
     * 
     * @return String String representation of Batch Update Person Response
     *         Model
     * 
     */


}
