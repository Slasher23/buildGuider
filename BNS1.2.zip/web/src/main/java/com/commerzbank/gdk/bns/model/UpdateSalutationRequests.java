package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for UpdateSalutationRequests.
 * 
 * @since 29/11/2017
 * @author ZE2SARO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 29/11/2017        1.00       ZE2SARO    Initial Version
 *          </pre>
 */
public class UpdateSalutationRequests {

    private List<UpdateSalutationRequest> updateSalutationRequest;

    /**
     * @return the updateSalutationRequest
     */
    public List<UpdateSalutationRequest> getUpdateSalutationRequest() {
        return updateSalutationRequest;
    }

    /**
     * @param updateSalutationRequest the updateSalutationRequest to set
     */
    public void setUpdateSalutationRequest(List<UpdateSalutationRequest> updateSalutationRequest) {
        this.updateSalutationRequest = updateSalutationRequest;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UpdateSalutationRequests [updateSalutationRequest=" + updateSalutationRequest + "]";
    }

}
