package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Batch Notification.
 * 
 * @author ZE2BAUL
 * @since 12/12/2017
 * @version 1.00
 *
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017	     1.00       ZE2BAUL    Initial Version
 *          </pre>
 */
@XmlRootElement
public class RequestForBatchNotification {

	/**
	 * List for Notification Request.
	 */
	private List<NotificationRequest> notificationRequest;

	/**
	 * Returns the List of Notification Request.
	 *
	 * @return the notificationRequest
	 */
	public List<NotificationRequest> getNotificationRequest() {
		return notificationRequest;
	}

	/**
	 * Sets the List of Notification Request.
	 *
	 * @param notificationRequest
	 *            the notificationRequest to set
	 */
	public void setNotificationRequest(List<NotificationRequest> notificationRequest) {
		this.notificationRequest = notificationRequest;
	}

	/**
	 * Returns the String representation of Notification Batch Request Model.
	 * 
	 * @return String String representation of Notification Batch Request Model
	 */
	@Override
	public String toString() {
		return "RequestForBatchNotification [notificationRequest=" + notificationRequest + "]";
	}
}
