package com.commerzbank.gdk.bns.model;

import java.time.LocalDateTime;

/**
 * Model Class for Response Message
 * 
 * @since 25/07/2017
 * @author ZE2RUBI
 * @version 1.03
 * 
 * <pre>
 * Modified Date     Version    Author     Description 
 * 25/07/2017        1.01       ZE2RUBI    Initial Version
 * 21/09/2017        1.02      	ZE2GOME    Updated Version
 * 26/09/2017		 1.03		ZE2BAUL	   Updated the return type of code from String to Integer
 * </pre>
 */
public class ResponseMessage {

	private Integer code;

	private String title;

	private String description;

	private String user;

	private Object errorMessage;

	private LocalDateTime timestamps = LocalDateTime.now();

	/**
	 * Constructor method to be used in the configuration file to initialised
	 * the Response Message Map
	 * 
	 * @param code Integer Code to set
	 * @param title String Title to set
	 * @param description String Description to set
	 */
	public ResponseMessage(Integer code, String title, String description) {
		super();
		this.code = code;
		this.title = title;
		this.description = description;
	}

	/**
	 * Returns the value of Code
	 * 
	 * @return String Code
	 */
	public Integer getCode() {
		return code;
	}

	/**
	 * Sets the value of Code
	 * 
	 * @param code Integer Code to set
	 */
	public void setCode(Integer code) {
		this.code = code;
	}

	/**
	 * Returns the value of Description
	 * 
	 * @return String Description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of Description
	 * 
	 * @param description String Description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Returns the value of Timestamps
	 * 
	 * @return LocalDateTime Timestamps
	 */
	public LocalDateTime getTimestamps() {
		return timestamps;
	}

	/**
	 * Sets the value of Timestamps
	 * 
	 * @param timestamps LocalDateTime Timestamps to set
	 */
	public void setTimestamps(LocalDateTime timestamps) {
		this.timestamps = timestamps;
	}

	/**
	 * Returns the value of Title
	 * 
	 * @return String Title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the value of Title
	 * 
	 * @param title String Title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Returns the value of User
	 * 
	 * @return String User
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Sets the value of User
	 * 
	 * @param user String User to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Returns the value of Error Message
	 * 
	 * @return Object Error Message
	 */
	public Object getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the value of Error Message
	 * 
	 * @param errorMessage Object Error Message to set
	 */
	public void setErrorMessage(Object errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	/**
	 * Returns the String representation of Response Message Model
	 * 
	 * @return String String representation of Response Message Model
	 */
	@Override
	public String toString() {
		return "ResponseMessage [code= " + code + " , title= " + title + 
			   " , description= " + description + " , user= " + user + 
			   " , errorMessage= " + errorMessage + " , timestamps= " + timestamps + "]";
	}
	
}
