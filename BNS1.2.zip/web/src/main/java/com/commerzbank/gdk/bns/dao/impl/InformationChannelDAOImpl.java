package com.commerzbank.gdk.bns.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.InformationChannelCustomDAO;
import com.commerzbank.gdk.bns.model.InformationChannel;

/**
 * DAO Implementation Class to get the Information Channel List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.01
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.01		ZE2SARO 	InitialVersion
 *          </pre>
 */
@Repository
public class InformationChannelDAOImpl implements InformationChannelCustomDAO {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Returns the value of Information Channel
     * 
     * @return Information Channel List of Information Channel DAO
     *         Implementation
     */
    @Override
    public List<InformationChannel> getInformationChannelList() {

        List<InformationChannel> informationChannelList = this.entityManager
                .createQuery("FROM InformationChannel", InformationChannel.class).getResultList();

        return informationChannelList;
    }

    /**
     * Returns the value of Information Channel.
     * 
     * @param type String use for condition.
     * @return Information Channel by type.
     */
    @Override
    public Long getInformationChannelUID(String type) {

        Long infoChannelUID = null;
        TypedQuery<InformationChannel> query = this.entityManager.createQuery(
                "FROM InformationChannel WHERE informationChannelType = '" + type + "'", InformationChannel.class);
        if (query.getResultList().size() != 0)
            infoChannelUID = query.setMaxResults(1).getSingleResult().getInformationChannelUID();

        return infoChannelUID;
    }

}
