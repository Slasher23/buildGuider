package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Notification Response
 * 
 * @since 26/10/2017
 * @author ZE2FUEN
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2FUEN    Initial Version
 * 14/12/2017        1.01       ZE2MENY    Change the length limit of vereinbarungskennung into 50
 *          </pre>
 */
@XmlRootElement(name = "NotificationRequest")
public class NotificationRequest {

	
	@Size(max = 16)
	private String bpkenn;

	@Size(max = 50)
	private String vereinbarungskennung;

	@Max(value = 999)
	private Integer sparte;

	/**
	 * Returns the value of bpkenn
	 * 
	 * @return String bpkenn
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * Sets the value of bpkenn
	 * 
	 * @param String
	 *            bpkenn
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the value of vereinbarungskennung
	 * 
	 * @return String vereinbarungskennung
	 */
	public String getVereinbarungskennung() {
		return vereinbarungskennung;
	}

	/**
	 * Sets the value of vereinbarungskennung
	 * 
	 * @param String
	 *            vereinbarungskennung
	 */
	public void setVereinbarungskennung(String vereinbarungskennung) {
		this.vereinbarungskennung = vereinbarungskennung;
	}

	/**
	 * Returns the value of sparte
	 * 
	 * @return int sparte
	 */
	public Integer getSparte() {
		return sparte;
	}

	/**
	 * Sets the value of sparte
	 * 
	 * @param int
	 *            sparte
	 */
	public void setSparte(Integer sparte) {
		this.sparte = sparte;
	}

	/**
	 * Returns the String representation of the request Model for
	 * NotificationRequest
	 * 
	 * @return String String representation of the request Model for
	 *         NotificationRequest
	 */
	@Override
	public String toString() {
		return "NotificationRequest [bpkenn=" + bpkenn + ", vereinbarungskennung=" + vereinbarungskennung + ", sparte="
				+ sparte + "]";
	}

}
