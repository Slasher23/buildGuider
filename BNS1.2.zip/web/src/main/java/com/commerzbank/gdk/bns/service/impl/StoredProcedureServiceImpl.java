package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.service.StoredProcedureService;

/**
 * Service Implementation Class used to implement the business logic
 * invalidating account.
 * 
 * @since 21/12/2017
 * @author ZE2MENY
 * @version 1.01
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 21/12/2017       1.00        ZE2MENY     InitialVersion
 * 27/12/2017       1.01        ZE2MACL     Update method, changed agreement to list and rename variable
 *          </pre>
 */
@Service
@Transactional
public class StoredProcedureServiceImpl implements StoredProcedureService {

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    private AgreementDAO agreementDAO;

    /**
     * Validate accounts using a given bpkenn, agreementId and sparte.
     * 
     * @param bpkenn
     * @param agreementId
     * @param sparte
     * @return String 01
     */
    @Override
    public String validateAccount(String bpkenn, String agreementId, Integer sparte) {
        String bpkenn02 = "STOREDPROC02";
        String agreementId02 = "DE01 2345 6789 1011 1213 99";
        Integer sparte02 = 100;
        
        String bpkenn03 = "STOREDPROC03";
        String agreementId03 = "DE01 2345 6789 1011 1213 98";
        Integer sparte03 = 100;
        
        String bpkenn04 = "STOREDPROC04";
        String agreementId04 = "DE01 2345 6789 1011 1213 97";
        Integer sparte04 = 100;
        
        if(bpkenn.equalsIgnoreCase(bpkenn02) && agreementId.equalsIgnoreCase(agreementId02) && sparte.equals(sparte02)){
            return "02";  
        } else if(bpkenn.equalsIgnoreCase(bpkenn03) && agreementId.equalsIgnoreCase(agreementId03) && sparte.equals(sparte03)){
            return "03";
        } else if(bpkenn.equalsIgnoreCase(bpkenn04) && agreementId.equalsIgnoreCase(agreementId04) && sparte.equals(sparte04)){
            return "04";
        } else {
            return "01";
             
        }
  
    }

    /**
     * Delete person related using a given bpkenn.
     * 
     * @param String bpkenn
     * @return String 02
     */
    @Override
    public void deletePersonRelated(String bpkenn) {
        Person person = this.personDAO.findByBpkennIgnoreCase(bpkenn);
        this.personDAO.delete(person.getPersonUID());

    }

    /**
     * Delete agreeement related using a given agreementId and sparte.
     * 
     * @param String agreementId
     * @param Integer sparte
     * @return String 03
     */
    @Override
    public void deleteAgreementRelated(String agreementId, Integer sparte) {
        List<Agreement> agreement = this.agreementDAO.findByAgreementIDIgnoreCaseAndBranch(agreementId, sparte);
        if (Objects.nonNull(agreement)) {
            this.agreementDAO.delete(agreement);
        }
       
    }


}
