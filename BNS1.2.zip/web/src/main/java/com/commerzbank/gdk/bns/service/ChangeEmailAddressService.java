package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.ChangeEmailAddressRequest;
import com.commerzbank.gdk.bns.model.ChangeEmailAddressResponse;

/**
 * Service Class used to process request to create, update and delete email
 * address records and update notification configuration records
 * 
 * @since 08/11/2017
 * @author ZE2BUEN
 * @version 1.02
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 08/11/2017        1.00       ZE2BUEN    Initial Version
 * 09/02/2018        1.01       ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface ChangeEmailAddressService {

	ChangeEmailAddressResponse requestForChangeEmailAddress(ChangeEmailAddressRequest request);

}
