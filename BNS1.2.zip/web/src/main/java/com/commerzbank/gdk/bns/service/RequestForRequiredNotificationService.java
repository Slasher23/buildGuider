package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.NotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForRequiredBatchNotification;
import com.commerzbank.gdk.bns.model.RequiredBatchNotificationResponseWrapper;
import com.commerzbank.gdk.bns.model.RequiredNotificationRequest;

/**
 * Service Class used for RequestForRequiredNotification.
 * 
 * @since 20/09/2017
 * @author ZE2FUEN
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 20/09/2017        1.00       ZE2FUEN    Initial Version
 * 10/11/2017        1.01       ZE2BAUL    Renamed the class to adhere to the requirements
 *                                         Added method for requiredBatchNotification
 * 23/11/2017        1.02       ZE2GOME    Change RequiredNotificationResponse to NotificationResponse
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 13/12/2017        1.04       ZE2CRUH    Added processRunID as parameter
 * 05/02/2018        1.05       ZE2FUEN    Removed processRunID as parameter
 * 09/02/2018        1.06       ZE2MACL    Removed throws Exception
 *          </pre>
 */

public interface RequestForRequiredNotificationService {

	/**
	 * Method for requestingForRequiredNotification.
	 * 
	 * @param requiredNotificatonRequest
	 *            notification to request.
	 * @return RequestForRequiredNotificationResponse notification response.
	 */
	NotificationResponse requestForRequiredNotification(RequiredNotificationRequest requiredNotificatonRequest);

	/**
	 * Method for requestingForRequiredBatchNotification.
	 * 
	 * @param requiredNotificatonBatchRequestList
	 *            RequiredNotificationRequest list of notification to request.
	 * @return RequiredBatchNotificationResponseWrapper notification response
	 *         with success and errors.
	 */
	RequiredBatchNotificationResponseWrapper requestForRequiredBatchNotification(
					RequestForRequiredBatchNotification requiredNotificatonBatchRequestList);
}
