package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Vereinbarung(Agreement) Table
 * 
 * @since 03/07/2017
 * @author ZE2FUEN
 * @version 1.11
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 03/07/2017        1.01       ZE2FUEN    Initial Version
 * 25/08/2017        1.02       ZE2BUEN    Modified max data size of VEREINBARUNGS_ID from 20 to 50
 * 30/08/2017        1.03       ZE2RUBI    Add XMLROOTELEMENT annotation
 * 14/09/2017        1.04       ZE2SARO    Change PERSON_UID to TEILNEHMENUMMER_UID
 * 21/09/2017		 1.05		ZE2BAUL	   Added TYP and AGREEMENTHOLDER_NAME (for standby for Nomenclature)
 * 29/09/2017		 1.06		ZE2BUEN	   Remove agreement holder name column.
 * 										   Added agreement holder last name column.
 *                                         Added agreement holder given name column.
 *                                         Modified type column datatype max size from 50 to 30.
 * 23/11/2017        1.07       ZE2BUEN    Modified TEILNEHMENUMMER_UID to PERSON_UID      
 * 22/12/2017        1.08       ZE2CRUH    Added IBAN column     
 * 30/01/2018        1.09       ZE2FARI    Added NAME_DES_INHABERS column
 * 30/01/2018        1.10       ZE2FARI    Removed the Lastname and Firstname column
 * 01/02/2018        1.11       ZE2BUEN    Modified agreement constructor
 */

@Entity
@Table(name = "VEREINBARUNG")
@XmlRootElement
public class Agreement {

	@Id
	@Column(name = "VEREINBARUNG_UID")
	@GeneratedValue(generator = "VEREINBARUNG_UID_SEQ")
	@SequenceGenerator(name = "VEREINBARUNG_UID_SEQ", sequenceName = "VEREINBARUNG_SEQ")
	private Long agreementUID;

	@NotNull
	@Size(max = 50)
	@Column(name = "VEREINBARUNGS_ID")
	private String agreementID;

	@NotNull
	@Max(value = 999)
	@Column(name = "SPARTE")
	private int branch;

	@Size(max = 3)
	@Column(name = "VEREINBARUNGS_TYP")
	private String agreementType;
	
	@Size(max = 30)
	@Column(name = "TYP")
	private String type;
	
	@Size(max = 500)
	@Column(name = "NAME_DES_INHABERS")
	private String agreementCustomerName;

	@NotNull
	@Max(value = 99999999999L)
	@Column(name = "PERSON_UID")
	private Long personUID;
	
	@Size(max = 22)
	@Column(name = "IBAN")
	private String iban;

	public Agreement(){}
	public Agreement(Long agreementUID, String agreementID, int branch, String agreementType, String type,
            String agreementCustomerName, Long personUID, String iban) {
        super();
        this.agreementUID = agreementUID;
        this.agreementID = agreementID;
        this.branch = branch;
        this.agreementType = agreementType;
        this.type = type;
        this.agreementCustomerName = agreementCustomerName;
        this.personUID = personUID;
        this.iban = iban;
        
    }

    /**
	 * Returns the value of Unique Identifier of Agreement Record
	 * 
	 * @return Long Unique Identifier of Agreement Record
	 */
	public Long getAgreementUID() {
		return agreementUID;
	}

	/**
	 * Sets the value of Unique Identifier of Agreement Record
	 * 
	 * @param agreementUID Long Unique Identifier of Agreement Record to set
	 */
	public void setAgreementUID(Long agreementUID) {
		this.agreementUID = agreementUID;
	}

	/**
	 * Returns the value of Agreement ID
	 * 
	 * @return String Agreement ID
	 */
	public String getAgreementID() {
		return agreementID;
	}

	/**
	 * Sets the value of Agreement ID
	 * 
	 * @param agreementID String Agreement ID to set
	 */
	public void setAgreementID(String agreementID) {
		this.agreementID = agreementID;
	}

	/**
	 * Returns the value of Branch
	 * 
	 * @return int Branch
	 */
	public int getBranch() {
		return branch;
	}

	/**
	 * Sets the value of Branch
	 * 
	 * @param branch int Branch to set
	 */
	public void setBranch(int branch) {
		this.branch = branch;
	}

	/**
	 * Returns the value of Agreement Type
	 * 
	 * @return String Agreement Type
	 */
	public String getAgreementType() {
		return agreementType;
	}

	/**
	 * Sets the value of Agreement Type
	 * 
	 * @param agreementType String Agreement Type to set
	 */
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}
	
	
	/**
	 * Returns the value of Type
	 * 
	 * @return String Type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the value of Type
	 * 
	 * @param type String Type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Returns the value of Unique Identifier of Person record
	 * 
	 * @return Long Unique Identifier of Person record
	 */
	public Long getPersonUID() {
		return personUID;
	}

	/**
	 * Sets the value of Unique Identifier of Person record
	 * 
	 * @param personUID Long Unique Identifier of Person to set
	 */
	public void setPersonUID(Long personUID) {
		this.personUID = personUID;
	}

	/**
	 * @return the iban
	 */
	public String getIban() {
		return iban;
	}

	/**
	 * @param iban the iban to set
	 */
	public void setIban(String iban) {
		this.iban = iban;
	}
	
	/**
	 * @param agreementCustomerName Full Customer Name to set
	 */
	public void setCustomerName(String agreementCustomerName) {
		this.agreementCustomerName = agreementCustomerName;
	}
	
	/**
	 * @return the customer name
	 */
	public String getCustomerName() {
		return this.agreementCustomerName;
	}

	/**
	 * Returns the String representation of Agreement Model
	 * 
	 * @return String String representation of Agreement Model
	 */
	@Override
	public String toString() {
		return "Agreement [agreementUID=" + agreementUID + ", agreementID=" + agreementID + ", branch=" + branch
				+ ", agreementType=" + agreementType + ", type=" + type + ", agreementCustomerNames=" + agreementCustomerName + ", personUID="
				+ personUID + ", iban=" + iban + "]";
	}
	
}
