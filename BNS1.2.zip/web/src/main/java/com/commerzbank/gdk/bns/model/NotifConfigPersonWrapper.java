package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for Notification Configuration Agreement for Person Agreement only
 * Returns and set Agreement and Notification Configuration Agreement of Person Agreement
 * 
 * @author 	ze2baul
 * @since 	02.10.2017
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 02.10.2017	     1.01       ze2baul    Initial Version
 * </pre>
 */
@XmlRootElement(name = "agreements")
public class NotifConfigPersonWrapper {
	
	private String textType;
	
	private NotificationConfigPerson notificationConfigPerson;
	
	/**
	 * Returns the value of the TextType (e.g. STD)
	 *
	 * @return the textType
	 */
	public String getTextType() {
		return textType;
	}
	/**
	 * Sets the value of the TextType (e.g. STD)
	 *
	 * @param textType the textType to set
	 */
	public void setTextType(String textType) {
		this.textType = textType;
	}
	/**
	 * Returns the Notification Configuration Person Agreement Model
	 *
	 * @return the notificationConfigPerson
	 */
	public NotificationConfigPerson getNotificationConfigPerson() {
		return notificationConfigPerson;
	}
	/**
	 * Sets the Notification Configuration Person Agreement Model
	 *
	 * @param notificationConfigPerson the notificationConfigPerson to set
	 */
	public void setNotificationConfigPerson(NotificationConfigPerson notificationConfigPerson) {
		this.notificationConfigPerson = notificationConfigPerson;
	}
	
	/**
	 * Returns the String representation of Person Notification Configuration 
	 * Agreement Wrapper
	 * 
	 * @return String String representation of Notification Configuration 
	 *                Agreement Wrapper
	 */
	@Override
	public String toString() {
		return "NotificationConfigPersonsWrapper [textType= " + textType + 
				" ,  notificationConfigPerson= " + notificationConfigPerson + "]";
	}	
}
