package com.commerzbank.gdk.bns.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.Person;

/**
 * Person DAO Interface
 * 
 * @since 30/06/2017
 * @author ZE2CRUH
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 30/06/2017		1.01		ZE2CRUH 	Initial Version
 * </pre>
 */

public interface PersonDAO extends PagingAndSortingRepository<Person, Long>, PersonCustomDAO{
	
	Person findByBpkennIgnoreCase(String bpkenn);
	Person findByPersonUID(Long personUID);
}
