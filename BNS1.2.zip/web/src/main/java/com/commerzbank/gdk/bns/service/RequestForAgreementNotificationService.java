package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.AgreementNotificationRequest;
import com.commerzbank.gdk.bns.model.RequestForAgreementNotificationResponse;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotification;
import com.commerzbank.gdk.bns.model.RequestForBatchAgreementNotificationResponse;

/**
 * Service Class used to access the Agreement Notification.
 * 
 * @since 11/12/2017
 * @author ZE2GOME
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 11/12/2017        1.00       ZE2GOME    Initial Version
 * 12/12/2017        1.01       ZE2JAVO    Added method for batch
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 *          </pre>
 */
public interface RequestForAgreementNotificationService {

	RequestForAgreementNotificationResponse requestForAgreementNotification(
			AgreementNotificationRequest agreementNotificationRequest);

	RequestForBatchAgreementNotificationResponse requestForBatchAgreementNotification(
			RequestForBatchAgreementNotification requestForBatchAgreementNotification);

}
