package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Wrapper Class for agreement Person.
 * This class returns and sets List of Benach_Konfig_Person.
 * 
 * @since 02/10/2017
 * @author ZE2BAUL
 * @version 1.01
 *
 * <pre>
 * Modified Date     Version    Author     Description
 * 02/10/2017        1.01       ZE2BAUL    Initial Version
 * </pre>
 */

@XmlRootElement(name = "personConfigType")
public class PersonConfigWrapper {
	
	private String agreementType;
	
	private NotifConfigPersonWrapper personConfig;

	/**
	 * Returns the value of Agreement Type
	 *
	 * @return the agreementType
	 */
	public String getAgreementType() {
		return agreementType;
	}

	/**
	 * Sets the value of Agreement Type
	 *
	 * @param agreementType the agreementType to set
	 */
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}

	/**
	 * Returns the Person Agreement
	 *
	 * @return the personAgreement
	 */
	public NotifConfigPersonWrapper getPersonConfig() {
		return personConfig;
	}

	/**
	 * Sets the Person Agreement
	 *
	 * @param personConfig the personAgreement to set
	 */
	public void setPersonAgreement(NotifConfigPersonWrapper personConfig) {
		this.personConfig = personConfig;
	}
	
	/**
	 * Returns the String representation of Person Agreement Types Wrapper
	 * 
	 * @return String String representation of Person Agreement Types Wrapper
	 */
	@Override
	public String toString() {
		return "PersonAgreementTypesWrapper [agreementType= " + agreementType + " , personConfig= " + personConfig + "]";
	}
}
