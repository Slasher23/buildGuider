package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.common.BNSConstants;
import com.commerzbank.gdk.bns.dao.AllNotificationConfigDAO;
import com.commerzbank.gdk.bns.dao.InformationChannelDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigAgreementDAO;
import com.commerzbank.gdk.bns.dao.NotificationConfigPersonDAO;
import com.commerzbank.gdk.bns.dao.NotificationTextDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.AllNotificationConfig;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.InformationChannel;
import com.commerzbank.gdk.bns.model.MainAgreementTypeWrapper;
import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;
import com.commerzbank.gdk.bns.model.NotificationConfigPerson;
import com.commerzbank.gdk.bns.model.NotificationText;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementTypesWrapperService;
import com.commerzbank.gdk.bns.service.AllNotificationConfigService;
import com.commerzbank.gdk.bns.utils.Tools;

/**
 * AllNotificationConfigServiceImpl class to get all notification configuration
 * 
 * @since 09/22/2017
 * @author ZE2SARO
 * @version 1.09
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 09/22/2017		1.00		ZE2SARO 	InitialVersion
 * 02/10/2017		1.01		ZE2BAUL		Changed the AgreementEmailChannelWrapper to MainAgreementTypeWrapper
 * 03/10/2017		1.02		ZE2BAUL		Added the implementation change for the PersonConfig
 * 14/11/2017       1.03        ZE2SARO     Added implementation for creating notification configuration
 * 23/11/2017       1.04        ZE2MACL     Removed participantDAO
 * 24/11/2017       1.05        ZE2MORA     Implemented Status Codes
 * 27/11/2017       1.06        ZE2CRUH     Removed Participant Number
 * 06/02/2018       1.07        ZE2FUEN     Disabled agreement update for custom agreement config
 * 20/02/2018       1.08        ZE2FUEN     Updated implementation to CIF-Integration
 * 28/02/2018       1.09        ZE2FUEN     Implemented BNStoken builder
 *          </pre>
 */
@Service
@Transactional
public class AllNotificationConfigServiceImpl implements AllNotificationConfigService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AllNotificationConfigServiceImpl.class);

    @Autowired
    private AllNotificationConfigDAO allNotificationConfigDAO;

    @Autowired
    private AgreementTypesWrapperService agreementTypesWrapperService;

    @Autowired
    private NotificationConfigAgreementDAO notifConfigAgreementDAO;

    @Autowired
    private NotificationConfigPersonDAO notifConfigPersonDAO;

    @Autowired
    private PersonDAO personDAO;

    @Autowired
    NotificationTextDAO notificationTextDAO;

    @Autowired
    private Environment environment;

    @Autowired
    private InformationChannelDAO informationChannelDAO;

    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;
    
    @Autowired
    public Tools tools;

    /**
     * Retrieves all notif config value.
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @param parameter
     *            Parameter to get all notif record
     * @return AllNotificationConfig record
     */
    @Override
    public ResponseBuilder<AllNotificationConfig> getAllNotifConfig(Tokenizer token) {

        ResponseBuilder<AllNotificationConfig> builder = new ResponseBuilder<>(LOGGER, token, globalResponseWrapper);

        String bpkenn = token.getBpkenn();

        try {

            Person person = this.personDAO.findByBpkennIgnoreCase(bpkenn);

            AllNotificationConfig allNotificationConfig = this.allNotificationConfigDAO
                    .findByPersonUID(person.getPersonUID());

            if (Objects.nonNull(allNotificationConfig)) {
                builder.OK(allNotificationConfig);
            } else {
                builder.OK(allNotificationConfig, Response.SUCCESS_NO_ALLNOTIFCONFIG_FOUND);
            }

        } catch (DataAccessException e) {
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        } catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
            builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        LOGGER.info("<<= User [{}] getAllNotifConfig({}) request was successfully processed.", token.getUserId(),
                bpkenn);

        return builder;
    }

    /**
     * Save all notif config and retrieves value of AgreementTypesWrapper of
     * Person Record.
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @param allNotificationConfig
     *            AllNotificationConfig to be saved
     * @return AgreementTypesWrapper record
     */
    @Override
    public ResponseBuilder<MainAgreementTypeWrapper> saveAllNotifConfig(Tokenizer token,
            AllNotificationConfig allNotificationConfig, String bnsToken) {

        ResponseBuilder<MainAgreementTypeWrapper> builder = new ResponseBuilder<MainAgreementTypeWrapper>(LOGGER, token,
                globalResponseWrapper);
        
        List<String> bnsTokenList = tools.bnsTokenDebuilder(bnsToken);
        
        if (bnsTokenList.size() > 1) {
            String agreementListString = bnsTokenList.get(1);
            List<String> listAgreementUIDString = Arrays.asList(agreementListString.split(Pattern.quote(",")));
            List<Long> listAgreementUID = new ArrayList<Long>();
            
            for(String agreementUidString : listAgreementUIDString) {
                listAgreementUID.add(Long.parseLong(agreementUidString)); 
             }
            
            try {

                Person person = this.personDAO.findOne(allNotificationConfig.getPersonUID());
                Parameter parameter = new Parameter();

                // save all notif config
                this.allNotificationConfigDAO.save(allNotificationConfig);

                // save notif config agreement
                saveNotifConfigAgreement(token, listAgreementUID, allNotificationConfig);

                // get notif config person per person uid
                NotificationConfigPerson notifConfigPerson = this.notifConfigPersonDAO
                        .findByPersonUID(person.getPersonUID());

                // save notif config person
                saveNotifConfigPerson(token, notifConfigPerson, allNotificationConfig);

                parameter.setBpkenn(person.getBPKENN());

                MainAgreementTypeWrapper mainAgreementTypesWrapper = this.agreementTypesWrapperService
                        .getMainAgreementTypeWrapperList(token, listAgreementUID).getData();

                if (Objects.nonNull(mainAgreementTypesWrapper)) {
                    builder.OK(mainAgreementTypesWrapper);
                } else {
                    builder.OK(mainAgreementTypesWrapper, Response.SUCCESS_NO_RESULTS_FOUND);
                }
                
                LOGGER.info("<<= User [{}] saveAllNotifConfig({}) request was successfully processed.", token.getUserId(),
                        allNotificationConfig.toString());

            } catch (DataAccessException e) {
                builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
            } catch (NullPointerException e) {
                builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
            } catch (Exception e) {
                builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
            }
            
        } else {
            builder.OK(Response.SUCCESS_NO_RESULTS_FOUND);
            
            LOGGER.info("<<= User [{}] saveAllNotifConfig({}) request was successfully processed.", token.getUserId(),
                    allNotificationConfig.toString());
        }
        
        return builder;
    }

    /**
     * Save notification config agreement.
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @param listAgreementUID
     *            List<Long> to be saved
     * @param allNotificationConfig
     *            AllNotificationConfig to be saved
     */
    private void saveNotifConfigAgreement(Tokenizer token, List<Long> listAgreementUID,
            AllNotificationConfig allNotificationConfig) {

        List<NotificationConfigAgreement> listNotifConfig = new ArrayList<NotificationConfigAgreement>();

        for (Long agreementUID : listAgreementUID) {
            // get notif config agreement per agreement uid
            NotificationConfigAgreement notifConfigAgreement = this.notifConfigAgreementDAO
                    .findByAgreementUID(agreementUID);

            if (Objects.nonNull(notifConfigAgreement)) {

                if (!this.isCustomSettings(notifConfigAgreement.getNotificationTextUID())) {
                    notifConfigAgreement.setEmailUID(allNotificationConfig.getEmailUID());
                    notifConfigAgreement.setInformationChannelUID(allNotificationConfig.getInformationChannelUID());
                }
                ;

            } else {
                notifConfigAgreement = new NotificationConfigAgreement(agreementUID, false,
                        getInitialInfoChannelUID(token), allNotificationConfig.getEmailUID(),
                        getTextUID(token, agreementUID, BNSConstants.VERLASSUNGS_TYPE_KEY));
            }

            listNotifConfig.add(notifConfigAgreement);
        }

        if (listNotifConfig.size() > 0) {
            this.notifConfigAgreementDAO.save(listNotifConfig);
        }

        LOGGER.info("<<= User [{}] saveNotifConfigAgreement({},{}) request was successfully processed.",
                token.getUserId(), listNotifConfig.toString(), allNotificationConfig.toString());
    }

    /**
     * Save notification config person.
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @param notifConfigPerson
     *            NotificationConfigPerson to be saved
     * @param allNotificationConfig
     *            AllNotificationConfig to be saved
     */
    private void saveNotifConfigPerson(Tokenizer token, NotificationConfigPerson notifConfigPerson,
            AllNotificationConfig allNotificationConfig) {

        if (Objects.nonNull(notifConfigPerson)) {

            if (!this.isCustomSettings(notifConfigPerson.getNotificationTextUID())) {
                notifConfigPerson.setEmailUID(allNotificationConfig.getEmailUID());
                notifConfigPerson.setInformationChannelUID(allNotificationConfig.getInformationChannelUID());
            }
            ;

        } else {
            notifConfigPerson = new NotificationConfigPerson(true, getInitialInfoChannelUID(token),
                    allNotificationConfig.getEmailUID(),
                    getTextUID(token, allNotificationConfig.getPersonUID(), BNSConstants.PERSON_TYPE_KEY),
                    allNotificationConfig.getPersonUID());
        }

        this.notifConfigPersonDAO.save(notifConfigPerson);

        LOGGER.info("<<= User [{}] saveNotifConfigPerson({},{}) request was successfully processed.", token.getUserId(),
                notifConfigPerson, allNotificationConfig);
    }

    /**
     * Get and save notif text.
     * 
     * @param participantNumberUID
     *            Long
     * @param type
     *            String
     * @return textUID
     */
    private Long getTextUID(Tokenizer token, Long veranlasungsUID, String type) {

        Long notifTextUID = null;
        NotificationText notifText = this.notificationTextDAO.getNotifText(environment.getProperty(type),
                veranlasungsUID);

        if (Objects.nonNull(notifText)) {
            notifTextUID = notifText.getNotificationTextUID();
        } else {
            notifTextUID = saveNotifText(token, veranlasungsUID, type);
        }

        LOGGER.info("<<= User [{}] getTextUID({},{}) request was successfully processed.", token.getUserId(),
                veranlasungsUID.toString(), type);

        return notifTextUID;
    }

    /**
     * Retrieves the value of Information Channel
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @return Long InfoChannelUID List of Information Channel
     */
    private Long getInitialInfoChannelUID(Tokenizer token) {

        List<InformationChannel> informationChannelList = this.informationChannelDAO.getInformationChannelList();
        Long infoChannelUID = null;

        for (InformationChannel informationChannel : informationChannelList) {

            if (informationChannel.getInformationChannelType()
                    .equalsIgnoreCase(this.environment.getProperty(BNSConstants.INFO_CHANNEL_KEY))) {
                infoChannelUID = informationChannel.getInformationChannelUID();
                break;
            }

        }

        LOGGER.info("<<= User [{}] getInitialInfoChannelUID() request was successfully processed.", token.getUserId());

        return infoChannelUID;
    }

    /**
     * Save notification text.
     * 
     * @param token
     *            Tokenizer used for identifying user
     * @param type
     *            String
     * @param Long
     *            veranlasungsUID to set
     * @return notificationUID
     */
    private Long saveNotifText(Tokenizer token, Long veranlasungsUID, String type) {

        NotificationText notifText = new NotificationText(BNSConstants.TEXT_TYPE_STD,
                this.environment.getProperty(type), veranlasungsUID, null);
        NotificationText savedNotificationText = this.notificationTextDAO.save(notifText);

        LOGGER.info("<<= User [{}] saveNotifText({},{}) request was successfully processed.", token.getUserId(),
                veranlasungsUID.toString(), type);

        return savedNotificationText.getNotificationTextUID();
    }

    /**
     * Determines if config is custom or standard.
     * 
     * @param Long
     *            notifTextUID
     * @return boolean
     */
    private boolean isCustomSettings(Long notifTextUID) {
        NotificationText notifText = this.notificationTextDAO.findOne(notifTextUID);

        return notifText.getNotificationTextType().equals(BNSConstants.TEXT_TYPE_FREE) ? true : false;
    }

}
