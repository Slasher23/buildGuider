package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;

/**
 * Service Class used to process request to enable and disable push configuration 
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.02
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.01       ZE2BUEN    Initial Version
 * 09/02/2018        1.02       ZE2MACL    Removed throws Exception
 * </pre>
 */

public interface PushConfigurationService {
	
	PushConfigurationResponse requestForPushConfiguration(PushConfigurationRequest request);
	
}
