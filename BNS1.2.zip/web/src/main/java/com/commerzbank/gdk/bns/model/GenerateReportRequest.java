package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Generate Report Request
 * 
 * @since 04/01/2018
 * @author ZE2BUEN
 * @version 1.00
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/01/2018        1.00       ZE2BUEN    Initial Version
 * </pre>
 */

@XmlRootElement
public class GenerateReportRequest {

    private String startDate;

    private String endDate;

    private String reportType;

    /**
     * Returns the value of Start Date
     * 
     * @return String Start Date
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of Start Date
     * 
     * @param startDate
     *            String Start Date to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * Returns the value of End Date
     * 
     * @return String End Date
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of End Date
     * 
     * @param endDate
     *            String End Date to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * Returns the value of Report Type
     * 
     * @return String Report Type
     */
    public String getReportType() {
        return reportType;
    }

    /**
     * Sets the value of Report Type
     * 
     * @param reportType
     *            String Report Type to set
     */
    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    /**
     * Returns the String representation of Generate Report Request Model
     * 
     * @return String String representation of Generate Report Request Model
     */
    @Override
    public String toString() {
        return "GenerateReportRequest [startDate=" + startDate + ", endDate=" + endDate + ", reportType=" + reportType
                + "]";
    }

}
