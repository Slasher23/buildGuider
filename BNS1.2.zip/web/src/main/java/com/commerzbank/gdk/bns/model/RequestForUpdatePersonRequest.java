package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for RequestForUpdatePersonRequest.
 * 
 * @since 27/11/2017
 * @author ZE2MENY
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 27/11/2017        1.00       ZE2MENY    Initial Version
 * 02/02/2018        1.01       ZE2MACL    Add regex and size for validation
 *          </pre>
 */
@XmlRootElement(name = "RequestForUpdatePersonRequest")
public class RequestForUpdatePersonRequest {
    
 
    private String bpkenn;
    
    @Size(max = 50)
    private String firstName;
   
    @Size(max = 50)
    private String lastName;
    
    /**
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }
    /**
     * @param bpkenn the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    /**
     * Returns the String representation of Request Model class.
     * RequestForUpdatePersonRequest
     * 
     * @return String String representation Request Model class
     *         RequestForUpdatePersonRequest
     */
    @Override
    public String toString() {
        return "RequestForUpdatePersonRequest [bpkenn=" + bpkenn + ", firstName=" + firstName + ", lastName=" + lastName
                + "]";
    } 
    
    
}
