package com.commerzbank.gdk.bns.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.RequestForBatchDeactivatePerson;
import com.commerzbank.gdk.bns.model.RequestForDeactivatePersonResponse;
import com.commerzbank.gdk.bns.model.ZslUpdateResponse;
import com.commerzbank.gdk.bns.service.RequestForDeactivatePersonService;
import com.commerzbank.gdk.bns.utils.RequiredFieldValidation;

/**
 * Service Implementation Class used to implement the business logic to
 * deactivate person.
 * 
 * @since 28/11/2017
 * @author ZE2GOME
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2GOME    Initial Version
 * 29/11/2017        1.01       ZE2GOME    Add method for batch request
 * 04/12/2017        1.02       ZE2GOME    Change response for batch request to RequestForDeactivatePersonResponse
 * 12/12/2017        1.03       ZE2BAUL    Clean up of request for Batch ZSL External Web Services
 * 14/12/2017        1.04       ZE2BUEN    Refactor/clean up of ZSL Status Messages
 * 06/02/2018        1.05       ZE2MACL    Remove throws Exception and add try catch
 * 21/02/2018        1.06       ZE2MACL    Added required field/s validation
 *          </pre>
 */
@Service
@Transactional
public class RequestForDeactivatePersonServiceImpl implements RequestForDeactivatePersonService {

    @Autowired
    private PersonDAO personDao;

    @Autowired
    private Environment environment;

    @Autowired
    private RequiredFieldValidation requiredFieldValidation;

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestForDeactivatePersonServiceImpl.class);

    private static final String STATUS_OK                          = "ZSL_STATUS_OK";
    private static final String STATUS_FA_INVALID_REQUEST          = "ZSL_STATUS_FA_INVALID_REQUEST";
    private static final String STATUS_FA_BPKENN_NOT_EXISTS        = "ZSL_STATUS_FA_BPKENN_NOT_EXISTS";
    private static final String STATUS_FA_FAILED_DEACTIVATE_PERSON = "ZSL_STATUS_FA_FAILED_DEACTIVATE_PERSON";
    private static final String EMPTY_STRING                       = "";

    /**
     * Removes all person related records from BNS and returns Deactivate Person
     * response
     * 
     * @param param Parameter Deactivate Person Request sent by ZSL.
     * @return ZslUpdateResponse Deactivate Person Response
     */
    @Override
    public ZslUpdateResponse requestForDeactivatePerson(Parameter param) {
        String status = EMPTY_STRING;

        final ZslUpdateResponse response = new ZslUpdateResponse();

        try {
            status = validateRequest(param);
            if (isNullOrEmpty(status)) {

                final Person person = this.personDao.findByBpkennIgnoreCase(param.getBpkenn());

                if (Objects.nonNull(person)) {
                    this.personDao.delete(person);

                    response.setBpkenn(param.getBpkenn());
                    response.setStatus(this.environment.getProperty(STATUS_OK));
                } else {
                    response.setBpkenn(param.getBpkenn());
                    response.setStatus(this.environment.getProperty(STATUS_FA_BPKENN_NOT_EXISTS));
                }

            } else {
                response.setBpkenn(param.getBpkenn());
                response.setStatus(status);

            }

        } catch (Exception e) {
            response.setStatus(this.environment.getProperty(STATUS_FA_FAILED_DEACTIVATE_PERSON));
            LOGGER.error(e.getMessage(), e);
        }

        return response;
    }

    /**
     * Method to validate request
     * 
     * @param param
     * @return String
     */
    private String validateRequest(Parameter param) {
        HashSet<String> invalidFields = new HashSet<String>();
        String inValidMsg;

        if (isNullOrEmpty(param.getBpkenn())) {
            invalidFields.add("bpkenn");
        }

        inValidMsg = requiredFieldValidation.requiredField(invalidFields);

        return inValidMsg;
    }

    /**
     * Method to check if string is null or empty.
     * 
     * @param stringToCheck String string to validate
     * @return boolean isNullOrEmpty
     */
    private boolean isNullOrEmpty(String stringToCheck) {

        return Objects.isNull(stringToCheck) || stringToCheck.isEmpty();
    }

    /**
     * Processes multiple requests to remove person related records from BNS and
     * returns Batch Deactivate Person response
     * 
     * @param param RequestForBatchDeactivatePerson Batch Deactivate Person
     *            Request sent by ZSL.
     * @return RequestForDeactivatePersonResponse Batch Deactivate Person
     *         Response
     */
    @Override
    public RequestForDeactivatePersonResponse requestFordeactivatePersonList(RequestForBatchDeactivatePerson param) {

        ZslUpdateResponse zslUpdateResponse = new ZslUpdateResponse();
        final RequestForDeactivatePersonResponse response = new RequestForDeactivatePersonResponse();
        final List<ZslUpdateResponse> zslUpdateResponseNoError = new ArrayList<ZslUpdateResponse>();
        final List<ZslUpdateResponse> zslUpdateResponseWithError = new ArrayList<ZslUpdateResponse>();

        for (Parameter parameter : param.getDeactivatePersonRequest()) {
            zslUpdateResponse = this.requestForDeactivatePerson(parameter);

            if (zslUpdateResponse.getStatus().equalsIgnoreCase(this.environment.getProperty(STATUS_OK))) {
                zslUpdateResponseNoError.add(zslUpdateResponse);
            } else {

                zslUpdateResponseWithError.add(zslUpdateResponse);
            }
        }

        response.setDeactivatePersonResponse(zslUpdateResponseNoError);
        response.setDeactivatePersonResponseWithErrors(zslUpdateResponseWithError);

        return response;
    }

}
