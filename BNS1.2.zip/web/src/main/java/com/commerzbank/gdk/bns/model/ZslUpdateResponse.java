package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for ZslUpdateResponse
 * 
 * @since 28/11/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/11/2017        1.00       ZE2GOME    Initial Version
 *          </pre>
 */
@XmlRootElement(name = "ZslUpdateResponse")
public class ZslUpdateResponse {

    private String bpkenn;
    
    private String status;

    /**
     * get bpkenn zsl response
     * 
     * @return the bpkenn
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * set bpkenn of zsl response
     * 
     * @param bpknn the bpkenn to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * get status of zsl response
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * set status of zsl response
     * 
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /* 
     * @return string
     */
    @Override
    public String toString() {
        return "ZslUpdateResponse [bpkenn=" + bpkenn + ", status=" + status + "]";
    }
    
}
