package com.commerzbank.gdk.bns.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Benachrichtigung Konfig Vereinbarung (Notification
 * Configuration Agreement) Table
 * 
 * @since 28/07/2017
 * @author ZE2BUEN
 * @version 1.03
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/07/2017        1.01       ZE2BUEN    Initial Version
 * 14/08/2017        1.02       ZE2BUEN    Modified data type of Active from int to boolean
 * 15/11/2017        1.03       ZE2SARO    Add constructor
 *          </pre>
 */

@XmlRootElement(name = "NotificationConfigAgreement")
@Entity
@Table(name = "BENACH_KONFIG_VEREINBARUNG")
public class NotificationConfigAgreement {

    @Id
    @Column(name = "BENACH_KONFIG_VEREINBARUNG_UID")
    @GeneratedValue(generator = "BENACH_KONFIG_VEREINBARUNG_ID_SEQ")
    @SequenceGenerator(name = "BENACH_KONFIG_VEREINBARUNG_ID_SEQ", sequenceName = "BENACH_KONFIG_VEREINBARUNG_SEQ")
    private Long notifConfigAgreementUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "VEREINBARUNG_UID")
    private Long agreementUID;

    @NotNull
    @Column(name = "AKTIV")
    private boolean active;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "INFORMATIONS_KANAL_UID")
    private Long informationChannelUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "EMAIL_UID")
    private Long emailUID;

    @NotNull
    @Max(value = 99999999999L)
    @Column(name = "BENACHRICHTIGUNGS_TEXT_UID")
    private Long notificationTextUID;

    /*
     * Constructor
     */
    public NotificationConfigAgreement() {

    }

    /**
     * Set all records
     * 
     * @param agreementUID
     * @param active
     * @param informationChannelUID
     * @param emailUID
     * @param notificationTextUID
     */
    public NotificationConfigAgreement(Long agreementUID, boolean active, Long informationChannelUID, Long emailUID,
            Long notificationTextUID) {

        this.setAgreementUID(agreementUID);
        this.setActive(active);
        this.setInformationChannelUID(informationChannelUID);
        this.setEmailUID(emailUID);
        this.setNotificationTextUID(notificationTextUID);
    }

    /**
     * Returns the value of Unique Identifier of Notification Configuration
     * Agreement Record
     * 
     * @return Long Unique Identifier of Notification Configuration Agreement
     *         Record
     */
    public Long getNotifConfigAgreementUID() {
        return notifConfigAgreementUID;
    }

    /**
     * Sets the value of Unique Identifier of Notification Configuration
     * Agreement Record
     * 
     * @param notifConfigAgreementUID Long Unique Identifier of Notification
     *            Configuration Agreement Record to set
     */
    public void setNotifConfigAgreementUID(Long notifConfigAgreementUID) {
        this.notifConfigAgreementUID = notifConfigAgreementUID;
    }

    /**
     * Returns the value of Unique Identifier of Agreement Record
     * 
     * @return Long Unique Identifier of Agreement Record
     */
    public Long getAgreementUID() {
        return agreementUID;
    }

    /**
     * Sets the value of Unique Identifier of Agreement Record
     * 
     * @param agreementUID Long Unique Identifier of Agreement Record to set
     */
    public void setAgreementUID(Long agreementUID) {
        this.agreementUID = agreementUID;
    }

    /**
     * Returns the value of Active Notification Configuration Flag
     * 
     * @return boolean Active Notification Configuration Flag
     */
    public boolean getActive() {
        return active;
    }

    /**
     * Sets the value of Active Notification Configuration Flag
     * 
     * @param active boolean Active Notification Configuration Flag to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Returns the value of Unique Identifier of Information Channel Record
     * 
     * @return Long Unique Identifier of Information Channel Record
     */
    public Long getInformationChannelUID() {
        return informationChannelUID;
    }

    /**
     * Sets the value of Unique Identifier of Information Channel Record
     * 
     * @param informationChannelUID Long Unique Identifier of Information
     *            Channel Record to set
     */
    public void setInformationChannelUID(Long informationChannelUID) {
        this.informationChannelUID = informationChannelUID;
    }

    /**
     * Returns the value of Unique Identifier of Email Record
     * 
     * @return Long Unique Identifier of Email Record
     */
    public Long getEmailUID() {
        return emailUID;
    }

    /**
     * Sets the value of Unique Identifier of Email Record
     * 
     * @param emailUID Long Unique Identifier of Email Record to set
     */
    public void setEmailUID(Long emailUID) {
        this.emailUID = emailUID;
    }

    /**
     * Returns the value of Unique Identifier of Notification Text Record
     * 
     * @return Long Unique Identifier of Notification Text Record
     */
    public Long getNotificationTextUID() {
        return notificationTextUID;
    }

    /**
     * Sets the value of Unique Identifier of Notification Text Record
     * 
     * @param notificationTextUID Long Unique Identifier of Notification Text
     *            Record to set
     */
    public void setNotificationTextUID(Long notificationTextUID) {
        this.notificationTextUID = notificationTextUID;
    }

    /**
     * Returns the String representation of Notification Configuration Agreement
     * Model
     * 
     * @return String String representation of Notification Configuration
     *         Agreement Model
     */
    @Override
    public String toString() {
        return "NotificationConfigAgreement [notifConfigAgreementUID= " + notifConfigAgreementUID + " , agreementUID= "
                + agreementUID + " , active= " + active + " , informationChannelUID= " + informationChannelUID
                + " , emailUID= " + emailUID + " , notificationTextUID= " + notificationTextUID + "]";
    }

}
