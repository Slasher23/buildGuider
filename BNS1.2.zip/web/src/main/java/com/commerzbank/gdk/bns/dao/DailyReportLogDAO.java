package com.commerzbank.gdk.bns.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.DailyReportLog;

/**
 * Report DAO Interface
 * 
 * @since 04/01/2018
 * @author ZE2RUBI
 * @version 1.01
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 04/01/2018		1.00		ZE2RUBI 	Initial Version
 * 11/01/2018		1.01		ZE2FUEN 	Added findBy eventType and between timestamp method
 * 25/01/2018       1.02        ZE2RUBI     Added deleteBy timestamp method
 * </pre>
 */

public interface DailyReportLogDAO extends PagingAndSortingRepository<DailyReportLog, Long>, DailyReportLogCustomDAO {
	
	List<DailyReportLog> findByEventTypeInAndTimestampGreaterThanEqualAndTimestampLessThan(List<String> eventTypeList, Date startDate, Date endDate);

    void deleteByTimestampLessThan(Date paramDate);


}
