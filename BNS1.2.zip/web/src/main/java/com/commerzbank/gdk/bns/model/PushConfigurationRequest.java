package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Request for Push Configuration
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.01
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.00       ZE2BUEN    Initial Version
 * 11/23/2017        1.01       ZE2SARO    Remove Participant number
 *          </pre>
 */

@XmlRootElement
public class PushConfigurationRequest {

    @NotNull
    @Size(max = 16)
    private String bpkenn;

    @NotNull
    private String deviceId;

    @NotNull
    private String appId;

    @NotNull
    private String appName;

    @NotNull
    private String appVersion;

    @NotNull
    private Boolean activate;

    /**
     * Returns the value of BPKENN
     * 
     * @return String BPKENN
     */
    public String getBpkenn() {
        return bpkenn;
    }

    /**
     * Sets the value of BPKENN
     * 
     * @param bpkenn String BPKENN to set
     */
    public void setBpkenn(String bpkenn) {
        this.bpkenn = bpkenn;
    }

    /**
     * Returns the value of Device ID
     * 
     * @return String Device ID
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * Sets the value of Device ID
     * 
     * @param deviceId String Device ID to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * Returns the value of App ID
     * 
     * @return String App ID
     */
    public String getAppId() {
        return appId;
    }

    /**
     * Sets the value of App ID
     * 
     * @param appId String App ID to set
     */
    public void setAppId(String appId) {
        this.appId = appId;
    }

    /**
     * Returns the value of App Name
     * 
     * @return String App Name
     */
    public String getAppName() {
        return appName;
    }

    /**
     * Sets the value of App Name
     * 
     * @param appName String App Name to set
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * Returns the value of App Version
     * 
     * @return String App Version
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * Sets the value of App Version
     * 
     * @param appVersion String App Version to set
     */
    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * Returns the value of Activate
     * 
     * @return Boolean Activate
     */
    public Boolean getActivate() {
        return activate;
    }

    /**
     * Sets the value of Activate
     * 
     * @param activate Boolean Activate to set
     */
    public void setActivate(Boolean activate) {
        this.activate = activate;
    }

    /**
     * Returns the String representation of Push Configuration Request Model
     * 
     * @return String String representation of Push Configuration Request Model
     * 
     */
    @Override
    public String toString() {
        return "PushConfigurationRequest [bpkenn=" + bpkenn + ", deviceId=" + deviceId + ", appId=" + appId
                + ", appName=" + appName + ", appVersion=" + appVersion + ", activate=" + activate + "]";
    }

}
