package com.commerzbank.gdk.bns.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.commerzbank.gdk.bns.dao.NotificationTextCustomDAO;
import com.commerzbank.gdk.bns.model.NotificationText;

/**
 * DAO Implementation Class to get the Notification Text List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.01
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 27/09/2017		1.01		ZE2SARO 	Relationship of agreement and notif text is 1:1
 *          </pre>
 */
@Repository
public class NotificationTextDAOImpl implements NotificationTextCustomDAO {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * Retrieves the Notification Text record using a given Identifier and type
     * of Event record
     * 
     * @param eventType string Type and eventID Long Identifier of Event Record
     *            to set
     * @return Notification Text
     */
    @Override
    public NotificationText getNotifText(String eventType, Long eventId) {

        NotificationText notifText = null;
        TypedQuery<NotificationText> query = this.entityManager.createQuery("FROM NotificationText WHERE eventType = '"
                + eventType + "' AND eventID = " + eventId + " ORDER BY notificationTextType DESC",
                NotificationText.class);
        if (query.getResultList().size() != 0)
            notifText = query.setMaxResults(1).getSingleResult();

        return notifText;
    }

}
