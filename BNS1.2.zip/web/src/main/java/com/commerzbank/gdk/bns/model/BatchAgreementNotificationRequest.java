package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for Request for Batch Agreement Notification Request.
 * 
 * @since 22/12/2017
 * @author ZE2JAVO
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 22/12/2017        1.00       ZE2JAVO    Initial Version
 *          </pre>
 */
public class BatchAgreementNotificationRequest {

	private List<AgreementNotificationRequest> agreementNotificationRequest;

	/**
	 * @return the agreementNotificationRequest
	 */
	public List<AgreementNotificationRequest> getAgreementNotificationRequest() {
		return agreementNotificationRequest;
	}

	/**
	 * @param agreementNotificationRequest the agreementNotificationRequest to set
	 */
	public void setAgreementNotificationRequest(List<AgreementNotificationRequest> agreementNotificationRequest) {
		this.agreementNotificationRequest = agreementNotificationRequest;
	}

}
