package com.commerzbank.gdk.bns.controller.zsl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.commerzbank.gdk.bns.model.PushConfigurationRequest;
import com.commerzbank.gdk.bns.model.PushConfigurationResponse;
import com.commerzbank.gdk.bns.service.PushConfigurationService;

/**
 * Push Configuration Controller - Accept push configuration request to
 * create/update push configuration record and return the status response to
 * ZSL.
 * 
 * @since 26/10/2017
 * @author ZE2BUEN
 * @version 1.06
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 26/10/2017        1.01       ZE2BUEN    Initial Version
 * 03/11/2017	  	 1.02		ZE2BAUL	   Added implementation for ProcessRunID requirement
 * 07/12/2017        1.03       ZE2SARO    Add Validation
 * 13/12/2017        1.04       ZE2BUEN    Clean up for ZSL logging
 * 05/02/2018        1.05       ZE2FUEN    Removed ProcessRunID in log message
 * 09/02/2018        1.06       ZE2MACL    Removed throws Exception
 *          </pre>
 */

@RestController
public class PushConfigurationController {

    @Autowired
    private PushConfigurationService pushConfigurationService;

    private static final Logger LOGGER = LoggerFactory.getLogger(PushConfigurationController.class);

    /**
     * Accept client push configuration request then call service to
     * create/update push configuration record and return the status response to
     * ZSL then return also produces xml or json format.
     * 
     * @param pushConfigurationRequest
     *            PushConfigurationRequest Push Configuration Request
     * @param request
     * @return ResponseEntity Push Configuration Response
     */
    @PostMapping(value = "/api/zsl/requestForPushConfiguration")
    public ResponseEntity<PushConfigurationResponse> requestForPushConfiguration(
            @Valid @RequestBody PushConfigurationRequest pushConfigurationRequest, HttpServletRequest request,
            BindingResult result) {

        LOGGER.info("=>> System [{}] - requestForPushConfiguration({})", "ZSL", pushConfigurationRequest.toString());

        PushConfigurationResponse pushResponse = new PushConfigurationResponse();

        if (!result.hasErrors()) {
            pushResponse = this.pushConfigurationService.requestForPushConfiguration(pushConfigurationRequest);

            if (Objects.isNull(pushResponse)) {
                pushResponse = new PushConfigurationResponse();
            }

        }

        ResponseEntity<PushConfigurationResponse> response = new ResponseEntity<PushConfigurationResponse>(pushResponse,
                HttpStatus.OK);

        LOGGER.info("<<= System [{}] response [{}]", "ZSL", pushResponse.toString());

        return response;
    }
}
