package com.commerzbank.gdk.bns.dao;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.commerzbank.gdk.bns.model.NotificationConfigAgreement;

/**
 * Notification Configuration Agreement DAO Interface
 * 
 * @since 28/07/2017
 * @author ZE2SARO
 * @version 1.04
 * 
 * <pre>
 * Modified Date	Version		Author		Description
 * 28/07/2017		1.00        ZE2BUEN     Initial Version
 * 25/09/2017		1.01        ZE2SARO     Change interface to extends
 * 09/11/2017		1.02        ZE2BUEN     Added findByEmailUID method
 * 14/11/2017       1.03        ZE2SARO     Add new method for getting agreement config
 * 05/01/2018       1.04        ZE2BUEN     Added query method findByActiveAndAgreementUIDIn
 * </pre>
 */

public interface NotificationConfigAgreementDAO
        extends PagingAndSortingRepository<NotificationConfigAgreement, Long>, NotificationConfigAgreementCustomDAO {

    List<NotificationConfigAgreement> findByAgreementUIDIn(List<Long> listAgreementUID);

    List<NotificationConfigAgreement> findByEmailUID(Long emailUID);

    NotificationConfigAgreement findByAgreementUID(Long agreementUID);

    List<NotificationConfigAgreement> findByActiveAndAgreementUIDIn(Boolean active, List<Long> listAgreementUID);

}
