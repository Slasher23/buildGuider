package com.commerzbank.gdk.bns.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for BNS Internal Request
 * 
 * @since 28/02/2018
 * @author ZE2FUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 28/02/2018        1.00       ZE2FUEN    Initial Version
 *          </pre>
 * 
 */

@XmlRootElement
public class BNSInternal<T> {

    private String bnsToken;

    private T request;

    /**
     * 
     * Constructor BNSInternal
     *
     * @param request
     *            for Build
     * @return BNSInternalRequest
     */
    public BNSInternal<T> build(T request) {
        this.setRequest(request);
        return this;
    }

    /**
     * Returns the value of bnsToken
     * 
     * @return String bnsToken
     */
    public String getBnsToken() {
        return bnsToken;
    }

    /**
     * Sets the value of bnsToken
     * 
     * @param bnsToken
     *            String bnsToken to set
     */
    public void setBnsToken(String bnsToken) {
        this.bnsToken = bnsToken;
    }

    /**
     * Returns the value of request object
     * 
     * @return T request object
     */
    public T getRequest() {
        return request;
    }

    /**
     * Sets the value of request object
     * 
     * @param request
     *            T request object to set
     */
    public void setRequest(T request) {
        this.request = request;
    }

    /**
     * Returns the String representation of BNSInternal Model
     * 
     * @return String String representation of BNSInternal Model
     */
    @Override
    public String toString() {
        return "BNSInternal [bnsToken=" + bnsToken + ", request=" + request + "]";
    }

}
