package com.commerzbank.gdk.bns.model;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Request Model Class for RequestForRequiredNotification
 * 
 * @since 20/09/2017
 * @author ZE2FUEN
 * @version 1.02
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 20/09/2017        1.00       ZE2FUEN    Initial Version
 * 10/11/2017        1.01       ZE2BAUL    Renamed the class to adhere to the requirements
 * 07/12/2017        1.02       ZE2CRUH    Updated RequiredNotification to include UUID
 *          </pre>
 */
@XmlRootElement(name="RequiredNotificationRequest")
public class RequiredNotificationRequest {

	private String bpkenn;

	private String notificationtype;

	private String notificationpath;

	private String notificationtext;

	private String notificationsubject;
	
	private String uuid;

	/**
	 * Returns the value of bpkenn
	 * 
	 * @return String bpkenn
	 */
	public String getBpkenn() {
		return bpkenn;
	}

	/**
	 * Sets the value of bpkenn
	 * 
	 * @param String
	 *            bpkenn
	 */
	public void setBpkenn(String bpkenn) {
		this.bpkenn = bpkenn;
	}

	/**
	 * Returns the value of notificationtype
	 * 
	 * @return String notificationtype
	 */
	public String getNotificationtype() {
		return notificationtype;
	}

	/**
	 * Sets the value of notificationtype
	 * 
	 * @param String
	 *            notificationtype
	 */
	public void setNotificationtype(String notificationtype) {
		this.notificationtype = notificationtype;
	}

	/**
	 * Returns the value of notificationpath
	 * 
	 * @return String notificationpath
	 */
	public String getNotificationpath() {
		return notificationpath;
	}

	/**
	 * Sets the value of notificationpath
	 * 
	 * @param String
	 *            notificationpath
	 */
	public void setNotificationpath(String notificationpath) {
		this.notificationpath = notificationpath;
	}

	/**
	 * Returns the value of notificationtext
	 * 
	 * @return String notificationtext
	 */
	public String getNotificationtext() {
		return notificationtext;
	}

	/**
	 * Sets the value of notificationtext
	 * 
	 * @param String
	 *            notificationtext
	 */
	public void setNotificationtext(String notificationtext) {
		this.notificationtext = notificationtext;
	}

	/**
	 * Returns the value of notificationsubject
	 * 
	 * @return String notificationsubject
	 */
	public String getNotificationsubject() {
		return notificationsubject;
	}

	/**
	 * Sets the value of notificationsubject
	 * 
	 * @param String
	 *            notificationsubject
	 */
	public void setNotificationsubject(String notificationsubject) {
		this.notificationsubject = notificationsubject;
	}

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * Returns the String representation of Request Model class
	 * RequiredNotificationRequest
	 * 
	 * @return String String representation Request Model class
	 *         RequiredNotificationRequest
	 */
	@Override
	public String toString() {
		return "RequiredNotificationRequest [bpkenn=" + bpkenn + ", notificationtype=" + notificationtype
				+ ", notificationpath=" + notificationpath + ", notificationtext=" + notificationtext
				+ ", notificationsubject=" + notificationsubject + ", uuid=" + uuid + "]";
	}

}
