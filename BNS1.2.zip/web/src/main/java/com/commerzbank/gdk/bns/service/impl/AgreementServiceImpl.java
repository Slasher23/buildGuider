package com.commerzbank.gdk.bns.service.impl;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.commerzbank.gdk.bns.dao.AgreementDAO;
import com.commerzbank.gdk.bns.dao.PersonDAO;
import com.commerzbank.gdk.bns.model.Agreement;
import com.commerzbank.gdk.bns.model.GlobalResponseWrapper;
import com.commerzbank.gdk.bns.model.Parameter;
import com.commerzbank.gdk.bns.model.Person;
import com.commerzbank.gdk.bns.model.Response;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
import com.commerzbank.gdk.bns.service.AgreementService;

/**
 * Service Implementation Class used to implement the business logic in getting
 * the Agreement List
 * 
 * @since 08/08/2017
 * @author ZE2SARO
 * @version 1.06
 * 
 *          <pre>
 * Modified Date	Version		Author		Description
 * 08/08/2017		1.00		ZE2SARO 	InitialVersion
 * 14/09/2017       1.01        ZE2SARO     Get agreement using participant UID
 * 22/09/2017       1.02        ZE2SARO     get agreement using participant number
 * 14/11/2017       1.03        ZE2MACL     Updated method to used response builder and added token parameter
 * 23/11/2017       1.04        ZE2MACL     Removed ParticipantDao
 * 24/11/2017       1.05        ZE2MORA     Implemented Status Codes
 * 09/02/2018       1.06        ZE2MACL    Removed throws Exception
 *          </pre>
 */
@Service
@Transactional
public class AgreementServiceImpl implements AgreementService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AgreementServiceImpl.class);

    @Autowired
    private AgreementDAO agreementDAO;
    
    @Autowired
    private GlobalResponseWrapper globalResponseWrapper;

    private PersonDAO personDAO;

    /**
     * Retrieves the List of Agreement records using a given bpkenn
     * 
     * @param token to identify the user
     * @param parameter Parameter to set
     * @return List List of Agreement
     */

    @Override
    public ResponseBuilder<List<Agreement>> getAgreementList(Tokenizer token, Parameter parameter) {

        ResponseBuilder<List<Agreement>> builder = new ResponseBuilder<List<Agreement>>(LOGGER, token, globalResponseWrapper);
        Person person;

        try {
           
            person = this.personDAO.findByBpkennIgnoreCase(parameter.getBpkenn());
            
            List<Agreement> agreementList = Lists.newArrayList(this.agreementDAO.getAgreementList(person.getPersonUID()));

            if (Objects.nonNull(agreementList)) {
                builder.OK(agreementList);
            } else {
                builder.OK(agreementList, Response.SUCCESS_NO_RESULTS_FOUND);
            }

        } catch (DataAccessException e) {
            builder.notOK(Response.DATA_ACCESS_EXCEPTION, e);
        } catch (NullPointerException e) {
            builder.notOK(Response.NULL_POINTER_EXCEPTION, e);
        } catch (Exception e) {
        	builder.notOK(Response.GENERAL_FUNCTION_ERROR, e);
        }

        LOGGER.info("<<= User [{}] getAgreementList({}) request was successfully processed.", token.getUserId(),
                parameter.getBpkenn());

        return builder;
    }

}
