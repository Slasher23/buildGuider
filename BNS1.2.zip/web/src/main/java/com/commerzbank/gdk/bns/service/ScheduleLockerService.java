package com.commerzbank.gdk.bns.service;

/**
 * Service Class used to access the ScheduleLocker
 * 
 * @since 15/02/2018
 * @author ZE2RUBI
 * @version 1.05
 * 
 *          <pre>
 * Modified Date    Version     Author      Description
 * 15/02/2018       1.00        ZE2RUBI     Initial Version
 *          </pre>
 */
public interface ScheduleLockerService {
        
	boolean isNodeActive();

}
