package com.commerzbank.gdk.bns.model;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for BNSCif
 * 
 * @since 12/02/2017
 * @author ZE2FUEN
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/02/2017        1.00       ZE2FUEN    Initial Version
 *          </pre>
 */

@XmlRootElement
public class BNSCif {

    private String bnsToken;
    
    private Person person;
    
    private Map<String, String> translatedTexts;
    
    private MainAgreementTypeWrapper agreementList;
    
    private boolean hasEmail;

    private boolean hasError;

    /**
     * Returns the value of bnsToken
     * 
     * @return String bnsToken
     */
    public String getBnsToken() {
        return bnsToken;
    }

    /**
     * Sets the value of bnsToken
     * 
     * @param bnsToken
     *            String bnsToken to set
     */
    public void setBnsToken(String bnsToken) {
        this.bnsToken = bnsToken;
    }
    
    /**
     * Returns the value of person
     * 
     * @return Person person
     */
    public Person getPerson() {
        return person;
    }

    /**
     * Sets the value of person
     * 
     * @param person
     *            Person person to set
     */
    public void setPerson(Person person) {
        this.person = person;
    }
    
    /**
     * Returns the value of translatedTexts
     * 
     * @return Map<String, String> translatedTexts
     */
    public Map<String, String> getTranslatedTexts() {
        return translatedTexts;
    }
    
    /**
     * Sets the value of translatedTexts
     * 
     * @param translatedTexts
     *            Map<String, String> translatedTexts to set
     */
    public void setTranslatedTexts(Map<String, String> translatedTexts) {
        this.translatedTexts = translatedTexts;
    }
    
    /**
     * Returns the value of agreementList
     * 
     * @return MainAgreementTypeWrapper agreementList
     */
    public MainAgreementTypeWrapper getAgreementList() {
        return agreementList;
    }

    /**
     * Sets the value of agreementList
     * 
     * @param agreementList
     *            MainAgreementTypeWrapper agreementList to set
     */
    public void setAgreementList(MainAgreementTypeWrapper agreementList) {
        this.agreementList = agreementList;
    }

    /**
     * Sets the value of hasEmail
     * 
     * @param hasEmail
     *            boolean hasEmail to set
     */
    public void setHasEmail(boolean hasEmail) {
        this.hasEmail = hasEmail;
    }
    
    /**
     * Returns the value of hasEmail
     * 
     * @return boolean hasEmail
     */
    public boolean getHasEmail() {
        return hasEmail;
    }

    /**
     * Sets the value of hasError
     * 
     * @param hasError
     *            boolean hasError to set
     */
    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    /**
     * Returns the value of hasError
     * 
     * @return boolean hasError
     */
    public boolean getHasError() {
        return hasError;
    }

    @Override
    public String toString() {
        return "BNSCif [bnsToken=" + bnsToken + ", person=" + person + ", agreementList=" + agreementList
                + ", hasEmail=" + hasEmail + ", hasError=" + hasError + "]";
    }



}
