package com.commerzbank.gdk.bns.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Model Class for Batch ZSL Update Response
 * 
 * @since 04/12/2017
 * @author ZE2GOME
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description 
 * 04/12/2017        1.00       ZE2MACL    Initial Version
 *          </pre>
 */
@XmlRootElement
public class BatchUpdateSalutationResponse {

    List<ZslUpdateResponse> updateSalutationResponse;

    List<ZslUpdateResponse> updateSalutationResponseWithErrors;

    /**
     * Get list of ZSL update response without error.
     * 
     * @return the updateSalutationResponse
     */
    public List<ZslUpdateResponse> getUpdateSalutationResponse() {
        return updateSalutationResponse;
    }

    /**
     * Set list of ZSL update response without error.
     * 
     * @param updateSalutationResponse the updateSalutationResponse to set
     */
    public void setUpdateSalutationResponse(List<ZslUpdateResponse> updateSalutationResponse) {
        this.updateSalutationResponse = updateSalutationResponse;
    }

    /**
     * Get list of ZSL update response without error.
     * 
     * @return the updateSalutationResponseWithErrors
     */
    public List<ZslUpdateResponse> getUpdateSalutationResponseWithErrors() {
        return updateSalutationResponseWithErrors;
    }

    /**
     * Set list of ZSL update response without error.
     * 
     * @param updateSalutationResponseWithErrors the
     *            updateSalutationResponseWithErrors to set
     */
    public void setUpdateSalutationResponseWithErrors(List<ZslUpdateResponse> updateSalutationResponseWithErrors) {
        this.updateSalutationResponseWithErrors = updateSalutationResponseWithErrors;
    }
    
    /**
     * Returns the String representation of BatchUpdateSalutationResponse Model
     * 
     * @return String String representation of BatchUpdateSalutationResponse Model
     */
    @Override
    public String toString() {
        return "BatchUpdateSalutationResponse [updateSalutationResponse=" + updateSalutationResponse
                + ", updateSalutationResponseWithErrors=" + updateSalutationResponseWithErrors + "]";
    }

}
