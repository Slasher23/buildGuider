package com.commerzbank.gdk.bns.service;

import com.commerzbank.gdk.bns.model.AuditLog;
import com.commerzbank.gdk.bns.model.ResponseBuilder;
import com.commerzbank.gdk.bns.model.Tokenizer;
/**
 * Interface used to access logging events service
 * 
 * @author ZE2RUBI
 * @version 1.01
 * @since 04/08/2017
 * 
 * <pre>
 * Modified Date     Version    Author     Description
 * 04/08/2017        1.01       ZE2RUBI   Initial Version
 * 10/04/2017        1.02       ZE2MACK   Remove unneeded interface method
 * 09/11/2017        1.03       ZE2MACL   Update method to used Response Builder
 * </pre>
 */
public interface AuditLogService {
	
	ResponseBuilder<AuditLog> save(Tokenizer token, AuditLog auditLog);
	
	
}
