package com.commerzbank.gdk.bns.model;

import java.util.List;

/**
 * Model Class for Request for Batch Person Exists.
 * 
 * @since 12/12/2017
 * @author ZE2MENY
 * @version 1.00
 * 
 *          <pre>
 * Modified Date     Version    Author     Description
 * 12/12/2017        1.00       ZE2MENY    Initial Version
 *          </pre>
 */
public class BatchPersonExistsRequest {

    private List<PersonExistsRequest> personExistsRequest;

    /**
     * Returns the List of Person Exists Request.
     * 
     * @return List List of Person Exists Request
     */

    public List<PersonExistsRequest> getPersonExistsRequest() {
        return personExistsRequest;
    }

    /**
     * Sets the List of Person Exists Request.
     * 
     * @param cpersonExistsRequest String List of Person Exists Request to set
     */
    public void setPersonExistsRequest(List<PersonExistsRequest> personExistsRequest) {
        this.personExistsRequest = personExistsRequest;
    }

    /**
     * Returns the String representation of Person Exists Batch Request Model.
     * 
     * @return String String representation of Person Exists Batch Request Model
     */
    @Override
    public String toString() {
        return "BatchPersonExists [personExistsRequest=" + personExistsRequest + "]";
    }

}
